#!/bin/sh

echo "====================================="
echo "Installing Matrix Toolkit v1.7"
echo "====================================="

mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/cgi-bin
mkdir -p /usr/local/matrix/web/admin

# Toolkit pagina

cp -f /usr/local/mnt/sda1/MatrixInstall/web/index.html /usr/local/matrix/web/index.html

# Admin pagina

cp -f /usr/local/mnt/sda1/MatrixInstall/web_admin/index.html /usr/local/matrix/web/admin/index.html

# Toolkit scripts

cp -f /usr/local/mnt/sda1/MatrixInstall/cgi-bin/*.sh /usr/local/matrix/web/cgi-bin/

# Admin scripts

cp -f /usr/local/mnt/sda1/MatrixInstall/cgi-bin_admin/*.sh /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

# Oude webserver stoppen

killall uhttpd 2>/dev/null

sleep 2

# Toolkit starten

uhttpd -h /usr/local/matrix/web -p 8080 -x /cgi-bin -i .sh=/bin/sh &

echo ""
echo "====================================="
echo "Matrix Toolkit v1.7 Installed"
echo ""
echo "Toolkit : http://192.168.1.1:8080"
echo "Admin   : http://192.168.1.1:8080/admin/"
echo "====================================="
