#!/bin/sh

echo "====================================="
echo "Installing Matrix Toolkit v1.1"
echo "====================================="

# Matrix Toolkit

mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/cgi-bin

cp -rf /usr/local/mnt/sda1/MatrixInstall/web/* /usr/local/matrix/web/
cp -rf /usr/local/mnt/sda1/MatrixInstall/cgi-bin/* /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh 2>/dev/null

# Matrix Admin

mkdir -p /usr/local/matrix_admin/web
mkdir -p /usr/local/matrix_admin/web/cgi-bin

cp -rf /usr/local/mnt/sda1/MatrixInstall/web_admin/* /usr/local/matrix_admin/web/
cp -rf /usr/local/mnt/sda1/MatrixInstall/cgi-bin_admin/* /usr/local/matrix_admin/web/cgi-bin/

chmod +x /usr/local/matrix_admin/web/cgi-bin/*.sh 2>/dev/null

# Startup

cat > /etc/rc.local << 'EOF'
#!/bin/sh

sleep 20

uhttpd -h /usr/local/matrix/web -p 8080 -x /cgi-bin -i .sh=/bin/sh &

uhttpd -h /usr/local/matrix_admin/web -p 8081 -x /cgi-bin -i .sh=/bin/sh &

exit 0
EOF

chmod +x /etc/rc.local

# Oude Matrix webservers stoppen

killall uhttpd 2>/dev/null

sleep 3

# Toolkit starten

uhttpd -h /usr/local/matrix/web -p 8080 -x /cgi-bin -i .sh=/bin/sh &

# Admin starten

uhttpd -h /usr/local/matrix_admin/web -p 8081 -x /cgi-bin -i .sh=/bin/sh &

echo ""
echo "====================================="
echo "Matrix Toolkit v1.1 Installed"
echo ""
echo "Toolkit : http://192.168.1.1:8080"
echo "Admin   : http://192.168.1.1:8081"
echo "====================================="
