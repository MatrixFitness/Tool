#!/bin/sh

# Always run from the script directory
cd "$(dirname "$0")"

echo ""
echo "====================================="
echo "Installing Matrix Toolkit"
echo "====================================="
echo ""

# Create folders
mkdir -p /usr/local/matrix
mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/admin
mkdir -p /usr/local/matrix/web/cgi-bin

# Install web files
cp -f web/index.html \
      /usr/local/matrix/web/index.html

cp -f web_admin/index.html \
      /usr/local/matrix/web/admin/index.html

# Install CGI scripts
cp -f cgi-bin/*.sh \
      /usr/local/matrix/web/cgi-bin/

cp -f cgi-bin_admin/*.sh \
      /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

# Install version file if present
if [ -f version.txt ]
then
    cp -f version.txt /usr/local/matrix/version.txt
fi

# Stop existing Matrix webserver
killall uhttpd 2>/dev/null

sleep 1

# Start Matrix webserver
uhttpd \
-h /usr/local/matrix/web \
-p 8080 \
-x /cgi-bin \
-i .sh=/bin/sh &

sleep 1

# Read version
if [ -f /usr/local/matrix/version.txt ]
then
    VERSION=$(grep "^Version=" /usr/local/matrix/version.txt | cut -d= -f2)

    if [ -z "$VERSION" ]
    then
        VERSION=$(cat /usr/local/matrix/version.txt)
    fi
else
    VERSION="Unknown"
fi

echo ""
echo "====================================="
echo "Matrix Toolkit Installed"
echo ""
echo "Version : $VERSION"
echo "Toolkit : http://192.168.1.1:8080"
echo "Admin   : http://192.168.1.1:8080/admin/"
echo "====================================="
echo ""