#!/bin/sh

echo "Content-Type: text/html"
echo ""

echo "<html><head><title>Matrix Full Test</title></head><body>"
echo "<h1>Matrix Full Connectiviteit Test</h1>"

echo "<table border='1' cellpadding='5'>"
echo "<tr><th>Host</th><th>Status</th></tr>"

for HOST in \
dapi.jfit.co \
orion.jfit.co \
mwtn.jfit.co \
pt-client.jfit.co \
facilitycalendar.jfit.co \
frontend-config.jfit.co \
config.jhtassets.com \
images.jhtassets.com \
location-ip.jfit.co \
am4.matrixfitness.com \
am4-api.jfit.co \
console-event-service.jfit.co \
console-event-service-prod.jfit.co \
console-event-service-staging.jfit.co \
console-settings-store.jfit.co \
dev-console-settings-store.jfit.co \
dev-orion.jfit.co \
qa-orion.jfit.co \
staging-orion.jfit.co \
staging-mwtn.jfit.co \
staging-pt-client.jfit.co \
staging-facilitycalendar.jfit.co \
staging-weather-console.jfit.co \
youtube.jfit.co \
myfitnesspal.jfit.co \
www-myfitnesspal-console.jfit.co \
www-weather-console.jfit.co
do

if nslookup "$HOST" >/dev/null 2>&1
then
    echo "<tr><td>$HOST</td><td><font color='green'>PASS</font></td></tr>"
else
    echo "<tr><td>$HOST</td><td><font color='red'>FAIL</font></td></tr>"
fi

done

echo "</table>"

echo "<hr>"
echo "<p>Matrix Full Test voltooid.</p>"

echo "</body></html>"