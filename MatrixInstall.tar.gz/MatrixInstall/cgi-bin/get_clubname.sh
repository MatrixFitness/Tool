#!/bin/sh

echo "Content-Type: text/plain"
echo ""

cat /usr/local/mnt/sda1/MatrixInstall/clubname.txt 2>/dev/null