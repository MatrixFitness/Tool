#!/bin/sh

echo "Content-Type: text/plain"
echo ""

if [ -f /usr/local/matrix/clubname.txt ]
then
    cat /usr/local/matrix/clubname.txt
else
    echo "Unknown Club"
fi