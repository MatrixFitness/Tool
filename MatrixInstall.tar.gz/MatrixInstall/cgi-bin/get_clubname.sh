#!/bin/sh

echo "Content-Type: text/plain"
echo ""

cat /usr/local/mnt/sda1/Backup/clubname.txt 2>/dev/null