#!/bin/sh

echo "Content-Type: text/plain"
echo ""

FILE=/usr/local/matrix/admin_password.txt

if [ -f "$FILE" ]
then
    cat "$FILE"
else
    echo "MatrixFitness2026"
fi