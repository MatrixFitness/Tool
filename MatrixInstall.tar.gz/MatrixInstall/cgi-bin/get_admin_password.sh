root@JNLMatrix:~# chmod +x /usr/local/matrix/web/cgi-bin/get_admin_password.sh
root@JNLMatrix:~# curl http://127.0.0.1:8080/cgi-bin/get_admin_password.sh
root@JNLMatrix:~# cat -n /usr/local/matrix/web/cgi-bin/get_admin_password.sh
cat: unrecognized option: n
BusyBox v1.34.1 (2026-05-27 07:59:57 UTC) multi-call binary.

Usage: cat [FILE]...

Print FILEs to stdout

root@JNLMatrix:~# cat /usr/local/mnt/sda1/MatrixInstall/admin_password.txt
cat: can't open '/usr/local/mnt/sda1/MatrixInstall/admin_password.txt': No such file or directory
root@JNLMatrix:~# 