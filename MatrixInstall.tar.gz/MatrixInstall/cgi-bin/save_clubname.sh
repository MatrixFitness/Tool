#!/bin/sh

echo "Content-Type: text/plain"
echo ""

CLUBNAME=$(echo "$QUERY_STRING" | sed 's/^club=//' | sed 's/%20/ /g')

echo "$CLUBNAME" > /usr/local/mnt/sda1/Backup/clubname.txt

echo "OK"