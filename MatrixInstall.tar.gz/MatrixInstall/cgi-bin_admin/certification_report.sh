#!/bin/sh

echo "Content-Type: text/html"
echo ""

WANSTATUS="FAIL"
INTERNETSTATUS="FAIL"
MATRIXSTATUS="FAIL"

ping -c 1 8.8.8.8 >/dev/null 2>&1 && WANSTATUS="PASS"

curl -s https://www.google.com >/dev/null 2>&1 && INTERNETSTATUS="PASS"

curl -s https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIXSTATUS="PASS"

STATUS=$(ubus call network.interface.wan status)

WANIP=$(echo "$STATUS" | grep '"address"' | head -1 | cut -d'"' -f4)

LANIP=$(ip addr show br-lan | grep "inet " | awk '{print $2}' | cut -d/ -f1)

HOSTNAME=$(uci get system.@system[0].hostname 2>/dev/null)

DATESTR=$(date '+%d-%m-%Y')
TIMESTR=$(date '+%H:%M:%S')
REPORTID=$(date '+%Y%m%d-%H%M%S')

if [ "$WANSTATUS" = "PASS" ] && 
[ "$INTERNETSTATUS" = "PASS" ] && 
[ "$MATRIXSTATUS" = "PASS" ]
then
RESULT="GOEDGEKEURD"
RESULTCOLOR="green"
else
RESULT="AFGEKEURD"
RESULTCOLOR="red"
fi

echo "<html>"
echo "<head>"
echo "<title>Matrix Toolkit Certificeringsrapport</title>"
echo "</head>"

echo "<body style='font-family:Arial;margin:20px'>"

echo "<h1>Matrix Toolkit Certificeringsrapport</h1>"

echo "<h2 style='color:$RESULTCOLOR'>RESULTAAT: $RESULT</h2>"

echo "<p><b>Installatie voldoet aan de minimale Matrix vereisten.</b></p>"

echo "<hr>"

echo "<h3>Installatiegegevens</h3>"

echo "<table border='1' cellpadding='6' cellspacing='0'>"
echo "<tr><td><b>Router</b></td><td>$HOSTNAME</td></tr>"
echo "<tr><td><b>WAN IP</b></td><td>$WANIP</td></tr>"
echo "<tr><td><b>LAN IP</b></td><td>$LANIP</td></tr>"
echo "<tr><td><b>Datum</b></td><td>$DATESTR</td></tr>"
echo "<tr><td><b>Tijd</b></td><td>$TIMESTR</td></tr>"
echo "<tr><td><b>Rapport ID</b></td><td>$REPORTID</td></tr>"
echo "<tr><td><b>Toolkit Versie</b></td><td>1.0 Final</td></tr>"
echo "</table>"

echo "<br>"

echo "<h3>Testresultaten</h3>"

echo "<table border='1' cellpadding='6' cellspacing='0'>"

if [ "$WANSTATUS" = "PASS" ]
then
echo "<tr><td>WAN Status</td><td style='color:green'><b>PASS</b></td></tr>"
else
echo "<tr><td>WAN Status</td><td style='color:red'><b>FAIL</b></td></tr>"
fi

if [ "$INTERNETSTATUS" = "PASS" ]
then
echo "<tr><td>Internet Test</td><td style='color:green'><b>PASS</b></td></tr>"
else
echo "<tr><td>Internet Test</td><td style='color:red'><b>FAIL</b></td></tr>"
fi

if [ "$MATRIXSTATUS" = "PASS" ]
then
echo "<tr><td>Matrix Connectiviteit</td><td style='color:green'><b>PASS</b></td></tr>"
else
echo "<tr><td>Matrix Connectiviteit</td><td style='color:red'><b>FAIL</b></td></tr>"
fi

echo "</table>"

echo "<br>"

if [ "$RESULT" = "GOEDGEKEURD" ]
then
echo "<h3 style='color:green'>Installatie succesvol gevalideerd</h3>"
echo "<p>Router, internetverbinding en Matrix cloud functioneren correct.</p>"
else
echo "<h3 style='color:red'>Geconstateerde problemen</h3>"

```
[ "$WANSTATUS" != "PASS" ] && echo "WAN verbinding niet beschikbaar<br>"
[ "$INTERNETSTATUS" != "PASS" ] && echo "Internet test mislukt<br>"
[ "$MATRIXSTATUS" != "PASS" ] && echo "Matrix cloud niet bereikbaar<br>"
```

fi

echo "<hr>"

echo "<h3>Aanvullende controles beschikbaar</h3>"

echo "Matrix Full Test<br>"
echo "EGYM Firewall Test<br>"
echo "LTE Analyse<br>"

echo "<br>"

echo "Deze controles zijn informatief en maken geen onderdeel uit van de basiscertificering."

echo "<br><br>"

echo "<small>Matrix Toolkit v1.0 Final - Teltonika RUTX50</small>"

echo "</body>"
echo "</html>"
