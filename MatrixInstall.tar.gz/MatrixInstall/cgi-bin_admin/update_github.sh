#!/bin/sh

echo "Content-Type: text/html"
echo ""

rm -rf /tmp/MatrixToolkit
mkdir -p /tmp/MatrixToolkit

wget -O /tmp/MatrixToolkit.tar.GZ \
https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.GZ

tar -xzf /tmp/MatrixToolkit.tar.GZ -C /tmp/MatrixToolkit

cp -f /tmp/MatrixToolkit/MatrixInstall/web/index.html \
      /usr/local/matrix/web/index.html

cp -f /tmp/MatrixToolkit/MatrixInstall/web_admin/index.html \
      /usr/local/matrix/web/admin/index.html

cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin/*.sh \
      /usr/local/matrix/web/cgi-bin/

cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin_admin/*.sh \
      /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

/etc/init.d/uhttpd reload >/dev/null 2>&1

echo "<html><body>"
echo "<h2>GitHub Update Completed</h2>"
echo "<p>Toolkit updated successfully.</p>"
echo "</body></html>"