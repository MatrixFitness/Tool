#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

REQ="/tmp/matrix_update_request"
LOG="/tmp/matrix_update_github.log"
STATUS="/tmp/matrix_update_status"
TECH="/tmp/matrix_update_technical.log"
HIST="/usr/local/matrix/logs/update_history.log"

mkdir -p /usr/local/matrix/logs
rm -f /tmp/matrix_update_worker.lock

if [ -f "$LOG" ]; then
    {
        echo ""
        echo "----------------------------------------"
        echo "Archived at: $(date)"
        cat "$LOG"
    } >> "$HIST" 2>/dev/null
fi

cat > "$STATUS" <<EOF
STATE=REQUESTED
MESSAGE=Cloud Update requested
START=$(date '+%d-%m-%Y %H:%M:%S')
EOF

cat > "$LOG" <<EOF
======================================
 MATRIX CLOUD UPDATE
 Production Edition
======================================

Requested: $(date)

Status:
Waiting for root update worker...

The web server may restart during the update.
This page will reconnect automatically.
EOF

: > "$TECH"
touch "$REQ"

cat <<'HTML'
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Cloud Update</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="2;url=/cgi-bin/update_github_log.sh">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:20px;color:#122033}
.card{background:white;border-radius:16px;padding:22px;max-width:760px;margin:20px auto;box-shadow:0 3px 12px rgba(0,0,0,.08)}
h1{color:#00589c;margin-top:0}
.status{background:#eaf4ff;border-left:6px solid #007bff;padding:14px;border-radius:10px}
.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:12px 16px;font-weight:bold;margin-top:12px}
</style>
</head>
<body>
<div class="card">
<h1>Matrix Cloud Update</h1>
<div class="status">
<b>Update has started.</b><br>
The web server and ZeroTier may restart during the update.<br>
This page will automatically reconnect.
</div>
<p><a class="btn" href="/cgi-bin/update_github_log.sh">Open Live Status</a></p>
<p><a href="/cgi-bin/admin_home.sh">Back to Admin</a></p>
</div>
</body>
</html>
HTML
