#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

LOG="/tmp/matrix_update_github.log"
STATUS="/tmp/matrix_update_status"
TECH="/tmp/matrix_update_technical.log"
HIST="/usr/local/matrix/logs/update_history.log"

STATE="$(grep '^STATE=' "$STATUS" 2>/dev/null | cut -d= -f2-)"
MSG="$(grep '^MESSAGE=' "$STATUS" 2>/dev/null | cut -d= -f2-)"
START="$(grep '^START=' "$STATUS" 2>/dev/null | cut -d= -f2-)"
[ -z "$STATE" ] && STATE="UNKNOWN"
[ -z "$MSG" ] && MSG="No active update status found"
[ -z "$START" ] && START="-"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

LOG_TXT="$(tail -n 120 "$LOG" 2>/dev/null)"
[ -z "$LOG_TXT" ] && LOG_TXT="No update log found yet."

TECH_TXT="$(tail -n 160 "$TECH" 2>/dev/null)"
[ -z "$TECH_TXT" ] && TECH_TXT="No technical details available yet."

REFRESH=""
case "$STATE" in
    REQUESTED|RUNNING|DOWNLOADING|INSTALLING|RECOVERY|DOCTOR|FINALIZING|UNKNOWN)
        REFRESH='<meta http-equiv="refresh" content="2">'
    ;;
esac

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Cloud Update Log</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
$REFRESH
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}
.card{background:white;border-radius:16px;padding:18px;max-width:1100px;margin:14px auto;box-shadow:0 3px 12px rgba(0,0,0,.08)}
h1{color:#00589c;margin-top:0}
.badge{display:inline-block;border-radius:999px;padding:8px 13px;font-weight:bold}
.RUNNING,.REQUESTED,.DOWNLOADING,.INSTALLING,.RECOVERY,.DOCTOR,.FINALIZING,.UNKNOWN{background:#fff4ce;color:#8a5a00}
.SUCCESS,.UPTODATE{background:#dff3e4;color:#137333}
.FAILED{background:#fde2e2;color:#a10000}
pre{background:#0f172a;color:#e5e7eb;padding:14px;border-radius:12px;overflow:auto;white-space:pre-wrap}
.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:11px 14px;font-weight:bold;margin:4px}
.note{background:#eaf4ff;border-left:6px solid #007bff;padding:12px;border-radius:10px}
details summary{cursor:pointer;font-weight:bold;color:#00589c;margin:12px 0}
</style>
</head>
<body>
<div class="card">
<h1>Matrix Cloud Update</h1>
<p><a class="btn" href="/cgi-bin/admin_home.sh">Back to Admin</a> <a class="btn" href="/cgi-bin/update_github_log.sh">Refresh</a></p>
<p><span class="badge $STATE">$(html_escape "$STATE")</span></p>
<div class="note">
<b>Message:</b> $(html_escape "$MSG")<br>
<b>Started:</b> $(html_escape "$START")<br>
If the browser temporarily shows a timeout during update, wait and refresh. The router restarts web/network services during recovery.
</div>
</div>

<div class="card">
<h2>Current Update Log</h2>
<pre>$(html_escape "$LOG_TXT")</pre>
</div>

<div class="card">
<details>
<summary>Show Technical Details</summary>
<pre>$(html_escape "$TECH_TXT")</pre>
</details>
</div>

<div class="card">
<details>
<summary>Show Update History</summary>
<pre>$(html_escape "$(tail -n 80 "$HIST" 2>/dev/null)")</pre>
</details>
</div>
</body>
</html>
HTML
