#!/bin/sh
REPO_RAW="${REPO_RAW:-https://raw.githubusercontent.com/MatrixFitness/Tool/main}"
PACKAGE_URL="${PACKAGE_URL:-https://github.com/MatrixFitness/Tool/raw/main/MatrixToolkit.tar.gz}"
ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
LOG="/tmp/matrix_bootstrap.log"
exec > "$LOG" 2>&1
echo "======================================"
echo " MATRIX BOOTSTRAP"
echo "======================================"
date
echo "Checking internet..."
ping -c 1 -W 5 8.8.8.8 >/dev/null 2>&1 || { echo "ERROR: No internet"; cat "$LOG"; exit 1; }
echo "Installing required packages..."
opkg update || true
opkg install ca-certificates wget tar gzip zerotier || true
echo "Downloading Matrix Toolkit package..."
rm -rf /tmp/MatrixInstall /tmp/MatrixToolkit.tar.gz
wget -O /tmp/MatrixToolkit.tar.gz "$PACKAGE_URL" || { echo "ERROR: Download failed"; cat "$LOG"; exit 1; }
echo "Extracting..."
tar -xzf /tmp/MatrixToolkit.tar.gz -C /tmp || { echo "ERROR: Extract failed"; cat "$LOG"; exit 1; }
[ -d /tmp/MatrixInstall ] || { echo "ERROR: MatrixInstall not found"; cat "$LOG"; exit 1; }
echo "Installing Matrix files..."
mkdir -p /usr/local/matrix/recovery_source /usr/local/matrix/web /usr/local/matrix/adminweb /usr/local/matrix/platform /usr/local/bin
rm -rf /usr/local/matrix/recovery_source/MatrixInstall
mkdir -p /usr/local/matrix/recovery_source/MatrixInstall
cp -R /tmp/MatrixInstall/* /usr/local/matrix/recovery_source/MatrixInstall/ 2>/dev/null || true
[ -d /tmp/MatrixInstall/web ] && cp -R /tmp/MatrixInstall/web/* /usr/local/matrix/web/ 2>/dev/null || true
[ -d /tmp/MatrixInstall/adminweb ] && cp -R /tmp/MatrixInstall/adminweb/* /usr/local/matrix/adminweb/ 2>/dev/null || true
[ -d /tmp/MatrixInstall/cgi-bin ] && { mkdir -p /usr/local/matrix/web/cgi-bin; cp -f /tmp/MatrixInstall/cgi-bin/*.sh /usr/local/matrix/web/cgi-bin/ 2>/dev/null || true; }
[ -f /tmp/MatrixInstall/index.html ] && cp -f /tmp/MatrixInstall/index.html /usr/local/matrix/web/index.html
[ -f /tmp/MatrixInstall/version.txt ] && cp -f /tmp/MatrixInstall/version.txt /usr/local/matrix/version.txt
[ -d /tmp/MatrixInstall/platform ] && cp -R /tmp/MatrixInstall/platform/* /usr/local/matrix/platform/ 2>/dev/null || true
[ -d /tmp/MatrixInstall/bin ] && cp -f /tmp/MatrixInstall/bin/* /usr/local/bin/ 2>/dev/null || true
chmod +x /usr/local/matrix/web/cgi-bin/*.sh 2>/dev/null || true
chmod +x /usr/local/matrix/adminweb/cgi-bin/*.sh 2>/dev/null || true
chmod +x /usr/local/matrix/platform/*.sh 2>/dev/null || true
chmod +x /usr/local/bin/matrix-* 2>/dev/null || true
echo "Running recovery..."
ZT_NETWORK_ID="$ZT_NETWORK_ID" /usr/local/bin/matrix-recovery
echo "======================================"
echo "Bootstrap completed."
echo "Toolkit local: http://192.168.1.1:8080"
echo "Admin local:   http://192.168.1.1:8081/cgi-bin/admin_login.sh"
ZT_IP="$(ip -4 addr | awk '/ztd/ && /inet / {split($2,a,"/"); print a[1]; exit}')"
if [ -n "$ZT_IP" ]; then
    echo "Toolkit ZeroTier: http://$ZT_IP:8080"
    echo "Admin ZeroTier:   http://$ZT_IP:8081/cgi-bin/admin_login.sh"
else
    NODE="$(cat /etc/zerotier/identity.public 2>/dev/null | cut -d: -f1)"
    echo "ZeroTier may need authorization."
    [ -n "$NODE" ] && echo "Authorize Node ID: $NODE"
fi
echo "Run: matrix-doctor"
echo "======================================"
cat "$LOG"
