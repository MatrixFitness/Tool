#!/bin/sh
printf "Content-Type: text/html\n\n"

LOG="/tmp/matrix_update_github.log"
REQ="/tmp/matrix_update_request"

cat > "$LOG" <<EOF
Matrix Cloud Update requested at: $(date)
This update uses the bootstrap/latest-release engine.
Waiting for root update worker...
EOF

rm -f /tmp/matrix_update_worker.lock
touch "$REQ"

cat <<'HTML'
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Matrix Cloud Update & Repair</title>
<meta http-equiv="refresh" content="2;url=/cgi-bin/update_github_log.sh">
<style>
body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0;padding:30px;color:#102033}
.card{background:#fff;border-radius:14px;padding:26px;max-width:820px;margin:auto;box-shadow:0 4px 14px rgba(0,0,0,.12)}
h1{margin-top:0;color:#00589c}
.info{background:#eaf4ff;border-left:5px solid #007bff;padding:14px;border-radius:8px;line-height:1.5}
.btn{display:inline-block;margin-top:18px;padding:12px 18px;background:#007bff;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold}
</style>
</head>
<body>
<div class="card">
<h1>Matrix Cloud Update & Repair</h1>
<div class="info">
The latest stable release is being downloaded from GitHub.<br>
Matrix Recovery and Matrix Doctor will run automatically.<br><br>
The web interface may be unavailable for a short moment while services restart.
</div>
<a class="btn" href="/cgi-bin/update_github_log.sh">Show update log</a>
</div>
</body>
</html>
HTML
