#!/bin/sh
printf "Status: 302 Found\r\n"
printf "Location: /cgi-bin/update_github.sh\r\n\r\n"
