#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n"
printf "Cache-Control: no-store\n\n"

HOST="$(uci -q get system.@system[0].hostname)"
[ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"
[ -n "$HOST" ] || HOST="Matrix Router"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
SSID_2G="$(uci -q get wireless.default_radio0.ssid)"
SSID_5G="$(uci -q get wireless.default_radio1.ssid)"
DIS_2G="$(uci -q get wireless.default_radio0.disabled)"
DIS_5G="$(uci -q get wireless.default_radio1.disabled)"
[ -n "$SSID_2G" ] || SSID_2G="Unknown"
[ -n "$SSID_5G" ] || SSID_5G="Unknown"
[ "$DIS_2G" = "1" ] && STATE_2G="Disabled" || STATE_2G="Enabled"
[ "$DIS_5G" = "1" ] && STATE_5G="Disabled" || STATE_5G="Enabled"

cat <<HTML
<!DOCTYPE html>
<html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Matrix WiFi Manager</title>
<style>
body{font-family:Arial;background:#eef3f8;color:#172033;margin:0;padding:16px}.wrap{max-width:900px;margin:auto}
.hero,.card{background:white;border-radius:16px;padding:20px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
.hero{background:linear-gradient(135deg,#123a63,#0878d1);color:white}.card{margin-top:16px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.item{border:1px solid #d6e0ea;border-radius:12px;padding:14px;background:#f8fafc}
.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:bold}.value{font-size:21px;font-weight:900;margin-top:6px}
.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:18px}.btn{display:inline-block;text-decoration:none;border-radius:10px;padding:12px 16px;font-weight:bold}
.primary{background:#0878d1;color:white}.green{background:#17833a;color:white}.orange{background:#d97706;color:white}.grey{background:#5f6670;color:white}
.notice{border-left:6px solid #17833a;background:#edf8ef;padding:14px;border-radius:10px}
@media(max-width:650px){.grid{grid-template-columns:1fr}.actions{display:block}.btn{display:block;text-align:center;margin:8px 0}}
</style>
</head><body><div class="wrap">
<section class="hero"><h1>Matrix WiFi Manager</h1><p>${HOST} · Build ${BUILD:-037}</p><p>Low Resource Edition</p></section>
<section class="card">
<div class="notice">Deze pagina laadt alleen noodzakelijke WiFi-informatie. Zware diagnostiek start uitsluitend via <b>Load Diagnostics</b>.</div>
<div class="grid" style="margin-top:16px">
<div class="item"><div class="label">2.4 GHz SSID</div><div class="value">${SSID_2G}</div><div>${STATE_2G}</div></div>
<div class="item"><div class="label">5 GHz SSID</div><div class="value">${SSID_5G}</div><div>${STATE_5G}</div></div>
</div>
<div class="actions">
<a class="btn primary" href="/cgi-bin/wifi_manager_full.sh">Load Diagnostics</a>
<a class="btn green" href="/cgi-bin/wifi_manager_full.sh?action=restore_matrix">Restore Matrix Default</a>
<a class="btn orange" href="/cgi-bin/wifi_manager_full.sh?action=enable_both">Enable Both Radios</a>
<a class="btn grey" href="/">Back to Toolkit</a>
</div></section></div></body></html>
HTML
