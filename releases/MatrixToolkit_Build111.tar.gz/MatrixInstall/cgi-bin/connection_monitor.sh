#!/bin/sh
# MATRIX_CONNECTION_MONITOR_WEB_BUILD103_MULTI_DURATION_PDF
# MATRIX_CONNECTION_MONITOR_WEB_BUILD104_SAFE_PROGRESS_REFRESH
# MATRIX_CONNECTION_MONITOR_WEB_BUILD105_PDF_RECOVERY_ACTION
# MATRIX_CONNECTION_MONITOR_WEB_BUILD107_VISIBLE_PDF_RECOVERY
# MATRIX_CONNECTION_MONITOR_WEB_BUILD108_REPORT_STORAGE
# MATRIX_CONNECTION_MONITOR_WEB_BUILD109_POST_CLEANUP_STORAGE
# MATRIX_CONNECTION_MONITOR_WEB_BUILD110_ROOT_WORKER_STORAGE
# MATRIX_CONNECTION_MONITOR_WEB_BUILD111_EXPLAINED_CONNECTION_PATH
MON=/usr/local/bin/matrix-connection-monitor
[ ! -x "$MON" ] && MON=/usr/local/matrix/bin/matrix-connection-monitor
ACTION=$(printf '%s' "$QUERY_STRING" | sed -n 's/.*action=\([^&]*\).*/\1/p')
FILE=$(printf '%s' "$QUERY_STRING" | sed -n 's/.*file=\([^&]*\).*/\1/p')
REPORT_DIR=/etc/matrix-connection-reports
if [ "$ACTION" = download ]; then case "$FILE" in Matrix_Verbindingsrapport_*.pdf) ;; *) echo 'Status: 400 Bad Request'; echo; exit;; esac; [ -f "$REPORT_DIR/$FILE" ] || { echo 'Status: 404 Not Found'; echo; exit; }; echo 'Content-Type: application/pdf'; echo 'Content-Disposition: attachment; filename="'"$FILE"'"'; echo; cat "$REPORT_DIR/$FILE"; exit; fi
case "$ACTION" in
 start5) "$MON" start 5m >/dev/null 2>&1;;
 start60) "$MON" start 1h >/dev/null 2>&1;;
 start24) "$MON" start 24h >/dev/null 2>&1;;
 stop) "$MON" stop >/dev/null 2>&1;;
 sample) "$MON" sample >/dev/null 2>&1;;
 pdfnow)
  echo 'BEZIG|PDF wordt opnieuw opgebouwd met Build111.' > /tmp/matrix_connection_monitor_pdf.state
  RECOVERY_OUTPUT=$($MON pdf-now 2>&1); RECOVERY_RC=$?
  CURRENT_PDF_STATE=$(cat /tmp/matrix_connection_monitor_pdf.state 2>/dev/null)
  if [ "$RECOVERY_RC" -ne 0 ] && printf '%s' "$CURRENT_PDF_STATE" | grep -q '^BEZIG|'; then
   SHORT_ERROR=$(printf '%s' "$RECOVERY_OUTPUT" | tr '\r\n' ' ' | cut -c1-240)
   echo "FOUT|Build111 herstelopdracht mislukt (code=$RECOVERY_RC): ${SHORT_ERROR:-geen uitvoer}. Meetgegevens zijn behouden." > /tmp/matrix_connection_monitor_pdf.state
  fi
 ;;
esac
if [ -n "$ACTION" ]; then echo 'Status: 303 See Other'; echo 'Location: '"${SCRIPT_NAME:-/cgi-bin/connection_monitor.sh}"; echo 'Cache-Control: no-store'; echo; exit; fi
STATUS=$($MON status 2>/dev/null); GENERATOR=$($MON version 2>/dev/null); GENERATOR=${GENERATOR:-ONBEKEND}; COUNT=$(cat /tmp/matrix_connection_monitor_session.count 2>/dev/null); COUNT=${COUNT:-0}; TARGET=$(cat /tmp/matrix_connection_monitor_session.target 2>/dev/null); TARGET=${TARGET:-0}; LABEL=$(cat /tmp/matrix_connection_monitor_session.label 2>/dev/null); LABEL=${LABEL:-Geen_test_geselecteerd}; START=$(cat /tmp/matrix_connection_monitor_session.start 2>/dev/null); START=${START:-Nog_niet_gestart}; PDFSTATE=$(cat /tmp/matrix_connection_monitor_pdf.state 2>/dev/null)
PCT=0; [ "$TARGET" -gt 0 ] && PCT=$((COUNT * 100 / TARGET)); [ "$PCT" -gt 100 ] && PCT=100
echo 'Content-Type: text/html'; echo
echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="10"><title>Matrix Verbinding Monitor</title><style>body{font-family:Segoe UI,Arial;background:#f2f6fa;color:#10233b;margin:0}.h{background:#0a4c83;color:#fff;padding:22px}.w{max-width:1200px;margin:20px auto;padding:0 16px}.c{background:#fff;border:1px solid #d7e1eb;border-radius:14px;padding:18px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}.choice{border:2px solid #d8e5ef;border-radius:12px;padding:16px}.b{display:inline-block;padding:11px 16px;margin:4px;text-decoration:none;border-radius:9px;background:#0878d1;color:#fff;font-weight:700}.disabled{background:#8b99a5;cursor:not-allowed}.stop{background:#a52a2a}.bar{height:18px;background:#dce5ec;border-radius:9px;overflow:hidden}.fill{height:100%;background:#16803a}.ok{color:#16803a;font-weight:800}.err{color:#b3261e;font-weight:800}pre{white-space:pre-wrap;word-break:break-word;background:#101820;color:#eaf2f8;padding:14px;border-radius:10px;max-height:420px;overflow:auto}</style></head><body>'
echo '<div class="h"><h1>VERBINDING MONITOR</h1><div>Internet • DNS • 5G/LTE • Wi-Fi • uptime • automatisch PDF-rapport</div></div><div class="w">'
echo '<div class="c"><h2>Kies de duur van de meting</h2><div class="grid">'
if [ "$STATUS" = RUNNING ]; then
 echo '<div class="choice"><h3>5 MINUTEN</h3><p>Snelle controle of de meting en PDF goed werken.</p><span class="b disabled">METING ACTIEF</span></div><div class="choice"><h3>1 UUR</h3><p>Korte diagnose voor terugkerende verbindingsproblemen.</p><span class="b disabled">METING ACTIEF</span></div><div class="choice"><h3>24 UUR</h3><p>Volledige analyse van een hele dag en nacht.</p><span class="b disabled">METING ACTIEF</span></div>'
else
 echo '<div class="choice"><h3>5 MINUTEN</h3><p>Snelle controle of de meting en PDF goed werken.</p><a class="b" href="?action=start5">START 5 MINUTEN</a></div><div class="choice"><h3>1 UUR</h3><p>Korte diagnose voor terugkerende verbindingsproblemen.</p><a class="b" href="?action=start60">START 1 UUR</a></div><div class="choice"><h3>24 UUR</h3><p>Volledige analyse van een hele dag en nacht.</p><a class="b" href="?action=start24">START 24 UUR</a></div>'
fi
echo '</div></div>'
echo '<div class="c"><b>Status:</b> <span class="ok">'"$STATUS"'</span><br><b>Actieve test:</b> '"$LABEL"'<br><b>Gestart:</b> '"$START"'<br><b>Voortgang:</b> '"$COUNT"' van '"$TARGET"' minuutmetingen ('"$PCT"'%)<div class="bar"><div class="fill" style="width:'"$PCT"'%"></div></div><p>Na de laatste meting wordt de PDF automatisch gemaakt en hieronder opgeslagen.</p><a class="b stop" href="?action=stop">STOP METING</a><a class="b" href="?action=sample">NU METEN</a>'
[ "$GENERATOR" = BUILD111_EXPLAINED_CONNECTION_PATH ] && echo '<p class="ok"><b>PDF-generator:</b> Build111 actief</p>' || echo '<p class="err"><b>PDF-generator:</b> '"$GENERATOR"' (niet Build111)</p>'
[ -n "$PDFSTATE" ] && echo '<p><b>Laatste PDF-status:</b> '"$PDFSTATE"'</p>'
[ -s /tmp/matrix_connection_monitor_session.log ] && printf '%s' "$PDFSTATE" | grep -q '^FOUT|' && echo '<p><a class="b" href="?action=pdfnow">HERSTEL PDF VAN BEWAARDE METING</a></p>'
echo '</div><div class="c"><h2>Opgeslagen PDF-rapporten</h2>'
FOUND=0; for P in $(ls -1t "$REPORT_DIR"/Matrix_Verbindingsrapport_*.pdf 2>/dev/null); do F=${P##*/}; FOUND=1; echo '<div><a class="b" href="?action=download&amp;file='"$F"'">DOWNLOAD '"$F"'</a></div>'; done; [ "$FOUND" = 0 ] && echo '<p>Nog geen compleet rapport beschikbaar. Test eerst de 5-minutenmeting.</p>'
echo '</div><div class="c"><h2>Storingsgebeurtenissen</h2><pre>'; "$MON" events 200 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'; echo '</pre></div><div class="c"><h2>Laatste metingen</h2><pre>'; "$MON" report 240 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'; echo '</pre></div></div></body></html>'