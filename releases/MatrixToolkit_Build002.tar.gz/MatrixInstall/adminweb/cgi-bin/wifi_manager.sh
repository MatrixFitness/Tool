#!/bin/sh
# Matrix WiFi Manager - Production Edition Build 002
# Fast CGI version: sends HTTP header immediately to prevent Bad Gateway.

printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

qs() {
    KEY="$1"
    printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | awk -F= -v k="$KEY" '$1==k{print $2; exit}' | sed 's/+/ /g;s/%2F/\//g;s/%3A/:/g;s/%20/ /g'
}

ACTION="$(qs action)"
LOG="/tmp/matrix_wifi_manager.log"
MSG=""

case "$ACTION" in
    reload_wifi)
        wifi reload >/dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi reload requested" >> "$LOG"
        MSG="WiFi reload requested."
        ;;
    restart_network)
        /etc/init.d/network restart >/dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') Network restart requested" >> "$LOG"
        MSG="Network restart requested."
        ;;
    restart_uhttpd)
        /etc/init.d/uhttpd restart >/dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') uhttpd restart requested" >> "$LOG"
        MSG="uhttpd restart requested."
        ;;
esac

get_value() {
    grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-
}

EDITION="$(get_value Edition)"
BUILD="$(get_value Build)"
STATUS="$(get_value Status)"
[ -z "$EDITION" ] && EDITION="Production Edition"
[ -z "$BUILD" ] && BUILD="002"
[ -z "$STATUS" ] && STATUS="Stable"

HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Unknown"

SSID_24="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
SSID_5="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
DIS_24="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
DIS_5="$(uci get wireless.default_radio1.disabled 2>/dev/null)"
[ -z "$SSID_24" ] && SSID_24="Unknown"
[ -z "$SSID_5" ] && SSID_5="Unknown"
[ "$DIS_24" = "1" ] && STATE_24="Disabled" || STATE_24="Enabled"
[ "$DIS_5" = "1" ] && STATE_5="Disabled" || STATE_5="Enabled"

WAN_ROUTE="$(ip route 2>/dev/null | awk '$1=="default"{print; exit}')"
WAN_DEV="$(echo "$WAN_ROUTE" | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
WAN_GW="$(echo "$WAN_ROUTE" | awk '{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}')"
WAN_IP=""
[ -n "$WAN_DEV" ] && WAN_IP="$(ip -4 addr show "$WAN_DEV" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
[ -z "$WAN_DEV" ] && WAN_DEV="Unknown"
[ -z "$WAN_GW" ] && WAN_GW="Unknown"
[ -z "$WAN_IP" ] && WAN_IP="Unknown"

ZT_IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
[ -z "$ZT_IP" ] && ZT_IP="Not available"

STA_INFO="$(uci show wireless 2>/dev/null | grep '=wifi-iface' | cut -d. -f2 | cut -d= -f1 | while read I; do
    MODE="$(uci get wireless.${I}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] || continue
    SSID="$(uci get wireless.${I}.ssid 2>/dev/null)"
    NET="$(uci get wireless.${I}.network 2>/dev/null)"
    DIS="$(uci get wireless.${I}.disabled 2>/dev/null)"
    echo "$I|$SSID|$NET|$DIS"
    break
done)"

STA_IFACE="$(echo "$STA_INFO" | cut -d'|' -f1)"
STA_SSID="$(echo "$STA_INFO" | cut -d'|' -f2)"
STA_NET="$(echo "$STA_INFO" | cut -d'|' -f3)"
STA_DIS="$(echo "$STA_INFO" | cut -d'|' -f4)"
[ -z "$STA_IFACE" ] && STA_IFACE="-"
[ -z "$STA_SSID" ] && STA_SSID="-"
[ -z "$STA_NET" ] && STA_NET="-"
[ -z "$STA_DIS" ] && STA_DIS="-"

LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
[ -z "$LAST" ] && LAST="No actions logged yet."

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix WiFi Manager</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}
.header{background:#fff;border-radius:16px;padding:22px;box-shadow:0 3px 12px rgba(0,0,0,.08);margin-bottom:18px}
h1{margin:0;color:#00589c}
.grid{display:grid;grid-template-columns:repeat(2,minmax(260px,1fr));gap:18px}
.card{background:#fff;border-radius:16px;padding:18px;box-shadow:0 3px 10px rgba(0,0,0,.07);border-top:7px solid #007bff}
.card.green{border-top-color:#24a148}.card.purple{border-top-color:#7048c8}.card.orange{border-top-color:#ff7a1a}
table{width:100%;border-collapse:collapse}td{padding:8px;border-bottom:1px solid #e5e7eb;vertical-align:top}td:first-child{font-weight:bold;width:42%}
.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:9px;padding:11px 14px;margin:6px 4px 6px 0;font-weight:bold}
.note{background:#eaf4ff;border-left:5px solid #007bff;padding:12px;border-radius:8px;margin:12px 0}
@media(max-width:800px){.grid{grid-template-columns:1fr}body{padding:10px}}
</style>
</head>
<body>
<div class="header">
<h1>Matrix WiFi Manager</h1>
<p>$(html_escape "$EDITION") | Build $(html_escape "$BUILD") | Status $(html_escape "$STATUS")</p>
<p><a href="/cgi-bin/admin_home.sh">Back to Admin</a> | <a href="/index.html">Back to Toolkit</a></p>
</div>
EOF

if [ -n "$MSG" ]; then
cat <<EOF
<div class="note"><b>Action:</b> $(html_escape "$MSG")</div>
EOF
fi

cat <<EOF
<div class="grid">
<div class="card green">
<h2>Router WiFi</h2>
<table>
<tr><td>Hostname</td><td>$(html_escape "$HOST")</td></tr>
<tr><td>2.4 GHz SSID</td><td>$(html_escape "$SSID_24")</td></tr>
<tr><td>2.4 GHz status</td><td>$(html_escape "$STATE_24")</td></tr>
<tr><td>5 GHz SSID</td><td>$(html_escape "$SSID_5")</td></tr>
<tr><td>5 GHz status</td><td>$(html_escape "$STATE_5")</td></tr>
</table>
<p><a class="btn" href="/cgi-bin/wifi_manager.sh?action=reload_wifi">Reload WiFi</a></p>
</div>

<div class="card purple">
<h2>Customer WiFi / Client</h2>
<table>
<tr><td>Client interface</td><td>$(html_escape "$STA_IFACE")</td></tr>
<tr><td>Configured SSID</td><td>$(html_escape "$STA_SSID")</td></tr>
<tr><td>Network</td><td>$(html_escape "$STA_NET")</td></tr>
<tr><td>Disabled</td><td>$(html_escape "$STA_DIS")</td></tr>
</table>
<p><a class="btn" href="/cgi-bin/wifi_survey.sh">Open WiFi Survey</a></p>
</div>

<div class="card orange">
<h2>WAN</h2>
<table>
<tr><td>Device</td><td>$(html_escape "$WAN_DEV")</td></tr>
<tr><td>IP</td><td>$(html_escape "$WAN_IP")</td></tr>
<tr><td>Gateway</td><td>$(html_escape "$WAN_GW")</td></tr>
</table>
</div>

<div class="card">
<h2>System</h2>
<table>
<tr><td>ZeroTier IP</td><td>$(html_escape "$ZT_IP")</td></tr>
<tr><td>Last action</td><td>$(html_escape "$LAST")</td></tr>
</table>
<p>
<a class="btn" href="/cgi-bin/wifi_manager.sh?action=restart_uhttpd">Restart Web</a>
<a class="btn" href="/cgi-bin/wifi_manager.sh?action=restart_network">Restart Network</a>
</p>
</div>
</div>
</body>
</html>
EOF

exit 0
