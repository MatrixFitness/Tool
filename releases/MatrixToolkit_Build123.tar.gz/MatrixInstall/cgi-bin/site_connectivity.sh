#!/bin/sh
QUERY_STRING="mode=both${QUERY_STRING:+&$QUERY_STRING}"
export QUERY_STRING
exec /usr/local/matrix/web/cgi-bin/connectivity_report.sh
