#!/bin/sh
PERSIST="/usr/local/matrix/zerotier_identity"
RUNTIME="/tmp/run/zerotier"
CLI="/usr/local/usr/bin/zerotier-cli"
ONE="/usr/local/usr/bin/zerotier-one"
NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
LOG="${1:-/tmp/matrix_zerotier_state.log}"
mkdir -p "$PERSIST" "$RUNTIME" /usr/local/matrix/logs
chmod 700 "$PERSIST" "$RUNTIME" 2>/dev/null
: > "$LOG" 2>/dev/null || LOG="/usr/local/matrix/logs/matrix_zerotier_state.log"
log(){ echo "$@" | tee -a "$LOG"; }
progress(){ echo "$1" > /tmp/matrix_update.progress 2>/dev/null || true; }
valid_identity(){ [ -s "$1/identity.secret" ] && [ -s "$1/identity.public" ]; }
info(){ "$CLI" -D"$RUNTIME" info 2>/dev/null; }
node(){ info | awk '/^200 info/ {print $3; exit}'; }
backup_once(){
  [ -s "$PERSIST/identity.secret" ] && return 0
  for SRC in "$RUNTIME" /etc/zerotier /usr/local/matrix/zerotier; do
    if valid_identity "$SRC"; then
      cp -f "$SRC/identity.secret" "$PERSIST/identity.secret"
      cp -f "$SRC/identity.public" "$PERSIST/identity.public"
      [ -s "$SRC/authtoken.secret" ] && cp -f "$SRC/authtoken.secret" "$PERSIST/authtoken.secret"
      chmod 600 "$PERSIST/identity.secret" "$PERSIST/authtoken.secret" 2>/dev/null
      chmod 644 "$PERSIST/identity.public" 2>/dev/null
      N="$(awk -F: '{print $1}' "$PERSIST/identity.public" 2>/dev/null)"
      [ -n "$N" ] && echo "$N" > "$PERSIST/node_id.txt"
      log "ZeroTier identity backup........ OK from $SRC"
      return 0
    fi
  done
  log "ZeroTier identity backup........ NOT FOUND"
  return 1
}
restore(){
  valid_identity "$PERSIST" || return 1
  rm -f "$RUNTIME/identity.secret" "$RUNTIME/identity.public" "$RUNTIME/authtoken.secret"
  cp -f "$PERSIST/identity.secret" "$RUNTIME/identity.secret"
  cp -f "$PERSIST/identity.public" "$RUNTIME/identity.public"
  [ -s "$PERSIST/authtoken.secret" ] && cp -f "$PERSIST/authtoken.secret" "$RUNTIME/authtoken.secret"
  chmod 600 "$RUNTIME/identity.secret" "$RUNTIME/authtoken.secret" 2>/dev/null
  chmod 644 "$RUNTIME/identity.public" 2>/dev/null
  log "Restoring persistent identity... OK"
}
start(){
  killall zerotier-one 2>/dev/null || true
  sleep 2
  rm -f "$RUNTIME/zerotier-one.pid" "$RUNTIME/zerotier-one.port"
  "$ONE" -d "$RUNTIME" >/tmp/matrix_zerotier_start.log 2>&1 &
  sleep 8
}
wait_control(){ I=0; while [ "$I" -lt 90 ]; do X="$(info)"; echo "$X"|grep -q '^200 info' && echo "$X"|grep -Eq 'ONLINE|TUNNELED' && return 0; I=$((I+5)); progress "Waiting for ZeroTier control plane $I/90"; sleep 5; done; return 1; }
ensure_joined(){ NET="$("$CLI" -D"$RUNTIME" listnetworks 2>/dev/null)"; echo "$NET"|grep -q "$NETWORK_ID" && return 0; log "ZeroTier network................. JOINING"; "$CLI" -D"$RUNTIME" join "$NETWORK_ID" >/dev/null 2>&1 || true; sleep 5; }
wait_network(){ I=0; while [ "$I" -lt 120 ]; do NET="$("$CLI" -D"$RUNTIME" listnetworks 2>/dev/null)"; echo "$NET"|grep "$NETWORK_ID"|grep -q ' OK ' && return 0; if echo "$NET"|grep "$NETWORK_ID"|grep -q ACCESS_DENIED; then log "Network authorization.......... ACCESS_DENIED"; log "Authorize Node ID.............. $(node)"; return 2; fi; I=$((I+5)); progress "Waiting for ZeroTier network $I/120"; sleep 5; done; return 1; }
wait_ip(){ I=0; while [ "$I" -lt 120 ]; do IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null|awk '/inet / {split($2,a,"/");print a[1];exit}')"; if [ -n "$IP" ]; then ip route|grep -q '10.74.91.0/24.*ztdiyqsthc' || ip route add 10.74.91.0/24 dev ztdiyqsthc 2>/dev/null || true; log "ZeroTier IP..................... $IP"; return 0; fi; I=$((I+5)); progress "Waiting for ZeroTier IP $I/120"; sleep 5; done; return 1; }
log "======================================"; log " ZEROTIER STATE MACHINE"; log "======================================"
progress "Checking ZeroTier identity"; backup_once || true
EXPECTED="$(cat "$PERSIST/node_id.txt" 2>/dev/null)"; log "Expected Node ID................ ${EXPECTED:-unknown}"
valid_identity "$PERSIST" && restore || log "Persistent identity............. MISSING"
progress "Starting ZeroTier"; start; wait_control || { log "ZeroTier control plane.......... FAILED"; exit 1; }
CURRENT="$(node)"; log "Current Node ID................. ${CURRENT:-unknown}"
if [ -n "$EXPECTED" ] && [ -n "$CURRENT" ] && [ "$EXPECTED" != "$CURRENT" ] && valid_identity "$PERSIST"; then log "Node ID mismatch................ DETECTED"; restore; start; wait_control || exit 1; CURRENT="$(node)"; log "Node ID after restore........... ${CURRENT:-unknown}"; fi
[ -z "$EXPECTED" ] && [ -n "$CURRENT" ] && valid_identity "$PERSIST" && echo "$CURRENT" > "$PERSIST/node_id.txt"
progress "Joining ZeroTier network"; ensure_joined; wait_network; R=$?; [ "$R" -eq 2 ] && exit 2; [ "$R" -eq 0 ] || exit 1
progress "Waiting for ZeroTier IP"; wait_ip || exit 1
IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null|awk '/inet / {split($2,a,"/");print a[1];exit}')"
wget -qO- -T 5 "http://$IP:8080" >/dev/null 2>&1 && log "Toolkit over ZeroTier........... OK" || log "Toolkit over ZeroTier........... WARNING"
wget -qO- -T 5 "http://$IP:8081/cgi-bin/admin_login.sh" >/dev/null 2>&1 && log "Admin over ZeroTier............. OK" || log "Admin over ZeroTier............. WARNING"
log "======================================"; log " ZEROTIER READY"; log "======================================"; exit 0
