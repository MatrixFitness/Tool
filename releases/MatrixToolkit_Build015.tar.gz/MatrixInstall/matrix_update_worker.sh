#!/bin/sh
REQ=/tmp/matrix_update_request; LOCK=/tmp/matrix_update_worker.lock; LOG=/tmp/matrix_update_github.log; STATE=/tmp/matrix_update.state; PROGRESS=/tmp/matrix_update.progress; PERSIST=/usr/local/matrix/logs/matrix_update_last_status; UPDATER=/usr/local/matrix/web/cgi-bin/update_github.sh
[ -f "$REQ" ] || exit 0
[ -f "$LOCK" ] && P="$(cat "$LOCK" 2>/dev/null)" && [ -n "$P" ] && kill -0 "$P" 2>/dev/null && exit 0
echo $$ > "$LOCK"; rm -f "$REQ"; mkdir -p /usr/local/matrix/logs
state(){ echo "$1" > "$STATE"; echo "$2" > "$PROGRESS"; printf 'state=%s
message=%s
updated=%s
' "$1" "$2" "$(date '+%Y-%m-%d %H:%M:%S')" > "$PERSIST"; }
trap 'rm -f "$LOCK"' EXIT INT TERM
state downloading "Downloading and installing latest build"
printf '======================================
 MATRIX CLOUD UPDATE
 Production Edition
======================================
Started: %s
' "$(date)" > "$LOG"
chmod +x "$UPDATER" 2>/dev/null || true
state installing "Installing files"; "$UPDATER" >> "$LOG" 2>&1; C=$?
[ "$C" -eq 0 ] || { state error "Update script failed with code $C"; exit "$C"; }
state restarting "Restarting and validating services"; sleep 5
state zerotier "Restoring ZeroTier identity and network"; /usr/local/bin/matrix-zerotier-state /tmp/matrix_zerotier_state.log >> "$LOG" 2>&1; Z=$?
if [ "$Z" -eq 2 ]; then N="$(/usr/local/usr/bin/zerotier-cli -D/tmp/run/zerotier info 2>/dev/null|awk '/^200 info/ {print $3;exit}')"; state access_denied "Authorize ZeroTier Node ID ${N:-unknown}"; exit 2; fi
[ "$Z" -eq 0 ] || { state error "ZeroTier recovery did not complete"; exit 1; }
state doctor "Running final Matrix Doctor"; /usr/local/bin/matrix-doctor >> "$LOG" 2>&1
if grep -q 'FAIL: 0' "$LOG" && grep -q 'SYSTEM HEALTH: OK' "$LOG"; then state success "Update completed successfully"; printf '
======================================
 UPDATE COMPLETED SUCCESSFULLY
======================================
' >> "$LOG"; exit 0; fi
state error "Final Matrix Doctor did not report a healthy system"; exit 1
