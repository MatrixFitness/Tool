#!/bin/sh
# Matrix WiFi Web Library - Build 040

MATRIX_DIR="/usr/local/matrix"
WIFI_LIB="$MATRIX_DIR/web/cgi-bin/wifi_lib.sh"
REQUEST_FILE="/tmp/matrix_wifi_action.request"
STATUS_FILE="/tmp/matrix_wifi_action.status"

[ -f "$WIFI_LIB" ] && . "$WIFI_LIB"

wifi_http_header(){
    printf "Content-Type: text/html; charset=UTF-8\n"
    printf "Cache-Control: no-store\n\n"
}

wifi_redirect(){
    printf "Status: 302 Found\n"
    printf "Location: %s\n"
    printf "Cache-Control: no-store\n\n" "$1"
    exit 0
}

wifi_error(){
    TITLE="$1"
    MESSAGE="$2"
    wifi_http_header
    cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>$TITLE</title><style>
body{font-family:Arial;background:#eef3f8;padding:18px}.card{max-width:720px;margin:auto;background:white;padding:22px;border-radius:15px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
h1{color:#b42318}.btn{display:inline-block;background:#5f6670;color:white;text-decoration:none;padding:11px 14px;border-radius:9px;font-weight:bold}
</style></head><body><div class="card"><h1>$(html_escape "$TITLE")</h1><p>$(html_escape "$MESSAGE")</p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></div></body></html>
HTML
    exit 0
}

wifi_queued(){
    MESSAGE="$1"
    wifi_http_header
    cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WiFi Action Queued</title><style>
body{font-family:Arial;background:#eef3f8;padding:18px}.card{max-width:720px;margin:auto;background:white;padding:22px;border-radius:15px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
h1{color:#17833a}.note{background:#edf8ef;border-left:6px solid #17833a;padding:13px;border-radius:9px}.btn{display:inline-block;background:#0878d1;color:white;text-decoration:none;padding:11px 14px;border-radius:9px;font-weight:bold;margin:5px}
.grey{background:#5f6670}
</style></head><body><div class="card"><h1>WiFi Action Queued</h1><div class="note">$(html_escape "$MESSAGE")</div>
<p>The root worker normally processes this within one minute.</p>
<a class="btn" href="/cgi-bin/wifi_manager_action_status.sh">View Action Status</a>
<a class="btn grey" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></div></body></html>
HTML
    exit 0
}

wifi_safe_value(){
    printf '%s' "$1" | tr '\r\n' '  ' | sed 's/[|]/ /g'
}

wifi_queue_action(){
    ACTION="$1"; BAND="$2"; TYPE="$3"; IDX="$4"; SSID2="$5"; PASS2="$6"; SSID5="$7"; PASS5="$8"
    umask 000
    TMP="/tmp/matrix_wifi_action.request.$$"
    {
        printf 'ACTION=%s\n' "$(wifi_safe_value "$ACTION")"
        printf 'BAND=%s\n' "$(wifi_safe_value "$BAND")"
        printf 'TYPE=%s\n' "$(wifi_safe_value "$TYPE")"
        printf 'IDX=%s\n' "$(wifi_safe_value "$IDX")"
        printf 'SSID2=%s\n' "$(wifi_safe_value "$SSID2")"
        printf 'PASS2=%s\n' "$(wifi_safe_value "$PASS2")"
        printf 'SSID5=%s\n' "$(wifi_safe_value "$SSID5")"
        printf 'PASS5=%s\n' "$(wifi_safe_value "$PASS5")"
        printf 'REQUESTED_AT=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    } >"$TMP" || return 1
    chmod 666 "$TMP" 2>/dev/null || true
    mv -f "$TMP" "$REQUEST_FILE" || return 1
    chmod 666 "$REQUEST_FILE" 2>/dev/null || true
    printf 'QUEUED\n' >"$STATUS_FILE"
    chmod 666 "$STATUS_FILE" 2>/dev/null || true
    return 0
}
