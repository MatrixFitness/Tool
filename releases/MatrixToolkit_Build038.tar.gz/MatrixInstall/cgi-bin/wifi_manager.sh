#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
HOST="$(uci -q get system.@system[0].hostname)"; [ -n "$HOST" ] || HOST="$(hostname)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
S2="$(uci -q get wireless.default_radio0.ssid)"; S5="$(uci -q get wireless.default_radio1.ssid)"
D2="$(uci -q get wireless.default_radio0.disabled)"; D5="$(uci -q get wireless.default_radio1.disabled)"
cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Matrix WiFi Manager</title><style>
body{font-family:Arial;background:#eef3f8;color:#172033;margin:0;padding:16px}.wrap{max-width:980px;margin:auto}
.hero,.card{background:white;border-radius:16px;padding:20px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
.hero{background:linear-gradient(135deg,#123a63,#0878d1);color:white}.card{margin-top:16px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.item{border:1px solid #d6e0ea;border-radius:12px;padding:14px;background:#f8fafc}
.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:bold}.value{font-size:21px;font-weight:900;margin-top:6px}
.actions{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:18px}.btn{display:block;text-decoration:none;border-radius:10px;padding:13px 16px;font-weight:bold;text-align:center;background:#0878d1;color:white}
.green{background:#17833a}.orange{background:#d97706}.grey{background:#5f6670}.notice{border-left:6px solid #17833a;background:#edf8ef;padding:14px;border-radius:10px}
@media(max-width:650px){.grid,.actions{grid-template-columns:1fr}}
</style></head><body><div class="wrap">
<section class="hero"><h1>Matrix WiFi Manager</h1><p>${HOST} · Build ${BUILD:-038}</p><p>Modular Low Resource Edition</p></section>
<section class="card"><div class="notice">Elke functie opent apart. Er draait niets automatisch op de achtergrond.</div>
<div class="grid" style="margin-top:16px">
<div class="item"><div class="label">2.4 GHz SSID</div><div class="value">${S2:-Unknown}</div><div>$([ "$D2" = 1 ] && echo Disabled || echo Enabled)</div></div>
<div class="item"><div class="label">5 GHz SSID</div><div class="value">${S5:-Unknown}</div><div>$([ "$D5" = 1 ] && echo Disabled || echo Enabled)</div></div>
</div>
<div class="actions">
<a class="btn" href="/cgi-bin/wifi_manager_status.sh">Status</a>
<a class="btn green" href="/cgi-bin/wifi_manager_profiles.sh">Profiles</a>
<a class="btn orange" href="/cgi-bin/wifi_manager_logs.sh">Logs</a>
<a class="btn grey" href="/">Back to Toolkit</a>
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=restore_matrix">Restore Matrix Default</a>
<a class="btn orange" href="/cgi-bin/wifi_manager_action.sh?action=enable_both">Enable Both Radios</a>
</div></section></div></body></html>
HTML
