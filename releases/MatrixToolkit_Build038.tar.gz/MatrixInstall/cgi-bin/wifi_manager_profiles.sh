#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
. /usr/local/matrix/web/cgi-bin/wifi_page_lib.sh
wifi_page_head "WiFi Profiles"
SYS="/usr/local/matrix/matrix_wifi_system_profiles.conf"
USR="/usr/local/matrix/matrix_wifi_user_profiles.conf"
cat <<HTML
<section class="card"><h2>System Profiles</h2><pre>$(cat "$SYS" 2>/dev/null)</pre>
<p><a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=apply&type=system&p=1">Apply Matrix Default</a>
<a class="btn orange" href="/cgi-bin/wifi_manager_action.sh?action=apply&type=system&p=2">Apply EGYM</a>
<a class="btn" href="/cgi-bin/wifi_manager_action.sh?action=apply&type=system&p=3">Apply Matrix + EGYM</a></p></section>
<section class="card"><h2>User Profiles</h2><pre>$(cat "$USR" 2>/dev/null)</pre>
<p><a class="btn grey" href="/cgi-bin/wifi_manager.sh">Back</a></p></section>
HTML
wifi_page_foot
