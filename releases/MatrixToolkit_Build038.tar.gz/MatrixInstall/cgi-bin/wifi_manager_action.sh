#!/bin/sh
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"
ACTION="$(qs action)"; TYPE="$(qs type)"; IDX="$(qs p)"
case "$ACTION" in
 apply) profile_apply "$TYPE" "$IDX" ;;
 restore_matrix)
  H="$(uci -q get system.@system[0].hostname)"; [ -n "$H" ] || H="$(hostname)"
  uci set wireless.default_radio0.ssid="${H}_2G"; uci set wireless.default_radio0.encryption='psk2'; uci set wireless.default_radio0.key='matrixfitness'; uci set wireless.default_radio0.disabled='0'
  uci set wireless.default_radio1.ssid="${H}_5G"; uci set wireless.default_radio1.encryption='psk2'; uci set wireless.default_radio1.key='matrixfitness'; uci set wireless.default_radio1.disabled='0'; uci commit wireless; wifi reload >/dev/null 2>&1 ;;
 enable_both) uci set wireless.default_radio0.disabled='0'; uci set wireless.default_radio1.disabled='0'; uci commit wireless; wifi reload >/dev/null 2>&1 ;;
 disable_both) uci set wireless.default_radio0.disabled='1'; uci set wireless.default_radio1.disabled='1'; uci commit wireless; wifi reload >/dev/null 2>&1 ;;
 reload_wifi) wifi reload >/dev/null 2>&1 ;;
esac
printf "Status: 302 Found\nLocation: /cgi-bin/wifi_manager.sh\n\n"
