#!/bin/sh
wifi_page_head(){
TITLE="$1"
cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>$TITLE</title><style>
body{font-family:Arial;background:#eef3f8;color:#172033;margin:0;padding:16px}.wrap{max-width:980px;margin:auto}
.hero,.card{background:white;border-radius:16px;padding:20px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
.hero{background:linear-gradient(135deg,#123a63,#0878d1);color:white}.card{margin-top:16px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.item{border:1px solid #d6e0ea;border-radius:12px;padding:14px;background:#f8fafc}
.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:bold}.value{font-size:19px;font-weight:900;margin-top:6px;overflow-wrap:anywhere}
.btn{display:inline-block;text-decoration:none;border-radius:10px;padding:11px 14px;font-weight:bold;margin:4px;background:#0878d1;color:white}
.green{background:#17833a}.orange{background:#d97706}.red{background:#b42318}.grey{background:#5f6670}
pre{white-space:pre-wrap;word-break:break-word;background:#101828;color:#f2f4f7;padding:14px;border-radius:12px}
@media(max-width:650px){.grid{grid-template-columns:1fr}.btn{display:block;text-align:center}}
</style></head><body><div class="wrap"><section class="hero"><h1>$TITLE</h1><p>Matrix Toolkit Build 038</p></section>
HTML
}
wifi_page_foot(){ echo '</div></body></html>'; }
