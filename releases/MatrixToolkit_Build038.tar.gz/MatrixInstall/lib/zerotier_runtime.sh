#!/bin/sh
# Matrix ZeroTier Runtime and Provisioning Library - Build 038

ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
ZT_INSTANCE="${ZT_INSTANCE:-matrix}"
ZT_NETWORK_SECTION="${ZT_NETWORK_SECTION:-matrix_network}"
ZT_DEFAULT_HOME="/var/run/zerotier/lib/zerotier-one"
ZT_PERSIST="/usr/local/matrix/zerotier_identity"
ZT_USB_PERSIST="/usr/local/mnt/sda1/MatrixBackup/zerotier_identity"

ZT_ONE=""
ZT_CLI=""
ZT_IDTOOL=""

zt_detect_binaries() {
    for B in /usr/local/usr/bin/zerotier-one /usr/bin/zerotier-one; do
        [ -x "$B" ] && { ZT_ONE="$B"; break; }
    done
    for B in /usr/local/usr/bin/zerotier-cli /usr/bin/zerotier-cli; do
        [ -x "$B" ] && { ZT_CLI="$B"; break; }
    done
    for B in /usr/local/usr/bin/zerotier-idtool /usr/bin/zerotier-idtool; do
        [ -x "$B" ] && { ZT_IDTOOL="$B"; break; }
    done
    [ -n "$ZT_ONE" ] && [ -n "$ZT_CLI" ]
}

zt_package_installed() {
    opkg list-installed 2>/dev/null | awk '{print $1}' | grep -qx 'zerotier'
}

zt_install_package() {
    # Existing binary or service is sufficient; do not reinstall unnecessarily.
    zt_detect_binaries && return 0
    [ -x /etc/init.d/zerotier ] && return 0
    zt_package_installed && {
        zt_detect_binaries
        return $?
    }

    opkg update >/tmp/matrix_opkg_update.log 2>&1 || return 1
    opkg install zerotier >/tmp/matrix_opkg_zerotier.log 2>&1 || return 1
    zt_detect_binaries
}

zt_identity_dir_valid() {
    D="$1"
    [ -s "$D/identity.secret" ] && [ -s "$D/identity.public" ]
}

zt_identity_secret_from_dir() {
    D="$1"
    zt_identity_dir_valid "$D" || return 1
    cat "$D/identity.secret"
}

zt_find_saved_secret() {
    # Prefer external storage because /usr/local can be erased by firmware.
    for D in "$ZT_USB_PERSIST" "$ZT_PERSIST"; do
        S="$(zt_identity_secret_from_dir "$D" 2>/dev/null)"
        [ -n "$S" ] && { echo "$S"; return 0; }
    done

    # Existing UCI configuration can also contain the identity.
    S="$(uci -q get zerotier.${ZT_INSTANCE}.secret 2>/dev/null)"
    [ -n "$S" ] && { echo "$S"; return 0; }

    return 1
}

zt_node_from_secret() {
    printf '%s' "$1" | cut -c1-10
}

zt_provision_uci() {
    SECRET="$(zt_find_saved_secret 2>/dev/null)"
    NODE=""
    [ -n "$SECRET" ] && NODE="$(zt_node_from_secret "$SECRET")"

    uci -q delete "zerotier.${ZT_INSTANCE}"
    uci set "zerotier.${ZT_INSTANCE}=instance"
    uci set "zerotier.${ZT_INSTANCE}.enabled=1"
    uci set "zerotier.${ZT_INSTANCE}.port=9993"

    if [ -n "$SECRET" ]; then
        uci set "zerotier.${ZT_INSTANCE}.secret=$SECRET"
        uci set "zerotier.${ZT_INSTANCE}.node_id=$NODE"
    fi

    uci -q delete "zerotier.${ZT_NETWORK_SECTION}"
    uci set "zerotier.${ZT_NETWORK_SECTION}=network_${ZT_INSTANCE}"
    uci set "zerotier.${ZT_NETWORK_SECTION}.enabled=1"
    uci set "zerotier.${ZT_NETWORK_SECTION}.network_id=$ZT_NETWORK_ID"
    uci set "zerotier.${ZT_NETWORK_SECTION}.allow_managed=1"

    uci commit zerotier
}

zt_service_enable() {
    [ -x /etc/init.d/zerotier ] || return 1
    /etc/init.d/zerotier enable >/dev/null 2>&1
}

zt_service_start() {
    [ -x /etc/init.d/zerotier ] || return 1
    /etc/init.d/zerotier restart >/tmp/matrix_zerotier_service.log 2>&1 || \
        /etc/init.d/zerotier start >>/tmp/matrix_zerotier_service.log 2>&1
}

zt_service_stop() {
    [ -x /etc/init.d/zerotier ] && /etc/init.d/zerotier stop >/dev/null 2>&1
}

zt_candidate_homes() {
    # Official RUTOS 7.24 symlink and generated instance directories.
    [ -e /var/run/zerotier/lib/zerotier-one ] && echo /var/run/zerotier/lib/zerotier-one
    for H in /var/run/zerotier/lib/zerotier-one_*; do
        [ -d "$H" ] && echo "$H"
    done

    # Older Matrix and Teltonika layouts.
    [ -d /tmp/run/zerotier ] && echo /tmp/run/zerotier
    [ -d /etc/zerotier ] && echo /etc/zerotier
    [ -d /usr/local/matrix/zerotier ] && echo /usr/local/matrix/zerotier
}

zt_info() {
    HOME="$1"
    zt_detect_binaries >/dev/null 2>&1 || return 1
    "$ZT_CLI" -D"$HOME" info 2>/dev/null
}

zt_networks() {
    HOME="$1"
    zt_detect_binaries >/dev/null 2>&1 || return 1
    "$ZT_CLI" -D"$HOME" listnetworks 2>/dev/null
}

zt_detect_home() {
    zt_detect_binaries >/dev/null 2>&1 || return 1

    PROCESS_HOME="$(ps w 2>/dev/null | awk '
        /[z]erotier-one/ {
            for (i=1; i<=NF; i++) {
                if ($i ~ /^\/var\/run\/zerotier\// || $i ~ /^\/tmp\/run\/zerotier/ || $i ~ /^\/etc\/zerotier/) {
                    print $i
                    exit
                }
            }
        }')"

    {
        [ -n "$PROCESS_HOME" ] && echo "$PROCESS_HOME"
        zt_candidate_homes
    } | awk '!seen[$0]++' | while read HOME_DIR; do
        [ -n "$HOME_DIR" ] || continue
        INFO="$(zt_info "$HOME_DIR")"
        echo "$INFO" | grep -q '^200 info ' && {
            echo "$HOME_DIR"
            exit 0
        }
    done | head -1
}

zt_status() {
    HOME="$1"
    zt_info "$HOME" | awk '/^200 info /{print $5;exit}'
}

zt_node_id() {
    HOME="$1"
    zt_info "$HOME" | awk '/^200 info /{print $3;exit}'
}

zt_expected_node_id() {
    [ -s "$ZT_USB_PERSIST/node_id.txt" ] && { cat "$ZT_USB_PERSIST/node_id.txt"; return; }
    [ -s "$ZT_PERSIST/node_id.txt" ] && { cat "$ZT_PERSIST/node_id.txt"; return; }
    NODE="$(uci -q get zerotier.${ZT_INSTANCE}.node_id 2>/dev/null)"
    [ -n "$NODE" ] && echo "$NODE"
}

zt_backup_identity() {
    HOME="$1"
    [ -s "$HOME/identity.secret" ] && [ -s "$HOME/identity.public" ] || return 1

    NODE="$(cut -d: -f1 "$HOME/identity.public" 2>/dev/null)"
    [ -n "$NODE" ] || return 1

    mkdir -p "$ZT_PERSIST"
    cp -f "$HOME/identity.secret" "$ZT_PERSIST/identity.secret"
    cp -f "$HOME/identity.public" "$ZT_PERSIST/identity.public"
    printf '%s\n' "$NODE" > "$ZT_PERSIST/node_id.txt"
    chmod 600 "$ZT_PERSIST/identity.secret"
    chmod 644 "$ZT_PERSIST/identity.public" "$ZT_PERSIST/node_id.txt"

    if [ -d /usr/local/mnt/sda1 ] && [ -w /usr/local/mnt/sda1 ]; then
        mkdir -p "$ZT_USB_PERSIST"
        cp -f "$ZT_PERSIST/identity.secret" "$ZT_USB_PERSIST/identity.secret"
        cp -f "$ZT_PERSIST/identity.public" "$ZT_USB_PERSIST/identity.public"
        cp -f "$ZT_PERSIST/node_id.txt" "$ZT_USB_PERSIST/node_id.txt"
        chmod 600 "$ZT_USB_PERSIST/identity.secret"
        chmod 644 "$ZT_USB_PERSIST/identity.public" "$ZT_USB_PERSIST/node_id.txt"
    fi
}

zt_provision() {
    LOG="${1:-/tmp/matrix_zerotier_provision.log}"
    : >"$LOG"

    echo "Checking ZeroTier package..." >>"$LOG"
    zt_install_package || {
        echo "ZeroTier package installation failed" >>"$LOG"
        return 1
    }

    echo "Creating RUTOS ZeroTier configuration..." >>"$LOG"
    zt_provision_uci || return 1

    echo "Starting official Teltonika ZeroTier service..." >>"$LOG"
    zt_service_enable || return 1
    zt_service_start || return 1

    I=0
    while [ "$I" -lt 90 ]; do
        HOME="$(zt_detect_home)"
        if [ -n "$HOME" ]; then
            STATUS="$(zt_status "$HOME")"
            if [ "$STATUS" = "ONLINE" ] || [ "$STATUS" = "TUNNELED" ]; then
                zt_backup_identity "$HOME" >/dev/null 2>&1 || true
                echo "$HOME"
                return 0
            fi
        fi
        sleep 3
        I=$((I+3))
    done

    echo "No responsive ZeroTier runtime after service start" >>"$LOG"
    return 1
}

zt_join_if_missing() {
    HOME="$1"
    zt_networks "$HOME" | grep -q "$ZT_NETWORK_ID" && return 0
    "$ZT_CLI" -D"$HOME" join "$ZT_NETWORK_ID" >/dev/null 2>&1 || true
}

zt_network_state() {
    HOME="$1"
    NET="$(zt_networks "$HOME")"
    echo "$NET" | grep "$ZT_NETWORK_ID" | grep -q ' OK ' && { echo OK; return 0; }
    echo "$NET" | grep "$ZT_NETWORK_ID" | grep -q ACCESS_DENIED && { echo ACCESS_DENIED; return 2; }
    echo "$NET" | grep -q "$ZT_NETWORK_ID" && { echo JOINED; return 1; }
    echo MISSING
    return 1
}

zt_wait_network() {
    HOME="$1"
    I=0
    while [ "$I" -lt 120 ]; do
        STATE="$(zt_network_state "$HOME")"
        [ "$STATE" = "OK" ] && return 0
        [ "$STATE" = "ACCESS_DENIED" ] && return 2
        sleep 5
        I=$((I+5))
    done
    return 1
}

zt_device() {
    zt_networks "$1" | awk -v n="$ZT_NETWORK_ID" '$3==n{print $(NF-1);exit}'
}

zt_ip() {
    DEV="$(zt_device "$1")"
    [ -n "$DEV" ] && [ "$DEV" != "-" ] || return 1
    ip -4 addr show "$DEV" 2>/dev/null | awk '/inet /{split($2,a,"/");print a[1];exit}'
}

zt_wait_ip() {
    HOME="$1"
    I=0
    while [ "$I" -lt 120 ]; do
        IP="$(zt_ip "$HOME")"
        [ -n "$IP" ] && { echo "$IP"; return 0; }
        sleep 5
        I=$((I+5))
    done
    return 1
}

zt_route_ok() {
    DEV="$(zt_device "$1")"
    [ -n "$DEV" ] && ip route 2>/dev/null | grep -q "dev $DEV"
}

zt_validate_network_mapping() {
    HOME="$1"
    STATE="$(zt_network_state "$HOME")"
    [ "$STATE" = "OK" ] || return 0
    DEV="$(zt_device "$HOME")"
    [ -n "$DEV" ] && [ "$DEV" != "-" ] || return 1
    IP="$(zt_ip "$HOME")"
    [ -n "$IP" ]
}

zt_repair_if_needed() {
    LOG="${1:-/tmp/matrix_zerotier_state.log}"

    HOME="$(zt_detect_home)"
    if [ -n "$HOME" ]; then
        CURRENT="$(zt_node_id "$HOME")"
        EXPECTED="$(zt_expected_node_id)"

        # Healthy runtime and no mismatch.
        if [ -z "$EXPECTED" ] || [ "$CURRENT" = "$EXPECTED" ]; then
            zt_backup_identity "$HOME" >/dev/null 2>&1 || true
            echo "$HOME"
            return 0
        fi

        echo "Node ID mismatch: current=$CURRENT expected=$EXPECTED" >>"$LOG"
    fi

    # Reprovisioning restores a saved secret into UCI when available.
    zt_service_stop >/dev/null 2>&1 || true
    HOME="$(zt_provision "$LOG")" || return 1

    CURRENT="$(zt_node_id "$HOME")"
    EXPECTED="$(zt_expected_node_id)"
    [ -n "$EXPECTED" ] && [ "$CURRENT" != "$EXPECTED" ] && {
        echo "Identity restore failed: current=$CURRENT expected=$EXPECTED" >>"$LOG"
        return 1
    }

    echo "$HOME"
}
