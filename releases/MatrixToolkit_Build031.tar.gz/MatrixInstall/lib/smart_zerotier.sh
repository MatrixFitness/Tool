#!/bin/sh
# Matrix Smart ZeroTier Detection - Build 031

matrix_zt_binary_present() {
    [ -x /usr/local/usr/bin/zerotier-one ] || [ -x /usr/bin/zerotier-one ]
}

matrix_zt_cli_present() {
    [ -x /usr/local/usr/bin/zerotier-cli ] || [ -x /usr/bin/zerotier-cli ]
}

matrix_zt_package_present() {
    opkg list-installed 2>/dev/null | awk '{print $1}' | grep -qx 'zerotier'
}

matrix_zt_service_present() {
    [ -x /etc/init.d/zerotier ]
}

matrix_zt_runtime_responsive() {
    matrix_zt_cli_present || return 1

    if [ -x /usr/local/usr/bin/zerotier-cli ]; then
        CLI=/usr/local/usr/bin/zerotier-cli
    else
        CLI=/usr/bin/zerotier-cli
    fi

    for H in \
        /var/run/zerotier/lib/zerotier-one \
        /var/run/zerotier/lib/zerotier-one_* \
        /tmp/run/zerotier \
        /etc/zerotier \
        /usr/local/matrix/zerotier
    do
        [ -e "$H" ] || continue
        "$CLI" -D"$H" info 2>/dev/null | grep -q '^200 info ' && return 0
    done

    return 1
}

matrix_zt_present() {
    matrix_zt_package_present && return 0
    matrix_zt_binary_present && return 0
    matrix_zt_service_present && return 0
    matrix_zt_runtime_responsive && return 0
    return 1
}

matrix_zt_install_if_missing() {
    MODE="${1:-normal}"
    LOG="${2:-/tmp/matrix_zerotier_install.log}"

    if matrix_zt_present; then
        echo "ZeroTier already present; package installation skipped." >>"$LOG"
        return 0
    fi

    echo "ZeroTier is genuinely missing; installing package..." >>"$LOG"

    opkg update >>"$LOG" 2>&1 || {
        echo "opkg update failed." >>"$LOG"
        [ "$MODE" = "firmware" ] && return 1
        return 2
    }

    opkg install zerotier >>"$LOG" 2>&1 || {
        echo "opkg install zerotier failed." >>"$LOG"
        [ "$MODE" = "firmware" ] && return 1
        return 2
    }

    matrix_zt_present
}
