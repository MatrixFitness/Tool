#!/bin/sh
VERSION_FILE="/usr/local/matrix/version.txt"
BUILD="$(grep '^Build=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
EDITION="$(grep '^Edition=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
[ -z "$BUILD" ] && BUILD="012"
[ -z "$EDITION" ] && EDITION="Production Edition"

PASS=0; FAIL=0; WARN=0
line(){ printf "%-42s %s\n" "$1" "$2"; }
ok(){ line "$1" "OK"; PASS=$((PASS+1)); }
fail(){ line "$1" "FAIL  -> $2"; FAIL=$((FAIL+1)); }
warn(){ line "$1" "WARNING  -> $2"; WARN=$((WARN+1)); }

echo "======================================"
echo " MATRIX DOCTOR"
echo " $EDITION"
echo " Build $BUILD"
echo "======================================"

[ -d /usr/local/matrix ] && ok "Matrix folder" || fail "Matrix folder" "missing"
[ -d /usr/local/matrix/web ] && ok "Toolkit web folder" || fail "Toolkit web folder" "missing"
[ -d /usr/local/matrix/adminweb ] && ok "Admin web folder" || fail "Admin web folder" "missing"
[ -f /usr/local/matrix/version.txt ] && ok "Version file" || fail "Version file" "missing"
[ -f /usr/local/matrix/web/index.html ] && ok "Toolkit index" || fail "Toolkit index" "missing"
[ -f /usr/local/matrix/adminweb/cgi-bin/admin_login.sh ] && ok "Admin login" || fail "Admin login" "missing"
[ -f /usr/local/matrix/web/cgi-bin/wifi_manager.sh ] && ok "WiFi Manager" || warn "WiFi Manager" "missing"
[ -f /usr/local/matrix/web/cgi-bin/wifi_survey.sh ] && ok "WiFi Survey" || warn "WiFi Survey" "missing"

BAD_CGI="$(find /usr/local/matrix/web/cgi-bin /usr/local/matrix/adminweb/cgi-bin -type f -name '*.sh' ! -perm -111 2>/dev/null | head -1)"
[ -z "$BAD_CGI" ] && ok "CGI executable" || fail "CGI executable" "$BAD_CGI"

[ -x /usr/local/bin/matrix-update ] && ok "CLI matrix-update" || fail "CLI matrix-update" "missing"
[ -x /usr/local/bin/matrix-version ] && ok "CLI matrix-version" || fail "CLI matrix-version" "missing"
[ -x /usr/local/bin/matrix-zerotier ] && ok "CLI matrix-zerotier" || warn "CLI matrix-zerotier" "missing"

ps | grep '[u]httpd' >/dev/null 2>&1 && ok "uhttpd running" || fail "uhttpd running" "not running"
netstat -lntp 2>/dev/null | grep -q ':8080' && ok "Toolkit port 8080" || fail "Toolkit port 8080" "not listening"
netstat -lntp 2>/dev/null | grep -q ':8081' && ok "Admin port 8081" || fail "Admin port 8081" "not listening"

[ -x /usr/local/matrix/matrix_update_worker.sh ] && ok "Update worker" || fail "Update worker" "missing"
crontab -l 2>/dev/null | grep -q '/usr/local/matrix/matrix_update_worker.sh' && ok "Cron worker" || fail "Cron worker" "matrix_update_worker.sh missing"

[ -f /usr/local/matrix/web/cgi-bin/update_github.sh ] && /bin/sh -n /usr/local/matrix/web/cgi-bin/update_github.sh 2>/dev/null && ok "Update wrapper syntax" || fail "Update wrapper syntax" "update_github.sh"
[ -f /usr/local/matrix/adminweb/cgi-bin/update_github.sh ] && /bin/sh -n /usr/local/matrix/adminweb/cgi-bin/update_github.sh 2>/dev/null && ok "Admin update wrapper syntax" || fail "Admin update wrapper syntax" "admin update"

uci show firewall 2>/dev/null | grep -q '8080' && ok "Firewall 8080" || warn "Firewall 8080" "rule not found"
uci show firewall 2>/dev/null | grep -q '8081' && ok "Firewall 8081" || warn "Firewall 8081" "rule not found"

ZTCLI=""
[ -x /usr/local/usr/bin/zerotier-cli ] && ZTCLI="/usr/local/usr/bin/zerotier-cli"
[ -z "$ZTCLI" ] && command -v zerotier-cli >/dev/null 2>&1 && ZTCLI="$(command -v zerotier-cli)"
[ -n "$ZTCLI" ] && ok "ZeroTier package" || fail "ZeroTier package" "zerotier-cli missing"
ps | grep '[z]erotier-one' >/dev/null 2>&1 && ok "ZeroTier daemon" || warn "ZeroTier daemon" "not running"
uci show network 2>/dev/null | grep -q 'zerotier' && ok "ZeroTier UCI interface" || warn "ZeroTier UCI interface" "not configured"

INFO=""; NETS=""
try_zt(){
    H="$1"
    [ -z "$ZTCLI" ] && return 1
    if [ -n "$H" ]; then
        I="$("$ZTCLI" -D"$H" info 2>/dev/null)"
        N="$("$ZTCLI" -D"$H" listnetworks 2>/dev/null)"
    else
        I="$("$ZTCLI" info 2>/dev/null)"
        N="$("$ZTCLI" listnetworks 2>/dev/null)"
    fi
    echo "$I" | grep -q '^200 info' || return 1
    INFO="$I"; NETS="$N"
    return 0
}
try_zt "/etc/zerotier" || try_zt "/usr/local/matrix/zerotier" || try_zt ""

NODE_ID="$(echo "$INFO" | awk '/^200 info/ {print $3; exit}')"
echo "$INFO" | grep -q 'ONLINE' && ok "ZeroTier online" || warn "ZeroTier online" "not ONLINE"
[ -n "$NODE_ID" ] && ok "ZeroTier Node ID" || warn "ZeroTier Node ID" "unknown"
echo "$NETS" | grep -q 'cf719fd5409699a2' && ok "ZeroTier network joined" || warn "ZeroTier network joined" "network not shown"
echo "$NETS" | grep 'cf719fd5409699a2' | grep -q ' OK ' && ok "ZeroTier authorization" || warn "ZeroTier authorization" "not OK or unknown"

ZT_IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')"
[ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr 2>/dev/null | awk '/10\.74\./ {split($2,a,"/"); print a[1]; exit}')"
[ -n "$ZT_IP" ] && ok "ZeroTier IPv4 address" || fail "ZeroTier IPv4 address" "no 10.74.x.x address"
ip route | grep -q '10.74.91.0/24' && ok "ZeroTier subnet route" || warn "ZeroTier subnet route" "missing"

if [ -n "$ZT_IP" ]; then
    wget -qO- -T 5 "http://$ZT_IP:8081/cgi-bin/admin_login.sh" >/dev/null 2>&1 && ok "ZeroTier local admin web test" || warn "ZeroTier local admin web test" "wait/retry"
    wget -qO- -T 5 "http://$ZT_IP:8080" >/dev/null 2>&1 && ok "ZeroTier local toolkit web test" || warn "ZeroTier local toolkit web test" "wait/retry"
else
    warn "ZeroTier local admin web test" "no IP"
    warn "ZeroTier local toolkit web test" "no IP"
fi

ip route | grep -q '^default' && ok "WAN route" || fail "WAN route" "no default route"
wget -qO- -T 5 http://127.0.0.1:8080 >/dev/null 2>&1 && ok "Local Toolkit response" || fail "Local Toolkit response" "no response"
wget -qO- -T 5 http://127.0.0.1:8081/cgi-bin/admin_login.sh >/dev/null 2>&1 && ok "Local Admin response" || fail "Local Admin response" "no response"

uci show uhttpd 2>/dev/null | grep -q "lua_prefix='='" && fail "uhttpd Lua prefix" "invalid '=' found" || ok "uhttpd Lua prefix"

echo "======================================"
echo "PASS: $PASS"
echo "FAIL: $FAIL"
echo "WARN: $WARN"
[ "$FAIL" -eq 0 ] && echo "SYSTEM HEALTH: OK" || echo "SYSTEM HEALTH: REPAIR ADVISED"
[ -n "$NODE_ID" ] && echo "ZeroTier Node ID: $NODE_ID"
[ -n "$ZT_IP" ] && echo "Toolkit ZeroTier URL: http://$ZT_IP:8080" && echo "Admin ZeroTier URL: http://$ZT_IP:8081/cgi-bin/admin_login.sh"
echo "======================================"
