#!/bin/sh
printf 'Content-Type: text/html; charset=UTF-8\r\n\r\n'
MATRIX_DIR=/usr/local/matrix
VERSION_FILE="$MATRIX_DIR/version.txt"; [ -f "$VERSION_FILE" ] || VERSION_FILE="$(dirname "$0")/../version.txt"
CLUB_FILE="$MATRIX_DIR/clubname.txt"; [ -f "$CLUB_FILE" ] || CLUB_FILE="$(dirname "$0")/../clubname.txt"
getv(){ grep "^$1=" "$VERSION_FILE" 2>/dev/null | head -1 | cut -d= -f2-; }
esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
param(){ printf '%s' "$QUERY_STRING" | tr '&' '\n' | sed -n "s/^$1=//p" | head -1 | sed 's/+/ /g;s/%20/ /g'; }
num(){ case "$1" in ''|*[!0-9]*) echo 0;; *) echo "$1";; esac; }
have(){ command -v "$1" >/dev/null 2>&1; }
BUILD="$(getv Build)"; [ -n "$BUILD" ] || BUILD=050
MODE="$(param mode)"; case "$MODE" in matrix|egym|both) ;; *) MODE=both;; esac
CLUB="$(param club)"; [ -n "$CLUB" ] || CLUB="$(cat "$CLUB_FILE" 2>/dev/null | head -1)"
CARDIO="$(num "$(param cardio)")"; EGYM_COUNT="$(num "$(param egym)")"
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"
RUN_DATE="$(date '+%d-%m-%Y %H:%M:%S %Z' 2>/dev/null || date)"
B_PASS=0; B_INFO=0; B_WARN=0; B_FAIL=0; M_PASS=0; M_INFO=0; M_WARN=0; M_FAIL=0; E_PASS=0; E_INFO=0; E_WARN=0; E_FAIL=0
B_ROWS=''; M_ROWS=''; E_ROWS=''
add(){ G="$1"; S="$2"; T="$3"; ST="$4"; D="$5"; case "$ST" in PASS) C=pass; L=PASS;; INFO) C=info; L=INFO;; WARN) C=warn; L=LET\ OP;; FAIL) C=fail; L=FAIL;; esac; R="<tr><td>$(esc "$S")</td><td><code>$(esc "$T")</code></td><td><span class='badge $C'>$L</span></td><td>$(esc "$D")</td></tr>"; eval "${G}_ROWS=\"\${${G}_ROWS}\$R\""; eval "${G}_${ST}=\$(( ${G}_${ST}+1 ))"; }
ping1(){ timeout 3 ping -c 1 -W 2 "$1" >/dev/null 2>&1; }
dns(){ nslookup "$1" >/dev/null 2>&1; }
https(){ H="$1"; if have curl; then timeout 7 curl -k -sS -o /dev/null --connect-timeout 4 --max-time 6 "https://$H/" >/dev/null 2>&1; return $?; fi; if have wget; then timeout 7 wget --no-check-certificate -q -T 5 -O /dev/null "https://$H/" >/dev/null 2>&1; return $?; fi; return 127; }
tcp443(){ H="$1"; if have nc; then timeout 4 nc -z -w 3 "$H" 443 >/dev/null 2>&1; return $?; fi; if have curl; then timeout 4 curl -sS --connect-timeout 3 "telnet://$H:443" >/dev/null 2>&1; return $?; fi; return 127; }
ROUTE="$(ip route 2>/dev/null | grep '^default ' | head -1)"; [ -n "$ROUTE" ] && add B Standaardroute "$(echo "$ROUTE"|awk '{print $3" via "$5}')" PASS "WAN-route aanwezig" || add B Standaardroute "default gateway" FAIL "Geen standaardroute gevonden"
ping1 1.1.1.1 && add B "Internet zonder DNS" 1.1.1.1 PASS "Extern IP-adres bereikbaar" || add B "Internet zonder DNS" 1.1.1.1 WARN "Geen ping-reactie; ICMP kan geblokkeerd zijn"
dns example.com && add B DNS-resolutie systeem-DNS PASS "Domeinnaam kan worden vertaald" || add B DNS-resolutie systeem-DNS FAIL "Domeinnaam kan niet worden vertaald"
https www.google.com; RC=$?; [ "$RC" -eq 0 ] && add B "Uitgaand HTTPS" "TCP 443" PASS "HTTPS-verkeer werkt" || add B "Uitgaand HTTPS" "TCP 443" FAIL "Geen uitgaande HTTPS-verbinding"
matrix_check(){ L="$1"; H="$2"; CRIT="$3"; dns "$H" || { add M "$L" "$H" FAIL "DNS-resolutie mislukt"; return; }; https "$H"; R=$?; if [ "$R" -eq 0 ]; then add M "$L" "$H" PASS "DNS en HTTPS bereikbaar"; elif [ "$R" -eq 127 ]; then add M "$L" "$H" WARN "DNS werkt; geen HTTPS-testprogramma beschikbaar"; elif [ "$CRIT" = yes ]; then add M "$L" "$H" FAIL "DNS werkt, maar HTTPS reageert niet"; else add M "$L" "$H" WARN "DNS werkt; webservice geeft geen directe reactie"; fi; }
if [ "$MODE" = matrix ] || [ "$MODE" = both ]; then
matrix_check "Cloud API" dapi.jfit.co yes
matrix_check "Orion service" orion.jfit.co yes
matrix_check "Console communication" console-event-service-prod.jfit.co no
matrix_check "Console settings" console-settings-store.jfit.co yes
matrix_check "Asset configuration" config.jhtassets.com yes
matrix_check "Asset images" images.jhtassets.com no
matrix_check "Location service" location-ip.jfit.co yes
matrix_check "Asset Management" am4.matrixfitness.com yes
matrix_check "Asset Management API" am4-api.jfit.co yes
matrix_check "Workout service" mwtn.jfit.co no
matrix_check "Personal training" pt-client.jfit.co no
fi
egym_check(){ L="$1"; IP="$2"; tcp443 "$IP" && { add E "$L" "$IP" PASS "TCP/443 bereikbaar; route werkt"; return; }; ping1 "$IP" && { add E "$L" "$IP" INFO "Ping reageert, maar deze losse TCP-test bevestigt de EGYM-dienst niet"; return; }; add E "$L" "$IP" INFO "Geen directe reactie. Cloudservers mogen ping en losse poorttests negeren; dit is geen bewezen blokkade"; }
if [ "$MODE" = egym ] || [ "$MODE" = both ]; then
for IP in 104.199.66.167 35.189.221.132 104.199.91.64 146.148.19.217 104.155.57.166 146.148.15.175 3.127.32.71 18.156.48.111 3.124.243.61 52.37.226.173 35.84.145.167 35.81.42.122; do egym_check "Training, updates en toestelstatus" "$IP"; done
for IP in 35.198.87.78 212.114.251.94 192.158.31.31; do egym_check "Remote maintenance" "$IP"; done
fi
score(){ T=$1; P=$2; I=$3; W=$4; [ "$T" -eq 0 ] && { echo 0; return; }; echo $((((P+I)*100+W*50)/T)); }
status(){ [ "$1" -gt 0 ] && { echo CRITICAL; return; }; [ "$2" -gt 0 ] && { echo ATTENTION; return; }; echo GOOD; }
BT=$((B_PASS+B_INFO+B_WARN+B_FAIL)); MT=$((M_PASS+M_INFO+M_WARN+M_FAIL)); ET=$((E_PASS+E_INFO+E_WARN+E_FAIL))
BS="$(score "$BT" "$B_PASS" "$B_INFO" "$B_WARN")"; MS="$(score "$MT" "$M_PASS" "$M_INFO" "$M_WARN")"; ES="$(score "$ET" "$E_PASS" "$E_INFO" "$E_WARN")"
BST="$(status "$B_FAIL" "$B_WARN")"; MST="$(status "$M_FAIL" "$M_WARN")"; EST="$(status "$E_FAIL" "$E_WARN")"
OVERALL=GOOD
case "$MODE" in
 matrix) TITLE="Matrix Connectivity Report"; TEXT="Netwerk geschikt voor Matrix."; [ "$B_FAIL" -gt 0 ] || [ "$M_FAIL" -gt 0 ] && { OVERALL=CRITICAL; TEXT="Actie nodig: basisnetwerk of een kritische Matrix-service faalt."; }; [ "$OVERALL" = GOOD ] && { [ "$B_WARN" -gt 0 ] || [ "$M_WARN" -gt 0 ]; } && { OVERALL=ATTENTION; TEXT="Matrix is bereikbaar, maar controleer de waarschuwingen."; };;
 egym) TITLE="EGYM Connectivity Report"; TEXT="De basisverbinding werkt. De EGYM IP-controles zijn alleen aanvullende technische informatie."; [ "$B_FAIL" -gt 0 ] && { OVERALL=CRITICAL; TEXT="Actie nodig: het basisnetwerk faalt."; }; [ "$OVERALL" = GOOD ] && [ "$B_WARN" -gt 0 ] && { OVERALL=ATTENTION; TEXT="De basisverbinding werkt, maar controleer de netwerkwaarschuwing."; };;
 both) TITLE="Matrix & EGYM Site Report"; TEXT="Netwerk geschikt voor Matrix en indicatief geschikt voor EGYM."; [ "$B_FAIL" -gt 0 ] || [ "$M_FAIL" -gt 0 ] && { OVERALL=CRITICAL; TEXT="Actie nodig: basisnetwerk of een kritische Matrix-service faalt."; }; [ "$OVERALL" = GOOD ] && { [ "$B_WARN" -gt 0 ] || [ "$M_WARN" -gt 0 ] || [ "$E_WARN" -gt 0 ]; } && { OVERALL=ATTENTION; TEXT="Basisverbinding werkt, maar controleer de relevante waarschuwingen en test de apparatuur in de praktijk."; };;
esac
cat <<HTML
<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>$(esc "$TITLE")</title><style>
:root{--blue:#0878d1;--dark:#123a63;--bg:#eef3f8;--line:#d7e1eb;--green:#17833a;--red:#b42318;--orange:#d97706;--muted:#667085}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial;color:#172033}.page{max-width:1180px;margin:auto;padding:16px}.hero{background:linear-gradient(135deg,var(--dark),var(--blue));color:#fff;border-radius:20px;padding:18px 22px}.hero-main{display:grid;grid-template-columns:190px 1fr;gap:20px;align-items:center}.report-logo{width:190px;height:58px;object-fit:contain;background:#fff;border-radius:10px;padding:8px}.hero h1{margin:0 0 7px;font-size:31px;line-height:1.1}.meta-row{display:flex;flex-wrap:wrap;gap:4px 8px;align-items:center;font-size:15px;line-height:1.45}.meta-item:not(:last-child)::after{content:" |";font-weight:400;opacity:.8;margin-left:8px}.actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:12px;margin-left:210px}.btn{display:inline-block;background:#fff;color:#075f9d;text-decoration:none;border:0;border-radius:10px;padding:10px 14px;font-weight:800;cursor:pointer}.card{background:#fff;border:1px solid var(--line);border-radius:17px;padding:18px;margin-top:15px}.result{display:grid;grid-template-columns:auto 1fr;gap:16px;align-items:center}.status-chip{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:9px 14px;font-size:15px;font-weight:900;white-space:nowrap}.status-chip:before{content:"";width:10px;height:10px;border-radius:50%;background:currentColor}.status-chip.GOOD{background:#e3f6e9;color:var(--green)}.status-chip.ATTENTION{background:#fff1cf;color:#9a5b00}.status-chip.CRITICAL{background:#fde8e8;color:var(--red)}.result h2{margin:0 0 6px}.result p{margin:4px 0}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:15px}.kpi{background:#fff;border:1px solid var(--line);border-radius:15px;padding:16px}.score{font-size:32px;font-weight:900}.badge{display:inline-block;padding:5px 8px;border-radius:999px;font-size:12px;font-weight:900}.badge.pass{background:#e3f6e9;color:#176b2c}.badge.info{background:#eaf3fa;color:#075f9d}.badge.warn{background:#fff1cf;color:#8b5700}.badge.fail,.badge.critical{background:#fde8e8;color:#a51f1f}.badge.good{background:#e3f6e9;color:#176b2c}.badge.attention{background:#fff1cf;color:#8b5700}.table{overflow:auto;border:1px solid var(--line);border-radius:12px}table{border-collapse:collapse;width:100%;min-width:720px}th,td{padding:10px;border-bottom:1px solid var(--line);text-align:left}th{background:#eaf3fa}tbody tr:nth-child(even){background:#f8fbfd}tbody tr:hover{background:#eef6fb}.muted{color:var(--muted)}details{margin-top:14px;border:1px solid var(--line);border-radius:12px;overflow:hidden}summary{cursor:pointer;padding:13px 15px;background:#f4f8fb;color:#075f9d;font-weight:900}details .table{border:0;border-radius:0}@media(max-width:720px){.page{padding:10px}.hero-main{grid-template-columns:1fr}.report-logo{width:175px}.actions{margin-left:0}.meta-row{display:block}.meta-item{display:block}.meta-item:not(:last-child)::after{content:""}.result,.kpis{grid-template-columns:1fr}.btn{width:100%;text-align:center}}
@page{size:A4 portrait;margin:9mm 9mm 11mm}@media print{html,body{width:100%;background:#fff;font-size:10.5px}.page{max-width:none;padding:0}.actions,.form{display:none}.hero{background:#fff!important;color:#172033!important;border:0;border-bottom:2px solid var(--line);border-radius:0;padding:0 0 7px;margin:0}.hero-main{grid-template-columns:130px 1fr;gap:10px}.report-logo{width:125px;height:36px;max-height:36px;padding:0;background:transparent;border-radius:0}.hero h1{font-size:20px;color:#075f9d;margin-bottom:4px}.meta-row{font-size:9.5px;gap:2px 5px;line-height:1.25}.meta-item:not(:last-child)::after{margin-left:5px}.card,.kpi,.hero{box-shadow:none}.card{border-radius:9px;padding:9px;margin-top:7px;break-inside:avoid;page-break-inside:avoid}.result{grid-template-columns:auto 1fr;gap:9px}.status-chip{padding:5px 8px;font-size:10px}.status-chip:before{width:7px;height:7px}.result h2,.card h2,.kpi h2{margin:0 0 4px;font-size:14px}.result p,.card p{margin:3px 0}.kpis{grid-template-columns:repeat(3,1fr);gap:6px;margin-top:7px;break-inside:avoid;page-break-inside:avoid}.kpi{border-radius:8px;padding:8px;break-inside:avoid;page-break-inside:avoid}.score{font-size:21px}.badge{padding:3px 6px;font-size:8.5px}.table{overflow:visible;border-radius:7px}table{min-width:0;font-size:8px;table-layout:fixed;margin:0}thead{display:table-header-group}tr{break-inside:avoid;page-break-inside:avoid}th,td{padding:4px 5px;overflow-wrap:anywhere}th:nth-child(1),td:nth-child(1){width:24%}th:nth-child(2),td:nth-child(2){width:24%}th:nth-child(3),td:nth-child(3){width:13%}th:nth-child(4),td:nth-child(4){width:39%}details{break-inside:avoid;page-break-inside:avoid;margin-top:7px}summary{padding:7px 9px}.muted{font-size:9px}.card ul{margin:3px 0;padding-left:17px}.card li{margin:1px 0}body:after{content:'Matrix Fitness - Matrix Toolkit Build $(esc "$BUILD")';display:block;margin-top:6px;padding-top:4px;border-top:1px solid var(--line);font-size:8px;color:#667085}}
}</style></head><body><div class="page"><section class="hero"><div class="hero-main"><img class="report-logo" src="/matrix_logo.png" alt="Matrix Fitness"><div><h1>$(esc "$TITLE")</h1><div class="meta-row"><span class="meta-item"><b>Router:</b> $(esc "$HOST")</span><span class="meta-item"><b>Toolkit:</b> Build $(esc "$BUILD") Stable</span><span class="meta-item"><b>Locatie:</b> $(esc "${CLUB:-Niet ingevuld}")</span><span class="meta-item"><b>Testmoment:</b> $(esc "$RUN_DATE")</span></div></div></div><div class="actions"><a class="btn" href="/cgi-bin/index.sh">Terug</a><button class="btn" onclick="window.print()">Print / Bewaar als PDF</button><a class="btn" href="/cgi-bin/connectivity_report.sh?mode=$MODE&amp;club=$(esc "$CLUB")&amp;cardio=$CARDIO&amp;egym=$EGYM_COUNT">Test opnieuw</a></div></section><section class="card result"><div><span class="status-chip $OVERALL">$OVERALL</span></div><div><h2>Eindconclusie</h2><p>$(esc "$TEXT")</p><p class="muted">Een routertest kan niet bevestigen dat iedere applicatiefunctie werkt. Bevestig het eindresultaat daarom altijd met een praktijktest op een toestel.</p></div></section><div class="kpis"><div class="kpi"><h2>Basisnetwerk</h2><div class="score">$BS%</div><span class="badge $(echo "$BST"|tr A-Z a-z)">$BST</span></div>
HTML
[ "$MODE" = matrix ] || [ "$MODE" = both ] && echo "<div class='kpi'><h2>Matrix</h2><div class='score'>$MS%</div><span class='badge $(echo "$MST"|tr A-Z a-z)'>$MST</span></div>"
[ "$MODE" = egym ] || [ "$MODE" = both ] && echo "<div class='kpi'><h2>EGYM</h2><div class='score'>$ES%</div><span class='badge $(echo "$EST"|tr A-Z a-z)'>$EST</span></div>"
echo "</div>"
section "Basisnetwerk" "$BASIC"
[ "$MODE" = matrix ] || [ "$MODE" = both ] && section "Matrix Connectivity" "$MATRIX"
[ "$MODE" = egym ] || [ "$MODE" = both ] && {
cat <<HTML
<section class="card"><h2>EGYM Connectivity</h2><p><b>Basisnetwerk:</b> $BST &nbsp; <b>Uitgaand HTTPS:</b> wordt hierboven gecontroleerd.</p><p>Geen reactie van een individueel cloud-IP is geen foutmelding. Open de technische details alleen bij diepere diagnose.</p><details><summary>Toon technische IP-details</summary><div class="table"><table><thead><tr><th>Controle</th><th>Doel</th><th>Status</th><th>Uitleg</th></tr></thead><tbody>
HTML
section_rows "$EGYM"
echo "</tbody></table></div></details></section>"
}
cat <<HTML
<section class="card"><h2>Monteursadvies</h2><ul><li>Voer een praktijktest uit op een toestel: aanmelden, synchronisatie, updatecontrole en remote maintenance.</li></ul></section></div></body></html>
HTML
