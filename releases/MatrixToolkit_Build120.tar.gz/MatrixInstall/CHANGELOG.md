Build 071 - 2026-08-24
- Fix: standard WiFi/network policy is now automatically applied during every install/update.
- 2.4 GHz is forced enabled as egym.
- 5 GHz is forced enabled as JNLMatrix_5G / JBEMatrix_5G / JDEMatrix_5G based on router hostname.
- Mobile SIM1 is primary Internet; Ethernet WAN remains enabled as fallback.


Build 060 - Connectivity Report Detail Rendering Fix
- Fixed empty Basis Network, Matrix and EGYM report tables.
- Restored detailed test results and added summary counters.
Build 058 - 2026-07-19
- Compact report header and aligned single-row metadata.
- Smaller conclusion status chip for GOOD, ATTENTION and CRITICAL.
- Admin Change Password redesigned to match Admin Login.
- Official Matrix logo preserved as baseline.
- Build 057 Customer WiFi layout and all Build 056 fixes retained.

# Matrix Toolkit v59.5

## Changed
- Added stable WiFi Manager integration without changing the existing USB install flow.
- WiFi Manager now uses `/usr/local/matrix/matrix_wifi_profiles.conf` as the active local profile file.
- Local profile edits are preserved during GitHub updates.
- Missing WiFi profile files are automatically created.
- Older test location `/usr/local/matrix/config/matrix_wifi_profiles.conf` is migrated if found.

## Fixed
- Edit Profiles save now writes back to the active profile file.
- Applying a WiFi profile no longer shows a false error when `wifi reload` returns a non-zero code but the SSID was applied.
- Restore Default Profiles recreates defaults if the default file is missing.

## Build 047 - 2026-07-18
- Added a unified Matrix & EGYM Connectivity Report.
- Added separate network, Matrix and EGYM scoring with a technician conclusion.
- Added print/save-as-PDF report layout and bandwidth recommendation.
- Removed duplicate test tiles while keeping legacy URLs as safe redirects.

## Build 072 - 2026-08-24
- Fixed network standard not being applied by Matrix Cloud Update.
- Integrated `matrix-network-standard` directly into transactional `matrix-recovery`.
- Added verification for 2.4 GHz `egym`, country-specific 5 GHz Matrix SSID, Mobile metric 1 and WAN metric 10.

## Build 073 - 2026-08-24
- Enforces `matrix-network-standard` from the freshly staged package in transactional recovery.
- Runs and verifies the network standard again in bootstrap after recovery.
- Update now fails if `egym`, Mobile metric 1, or WAN metric 10 are not active.

## Build 093 - 2026-09-12
- Fixed Matrix Doctor ZeroTier recovery when the ZeroTier package is missing.
- `opkg update` is now best-effort so a missing optional/custom RutOS feed cannot block an otherwise valid Teltonika package install.
- `opkg install zerotier` is always attempted after the refresh step and its actual result is authoritative.
- Existing ZeroTier UCI configuration is safeguarded during package installation.
- Package, init service and binaries are verified before the existing ZeroTier provisioning/self-heal continues.
