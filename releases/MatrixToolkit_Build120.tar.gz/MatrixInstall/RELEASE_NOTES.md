# Matrix Toolkit Build 046

Build 046 is a focused compatibility fix for Mobile Fleet Node ID detection. Existing Toolkit and Admin functionality is retained.

## Build 063
Signal Reference Guide and Mobile Data Recovery.

## Build 093 - ZeroTier Missing Package Auto-Recovery
Matrix Doctor can now install a genuinely missing ZeroTier package even when RutOS reports a non-fatal error for an optional local/custom opkg feed. The existing ZeroTier configuration and identity are preserved, and the normal Matrix provisioning/self-heal path continues after installation.
