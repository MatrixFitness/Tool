#!/bin/sh
# Matrix Admin Authentication Library - Build 027

MATRIX_ADMIN_PASSWORD_FILE="${MATRIX_ADMIN_PASSWORD_FILE:-/usr/local/matrix/admin_password.txt}"
MATRIX_ADMIN_DEFAULT_PASSWORD="${MATRIX_ADMIN_DEFAULT_PASSWORD:-Matrix2025}"
MATRIX_ADMIN_SESSION_DIR="${MATRIX_ADMIN_SESSION_DIR:-/tmp/matrix_admin_sessions}"

matrix_admin_password_valid() {
    [ -s "$MATRIX_ADMIN_PASSWORD_FILE" ]
}

matrix_admin_password_permissions_ok() {
    [ -e "$MATRIX_ADMIN_PASSWORD_FILE" ] || return 1

    MODE="$(stat -c '%a' "$MATRIX_ADMIN_PASSWORD_FILE" 2>/dev/null)"
    OWNER="$(stat -c '%U:%G' "$MATRIX_ADMIN_PASSWORD_FILE" 2>/dev/null)"

    [ "$MODE" = "600" ] && [ "$OWNER" = "root:root" ]
}

matrix_admin_fix_permissions() {
    [ -e "$MATRIX_ADMIN_PASSWORD_FILE" ] || return 1
    chown root:root "$MATRIX_ADMIN_PASSWORD_FILE" 2>/dev/null || true
    chmod 600 "$MATRIX_ADMIN_PASSWORD_FILE" 2>/dev/null || return 1
}

matrix_admin_clear_sessions() {
    rm -rf "$MATRIX_ADMIN_SESSION_DIR" 2>/dev/null || true
}

matrix_admin_ensure_password() {
    REPAIRED=0

    mkdir -p "$(dirname "$MATRIX_ADMIN_PASSWORD_FILE")" || return 1

    if ! matrix_admin_password_valid; then
        umask 077
        printf '%s\n' "$MATRIX_ADMIN_DEFAULT_PASSWORD" > "$MATRIX_ADMIN_PASSWORD_FILE" || return 1
        REPAIRED=1
    fi

    matrix_admin_fix_permissions || return 1

    if [ "$REPAIRED" -eq 1 ]; then
        matrix_admin_clear_sessions
        return 2
    fi

    return 0
}

matrix_admin_restart_web_if_repaired() {
    RC="$1"
    [ "$RC" -eq 2 ] || return 0
    [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd restart >/dev/null 2>&1 || true
}
