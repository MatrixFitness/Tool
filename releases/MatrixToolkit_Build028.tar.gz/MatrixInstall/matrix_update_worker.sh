#!/bin/sh
REQ="/tmp/matrix_update_request"; LOCK="/tmp/matrix_update_worker.lock"; LOG="/tmp/matrix_update_github.log"; TECH="/tmp/matrix_update_technical.log"; STATE="/tmp/matrix_update.state"; PROGRESS="/tmp/matrix_update.progress"; PERSIST="/usr/local/matrix/logs/matrix_update_last_status"; HIST="/usr/local/matrix/logs/update_history.log"
LAST_LOG="/usr/local/matrix/logs/matrix_update_last.log"
PREV_LOG="/usr/local/matrix/logs/matrix_update_previous.log"
BOOTSTRAP_URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/bootstrap.sh"; LATEST_URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/latest.txt"
mkdir -p /usr/local/matrix/logs; [ -f "$REQ" ] || exit 0
if [ -f "$LOCK" ]; then O="$(cat "$LOCK" 2>/dev/null)"; [ -n "$O" ] && kill -0 "$O" 2>/dev/null && exit 0; fi
echo $$ > "$LOCK"; rm -f "$REQ"; START="$(date +%s)"
state(){ echo "$1" > "$STATE"; echo "$2" > "$PROGRESS"; { echo "state=$1"; echo "message=$2"; echo "updated=$(date '+%Y-%m-%d %H:%M:%S')"; } > "$PERSIST"; echo "[$(echo "$1"|tr a-z A-Z)] $2" >> "$LOG"; }
trap 'rm -f "$LOCK"' EXIT INT TERM
: > "$TECH"; : > "$LOG"; state downloading "Reading latest build"
CURRENT="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null|cut -d= -f2-)"; LATEST="$(wget -qO- "$LATEST_URL" 2>>"$TECH"|tr -d '
 ')"
echo "Installed Build : ${CURRENT:-Unknown}" >> "$LOG"; echo "Latest Build    : ${LATEST:-Unknown}" >> "$LOG"
[ -n "$LATEST" ] || { state error "Could not read latest.txt"; exit 1; }
[ "$CURRENT" = "$LATEST" ] && { state success "Already up to date"; exit 0; }
state downloading "Downloading bootstrap"; wget -q -O /tmp/bootstrap.sh "$BOOTSTRAP_URL" >>"$TECH" 2>&1 || { state error "Bootstrap download failed"; exit 1; }; chmod +x /tmp/bootstrap.sh
state installing "Installing Build $LATEST"; SAFE_UPDATE=1 BOOTSTRAP_MODE=update sh /tmp/bootstrap.sh >>"$TECH" 2>&1; C=$?; tail -n 120 "$TECH" >> "$LOG" 2>/dev/null
[ "$C" -eq 0 ] || { state error "Bootstrap failed with code $C"; exit "$C"; }
state web "Reloading Toolkit web service"; [ -x /etc/init.d/uhttpd ] && { /etc/init.d/uhttpd reload >>"$LOG" 2>&1 || /etc/init.d/uhttpd restart >>"$LOG" 2>&1 || true; }; sleep 3
state doctor "Running Matrix Doctor"; /usr/local/bin/matrix-doctor > /tmp/matrix_doctor_after_update.log 2>&1 || true; cat /tmp/matrix_doctor_after_update.log >> "$LOG"
F="$(awk '/^FAIL:/ {print $2}' /tmp/matrix_doctor_after_update.log|tail -1)"; W="$(awk '/^WARN:/ {print $2}' /tmp/matrix_doctor_after_update.log|tail -1)"
if [ "$F" = 0 ]; then END="$(date +%s)"; D=$((END-START)); I="$(grep '^Build=' /usr/local/matrix/version.txt|cut -d= -f2-)"; state success "Build $I completed successfully"; echo "$(date '+%F %T') SUCCESS Build $I Duration ${D}s Warnings ${W:-0}" >> "$HIST"; 
# Build 028 Admin Authentication Recovery
if [ -f /usr/local/matrix/lib/admin_auth.sh ]; then
    . /usr/local/matrix/lib/admin_auth.sh
    matrix_admin_ensure_password
    MATRIX_ADMIN_RC=$?
    matrix_admin_restart_web_if_repaired "$MATRIX_ADMIN_RC"
fi

exit 0; fi
state error "Self-healing Matrix Doctor still reports ${F:-unknown} failure(s)"; exit 1
