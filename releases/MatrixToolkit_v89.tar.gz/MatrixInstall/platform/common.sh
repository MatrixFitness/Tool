#!/bin/sh
MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
ADMIN_DIR="$MATRIX_DIR/adminweb"
ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"

zt_cli() {
    if command -v zerotier-cli >/dev/null 2>&1; then
        zerotier-cli -D/etc/zerotier "$@"
    elif [ -x /usr/local/usr/bin/zerotier-cli ]; then
        /usr/local/usr/bin/zerotier-cli -D/etc/zerotier "$@"
    else
        return 127
    fi
}

zt_one_path() {
    if command -v zerotier-one >/dev/null 2>&1; then
        command -v zerotier-one
    elif [ -x /usr/local/usr/bin/zerotier-one ]; then
        echo /usr/local/usr/bin/zerotier-one
    else
        return 1
    fi
}

get_zt_ip() {
    ip -4 addr 2>/dev/null | awk '/ztd/ && /inet / {split($2,a,"/"); print a[1]; exit}'
}

get_zt_node() {
    if [ -f /etc/zerotier/identity.public ]; then
        cut -d: -f1 /etc/zerotier/identity.public 2>/dev/null
    else
        zt_cli info 2>/dev/null | awk '{print $3; exit}'
    fi
}
