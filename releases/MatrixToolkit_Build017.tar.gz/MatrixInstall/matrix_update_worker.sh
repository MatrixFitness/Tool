#!/bin/sh
REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
LOG="/tmp/matrix_update_github.log"
TECH="/tmp/matrix_update_technical.log"
STATE="/tmp/matrix_update.state"
PROGRESS="/tmp/matrix_update.progress"
PERSIST="/usr/local/matrix/logs/matrix_update_last_status"
HIST="/usr/local/matrix/logs/update_history.log"
BOOTSTRAP_URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/bootstrap.sh"
LATEST_URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/latest.txt"

mkdir -p /usr/local/matrix/logs
[ -f "$REQ" ] || exit 0

if [ -f "$LOCK" ]; then
    OLD="$(cat "$LOCK" 2>/dev/null)"
    [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null && exit 0
fi

echo "$$" > "$LOCK"
rm -f "$REQ"
START="$(date +%s)"

state(){
    echo "$1" > "$STATE"
    echo "$2" > "$PROGRESS"
    {
        echo "state=$1"
        echo "message=$2"
        echo "updated=$(date '+%Y-%m-%d %H:%M:%S')"
    } > "$PERSIST"
}
cleanup(){ rm -f "$LOCK"; }
trap cleanup EXIT INT TERM

: > "$TECH"
state downloading "Reading latest build"
CURRENT="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
LATEST="$(wget -qO- "$LATEST_URL" 2>>"$TECH" | tr -d '\r\n ')"

{
echo "======================================"
echo " MATRIX CLOUD UPDATE"
echo " Production Edition"
echo "======================================"
echo "Started: $(date)"
echo "Installed Build : ${CURRENT:-Unknown}"
echo "Latest Build    : ${LATEST:-Unknown}"
} > "$LOG"

[ -n "$LATEST" ] || { state error "Could not read latest.txt"; exit 1; }

if [ "$CURRENT" = "$LATEST" ]; then
    state success "Already up to date"
    echo "Already up to date." >> "$LOG"
    exit 0
fi

state downloading "Downloading bootstrap"
wget -q -O /tmp/bootstrap.sh "$BOOTSTRAP_URL" >>"$TECH" 2>&1 || {
    state error "Bootstrap download failed"
    exit 1
}
chmod +x /tmp/bootstrap.sh

state installing "Installing Build $LATEST"
BOOTSTRAP_MODE=update sh /tmp/bootstrap.sh >>"$TECH" 2>&1
CODE=$?

echo "" >> "$LOG"
echo "Technical summary:" >> "$LOG"
tail -n 100 "$TECH" >> "$LOG" 2>/dev/null

[ "$CODE" -eq 0 ] || {
    state error "Bootstrap failed with code $CODE"
    exit "$CODE"
}

state zerotier "Checking ZeroTier runtime and network"
/usr/local/bin/matrix-zerotier-state /tmp/matrix_zerotier_state.log >>"$LOG" 2>&1
ZRC=$?
if [ "$ZRC" -eq 2 ]; then
    NODE="$(/usr/local/usr/bin/zerotier-cli -D/tmp/run/zerotier info 2>/dev/null | awk '/^200 info/ {print $3;exit}')"
    state access_denied "Authorize ZeroTier Node ID ${NODE:-unknown}"
    exit 2
fi
[ "$ZRC" -eq 0 ] || {
    state error "ZeroTier validation failed"
    exit 1
}

state doctor "Running Matrix Doctor"
/usr/local/bin/matrix-doctor >>"$LOG" 2>&1 || true

FAILS="$(awk '/^FAIL:/ {print $2}' "$LOG" | tail -1)"
[ "$FAILS" = "0" ] || {
    state error "Matrix Doctor reports ${FAILS:-unknown} failure(s)"
    exit 1
}

END="$(date +%s)"
DUR=$((END-START))
INSTALLED="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
state success "Build $INSTALLED completed successfully"
{
echo "======================================"
echo " UPDATE COMPLETED SUCCESSFULLY"
echo "======================================"
echo "Installed Build : $INSTALLED"
echo "Duration        : ${DUR} sec"
} >>"$LOG"
echo "$(date '+%Y-%m-%d %H:%M:%S') SUCCESS Build $INSTALLED Duration ${DUR}s" >>"$HIST"
exit 0
