#!/bin/sh
ZT_CLI="${ZT_CLI:-/usr/local/usr/bin/zerotier-cli}"
ZT_ONE="${ZT_ONE:-/usr/local/usr/bin/zerotier-one}"
ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
ZT_DEFAULT_HOME="${ZT_DEFAULT_HOME:-/tmp/run/zerotier}"
ZT_PERSIST="${ZT_PERSIST:-/usr/local/matrix/zerotier_identity}"
zt_process_home(){ ps w 2>/dev/null | awk '/[z]erotier-one/{for(i=1;i<=NF;i++){if($i=="-d"&&i<NF){print $(i+1);exit} if($i~/^-d\/|^-d=/){x=$i;sub(/^-d=?/,"",x);print x;exit}}}'; }
zt_info(){ "$ZT_CLI" -D"$1" info 2>/dev/null; }
zt_networks(){ "$ZT_CLI" -D"$1" listnetworks 2>/dev/null; }
zt_home_valid(){ zt_info "$1" | grep -q '^200 info '; }
zt_detect_home(){ PH="$(zt_process_home)"; for H in "$PH" "$ZT_DEFAULT_HOME" /etc/zerotier /usr/local/matrix/zerotier; do [ -n "$H" ] || continue; zt_home_valid "$H" && { echo "$H"; return 0; }; done; return 1; }
zt_node_id(){ zt_info "$1" | awk '/^200 info/{print $3;exit}'; }
zt_status(){ zt_info "$1" | awk '/^200 info/{print $5;exit}'; }
zt_valid_identity(){ [ -s "$1/identity.secret" ] && [ -s "$1/identity.public" ]; }
zt_public_node_id(){ awk -F: 'NF{print $1;exit}' "$1/identity.public" 2>/dev/null; }
zt_expected_node_id(){ if [ -s "$ZT_PERSIST/node_id.txt" ]; then cat "$ZT_PERSIST/node_id.txt"; elif zt_valid_identity "$ZT_PERSIST"; then zt_public_node_id "$ZT_PERSIST"; fi; }
zt_backup_identity_once(){ SRC="$1"; mkdir -p "$ZT_PERSIST"; chmod 700 "$ZT_PERSIST" 2>/dev/null; [ -s "$ZT_PERSIST/identity.secret" ] && return 0; zt_valid_identity "$SRC" || return 1; cp -f "$SRC/identity.secret" "$ZT_PERSIST/identity.secret"; cp -f "$SRC/identity.public" "$ZT_PERSIST/identity.public"; [ -s "$SRC/authtoken.secret" ] && cp -f "$SRC/authtoken.secret" "$ZT_PERSIST/authtoken.secret"; chmod 600 "$ZT_PERSIST/identity.secret" "$ZT_PERSIST/authtoken.secret" 2>/dev/null; chmod 644 "$ZT_PERSIST/identity.public" 2>/dev/null; NODE="$(zt_public_node_id "$ZT_PERSIST")"; [ -n "$NODE" ] && echo "$NODE" > "$ZT_PERSIST/node_id.txt"; }
zt_restore_identity(){ DEST="$1"; zt_valid_identity "$ZT_PERSIST" || return 1; mkdir -p "$DEST"; rm -f "$DEST/identity.secret" "$DEST/identity.public" "$DEST/authtoken.secret" "$DEST/zerotier-one.pid" "$DEST/zerotier-one.port"; cp -f "$ZT_PERSIST/identity.secret" "$DEST/identity.secret"; cp -f "$ZT_PERSIST/identity.public" "$DEST/identity.public"; [ -s "$ZT_PERSIST/authtoken.secret" ] && cp -f "$ZT_PERSIST/authtoken.secret" "$DEST/authtoken.secret"; chmod 600 "$DEST/identity.secret" "$DEST/authtoken.secret" 2>/dev/null; chmod 644 "$DEST/identity.public" 2>/dev/null; }
zt_service_disable(){ [ -x /etc/init.d/matrix_zerotier ] && /etc/init.d/matrix_zerotier disable >/dev/null 2>&1 || true; }
zt_service_enable(){ [ -x /etc/init.d/matrix_zerotier ] && /etc/init.d/matrix_zerotier enable >/dev/null 2>&1 || true; }
zt_service_stop(){ [ -x /etc/init.d/matrix_zerotier ] && /etc/init.d/matrix_zerotier stop >/dev/null 2>&1 || true; [ -x /etc/init.d/zerotier ] && /etc/init.d/zerotier stop >/dev/null 2>&1 || true; }
zt_port_in_use(){ netstat -ln 2>/dev/null | grep -qE '(^|[.:])9993[[:space:]]'; }
zt_wait_stopped(){ I=0; while [ "$I" -lt 25 ]; do if ! ps w 2>/dev/null | grep -q '[z]erotier-one' && ! zt_port_in_use; then return 0; fi; sleep 1; I=$((I+1)); done; return 1; }
zt_hard_stop(){ zt_service_disable; zt_service_stop; killall zerotier-one >/dev/null 2>&1 || true; sleep 2; ps w 2>/dev/null | grep -q '[z]erotier-one' && killall -9 zerotier-one >/dev/null 2>&1 || true; zt_wait_stopped; }
zt_start_one(){ HOME="$1"; mkdir -p "$HOME"; rm -f "$HOME/zerotier-one.pid" "$HOME/zerotier-one.port"; : >/tmp/matrix_zerotier_start.log; "$ZT_ONE" -d "$HOME" >>/tmp/matrix_zerotier_start.log 2>&1 & }
zt_wait_control(){ HOME="$1"; I=0; while [ "$I" -lt 90 ]; do INFO="$(zt_info "$HOME")"; echo "$INFO" | grep -q '^200 info ' && echo "$INFO" | grep -Eq 'ONLINE|TUNNELED' && return 0; sleep 3; I=$((I+3)); done; return 1; }
zt_join_if_missing(){ HOME="$1"; zt_networks "$HOME" | grep -q "$ZT_NETWORK_ID" && return 0; "$ZT_CLI" -D"$HOME" join "$ZT_NETWORK_ID" >/dev/null 2>&1 || true; }
zt_network_state(){ HOME="$1"; NET="$(zt_networks "$HOME")"; echo "$NET" | grep "$ZT_NETWORK_ID" | grep -q ' OK ' && { echo OK; return 0; }; echo "$NET" | grep "$ZT_NETWORK_ID" | grep -q ACCESS_DENIED && { echo ACCESS_DENIED; return 2; }; echo "$NET" | grep -q "$ZT_NETWORK_ID" && { echo JOINED; return 1; }; echo MISSING; return 1; }
zt_wait_network(){ HOME="$1"; I=0; while [ "$I" -lt 120 ]; do S="$(zt_network_state "$HOME")"; [ "$S" = OK ] && return 0; [ "$S" = ACCESS_DENIED ] && return 2; sleep 5; I=$((I+5)); done; return 1; }
zt_device(){ zt_networks "$1" | awk -v n="$ZT_NETWORK_ID" '$2==n{print $7;exit}'; }
zt_ip(){ D="$(zt_device "$1")"; [ -n "$D" ] && [ "$D" != - ] || return 1; ip -4 addr show "$D" 2>/dev/null | awk '/inet /{split($2,a,"/");print a[1];exit}'; }
zt_wait_ip(){ HOME="$1"; I=0; while [ "$I" -lt 120 ]; do IP="$(zt_ip "$HOME")"; [ -n "$IP" ] && { echo "$IP"; return 0; }; sleep 5; I=$((I+5)); done; return 1; }
zt_route_ok(){ D="$(zt_device "$1")"; [ -n "$D" ] && ip route 2>/dev/null | grep -q "dev $D"; }
zt_repair_if_needed(){ LOG="${1:-/tmp/matrix_zerotier_state.log}"; mkdir -p "$ZT_PERSIST" "$ZT_DEFAULT_HOME"; HOME="$(zt_detect_home)"; if [ -n "$HOME" ]; then zt_backup_identity_once "$HOME" || true; CUR="$(zt_node_id "$HOME")"; EXP="$(zt_expected_node_id)"; if [ -z "$EXP" ] || [ -z "$CUR" ] || [ "$CUR" = "$EXP" ]; then echo "$HOME"; return 0; fi; echo "Node ID mismatch: current=$CUR expected=$EXP" >>"$LOG"; else for H in "$ZT_DEFAULT_HOME" /etc/zerotier /usr/local/matrix/zerotier; do zt_backup_identity_once "$H" && break; done; fi; zt_hard_stop || return 1; zt_restore_identity "$ZT_DEFAULT_HOME" || return 1; zt_start_one "$ZT_DEFAULT_HOME"; zt_wait_control "$ZT_DEFAULT_HOME" || return 1; CUR="$(zt_node_id "$ZT_DEFAULT_HOME")"; EXP="$(zt_expected_node_id)"; [ -n "$EXP" ] && [ "$CUR" != "$EXP" ] && return 1; zt_service_enable; echo "$ZT_DEFAULT_HOME"; }
