#!/bin/sh
printf "Content-Type: text/html\n\n"

VERSION_FILE="/usr/local/matrix/version.txt"
[ -f "$VERSION_FILE" ] || VERSION_FILE="/tmp/MatrixInstall/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

PRODUCT="$(get_value Product)"
EDITION="$(get_value Edition)"
BUILD="$(get_value Build)"
BUILDDATE="$(get_value BuildDate)"
STATUS="$(get_value Status)"

[ -z "$PRODUCT" ] && PRODUCT="Matrix Toolkit"
[ -z "$EDITION" ] && EDITION="Production Edition"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$BUILDDATE" ] && BUILDDATE="Unknown"
[ -z "$STATUS" ] && STATUS="Unknown"

DISPLAY_DATE="$BUILDDATE"
case "$BUILDDATE" in
    ????-??-??)
        Y="$(echo "$BUILDDATE" | cut -d- -f1)"
        M="$(echo "$BUILDDATE" | cut -d- -f2)"
        D="$(echo "$BUILDDATE" | cut -d- -f3)"
        DISPLAY_DATE="$D-$M-$Y"
    ;;
esac

ZT_IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Matrix Toolkit Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}
.header{background:white;border-radius:16px;padding:22px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 3px 12px rgba(0,0,0,.08);margin-bottom:18px}
h1{margin:0;color:#00589c}
.logout{background:#666;color:white;text-decoration:none;border-radius:10px;padding:14px 28px;font-weight:bold}
.grid{display:grid;grid-template-columns:repeat(4,minmax(240px,1fr));gap:18px}
.card{background:white;border-radius:16px;padding:18px;box-shadow:0 3px 10px rgba(0,0,0,.07);border-top:7px solid #007bff;min-height:300px}
.card.green{border-top-color:#24a148}.card.purple{border-top-color:#7048c8}.card.orange{border-top-color:#ff7a1a}
.title{font-size:23px;font-weight:800;margin-bottom:6px}
.desc{color:#52606d;margin-bottom:16px}
.btn{display:block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:13px;margin:10px 0;font-weight:bold}
.green .btn{background:#24a148}.purple .btn{background:#7048c8}.orange .btn{background:#ff7a1a}
small{display:block;font-weight:normal;margin-top:4px}
.info{background:white;border-radius:16px;padding:18px;margin-top:18px;box-shadow:0 3px 10px rgba(0,0,0,.07)}
.status{display:inline-block;background:#e6f6ea;color:#0b6b2b;border-radius:999px;padding:6px 12px;font-weight:bold}
@media(max-width:1100px){.grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:650px){.grid{grid-template-columns:1fr}.header{display:block}.logout{display:inline-block;margin-top:16px}}
</style>
</head>
<body>
<div class="header">
<div><h1>Matrix Toolkit Admin</h1><p>Matrix Fitness | Created by Rob Bosman | rob.bosman@matrixfitness.nl</p></div>
<a class="logout" href="/cgi-bin/admin_logout.sh">Logout</a>
</div>

<div class="grid">
<div class="card green">
<div class="title">Toolkit</div>
<div class="desc">Open and test the Matrix Toolkit.</div>
<a class="btn" href="http://__HOST__:8080/index.html">Open Toolkit<small>Port 8080</small></a>
<a class="btn" href="/cgi-bin/about.sh">Toolkit Information<small>Version and system information</small></a>
<a class="btn" href="/cgi-bin/matrix_health.sh">Matrix Health Check<small>Router and internet health</small></a>
</div>

<div class="card">
<div class="title">Cloud Maintenance</div>
<div class="desc">Update, repair and verify the platform.</div>
<a class="btn" href="/cgi-bin/update_github.sh">Cloud Update & Repair<small>Download latest release, run Recovery and Doctor</small></a>
<a class="btn" href="/cgi-bin/matrix_doctor.sh">Run Matrix Doctor<small>Check complete system health</small></a>
<a class="btn" href="/cgi-bin/matrix_recovery.sh">Run Matrix Recovery<small>Repair platform services</small></a>
</div>

<div class="card purple">
<div class="title">ZeroTier</div>
<div class="desc">Remote access, IP address and repair.</div>
<a class="btn" href="/cgi-bin/zerotier_manager.sh">ZeroTier Manager<small>Status, IP address and diagnostics</small></a>
<a class="btn" href="/cgi-bin/zerotier_setup.sh">ZeroTier Repair<small>Repair or restart ZeroTier</small></a>
<a class="btn" href="/cgi-bin/update_github_log.sh">Update Log<small>Show cloud update progress</small></a>
</div>

<div class="card orange">
<div class="title">Backup & Security</div>
<div class="desc">Backups and administrator security.</div>
<a class="btn" href="/cgi-bin/router_config_backup.sh">Router Config Backup<small>Save router configuration</small></a>
<a class="btn" href="/cgi-bin/toolkit_backup.sh">Toolkit Backup<small>Save Toolkit files</small></a>
<a class="btn" href="/cgi-bin/admin_change_password.sh">Change Admin Password<small>Update administrator password</small></a>
</div>
</div>

<div class="info">
<h2>Toolkit Version</h2>
<p><b>$PRODUCT</b></p>
<p>$EDITION | Build $BUILD | $DISPLAY_DATE</p>
<p><span class="status">$STATUS</span></p>
HTML

if [ -n "$ZT_IP" ]; then
cat <<HTML
<p>Toolkit: <a href="http://$ZT_IP:8080">http://$ZT_IP:8080</a></p>
<p>Admin: <a href="http://$ZT_IP:8081/cgi-bin/admin_login.sh">http://$ZT_IP:8081/cgi-bin/admin_login.sh</a></p>
HTML
fi

cat <<HTML
<p>Cloud updates use latest.txt and the release package from GitHub.</p>
</div>

<script>document.body.innerHTML = document.body.innerHTML.replaceAll('__HOST__', window.location.hostname);</script>
<a class="btn blue" href="/cgi-bin/system_info.sh"><b>System Information</b><br><span>Router and Toolkit details</span></a>
</body>
</html>
HTML
