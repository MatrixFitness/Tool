#!/bin/sh
# Matrix WiFi Quick Action Loop - Build 042

WORKER="/usr/local/matrix/matrix_wifi_action_worker.sh"
REQ="/tmp/matrix_wifi_action.request"
LTE_WORKER="/usr/local/matrix/lte_info_cache.sh"
LTE_REQ="/tmp/matrix_lte_refresh.request"

while true; do
    if [ -f "$REQ" ] && [ -x "$WORKER" ]; then
        "$WORKER"
    fi
    if [ -f "$LTE_REQ" ] && [ -x "$LTE_WORKER" ]; then
        rm -f "$LTE_REQ"
        "$LTE_WORKER" >/dev/null 2>&1
    fi
    sleep 1
done
