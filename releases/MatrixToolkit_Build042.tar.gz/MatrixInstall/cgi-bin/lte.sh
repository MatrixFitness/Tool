#!/bin/sh

echo "Content-Type: text/html"
echo ""

LTE_CACHE="/tmp/matrix_lte_info.cache"

if [ -f "$LTE_CACHE" ]; then
    LTE_UPDATED=$(grep "^UPDATED=" "$LTE_CACHE" | cut -d= -f2-)
    OPERATOR=$(grep "^OPERATOR=" "$LTE_CACHE" | cut -d= -f2-)
    TECH=$(grep "^TECH=" "$LTE_CACHE" | cut -d= -f2-)
    REGISTRATION=$(grep "^REGISTRATION=" "$LTE_CACHE" | cut -d= -f2-)
    SIGNAL=$(awk '/SIGNAL_START/{flag=1;next}/SIGNAL_END/{flag=0}flag' "$LTE_CACHE")
else
    LTE_UPDATED="Not available"
    OPERATOR="Not available"
    TECH="Not available"
    REGISTRATION="Unknown"
    SIGNAL="Not available"
fi

[ -z "$LTE_UPDATED" ] && LTE_UPDATED="Not available"
[ -z "$OPERATOR" ] && OPERATOR="Not available"
[ -z "$TECH" ] && TECH="Not available"
[ -z "$REGISTRATION" ] && REGISTRATION="Unknown"
[ -z "$SIGNAL" ] && SIGNAL="Not available"

RSSI="$(grep "^RSSI=" "$LTE_CACHE" 2>/dev/null | cut -d= -f2-)"
RSRP="$(grep "^RSRP=" "$LTE_CACHE" 2>/dev/null | cut -d= -f2-)"
RSRQ="$(grep "^RSRQ=" "$LTE_CACHE" 2>/dev/null | cut -d= -f2-)"
SINR="$(grep "^SINR=" "$LTE_CACHE" 2>/dev/null | cut -d= -f2-)"
[ -n "$RSSI" ] || RSSI=$(echo "$SIGNAL" | grep -i RSSI | awk '{print $2}')
[ -n "$RSRP" ] || RSRP=$(echo "$SIGNAL" | grep -i RSRP | awk '{print $2}')
[ -n "$RSRQ" ] || RSRQ=$(echo "$SIGNAL" | grep -i RSRQ | awk '{print $2}')
[ -n "$SINR" ] || SINR=$(echo "$SIGNAL" | grep -i SINR | awk '{print $2}')

is_number() {
    case "$1" in
        ''|*[!0-9-]*) return 1 ;;
        *) return 0 ;;
    esac
}

quality_cell() {
    NAME="$1"
    VALUE="$2"
    UNIT="$3"
    EXCELLENT="$4"
    GOOD="$5"
    FAIR="$6"

    STATUS="Niet beschikbaar"
    COLOR="#6c757d"
    DISPLAY="Not available"

    if is_number "$VALUE"; then
        DISPLAY="$VALUE $UNIT"
        STATUS="Slecht"
        COLOR="#dc3545"

        if [ "$VALUE" -ge "$FAIR" ]; then STATUS="Matig"; COLOR="#ff9800"; fi
        if [ "$VALUE" -ge "$GOOD" ]; then STATUS="Goed"; COLOR="#8bc34a"; fi
        if [ "$VALUE" -ge "$EXCELLENT" ]; then STATUS="Uitstekend"; COLOR="#28a745"; fi
    fi

    echo "<tr><td>$NAME</td><td style='background:$COLOR;color:white'><b>$DISPLAY ($STATUS)</b></td></tr>"
}

# Balanced final score:
# RSRP and RSRQ are important for usable mobile data.
# SINR is quality/interference. One low value should not always force "Slecht".
GOOD_COUNT=0
WARN_COUNT=0
BAD_COUNT=0

score_metric() {
    VALUE="$1"
    GOOD="$2"
    FAIR="$3"
    if ! is_number "$VALUE"; then
        BAD_COUNT=$((BAD_COUNT+1))
    elif [ "$VALUE" -ge "$GOOD" ]; then
        GOOD_COUNT=$((GOOD_COUNT+1))
    elif [ "$VALUE" -ge "$FAIR" ]; then
        WARN_COUNT=$((WARN_COUNT+1))
    else
        BAD_COUNT=$((BAD_COUNT+1))
    fi
}

score_metric "$RSSI" -75 -85
score_metric "$RSRP" -100 -110
score_metric "$RSRQ" -14 -20
score_metric "$SINR" 13 0

FINAL_TITLE="MATIG"
FINAL_COLOR="#fd7e14"
FINAL_TEXT="Verbinding werkt, maar betere antenneplaatsing kan prestaties verbeteren."
FINAL_ADVICE="Controleer de positie van de router of gebruik een externe antenne."

if [ "$OPERATOR" = "Not available" ] && [ "$TECH" = "Not available" ]; then
    FINAL_TITLE="GEEN LTE DATA"
    FINAL_COLOR="#6c757d"
    FINAL_TEXT="De LTE cache bevat nog geen bruikbare modemdata."
    FINAL_ADVICE="Controleer of /usr/local/matrix/lte_info_cache.sh als root draait via cron."
elif [ "$BAD_COUNT" -ge 3 ]; then
    FINAL_TITLE="SLECHT"
    FINAL_COLOR="#dc3545"
    FINAL_TEXT="Meerdere LTE signaalwaarden zijn zwak. Kans op lage snelheid of instabiliteit."
    FINAL_ADVICE="Controleer locatie, bekabeling, antennes en test een andere positie."
elif [ "$GOOD_COUNT" -ge 3 ] && [ "$BAD_COUNT" -eq 0 ]; then
    FINAL_TITLE="GOED"
    FINAL_COLOR="#28a745"
    FINAL_TEXT="LTE signaal en kwaliteit zijn goed genoeg voor normaal gebruik."
    FINAL_ADVICE="Geen directe actie nodig."
elif [ "$GOOD_COUNT" -ge 2 ] && [ "$BAD_COUNT" -le 1 ]; then
    FINAL_TITLE="GOED / MATIG"
    FINAL_COLOR="#8bc34a"
    FINAL_TEXT="Sterke LTE ontvangst gedetecteerd, maar één kwaliteitswaarde kan beter."
    FINAL_ADVICE="Bij lage snelheid: router of antennepositie optimaliseren en opnieuw testen."
fi

cat <<HTML
<html>
<head>
<title>LTE Analyse</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222;}
.card{background:white;border-radius:8px;padding:18px;max-width:980px;box-shadow:0 1px 4px rgba(0,0,0,.12);}
table{border-collapse:collapse;width:100%;margin-bottom:22px;background:white;}
th,td{border:1px solid #ccc;padding:8px;text-align:left;vertical-align:top;}
th{background:#f2f2f2;}
h1{margin-top:0;color:#005a9c;}
h2{color:#005a9c;margin-top:26px;}
.note{background:#f8fafc;border-left:4px solid #007bff;padding:12px;border-radius:6px;margin-bottom:18px;}
pre{background:#111;color:#eee;padding:12px;border-radius:6px;white-space:pre-wrap;overflow:auto;}
button{width:220px;height:48px;font-size:15px;font-weight:bold;cursor:pointer;border:0;border-radius:6px;background:#007bff;color:white;}
.result{border-left:6px solid $FINAL_COLOR;background:#f8fafc;padding:14px;border-radius:6px;margin-bottom:22px;}
.result b{color:$FINAL_COLOR;font-size:20px;}
@media(max-width:700px){body{margin:12px}.card{padding:14px}button{width:100%;}}
</style>
</head>
<body>
<div class="card">
<h1>LTE Analyse</h1>
<div class="note">
Deze pagina gebruikt de LTE root cache: <b>/tmp/matrix_lte_info.cache</b><br>
Laatste update: <b>$LTE_UPDATED</b>
</div>

<table>
<tr><th colspan="2" style="background:#007bff;color:white;font-size:18px;">Netwerk</th></tr>
<tr><td>Operator</td><td>$OPERATOR</td></tr>
<tr><td>Technologie</td><td>$TECH</td></tr>
<tr><td>Registratie</td><td>$REGISTRATION</td></tr>
</table>

<table>
<tr><th colspan="2" style="background:#6f42c1;color:white;font-size:18px;">Signaal Analyse</th></tr>
HTML

quality_cell "RSSI" "$RSSI" "dBm" -65 -75 -85
quality_cell "RSRP" "$RSRP" "dBm" -90 -100 -110
quality_cell "RSRQ" "$RSRQ" "dB" -10 -14 -20
quality_cell "SINR" "$SINR" "dB" 20 13 0

cat <<HTML
</table>

<h2>LTE Details / Ruwe modemdata</h2>
<pre>$SIGNAL</pre>

<table>
<tr><th colspan="2" style="background:#17a2b8;color:white;font-size:18px;">Uitleg</th></tr>
<tr><td><b>RSSI</b></td><td>Algemene sterkte van het ontvangen radiosignaal.</td></tr>
<tr><td><b>RSRP</b></td><td>Werkelijke sterkte van het 4G/5G signaal. Belangrijkste waarde voor bereik.</td></tr>
<tr><td><b>RSRQ</b></td><td>Kwaliteit van het radiosignaal. Hoe minder negatief, hoe beter.</td></tr>
<tr><td><b>SINR</b></td><td>Verhouding tussen bruikbaar signaal en storing. Hoe hoger, hoe beter.</td></tr>
</table>

<table>
<tr><th colspan="5" style="background:#343a40;color:white;font-size:18px;">Referentiewaarden</th></tr>
<tr>
<th>Waarde</th>
<th style="background:#28a745;color:white">Uitstekend</th>
<th style="background:#8bc34a;color:white">Goed</th>
<th style="background:#ff9800;color:white">Matig</th>
<th style="background:#dc3545;color:white">Slecht</th>
</tr>
<tr><td><b>RSSI</b></td><td>&gt; -65</td><td>-65 t/m -75</td><td>-75 t/m -85</td><td>&lt; -85</td></tr>
<tr><td><b>RSRP</b></td><td>&gt; -90</td><td>-90 t/m -100</td><td>-100 t/m -110</td><td>&lt; -110</td></tr>
<tr><td><b>RSRQ</b></td><td>&gt; -10</td><td>-10 t/m -14</td><td>-15 t/m -20</td><td>&lt; -20</td></tr>
<tr><td><b>SINR</b></td><td>&gt; 20</td><td>13 t/m 20</td><td>0 t/m 13</td><td>&lt; 0</td></tr>
</table>

<h2>Eindbeoordeling</h2>
<div class="result">
<b>$FINAL_TITLE</b><br><br>
$FINAL_TEXT<br><br>
<b>Advies:</b> $FINAL_ADVICE
</div>

<br>
<button onclick="window.location='/index.html'">Terug naar Matrix Toolkit</button>
<a href="/cgi-bin/lte_refresh.sh" style="display:inline-block;width:220px;height:48px;line-height:48px;text-align:center;font-size:15px;font-weight:bold;border-radius:6px;background:#fd7e14;color:white;text-decoration:none;">Refresh LTE Data</a>
</div>
</body>
</html>
HTML

exit 0
