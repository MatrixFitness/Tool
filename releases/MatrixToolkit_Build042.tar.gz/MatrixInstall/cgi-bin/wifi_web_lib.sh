#!/bin/sh
# Matrix WiFi Web Library - Build 042

MATRIX_DIR="/usr/local/matrix"
WIFI_LIB="$MATRIX_DIR/web/cgi-bin/wifi_lib.sh"
REQUEST_FILE="/tmp/matrix_wifi_action.request"
STATUS_FILE="/tmp/matrix_wifi_action.status"

[ -f "$WIFI_LIB" ] && . "$WIFI_LIB"

wifi_http_header(){
    printf "Content-Type: text/html; charset=UTF-8\n"
    printf "Cache-Control: no-store\n\n"
}

wifi_redirect(){
    printf "Status: 302 Found\n"
    printf "Location: %s\n"
    printf "Cache-Control: no-store\n\n" "$1"
    exit 0
}

wifi_error(){
    TITLE="$1"
    MESSAGE="$2"
    wifi_http_header
    cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>$TITLE</title><style>
body{font-family:Arial;background:#eef3f8;padding:18px}.card{max-width:720px;margin:auto;background:white;padding:22px;border-radius:15px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
h1{color:#b42318}.btn{display:inline-block;background:#5f6670;color:white;text-decoration:none;padding:11px 14px;border-radius:9px;font-weight:bold}
</style></head><body><div class="card"><h1>$(html_escape "$TITLE")</h1><p>$(html_escape "$MESSAGE")</p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></div></body></html>
HTML
    exit 0
}

wifi_queued(){
    MESSAGE="$1"
    wifi_http_header
    cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WiFi Quick Action</title><style>
body{font-family:Arial;background:#eef3f8;padding:18px}.card{max-width:760px;margin:auto;background:white;padding:22px;border-radius:15px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
h1{color:#0878d1}.status{font-size:24px;font-weight:900;padding:16px;border-radius:12px;background:#fff4ce;color:#8a5a00}
.success{background:#edf8ef;color:#17833a}.error{background:#fdecec;color:#b42318}.btn{display:inline-block;background:#0878d1;color:white;text-decoration:none;padding:11px 14px;border-radius:9px;font-weight:bold;margin:5px}.grey{background:#5f6670}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:16px}.item{background:#f8fafc;border:1px solid #d6e0ea;border-radius:10px;padding:12px}
.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:bold}.value{font-size:18px;font-weight:900;margin-top:5px}
@media(max-width:600px){.grid{grid-template-columns:1fr}.btn{display:block;text-align:center}}
</style></head><body><div class="card"><h1>WiFi Quick Action</h1><p>$(html_escape "$MESSAGE")</p>
<div id="status" class="status">QUEUED</div>
<div class="grid">
<div class="item"><div class="label">2.4 GHz</div><div id="r2" class="value">Checking...</div></div>
<div class="item"><div class="label">5 GHz</div><div id="r5" class="value">Checking...</div></div>
<div class="item"><div class="label">Execution time</div><div id="elapsed" class="value">0 s</div></div>
<div class="item"><div class="label">Last update</div><div id="updated" class="value">-</div></div>
</div>
<p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a><a class="btn grey" href="/cgi-bin/wifi_manager_action_status.sh">Detailed Status</a></p>
<script>
(function(){
 let attempts=0;
 function radio(v){return v==="1"?"Disabled":"Enabled";}
 function poll(){
   fetch("/cgi-bin/wifi_manager_action_state.sh?nocache="+Date.now(),{cache:"no-store"})
   .then(r=>r.json()).then(d=>{
      attempts++;
      const s=document.getElementById("status");
      s.textContent=d.phase+": "+d.message;
      s.className="status "+(d.phase==="SUCCESS"?"success":(d.phase==="ERROR"?"error":""));
      document.getElementById("r2").textContent=radio(d.radio2);
      document.getElementById("r5").textContent=radio(d.radio5);
      document.getElementById("elapsed").textContent=(d.elapsed||"0")+" s";
      document.getElementById("updated").textContent=d.updated||"-";
      if(d.phase!=="SUCCESS" && d.phase!=="ERROR" && attempts<40){setTimeout(poll,500);}
   }).catch(()=>{attempts++;if(attempts<40)setTimeout(poll,500);});
 }
 setTimeout(poll,250);
})();
</script></div></body></html>
HTML
    exit 0
}

wifi_safe_value(){
    printf '%s' "$1" | tr '\r\n' '  ' | sed 's/[|]/ /g'
}

wifi_queue_action(){
    ACTION="$1"; BAND="$2"; TYPE="$3"; IDX="$4"; SSID2="$5"; PASS2="$6"; SSID5="$7"; PASS5="$8"
    umask 000
    TMP="/tmp/matrix_wifi_action.request.$$"
    {
        printf 'ACTION=%s\n' "$(wifi_safe_value "$ACTION")"
        printf 'BAND=%s\n' "$(wifi_safe_value "$BAND")"
        printf 'TYPE=%s\n' "$(wifi_safe_value "$TYPE")"
        printf 'IDX=%s\n' "$(wifi_safe_value "$IDX")"
        printf 'SSID2=%s\n' "$(wifi_safe_value "$SSID2")"
        printf 'PASS2=%s\n' "$(wifi_safe_value "$PASS2")"
        printf 'SSID5=%s\n' "$(wifi_safe_value "$SSID5")"
        printf 'PASS5=%s\n' "$(wifi_safe_value "$PASS5")"
        printf 'REQUESTED_AT=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    } >"$TMP" || return 1
    chmod 666 "$TMP" 2>/dev/null || true
    mv -f "$TMP" "$REQUEST_FILE" || return 1
    chmod 666 "$REQUEST_FILE" 2>/dev/null || true
    {
        printf 'PHASE=QUEUED\n'
        printf 'MESSAGE=Waiting for root service\n'
        printf 'RESULT=QUEUED\n'
        printf 'ELAPSED=0\n'
        printf 'ACTION=%s\n' "$(wifi_safe_value "$ACTION")"
        printf 'RADIO2=%s\n' "$(uci -q get wireless.default_radio0.disabled)"
        printf 'RADIO5=%s\n' "$(uci -q get wireless.default_radio1.disabled)"
        printf 'UPDATED=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    } > /tmp/matrix_wifi_action.state
    chmod 666 /tmp/matrix_wifi_action.state 2>/dev/null || true
    printf 'QUEUED: %s\n' "$(wifi_safe_value "$ACTION")" >"$STATUS_FILE"
    chmod 666 "$STATUS_FILE" 2>/dev/null || true
    return 0
}
