#!/bin/sh
# Matrix LTE Root Cache Worker - Build 042

OUT="/tmp/matrix_lte_info.cache"
TMP="/tmp/matrix_lte_info.cache.$$"
LOG="/tmp/matrix_lte_info.log"

clean_line(){
    printf '%s' "$1" | tr '\r\n' '  ' | sed 's/[[:space:]][[:space:]]*/ /g;s/^ //;s/ $//'
}

run_gsm(){
    OPT="$1"
    gsmctl "$OPT" 2>/dev/null | grep -v "ERROR:" | grep -v "Couldn't retrieve data"
}

OPERATOR="$(run_gsm -o)"
TECH="$(run_gsm -t)"
SIGNAL="$(run_gsm -q)"
REGISTRATION="$(run_gsm -j)"

# Additional raw sources are useful after firmware changes.
RAW_API=""
if [ -x /sbin/api ]; then
    RAW_API="$(/sbin/api GET /system/device/status 2>/dev/null)"
fi

[ -n "$OPERATOR" ] || OPERATOR="Not available"
[ -n "$TECH" ] || TECH="Not available"
[ -n "$REGISTRATION" ] || REGISTRATION="Unknown"
[ -n "$SIGNAL" ] || SIGNAL="Not available"

# Parse the common gsmctl formats:
# RSSI: -65
# RSSI=-65
# "rssi": -65
metric(){
    NAME="$1"
    printf '%s\n' "$SIGNAL" | awk -v n="$NAME" '
    BEGIN{IGNORECASE=1}
    {
      line=$0
      gsub(/"/,"",line)
      gsub(/[:,=]/," ",line)
      for(i=1;i<=NF;i++){
        x=toupper($i)
        if(x==toupper(n)){
          for(j=i+1;j<=NF;j++){
            if($j ~ /^-?[0-9]+([.][0-9]+)?$/){print $j; exit}
          }
        }
      }
    }'
}

RSSI="$(metric RSSI)"
RSRP="$(metric RSRP)"
RSRQ="$(metric RSRQ)"
SINR="$(metric SINR)"

{
    printf 'UPDATED=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf 'UPDATED_EPOCH=%s\n' "$(date +%s)"
    printf 'OPERATOR=%s\n' "$(clean_line "$OPERATOR")"
    printf 'TECH=%s\n' "$(clean_line "$TECH")"
    printf 'REGISTRATION=%s\n' "$(clean_line "$REGISTRATION")"
    printf 'RSSI=%s\n' "$RSSI"
    printf 'RSRP=%s\n' "$RSRP"
    printf 'RSRQ=%s\n' "$RSRQ"
    printf 'SINR=%s\n' "$SINR"
    echo "SIGNAL_START"
    printf '%s\n' "$SIGNAL"
    echo "SIGNAL_END"
    echo "API_START"
    printf '%s\n' "$RAW_API"
    echo "API_END"
} >"$TMP" || exit 1

mv -f "$TMP" "$OUT"
chmod 644 "$OUT"
echo "$(date '+%Y-%m-%d %H:%M:%S') LTE cache updated operator=$(clean_line "$OPERATOR") tech=$(clean_line "$TECH")" >>"$LOG"
exit 0
