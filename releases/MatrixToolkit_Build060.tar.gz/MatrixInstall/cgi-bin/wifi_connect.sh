#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d'=' -f2-)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d'=' -f2-)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d'=' -f2-)
HOST="$(uci -q get system.@system[0].hostname 2>/dev/null)"; [ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"; [ -n "$HOST" ] || HOST="Matrix Router"
[ -n "$BUILD" ] || BUILD="057"
[ -n "$RELEASE" ] || RELEASE="Customer WiFi Login Layout and Official Logo Baseline"

url_decode(){ printf '%s' "$1" | sed 's/+/ /g;s/%/\\x/g' | xargs -0 printf '%b' 2>/dev/null; }
get_qs(){ KEY="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | awk -F= -v k="$KEY" '$1==k{print substr($0,length(k)+2); exit}'; }
esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
SSID="$(url_decode "$(get_qs ssid)")"
PASSWORD="$(url_decode "$(get_qs password)")"
if [ -z "$SSID" ]; then SSID="$(echo "$QUERY_STRING" | cut -d'&' -f1 | cut -d'=' -f2-)"; fi
if [ -z "$PASSWORD" ]; then PASSWORD="$(echo "$QUERY_STRING" | cut -d'&' -f2 | cut -d'=' -f2-)"; fi

if ! uci show network.wan1 >/dev/null 2>&1; then
  uci set network.wan1=interface
  uci set network.wan1.proto='dhcp'
  uci set network.wan1.metric='5'
  uci commit network
fi
if ! uci show wireless.1 >/dev/null 2>&1; then
  uci set wireless.1=wifi-iface
  uci set wireless.1.device='radio0'
  uci set wireless.1.mode='sta'
  uci set wireless.1.network='wan1'
fi
uci delete wireless.1.bssid 2>/dev/null
uci delete wireless.1.matrix_selected_bssid 2>/dev/null
uci delete wireless.1.matrix_selected_band 2>/dev/null
uci delete wireless.1.matrix_selected_channel 2>/dev/null
uci delete wireless.1.matrix_selected_radio 2>/dev/null
uci set wireless.1.ssid="$SSID"
uci set wireless.1.key="$PASSWORD"
uci set wireless.1.encryption='psk2'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'
uci commit wireless
wifi reload
sleep 20
IPADDR=$(/sbin/ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)
SIGNAL="$(iwinfo 2>/dev/null | awk '/ESSID:/{e=$0}/Signal:/{if(e~s){print $2" "$3;exit}}' s="$SSID")"
[ -n "$SIGNAL" ] || SIGNAL="Not available"

SAFE_HOST="$(esc "$HOST")"; SAFE_SSID="$(esc "$SSID")"; SAFE_IP="$(esc "$IPADDR")"; SAFE_SIGNAL="$(esc "$SIGNAL")"
cat <<HTML
<!doctype html><html lang="nl"><head><meta charset="UTF-8"><title>Customer WiFi resultaat</title><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><meta name="theme-color" content="#075f9d"><style>
:root{--blue:#0878d1;--dark:#123a63;--bg:#edf3f8;--text:#152033;--muted:#667085;--line:#d6e0ea;--green:#17833a;--red:#b42318}*{box-sizing:border-box}html,body{min-height:100%}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text);display:flex;align-items:center;justify-content:center;padding:18px}.shell{width:min(100%,590px)}.hero{background:linear-gradient(135deg,var(--dark),var(--blue));color:#fff;border-radius:20px 20px 0 0;padding:24px;box-shadow:0 8px 24px rgba(18,58,99,.18)}.brand-row{display:flex;align-items:center;gap:15px}.logo-box{background:#fff;border-radius:11px;padding:8px 10px}.logo{display:block;width:150px;height:52px;object-fit:contain}.step{font-size:13px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;opacity:.92}.hero h1{margin:8px 0 6px;font-size:31px}.meta{font-size:15px;line-height:1.5}.card{background:#fff;border-radius:0 0 20px 20px;padding:25px 24px;box-shadow:0 8px 24px rgba(15,23,42,.12)}.status{padding:13px 15px;border-radius:11px;font-size:16px;font-weight:900;text-align:center;color:#fff;background:var(--green)}.status.fail{background:var(--red)}.details{margin-top:16px;border:1px solid var(--line);border-radius:12px;overflow:hidden}.row{display:grid;grid-template-columns:145px 1fr;gap:12px;padding:12px 14px;border-bottom:1px solid var(--line)}.row:last-child{border-bottom:0}.row b{color:#52647a}.primary,.back{display:block;width:100%;min-height:56px;border-radius:12px;font-size:18px;font-weight:900;text-align:center;text-decoration:none}.primary{margin-top:18px;line-height:56px;background:var(--blue);color:#fff}.back{margin-top:12px;line-height:56px;background:#5f6670;color:#fff}.footer{text-align:center;color:var(--muted);font-size:12px;margin-top:16px}@media(max-width:600px){body{align-items:flex-start;padding:12px}.hero{padding:22px 20px}.logo{width:125px;height:44px}.hero h1{font-size:27px}.card{padding:23px 20px}.row{grid-template-columns:1fr;gap:3px}.primary,.back{min-height:60px;line-height:60px}}
</style></head><body><main class="shell"><section class="hero"><div class="brand-row"><div class="logo-box"><img class="logo" src="/matrix_logo.png" alt="Matrix Fitness"></div><div><div class="step">Stap 2 van 2</div><h1>Customer WiFi resultaat</h1><div class="meta"><b>$SAFE_HOST</b><br>Matrix Toolkit · Build $BUILD</div></div></div></section><section class="card">
HTML
if [ -n "$IPADDR" ]; then
cat <<HTML
<div class="status">Verbonden met Customer WiFi</div><div class="details"><div class="row"><b>SSID</b><span>$SAFE_SSID</span></div><div class="row"><b>IP-adres</b><span>$SAFE_IP</span></div><div class="row"><b>Signaal</b><span>$SAFE_SIGNAL</span></div><div class="row"><b>Status</b><span>Verbonden en DHCP-adres ontvangen</span></div></div><a class="primary" href="/location_survey.html">Start WiFi Survey</a><a class="back" href="/cgi-bin/wifi_survey.sh">Andere WiFi kiezen</a>
HTML
else
cat <<HTML
<div class="status fail">Verbinding niet gelukt</div><div class="details"><div class="row"><b>SSID</b><span>$SAFE_SSID</span></div><div class="row"><b>Resultaat</b><span>Geen DHCP-adres ontvangen van het klantnetwerk.</span></div></div><a class="primary" href="/cgi-bin/wifi_survey.sh">Opnieuw proberen</a><a class="back" href="/">Terug naar Toolkit</a>
HTML
fi
cat <<HTML
</section><div class="footer">Matrix Fitness · Created by Rob Bosman · $RELEASE</div></main></body></html>
HTML
