#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

PASS_FILE="/usr/local/matrix/admin_password.txt"
MSG=""
MSG_CLASS="info"

url_decode_common(){ sed 's/+/ /g; s/%21/!/g; s/%23/#/g; s/%24/\$/g; s/%25/%/g; s/%26/\&/g; s/%2B/+/g; s/%2D/-/g; s/%2E/./g; s/%3A/:/g; s/%3D/=/g; s/%40/@/g; s/%5F/_/g; s/%7E/~/g; s/%2f/\//g; s/%2F/\//g'; }
html_escape(){ sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'; }
ensure_password_file(){ mkdir -p /usr/local/matrix; [ -f "$PASS_FILE" ] || printf '%s' 'Matrix2025' >"$PASS_FILE"; chmod 644 "$PASS_FILE" 2>/dev/null || true; }

ensure_password_file
HOST="$(uci -q get system.@system[0].hostname)"; [ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"; [ -n "$HOST" ] || HOST="Matrix Router"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"; [ -n "$BUILD" ] || BUILD="058"
EDITION="$(grep '^Edition=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"; [ -n "$EDITION" ] || EDITION="Production Edition"

if [ "$REQUEST_METHOD" = "POST" ]; then
    read POST_DATA
    OLD_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^oldpass=' | cut -d= -f2-)"
    NEW_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^newpass=' | cut -d= -f2-)"
    CONFIRM_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^confirm=' | cut -d= -f2-)"
    OLD="$(echo "$OLD_RAW" | url_decode_common)"
    NEW="$(echo "$NEW_RAW" | url_decode_common)"
    CONFIRM="$(echo "$CONFIRM_RAW" | url_decode_common)"
    CURRENT="$(cat "$PASS_FILE" 2>/dev/null)"
    if [ "$OLD" != "$CURRENT" ]; then MSG="Current password is incorrect."; MSG_CLASS="error"
    elif [ -z "$NEW" ]; then MSG="New password cannot be empty."; MSG_CLASS="error"
    elif [ "$NEW" != "$CONFIRM" ]; then MSG="New passwords do not match."; MSG_CLASS="error"
    elif [ ${#NEW} -lt 6 ]; then MSG="Password must be at least 6 characters."; MSG_CLASS="error"
    elif echo "$NEW" | grep -q '[;&|`<>"\\ ]'; then MSG="Password contains unsafe characters. Use letters, numbers and characters like . _ - @ # ! : = +"; MSG_CLASS="error"
    else
        printf '%s' "$NEW" >"$PASS_FILE"; chmod 644 "$PASS_FILE" 2>/dev/null || true
        rm -rf /tmp/matrix_admin_sessions 2>/dev/null
        MSG="Password changed. Sessions were cleared. Please login again with the new password."; MSG_CLASS="success"
    fi
fi
SAFE_MSG="$(echo "$MSG" | html_escape)"

echo "Content-Type: text/html; charset=UTF-8"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""
cat <<HTML
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="theme-color" content="#075f9d"><title>Change Admin Password · $(echo "$HOST" | html_escape)</title><style>
:root{--blue:#0878d1;--dark:#123a63;--bg:#edf3f8;--text:#152033;--muted:#667085;--red:#b42318;--green:#17783b;--line:#d6e0ea}
*{box-sizing:border-box}html,body{min-height:100%}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text);display:flex;align-items:center;justify-content:center;padding:18px}.shell{width:min(100%,560px)}.hero{background:linear-gradient(135deg,var(--dark),var(--blue));color:#fff;border-radius:20px 20px 0 0;padding:25px 24px;box-shadow:0 8px 24px rgba(18,58,99,.18)}.brand{font-size:13px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;opacity:.9}.hero h1{margin:8px 0 7px;font-size:32px}.meta{font-size:16px;line-height:1.55}.card{background:#fff;border-radius:0 0 20px 20px;padding:26px 24px;box-shadow:0 8px 24px rgba(15,23,42,.12)}label{display:block;margin:16px 0 7px;font-size:15px;font-weight:900}.field{position:relative}.field input{padding-right:78px}input{width:100%;height:56px;border:1px solid var(--line);border-radius:12px;padding:0 15px;font-size:18px;background:#fbfdff;outline:none}input:focus{border:2px solid var(--blue);box-shadow:0 0 0 4px rgba(8,120,209,.1)}.toggle{position:absolute;right:8px;top:8px;height:40px;border:0;border-radius:9px;padding:0 12px;background:#eaf3fa;color:#075f9d;font-weight:900;cursor:pointer}.save,.back{display:block;width:100%;min-height:56px;border-radius:12px;font-size:18px;font-weight:900;text-align:center;text-decoration:none}.save{margin-top:21px;border:0;background:var(--blue);color:#fff;cursor:pointer}.back{margin-top:12px;line-height:56px;background:#5f6670;color:#fff}.message{margin-top:16px;padding:13px;border-radius:10px;font-weight:800}.message:empty{display:none}.error{background:#fdecec;color:var(--red)}.success{background:#e8f6ec;color:var(--green)}.info{background:#eef4f8;color:var(--muted)}.small{margin:15px 0 0;text-align:center;color:var(--muted);font-size:13px;line-height:1.4}@media(max-width:600px){body{align-items:flex-start;padding:12px}.shell{width:100%}.hero{padding:25px 21px}.hero h1{font-size:29px}.card{padding:24px 20px}input{height:60px;font-size:19px}.toggle{top:10px}.save,.back{min-height:60px;font-size:19px}.back{line-height:60px}}
</style><script>function toggleAll(){var f=document.querySelectorAll('input[type=password],input[data-password]');var show=false;f.forEach(function(i){if(i.type==='password')show=true});f.forEach(function(i){i.type=show?'text':'password';i.setAttribute('data-password','1')});document.getElementById('toggleText').textContent=show?'Hide':'Show'}</script></head><body><main class="shell"><section class="hero"><div class="brand">Matrix Fitness</div><h1>Change Admin Password</h1><div class="meta"><b>$(echo "$HOST" | html_escape)</b><br>$(echo "$EDITION" | html_escape) · Build $(echo "$BUILD" | html_escape)</div></section><section class="card"><form method="POST" action="/cgi-bin/admin_change_password.sh"><label for="oldpass">Current password</label><div class="field"><input id="oldpass" type="password" name="oldpass" required autocomplete="current-password"><button class="toggle" type="button" onclick="toggleAll()"><span id="toggleText">Show</span></button></div><label for="newpass">New password</label><input id="newpass" type="password" name="newpass" required autocomplete="new-password"><label for="confirm">Confirm new password</label><input id="confirm" type="password" name="confirm" required autocomplete="new-password"><button class="save" type="submit">Save New Password</button></form><div class="message $MSG_CLASS">$SAFE_MSG</div><a class="back" href="/cgi-bin/admin_home.sh">Back to Admin</a><p class="small">The username remains <b>admin</b>. Changing the password closes all current admin sessions.</p></section></main></body></html>
HTML
