#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
LOG="/tmp/matrix_update_github.log"
PERSISTENT_LOG="/usr/local/matrix/logs/matrix_update_last.log"
[ -s "$LOG" ] || [ ! -s "$PERSISTENT_LOG" ] || LOG="$PERSISTENT_LOG"
TECH="/tmp/matrix_update_technical.log"
HIST="/usr/local/matrix/logs/update_history.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

FLEET_CONF="/usr/local/matrix/fleet.conf"
fleet_ip(){ awk -F= -v h="$1" '$1==h{print $2;exit}' "$FLEET_CONF" 2>/dev/null; }
JNL_IP="$(fleet_ip JNLMatrix)"
JBE_IP="$(fleet_ip JBEMatrix)"
JDK_IP="$(fleet_ip JDKMatrix)"
[ -n "$JNL_IP" ] || JNL_IP="Unknown"
[ -n "$JBE_IP" ] || JBE_IP="Unknown"
[ -n "$JDK_IP" ] || JDK_IP="Unknown"

LOG_TXT="$(cat "$LOG" 2>/dev/null)"
[ -z "$LOG_TXT" ] && LOG_TXT="No update log found yet."
TECH_TXT="$(tail -n 180 "$TECH" 2>/dev/null)"
[ -z "$TECH_TXT" ] && TECH_TXT="No technical details available."
HIST_TXT="$(tail -n 120 "$HIST" 2>/dev/null)"
[ -z "$HIST_TXT" ] && HIST_TXT="No update history available."

STATE="IDLE"
MSG="No update running."
REFRESH=""

if [ -f "$REQ" ]; then
  STATE="WAITING"; MSG="Waiting for root update worker..."; REFRESH='<meta http-equiv="refresh" content="2">'
elif [ -f "$LOCK" ]; then
  OLD="$(cat "$LOCK" 2>/dev/null)"
  if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
    STATE="RUNNING"; MSG="Update is running. The page will reconnect automatically."; REFRESH='<meta http-equiv="refresh" content="2">'
  else
    STATE="STALE"; MSG="Stale lock detected. Refresh or run matrix-update again."
  fi
elif echo "$LOG_TXT" | grep -q "Already up to date"; then
  STATE="UPTODATE"; MSG="Already up to date."
elif echo "$LOG_TXT" | grep -q "UPDATE COMPLETED SUCCESSFULLY"; then
  STATE="SUCCESS"; MSG="Update completed successfully."
elif echo "$LOG_TXT" | grep -q "UPDATE COMPLETED"; then
  STATE="SUCCESS"; MSG="Update completed."
elif echo "$LOG_TXT" | grep -q "BOOTSTRAP COMPLETED\|SELF-HEAL COMPLETED\|SYSTEM HEALTH: OK\|Installed: Production Edition Build"; then
  STATE="SUCCESS"; MSG="Update completed successfully."
elif echo "$LOG_TXT" | grep -q "UPDATE FAILED\|ERROR:"; then
  STATE="FAILED"; MSG="Update failed. Open technical details for more information."
elif echo "$LOG_TXT" | grep -q "Waiting for root update worker"; then
  STATE="WAITING"; MSG="Waiting for root update worker..."; REFRESH='<meta http-equiv="refresh" content="2">'
fi

CURRENT="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
LATEST="$(wget -qO- https://raw.githubusercontent.com/MatrixFitness/Tool/main/latest.txt 2>/dev/null | tr -d '\r\n ')"
[ -z "$CURRENT" ] && CURRENT="Unknown"
[ -z "$LATEST" ] && LATEST="Unknown"

cat <<HTML
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="$([ "$STATE" = RUNNING ]||[ "$STATE" = WAITING ]&&echo 5)"><title>GitHub Update Log</title><style>
:root{--bg:#edf3f8;--blue1:#0d4778;--blue2:#0878d1;--text:#132238;--muted:#61708a;--border:#d6e1ec;--green:#18843b;--amber:#b66b00;--red:#b42318;--shadow:0 5px 18px rgba(15,23,42,.08)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1400px;margin:auto;padding:18px}.hero{background:linear-gradient(135deg,var(--blue1),var(--blue2));color:#fff;border-radius:20px;padding:20px 24px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}.brand{display:flex;align-items:center;gap:20px;min-width:0}.logoBox{background:#fff;border-radius:12px;padding:10px 14px;display:flex;align-items:center;justify-content:center}.logoBox img{width:210px;max-width:100%;height:54px;object-fit:contain}.hero h1{margin:0;font-size:30px}.meta{margin-top:7px;display:flex;flex-wrap:wrap;gap:5px 12px;font-size:14px}.actions{display:flex;gap:9px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:43px;padding:10px 15px;border-radius:11px;border:1px solid #ffffff80;background:#ffffff18;color:#fff;text-decoration:none;font-weight:800}.btn.primary{background:#fff;color:#075f9d}.btn.dark{background:#667085;border-color:#667085}.panel{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);margin-top:16px;overflow:hidden}.panelHead{padding:15px 19px;background:#0d5f9c;color:#fff;font-size:20px;font-weight:900}.panelBody{padding:18px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:14px;padding:14px;min-width:0}.label{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);font-weight:900}.value{font-size:20px;font-weight:900;margin-top:6px;overflow-wrap:anywhere}.sub{font-size:13px;color:var(--muted);margin-top:5px;overflow-wrap:anywhere}.badge{display:inline-block;padding:6px 11px;border-radius:999px;font-size:12px;font-weight:900}.ok{background:#e1f4e6;color:#116b2d}.warn{background:#fff0cf;color:#8a5200}.fail{background:#fde5e4;color:#a51d17}.note{border-left:5px solid var(--blue2);background:#eaf4ff;border-radius:10px;padding:12px 14px}.tableWrap{overflow:auto}table{width:100%;border-collapse:collapse}th,td{padding:11px 12px;border:1px solid var(--border);text-align:left;vertical-align:top}th{background:#eaf3fa;color:#075f9d}tbody tr:nth-child(even){background:#f9fbfd}pre{margin:0;background:#101828;color:#f2f4f7;padding:16px;border-radius:13px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:560px;overflow:auto}.footer{text-align:center;color:var(--muted);font-size:13px;padding:18px}.statusRow{display:flex;align-items:flex-start;gap:14px}.statusRow .badge{margin-top:2px;white-space:nowrap}details{margin-top:14px;border:1px solid var(--border);border-radius:13px;overflow:hidden}summary{cursor:pointer;background:#eef5fa;color:#075f9d;font-weight:900;padding:13px 15px}details pre{border-radius:0}.empty{color:#8a94a6;font-weight:700}
@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}.hero{align-items:flex-start}.logoBox img{width:170px}}
@media(max-width:620px){.page{padding:10px}.hero{padding:16px;border-radius:15px}.brand{align-items:flex-start;flex-direction:column}.hero h1{font-size:24px}.grid{grid-template-columns:1fr}.actions,.btn{width:100%}.logoBox img{width:190px}}
</style></head><body><main class="page"><section class="hero"><div class="brand"><div class="logoBox"><img src="/matrix_logo.png" alt="Matrix"></div><div><h1>GitHub Update Log</h1><div class="meta"><span><b>Router:</b> $(html_escape "$(hostname)")</span><span>|</span><span><b>Toolkit:</b> Build 059 Stable</span><span>|</span><span><b>Status:</b> $(html_escape "$STATE")</span></div></div></div><div class="actions"><a class="btn primary" href="/cgi-bin/admin_home.sh">Back to Admin</a><a class="btn" href="/cgi-bin/update_github_log.sh">Refresh</a><a class="btn" href="/cgi-bin/update_github_start.sh">Start Update</a></div></section>
<section class="panel"><div class="panelHead">Update Status</div><div class="panelBody"><div class="statusRow"><span class="badge $([ "$STATE" = SUCCESS ]||[ "$STATE" = UPTODATE ]&&echo ok||([ "$STATE" = FAILED ]||[ "$STATE" = STALE ]&&echo fail||echo warn))">$(html_escape "$STATE")</span><div>$(html_escape "$MSG")</div></div></div></section>
<section class="panel"><div class="panelHead">Current Update Log</div><div class="panelBody"><pre id="log">$(html_escape "$LOG_TXT")</pre></div></section>
<section class="panel"><div class="panelHead">Technical Details</div><div class="panelBody"><details><summary>Open technical log</summary><pre>$(html_escape "$(cat "$TECH" 2>/dev/null)")</pre></details><details><summary>Update history</summary><pre>$(html_escape "$(tail -n 100 "$HIST" 2>/dev/null)")</pre></details></div></section><div class="footer">Matrix Toolkit · Build 059 · Created by Rob Bosman</div><script>const l=document.getElementById('log');if(l)l.scrollTop=l.scrollHeight;</script></main></body></html>
HTML
