
Build 060 - Connectivity Report Detail Rendering Fix
- Fixed empty Basis Network, Matrix and EGYM report tables.
- Restored detailed test results and added summary counters.
Build 058 - 2026-07-19
- Compact report header and aligned single-row metadata.
- Smaller conclusion status chip for GOOD, ATTENTION and CRITICAL.
- Admin Change Password redesigned to match Admin Login.
- Official Matrix logo preserved as baseline.
- Build 057 Customer WiFi layout and all Build 056 fixes retained.

# Matrix Toolkit v59.5

## Changed
- Added stable WiFi Manager integration without changing the existing USB install flow.
- WiFi Manager now uses `/usr/local/matrix/matrix_wifi_profiles.conf` as the active local profile file.
- Local profile edits are preserved during GitHub updates.
- Missing WiFi profile files are automatically created.
- Older test location `/usr/local/matrix/config/matrix_wifi_profiles.conf` is migrated if found.

## Fixed
- Edit Profiles save now writes back to the active profile file.
- Applying a WiFi profile no longer shows a false error when `wifi reload` returns a non-zero code but the SSID was applied.
- Restore Default Profiles recreates defaults if the default file is missing.

## Build 047 - 2026-07-18
- Added a unified Matrix & EGYM Connectivity Report.
- Added separate network, Matrix and EGYM scoring with a technician conclusion.
- Added print/save-as-PDF report layout and bandwidth recommendation.
- Removed duplicate test tiles while keeping legacy URLs as safe redirects.
