#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-cache, no-store, must-revalidate\n\n"
SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

VF="/usr/local/matrix/version.txt"; FLEET_CONF="/usr/local/matrix/fleet.conf"; FLEET_DEFAULT="/usr/local/matrix/fleet.conf.default"
[ -s "$FLEET_CONF" ] || [ ! -s "$FLEET_DEFAULT" ] || cp -f "$FLEET_DEFAULT" "$FLEET_CONF"
fleet_ip(){ awk -F= -v h="$1" '$1==h{print $2;exit}' "$FLEET_CONF" 2>/dev/null; }
esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
CURRENT_HOST="$(uci -q get system.@system[0].hostname)"; [ -n "$CURRENT_HOST" ] || CURRENT_HOST="$(hostname 2>/dev/null)"
BUILD="$(grep '^Build=' "$VF" 2>/dev/null | cut -d= -f2-)"
FLEET_LIB="/usr/local/matrix/lib/fleet_status.sh"; [ -f "$FLEET_LIB" ] && . "$FLEET_LIB"
fetch_status(){ H="$1"; IP="$2"; if [ "$CURRENT_HOST" = "$H" ] && command -v fleet_local_status >/dev/null 2>&1; then fleet_local_status; else command -v fleet_fetch_remote >/dev/null 2>&1 && fleet_fetch_remote "$IP"; fi; }
card(){
 H="$1"; COUNTRY="$2"; FLAG="$3"; IP="$(fleet_ip "$H")"; DATA="$(fetch_status "$H" "$IP" 2>/dev/null)"; ONLINE=0; SOURCE="LIVE"
 RH="$(printf '%s\n' "$DATA"|awk -F= '$1=="Hostname"{print $2;exit}')"; RS="$(printf '%s\n' "$DATA"|awk -F= '$1=="Status"{print $2;exit}')"
 [ "$RH" = "$H" ] && [ "$RS" = "ONLINE" ] && ONLINE=1
 if [ "$ONLINE" -ne 1 ] && command -v fleet_toolkit_online >/dev/null 2>&1 && fleet_toolkit_online "$IP"; then ONLINE=1; SOURCE="TOOLKIT"; fi
 if [ -z "$DATA" ] && command -v fleet_cache_read >/dev/null 2>&1; then DATA="$(fleet_cache_read "$H" 2>/dev/null)"; [ -n "$DATA" ] && SOURCE="CACHED"; fi
 RB="$(printf '%s\n' "$DATA"|awk -F= '$1=="Build"{print $2;exit}')"; NODE="$(printf '%s\n' "$DATA"|awk -F= '$1=="NodeID"{print $2;exit}')"; FW="$(printf '%s\n' "$DATA"|awk -F= '$1=="Firmware"{print $2;exit}')"; LAST="$(printf '%s\n' "$DATA"|awk -F= '$1=="Timestamp"{print $2;exit}')"
 [ -n "$RB" ] || RB="-"; [ -n "$NODE" ] || NODE="-"; [ -n "$FW" ] || FW="-"; [ -n "$LAST" ] || LAST="-"
 [ "$ONLINE" -eq 1 ] && ST="ONLINE" && SC="online" || { ST="OFFLINE"; SC="offline"; }
 [ "$CURRENT_HOST" = "$H" ] && CUR=" current" || CUR=""
 cat <<HTML
<article class="router$CUR"><div class="top"><div><span class="flag">$FLAG</span><span class="name">$(esc "$H")</span></div><span class="pill $SC"><i></i>$ST</span></div><div class="country">$(esc "$COUNTRY") · $SOURCE</div><div class="ip-label">ZeroTier IP</div><div class="ip">$(esc "${IP:-Unknown}")</div><div class="details"><div><span>Build</span><b>$(esc "$RB")</b></div><div><span>Node</span><b>$(esc "$NODE")</b></div><div><span>Firmware</span><b>$(esc "$FW")</b></div><div><span>Last seen</span><b>$(esc "$LAST")</b></div></div><div class="actions"><a class="toolkit" href="http://$(esc "$IP"):8080/">Toolkit</a><a class="admin" href="http://$(esc "$IP"):8081/cgi-bin/admin_login.sh">Admin</a><button data-copy="ssh root@$(esc "$IP")">Copy SSH</button></div></article>
HTML
}
cat <<HTML
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><meta name="theme-color" content="#075f9d"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default"><meta name="apple-mobile-web-app-title" content="Matrix Fleet"><meta name="mobile-web-app-capable" content="yes"><title>Matrix Fleet</title><style>
:root{--blue:#0878d1;--dark:#123a63;--green:#17833a;--red:#b42318;--bg:#edf3f8;--line:#d6e0ea;--text:#152033;--muted:#667085}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:650px;margin:auto;padding:12px}.hero{position:sticky;top:0;z-index:5;background:linear-gradient(135deg,var(--dark),var(--blue));color:#fff;border-radius:18px;padding:19px;box-shadow:0 5px 18px rgba(18,58,99,.22)}.hero-row{display:flex;align-items:center;justify-content:space-between;gap:12px}.hero h1{font-size:28px;margin:0}.hero p{margin:7px 0 0;font-size:14px}.refresh{background:#17833a;color:#fff;text-decoration:none;padding:11px 13px;border-radius:11px;font-weight:900;white-space:nowrap}.routers{display:grid;gap:13px;margin-top:13px}.router{background:#fff;border:1px solid var(--line);border-radius:17px;padding:17px;box-shadow:0 4px 13px rgba(15,23,42,.08)}.router.current{border:2px solid var(--blue)}.top{display:flex;justify-content:space-between;align-items:center;gap:8px}.flag{font-size:23px}.name{font-size:23px;font-weight:900;margin-left:6px}.pill{display:inline-flex;align-items:center;gap:6px;padding:6px 9px;border-radius:999px;font-size:11px;font-weight:900}.pill i{width:8px;height:8px;border-radius:50%}.online{background:#e6f5ea;color:#176b2c}.online i{background:#1e963f}.offline{background:#fde8e8;color:var(--red)}.offline i{background:#d92d20}.country{font-size:12px;color:var(--muted);margin:6px 0 13px}.ip-label{font-size:11px;color:var(--muted);font-weight:900;text-transform:uppercase}.ip{font-size:28px;color:#075f9d;font-weight:900;margin:4px 0 13px;overflow-wrap:anywhere}.details{display:grid;grid-template-columns:1fr 1fr;gap:8px}.details div{background:#f7fafc;border-radius:9px;padding:9px}.details span{display:block;font-size:10px;color:var(--muted);text-transform:uppercase;font-weight:900}.details b{display:block;font-size:12px;margin-top:4px;overflow-wrap:anywhere}.actions{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:13px}.actions a,.actions button{min-height:50px;border-radius:10px;font-size:15px;font-weight:900;text-align:center;text-decoration:none;display:flex;align-items:center;justify-content:center}.toolkit{background:var(--blue);color:#fff}.admin{background:#fff;color:#075f9d;border:1px solid var(--blue)}.actions button{border:1px solid #5f6670;background:#5f6670;color:#fff}.footer{text-align:center;color:var(--muted);font-size:12px;padding:18px 5px}.desktop{color:#075f9d;font-weight:800;text-decoration:none}@media(max-width:390px){.hero h1{font-size:24px}.name{font-size:20px}.ip{font-size:24px}.actions{grid-template-columns:1fr}.details{grid-template-columns:1fr}}
</style></head><body><main class="page"><header class="hero"><div class="hero-row"><div><h1>Matrix Fleet</h1><p>Build $(esc "$BUILD") · $(esc "$CURRENT_HOST")</p></div><a class="refresh" href="/cgi-bin/mobile_fleet.sh">Refresh</a></div></header><section class="routers">
HTML
card JNLMatrix Netherlands '🇳🇱'
card JBEMatrix Belgium '🇧🇪'
card JDKMatrix Denmark '🇩🇰'
cat <<'HTML'
</section><footer class="footer">Status wordt alleen geladen wanneer je de pagina opent of op Refresh drukt.<br><a class="desktop" href="/cgi-bin/admin_home.sh">Open volledige Admin</a></footer></main><script>document.querySelectorAll('[data-copy]').forEach(function(b){b.onclick=function(){var v=b.getAttribute('data-copy');if(navigator.clipboard){navigator.clipboard.writeText(v).then(function(){b.textContent='Copied';setTimeout(function(){b.textContent='Copy SSH'},1200);});}else{window.prompt('Copy SSH command:',v);}};});</script></body></html>
HTML
