#!/bin/sh
# Matrix ZeroTier Root Worker v70.2
# Runs as root from cron. Handles requests from Admin ZeroTier Manager.

REQ="/tmp/matrix_zerotier_repair_request"
LOCK="/tmp/matrix_zerotier_repair.lock"
LOG="/tmp/matrix_zerotier_fix.log"

ZT_NETWORK_ID="cf719fd5409699a2"
ZT_RUNTIME="/tmp/run/zerotier"

[ -f "$REQ" ] || exit 0

if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        exit 0
    fi
fi

echo "$$" > "$LOCK"

ACTION="$(cat "$REQ" 2>/dev/null | head -n1)"
rm -f "$REQ"

zt_cli_path(){
    for p in /usr/bin/zerotier-cli /usr/local/usr/bin/zerotier-cli /usr/sbin/zerotier-cli; do
        [ -x "$p" ] && { echo "$p"; return; }
    done
    command -v zerotier-cli 2>/dev/null
}

zt_one_path(){
    for p in /usr/bin/zerotier-one /usr/local/usr/bin/zerotier-one /usr/sbin/zerotier-one; do
        [ -x "$p" ] && { echo "$p"; return; }
    done
    command -v zerotier-one 2>/dev/null
}

zt_cli(){
    ZT_CLI="$(zt_cli_path)"
    [ -n "$ZT_CLI" ] || return 1
    "$ZT_CLI" -D"$ZT_RUNTIME" "$@"
}

zt_iface(){
    ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}'
}

zt_ip(){
    IFACE="$(zt_iface)"
    [ -n "$IFACE" ] || return
    ip -4 addr show "$IFACE" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1
}

log(){
    echo "$1" >> "$LOG"
}

write_autostart(){
    ZT_ONE="$1"
    [ -n "$ZT_ONE" ] || return 1
    cat > /etc/init.d/matrix_zerotier <<EOF
#!/bin/sh /etc/rc.common
START=99
STOP=10

start() {
    mkdir -p $ZT_RUNTIME
    if ! pgrep -f zerotier-one >/dev/null 2>&1; then
        $ZT_ONE -d $ZT_RUNTIME >/tmp/zt_start.log 2>&1 &
    fi
}

stop() {
    killall zerotier-one >/dev/null 2>&1
}
EOF
    chmod +x /etc/init.d/matrix_zerotier
    /etc/init.d/matrix_zerotier enable >/dev/null 2>&1
}

start_zerotier(){
    ZT_ONE="$(zt_one_path)"
    [ -n "$ZT_ONE" ] || { log "ERROR: zerotier-one missing"; return 1; }

    mkdir -p "$ZT_RUNTIME"

    if ! pgrep -f zerotier-one >/dev/null 2>&1; then
        log "Starting zerotier-one with runtime $ZT_RUNTIME"
        "$ZT_ONE" -d "$ZT_RUNTIME" >/tmp/zt_start.log 2>&1 &
        sleep 20
    fi

    if [ ! -f "$ZT_RUNTIME/zerotier-one.port" ]; then
        log "Runtime port file missing, restarting cleanly"
        killall zerotier-one >/dev/null 2>&1
        rm -rf "$ZT_RUNTIME"
        mkdir -p "$ZT_RUNTIME"
        "$ZT_ONE" -d "$ZT_RUNTIME" >/tmp/zt_start.log 2>&1 &
        sleep 20
    fi

    write_autostart "$ZT_ONE"
}

ensure_firewall(){
    if ! uci show firewall 2>/dev/null | grep -q "name='zerotier'"; then
        log "Creating firewall zone zerotier"
        uci add firewall zone >/dev/null
        uci set firewall.@zone[-1].name='zerotier'
        uci set firewall.@zone[-1].input='ACCEPT'
        uci set firewall.@zone[-1].output='ACCEPT'
        uci set firewall.@zone[-1].forward='ACCEPT'
        uci set firewall.@zone[-1].masq='1'
        uci set firewall.@zone[-1].mtu_fix='1'
        uci add_list firewall.@zone[-1].network='zerotier'
        uci add firewall forwarding >/dev/null
        uci set firewall.@forwarding[-1].src='zerotier'
        uci set firewall.@forwarding[-1].dest='lan'
        uci add firewall forwarding >/dev/null
        uci set firewall.@forwarding[-1].src='lan'
        uci set firewall.@forwarding[-1].dest='zerotier'
        uci commit firewall
    fi
    /etc/init.d/firewall reload >/dev/null 2>&1
}

ensure_network_interface(){
    IFACE="$(zt_iface)"
    [ -n "$IFACE" ] || { log "WARN: no ZeroTier interface yet"; return 1; }
    log "Configuring OpenWrt network.zerotier device=$IFACE"
    uci set network.zerotier='interface'
    uci set network.zerotier.proto='none'
    uci set network.zerotier.device="$IFACE"
    uci commit network
    /etc/init.d/network reload >/dev/null 2>&1
}

install_package_if_needed(){
    ZT_CLI="$(zt_cli_path)"
    ZT_ONE="$(zt_one_path)"
    if [ -z "$ZT_CLI" ] || [ -z "$ZT_ONE" ]; then
        if command -v opkg >/dev/null 2>&1; then
            log "ZeroTier missing; running opkg update/install"
            opkg update >> "$LOG" 2>&1
            opkg install zerotier >> "$LOG" 2>&1
        else
            log "ERROR: opkg unavailable and ZeroTier missing"
        fi
    fi
}

run_status(){
    log ""
    log "ZeroTier status:"
    zt_cli status >> "$LOG" 2>&1
    log ""
    log "ZeroTier networks:"
    zt_cli listnetworks >> "$LOG" 2>&1
    log ""
    log "ZeroTier IP: $(zt_ip)"
    log "ZeroTier iface: $(zt_iface)"
}

run_repair(){
    : > "$LOG"
    log "Matrix ZeroTier root repair started at: $(date)"
    log "Requested action: $ACTION"
    log "Runtime path: $ZT_RUNTIME"

    install_package_if_needed
    start_zerotier
    zt_cli join "$ZT_NETWORK_ID" >> "$LOG" 2>&1
    sleep 3
    ensure_network_interface
    ensure_firewall
    run_status
    log "Matrix ZeroTier root repair finished at: $(date)"
}

run_restart(){
    : > "$LOG"
    log "Matrix ZeroTier restart started at: $(date)"
    killall zerotier-one >/dev/null 2>&1
    rm -rf "$ZT_RUNTIME"
    start_zerotier
    run_status
    log "Matrix ZeroTier restart finished at: $(date)"
}

run_rejoin(){
    : > "$LOG"
    log "Matrix ZeroTier rejoin started at: $(date)"
    start_zerotier
    zt_cli join "$ZT_NETWORK_ID" >> "$LOG" 2>&1
    sleep 3
    run_status
    log "Matrix ZeroTier rejoin finished at: $(date)"
}

case "$ACTION" in
    restart) run_restart ;;
    rejoin) run_rejoin ;;
    repair|*) run_repair ;;
esac

rm -f "$LOCK"
exit 0
