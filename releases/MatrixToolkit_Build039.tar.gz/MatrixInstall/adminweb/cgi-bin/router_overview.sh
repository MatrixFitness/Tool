#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
CONF="/usr/local/matrix/router_overview.conf"
VERSION_FILE="/usr/local/matrix/version.txt"
BUILD="$(grep '^Build=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
[ -z "$BUILD" ] && BUILD="011"
html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
mkdir -p /usr/local/matrix
if [ ! -f "$CONF" ]; then
cat > "$CONF" <<'EOF'
JDKMatrix|Denemarken|10.74.91.51
JNLMatrix|Nederland|10.74.91.3
JBEMatrix|Belgie|10.74.91.4
EOF
fi
cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Matrix Router Overview</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}.header,.card{background:white;border-radius:16px;padding:18px;max-width:1160px;margin:14px auto;box-shadow:0 3px 12px #0001}h1{color:#00589c;margin:0 0 8px}.sub{color:#667085}table{width:100%;border-collapse:collapse}td,th{border:1px solid #d9e2ec;padding:10px;text-align:left}th{background:#f0f6fb;color:#00589c}.badge{display:inline-block;border-radius:999px;padding:6px 10px;font-weight:900}.ok{background:#dff3e4;color:#137333}.warn{background:#fff4ce;color:#8a5a00}.fail{background:#fde2e2;color:#a10000}.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:9px 12px;font-weight:bold;margin:2px}.btn.grey{background:#667085}pre{background:#0f172a;color:#e5e7eb;padding:14px;border-radius:12px;overflow:auto;white-space:pre-wrap}</style>
<script>function copyText(t){navigator.clipboard.writeText(t).then(function(){alert('Copied: '+t);});}</script></head><body>
<div class="header"><h1>Matrix Router Overview</h1><div class="sub">Matrix Toolkit Build $(html_escape "$BUILD") · ZeroTier router shortcuts</div><p><a class="btn" href="/cgi-bin/admin_home.sh">Back to Admin</a> <a class="btn" href="/cgi-bin/router_overview.sh">Refresh</a></p></div><div class="card"><table><tr><th>Country</th><th>Hostname</th><th>ZeroTier IP</th><th>Toolkit</th><th>Admin</th><th>Status</th><th>Copy</th></tr>
HTML
while IFS='|' read -r HOST COUNTRY IP REST; do
 [ -z "$HOST" ] && continue; echo "$HOST"|grep -q '^#'&&continue
 TOOLKIT_URL="http://$IP:8080"; ADMIN_URL="http://$IP:8081/cgi-bin/admin_login.sh"
 TOOLKIT_OK="NO"; ADMIN_OK="NO"; wget -qO- -T 3 "$TOOLKIT_URL" >/dev/null 2>&1 && TOOLKIT_OK="YES"; wget -qO- -T 3 "$ADMIN_URL" >/dev/null 2>&1 && ADMIN_OK="YES"
 STATUS="OFFLINE"; CLASS="fail"; if [ "$TOOLKIT_OK" = "YES" ] && [ "$ADMIN_OK" = "YES" ]; then STATUS="ONLINE"; CLASS="ok"; elif [ "$TOOLKIT_OK" = "YES" ] || [ "$ADMIN_OK" = "YES" ]; then STATUS="PARTIAL"; CLASS="warn"; fi
cat <<HTML
<tr><td>$(html_escape "$COUNTRY")</td><td><b>$(html_escape "$HOST")</b></td><td>$(html_escape "$IP")</td><td><a class="btn" href="$(html_escape "$TOOLKIT_URL")" target="_blank">Open Toolkit</a></td><td><a class="btn" href="$(html_escape "$ADMIN_URL")" target="_blank">Open Admin</a></td><td><span class="badge $CLASS">$(html_escape "$STATUS")</span><br><small>Toolkit: $(html_escape "$TOOLKIT_OK") · Admin: $(html_escape "$ADMIN_OK")</small></td><td><a class="btn grey" href="#" onclick="copyText('$(html_escape "$TOOLKIT_URL")');return false;">Copy Toolkit</a><a class="btn grey" href="#" onclick="copyText('$(html_escape "$ADMIN_URL")');return false;">Copy Admin</a></td></tr>
HTML
done < "$CONF"
cat <<HTML
</table></div><div class="card"><h2>Configuration</h2><p>Edit this file if a ZeroTier IP changes:</p><pre>$(html_escape "$(cat "$CONF" 2>/dev/null)")</pre><p>Format: <b>hostname|country|zerotier_ip</b></p></div></body></html>
HTML
