#!/bin/sh
printf "Content-Type: application/json; charset=UTF-8\nCache-Control: no-store\n\n"
S="$(cat /tmp/matrix_update.state 2>/dev/null)"; M="$(cat /tmp/matrix_update.progress 2>/dev/null)"
[ -z "$S" ] && S="$(grep '^state=' /usr/local/matrix/logs/matrix_update_last_status 2>/dev/null|cut -d= -f2-)"
[ -z "$M" ] && M="$(grep '^message=' /usr/local/matrix/logs/matrix_update_last_status 2>/dev/null|cut -d= -f2-)"
[ -z "$S" ] && S=idle; [ -z "$M" ] && M=Waiting
B="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null|cut -d= -f2-)"
IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null|awk '/inet / {split($2,a,"/");print a[1];exit}')"
L="$(tail -n 80 /tmp/matrix_update_github.log 2>/dev/null | sed 's/\/\\/g;s/"/\"/g' | awk '{printf "%s\n",$0}')"
printf '{"state":"%s","message":"%s","build":"%s","zerotier_ip":"%s","log":"%s"}' "$S" "$M" "$B" "$IP" "$L"
