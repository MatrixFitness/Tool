#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

VERSION_FILE="/usr/local/matrix/version.txt"
BUILD="$(grep '^Build=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
EDITION="$(grep '^Edition=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
[ -z "$BUILD" ] && BUILD="010"
[ -z "$EDITION" ] && EDITION="Production Edition"

ZT_DEV="${ZT_DEV:-ztdiyqsthc}"
ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"

CLI=""
[ -x /usr/local/usr/bin/zerotier-cli ] && CLI="/usr/local/usr/bin/zerotier-cli"
[ -z "$CLI" ] && command -v zerotier-cli >/dev/null 2>&1 && CLI="$(command -v zerotier-cli)"
ONE=""
[ -x /usr/local/usr/bin/zerotier-one ] && ONE="/usr/local/usr/bin/zerotier-one"
[ -z "$ONE" ] && command -v zerotier-one >/dev/null 2>&1 && ONE="$(command -v zerotier-one)"

ACTIVE_HOME=""
INFO=""
NETWORKS=""
HOME_STATUS=""

try_home(){
    H="$1"
    [ -z "$CLI" ] && return 1
    if [ -n "$H" ]; then
        OUT="$("$CLI" -D"$H" info 2>/dev/null)"
        NET="$("$CLI" -D"$H" listnetworks 2>/dev/null)"
    else
        OUT="$("$CLI" info 2>/dev/null)"
        NET="$("$CLI" listnetworks 2>/dev/null)"
    fi
    echo "$OUT" | grep -q "^200 info" || return 1
    echo "$OUT" | grep -q "ONLINE" || return 2
    INFO="$OUT"
    NETWORKS="$NET"
    ACTIVE_HOME="$H"
    [ -z "$ACTIVE_HOME" ] && ACTIVE_HOME="default"
    return 0
}

if [ -n "$CLI" ]; then
    try_home "/etc/zerotier" || try_home "/usr/local/matrix/zerotier" || try_home ""
fi

if [ -z "$INFO" ] && [ -n "$CLI" ]; then
    INFO_ETC="$("$CLI" -D/etc/zerotier info 2>/dev/null)"
    INFO_MATRIX="$("$CLI" -D/usr/local/matrix/zerotier info 2>/dev/null)"
    INFO_DEF="$("$CLI" info 2>/dev/null)"
    INFO="$INFO_ETC"
    [ -z "$INFO" ] && INFO="$INFO_MATRIX"
    [ -z "$INFO" ] && INFO="$INFO_DEF"
    HOME_STATUS="Wrong or inactive ZeroTier home detected. IP/route/web reachability are used as final health source."
fi

ZT_IP="$(ip -4 addr show "$ZT_DEV" 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')"
[ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr 2>/dev/null | awk '/10\.74\./ {split($2,a,"/"); print a[1]; exit}')"

ROUTE_OK="NO"
ip route | grep -q "10.74.91.0/24.*$ZT_DEV" && ROUTE_OK="YES"

ONLINE="NO"
echo "$INFO" | grep -q "ONLINE" && ONLINE="YES"

NODE_ID="$(echo "$INFO" | awk '/^200 info/ {print $3; exit}')"
ZT_VER="$(echo "$INFO" | awk '/^200 info/ {print $4; exit}')"
[ -z "$NODE_ID" ] && NODE_ID="-"
[ -z "$ZT_VER" ] && ZT_VER="-"

NETWORK_STATUS="UNKNOWN"
if [ -n "$NETWORKS" ]; then
    NETWORK_STATUS="$(echo "$NETWORKS" | awk -v n="$ZT_NETWORK_ID" '$0 ~ n {print $6; exit}')"
fi
[ -z "$NETWORK_STATUS" ] && NETWORK_STATUS="UNKNOWN"

TOOLKIT_OK="NO"
ADMIN_OK="NO"
if [ -n "$ZT_IP" ]; then
    wget -qO- -T 5 "http://$ZT_IP:8080" >/dev/null 2>&1 && TOOLKIT_OK="YES"
    wget -qO- -T 5 "http://$ZT_IP:8081/cgi-bin/admin_login.sh" >/dev/null 2>&1 && ADMIN_OK="YES"
fi

OVERALL="WARNING"
REASON="ZeroTier status incomplete."
if [ "$ONLINE" = "YES" ] && [ "$NETWORK_STATUS" = "OK" ] && [ -n "$ZT_IP" ] && [ "$ROUTE_OK" = "YES" ] && [ "$TOOLKIT_OK" = "YES" ] && [ "$ADMIN_OK" = "YES" ]; then
    OVERALL="OK"
    REASON="ZeroTier is online, network is authorized, IP/route are present and Toolkit/Admin are reachable."
elif [ -n "$ZT_IP" ] && [ "$ROUTE_OK" = "YES" ] && [ "$TOOLKIT_OK" = "YES" ] && [ "$ADMIN_OK" = "YES" ]; then
    OVERALL="OK"
    REASON="ZeroTier remote access is working. CLI home/status is incomplete but IP, route and web reachability are OK."
fi

BADGE_CLASS="warn"
[ "$OVERALL" = "OK" ] && BADGE_CLASS="ok"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ZeroTier Manager</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}
.header,.card{background:white;border-radius:16px;padding:18px;max-width:1120px;margin:14px auto;box-shadow:0 3px 12px rgba(0,0,0,.08)}
h1{color:#00589c;margin:0 0 8px}.sub{color:#667085}
.badge{display:inline-block;border-radius:999px;padding:8px 14px;font-weight:900}
.ok{background:#dff3e4;color:#137333}.warn{background:#fff4ce;color:#8a5a00}.fail{background:#fde2e2;color:#a10000}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.metric{background:#f8fafc;border:1px solid #d9e2ec;border-radius:12px;padding:12px}
.metric-label{font-size:12px;text-transform:uppercase;color:#667085;font-weight:bold}.metric-value{font-size:20px;font-weight:900;margin-top:4px;word-break:break-word}
table{width:100%;border-collapse:collapse}td,th{border:1px solid #d9e2ec;padding:9px;text-align:left}th{background:#f0f6fb;color:#00589c}
.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:11px 14px;font-weight:bold;margin:4px}
pre{background:#0f172a;color:#e5e7eb;padding:14px;border-radius:12px;overflow:auto;white-space:pre-wrap}
.note{background:#eaf4ff;border-left:6px solid #007bff;padding:12px;border-radius:10px;margin-top:10px}
@media(max-width:800px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="header">
<h1>ZeroTier Manager</h1>
<div class="sub">Matrix Toolkit $(html_escape "$EDITION") · Build $(html_escape "$BUILD")</div>
<p><a class="btn" href="/cgi-bin/admin_home.sh">Back to Admin</a> <a class="btn" href="http://$(html_escape "$ZT_IP"):8080/">Open Toolkit</a> <a class="btn" href="/cgi-bin/zerotier_manager.sh">Refresh</a></p>
<p><span class="badge $BADGE_CLASS">$(html_escape "$OVERALL")</span></p>
<div class="note">$(html_escape "$REASON")</div>
</div>

<div class="card">
<h2>Remote Access Summary</h2>
<div class="grid">
<div class="metric"><div class="metric-label">ZeroTier IP</div><div class="metric-value">$(html_escape "$ZT_IP")</div></div>
<div class="metric"><div class="metric-label">Toolkit URL</div><div class="metric-value">http://$(html_escape "$ZT_IP"):8080</div></div>
<div class="metric"><div class="metric-label">Admin URL</div><div class="metric-value">http://$(html_escape "$ZT_IP"):8081</div></div>
</div>
</div>

<div class="card">
<h2>Live Status</h2>
<table>
<tr><th>Check</th><th>Status</th><th>Details</th></tr>
<tr><td>zerotier-cli</td><td>$([ -n "$CLI" ] && echo OK || echo FAIL)</td><td>$(html_escape "$CLI")</td></tr>
<tr><td>zerotier-one</td><td>$([ -n "$ONE" ] && echo OK || echo FAIL)</td><td>$(html_escape "$ONE")</td></tr>
<tr><td>Active Home</td><td>$([ -n "$ACTIVE_HOME" ] && echo OK || echo WARN)</td><td>$(html_escape "$ACTIVE_HOME") $(html_escape "$HOME_STATUS")</td></tr>
<tr><td>Node ID</td><td>$([ "$NODE_ID" != "-" ] && echo OK || echo WARN)</td><td>$(html_escape "$NODE_ID")</td></tr>
<tr><td>Online</td><td>$([ "$ONLINE" = "YES" ] && echo OK || echo WARN)</td><td>$(html_escape "$INFO")</td></tr>
<tr><td>Network joined</td><td>$([ "$NETWORK_STATUS" = "OK" ] && echo OK || echo WARN)</td><td>$(html_escape "$NETWORK_STATUS")</td></tr>
<tr><td>ZeroTier IP</td><td>$([ -n "$ZT_IP" ] && echo OK || echo FAIL)</td><td>$(html_escape "$ZT_IP")</td></tr>
<tr><td>Interface</td><td>OK</td><td>$(html_escape "$ZT_DEV")</td></tr>
<tr><td>Route</td><td>$(html_escape "$ROUTE_OK")</td><td>10.74.91.0/24 via $(html_escape "$ZT_DEV")</td></tr>
<tr><td>Toolkit Reachable</td><td>$(html_escape "$TOOLKIT_OK")</td><td>http://$(html_escape "$ZT_IP"):8080</td></tr>
<tr><td>Admin Reachable</td><td>$(html_escape "$ADMIN_OK")</td><td>http://$(html_escape "$ZT_IP"):8081/cgi-bin/admin_login.sh</td></tr>
</table>
</div>

<div class="card">
<h2>Actions</h2>
<p>
<a class="btn" href="/cgi-bin/zerotier_manager.sh?action=refresh">Refresh Status</a>
<a class="btn" href="/cgi-bin/zerotier_setup.sh">Repair / Setup</a>
</p>
</div>

<div class="card">
<h2>Diagnostics</h2>
<pre>Hostname: $(html_escape "$(hostname)")
ZeroTier CLI: $(html_escape "$CLI")
ZeroTier One: $(html_escape "$ONE")
Active Home: $(html_escape "$ACTIVE_HOME")
Network ID: $(html_escape "$ZT_NETWORK_ID")
Node ID: $(html_escape "$NODE_ID")
Version: $(html_escape "$ZT_VER")
ZeroTier IP: $(html_escape "$ZT_IP")
Interface: $(html_escape "$ZT_DEV")
Route OK: $(html_escape "$ROUTE_OK")
Toolkit OK: $(html_escape "$TOOLKIT_OK")
Admin OK: $(html_escape "$ADMIN_OK")

Info:
$(html_escape "$INFO")

Networks:
$(html_escape "$NETWORKS")
</pre>
</div>
</body>
</html>
HTML
