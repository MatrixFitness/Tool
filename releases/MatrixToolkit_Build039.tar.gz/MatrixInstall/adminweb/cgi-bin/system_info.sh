#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

VF="/usr/local/matrix/version.txt"
PRODUCT="$(grep '^Product=' "$VF" 2>/dev/null | cut -d= -f2-)"
BUILD="$(grep '^Build=' "$VF" 2>/dev/null | cut -d= -f2-)"
BDATE="$(grep '^BuildDate=' "$VF" 2>/dev/null | cut -d= -f2-)"
EDITION="$(grep '^Edition=' "$VF" 2>/dev/null | cut -d= -f2-)"
HOST="$(hostname)"
MODEL="$(cat /tmp/sysinfo/model 2>/dev/null)"
FW="$(grep DISTRIB_DESCRIPTION /etc/openwrt_release 2>/dev/null | cut -d= -f2- | tr -d "'")"
KERNEL="$(uname -r)"
UPTIME="$(uptime | sed 's/^ //')"
LOAD="$(cat /proc/loadavg 2>/dev/null | awk '{print $1" "$2" "$3}')"
MEM="$(free 2>/dev/null)"
DF="$(df -h 2>/dev/null)"
ZT="$(/usr/local/bin/matrix-zerotier 2>/dev/null)"
LAST_UPDATE="$(tail -n 40 /tmp/matrix_update_github.log 2>/dev/null)"
LAST_RECOVERY="$(tail -n 40 /tmp/matrix_recovery.log 2>/dev/null)"
[ -z "$LAST_RECOVERY" ] && LAST_RECOVERY="$(tail -n 40 /usr/local/matrix/logs/matrix_recovery.log 2>/dev/null)"
LAST_DOCTOR="$(/usr/local/bin/matrix-doctor 2>/dev/null | tail -n 30)"

cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Matrix System Information</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}.header,.card{background:white;border-radius:16px;padding:18px;max-width:1120px;margin:14px auto;box-shadow:0 3px 12px #0001}h1{color:#00589c;margin:0 0 8px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.metric{background:#f8fafc;border:1px solid #d9e2ec;border-radius:12px;padding:12px}.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:bold}.value{font-size:20px;font-weight:900;margin-top:4px;word-break:break-word}pre{background:#0f172a;color:#e5e7eb;padding:14px;border-radius:12px;overflow:auto;white-space:pre-wrap}.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:10px 13px;font-weight:bold}@media(max-width:800px){.grid{grid-template-columns:1fr}}
</style></head><body>
<div class="header"><h1>Matrix System Information</h1><p><a class="btn" href="/cgi-bin/admin_home.sh">Back to Admin</a></p></div>
<div class="card"><div class="grid">
<div class="metric"><div class="label">Product</div><div class="value">$(html_escape "$PRODUCT")</div></div>
<div class="metric"><div class="label">Edition</div><div class="value">$(html_escape "$EDITION")</div></div>
<div class="metric"><div class="label">Build</div><div class="value">$(html_escape "$BUILD")</div></div>
<div class="metric"><div class="label">Build Date</div><div class="value">$(html_escape "$BDATE")</div></div>
<div class="metric"><div class="label">Hostname</div><div class="value">$(html_escape "$HOST")</div></div>
<div class="metric"><div class="label">Router Model</div><div class="value">$(html_escape "$MODEL")</div></div>
<div class="metric"><div class="label">Firmware</div><div class="value">$(html_escape "$FW")</div></div>
<div class="metric"><div class="label">Kernel</div><div class="value">$(html_escape "$KERNEL")</div></div>
<div class="metric"><div class="label">CPU Load</div><div class="value">$(html_escape "$LOAD")</div></div>
</div></div>
<div class="card"><h2>Uptime</h2><pre>$(html_escape "$UPTIME")</pre></div>
<div class="card"><h2>Memory</h2><pre>$(html_escape "$MEM")</pre></div>
<div class="card"><h2>Storage</h2><pre>$(html_escape "$DF")</pre></div>
<div class="card"><h2>ZeroTier</h2><pre>$(html_escape "$ZT")</pre></div>
<div class="card"><h2>Last Cloud Update</h2><pre>$(html_escape "$LAST_UPDATE")</pre></div>
<div class="card"><h2>Last Recovery</h2><pre>$(html_escape "$LAST_RECOVERY")</pre></div>
<div class="card"><h2>Doctor Summary</h2><pre>$(html_escape "$LAST_DOCTOR")</pre></div>
</body></html>
HTML
