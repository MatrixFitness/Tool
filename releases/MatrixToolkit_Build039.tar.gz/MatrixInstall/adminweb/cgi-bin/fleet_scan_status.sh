#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

STATE="$(cat /tmp/matrix_fleet_scan.state 2>/dev/null)"
[ -z "$STATE" ] && STATE="RUNNING"
LOG="$(cat /tmp/matrix_fleet_scan.log 2>/dev/null)"

REFRESH=""
[ "$STATE" != "DONE" ] && REFRESH=''

cat <<HTML
<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
$REFRESH
<title>Matrix Fleet Scan</title>
<style>
body{font-family:Arial;background:#eef3f8;color:#172033;padding:18px}
.box{max-width:850px;margin:auto;background:white;border-radius:16px;padding:22px;box-shadow:0 4px 18px rgba(0,0,0,.1)}
pre{background:#111827;color:#e5e7eb;padding:16px;border-radius:12px;white-space:pre-wrap}
.btn{display:inline-block;background:#0878d1;color:white;text-decoration:none;padding:12px 17px;border-radius:10px;font-weight:bold}
</style></head><body><div class="box">
<h1>Matrix Fleet Scan</h1>
<p>Status: <b>$STATE</b></p>
<pre>$LOG</pre>
HTML

if [ "$STATE" = "DONE" ]; then
    echo '<a class="btn" href="/cgi-bin/admin_home.sh">Terug naar Admin Dashboard</a>'
else
    echo '<p>Scan is nog bezig. Gebruik Refresh in de browser om opnieuw te controleren.</p>'
fi

echo '</div></body></html>'
