#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
mkdir -p /usr/local/matrix/logs
[ -f /tmp/matrix_update_github.log ] && cp -f /tmp/matrix_update_github.log /usr/local/matrix/logs/matrix_update_previous.log 2>/dev/null
: > /tmp/matrix_update_github.log
echo queued > /tmp/matrix_update.state
echo "Update queued" > /tmp/matrix_update.progress
date > /tmp/matrix_update_request
cat <<'HTML'
<html><head><meta http-equiv="refresh" content="1;url=/cgi-bin/update_monitor.sh"></head><body style="font-family:Arial;padding:30px"><h2>Starting Matrix Cloud Update...</h2><p><a href="/cgi-bin/update_monitor.sh">Open Update Monitor</a></p></body></html>
HTML
