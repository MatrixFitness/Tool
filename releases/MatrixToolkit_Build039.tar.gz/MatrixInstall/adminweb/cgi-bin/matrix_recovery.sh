#!/bin/sh
printf "Content-Type: text/html\n\n"
echo '<html><head><title>Matrix Recovery</title><style>body{font-family:Arial;background:#f4f7fb;padding:24px}pre{background:#111827;color:#e5e7eb;padding:16px;border-radius:10px;white-space:pre-wrap}</style></head><body><h1>Matrix Recovery</h1><p><a href="/cgi-bin/admin_home.sh">Back to Admin</a></p><pre>'
/usr/local/bin/matrix-recovery 2>&1
echo ''
/usr/local/bin/matrix-doctor 2>&1
echo '</pre></body></html>'
