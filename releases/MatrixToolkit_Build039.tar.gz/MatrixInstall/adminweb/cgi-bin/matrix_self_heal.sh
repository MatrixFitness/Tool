#!/bin/sh
LOG="${1:-/tmp/matrix_self_heal.log}"
: > "$LOG" 2>/dev/null || { mkdir -p /usr/local/matrix/logs; LOG="/usr/local/matrix/logs/matrix_self_heal.log"; : > "$LOG"; }
log(){ echo "$@" | tee -a "$LOG"; }

ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
ZT_DEV="${ZT_DEV:-ztdiyqsthc}"

find_zt_cli(){
    [ -x /usr/local/usr/bin/zerotier-cli ] && { echo /usr/local/usr/bin/zerotier-cli; return; }
    command -v zerotier-cli 2>/dev/null
}
find_zt_one(){
    [ -x /usr/local/usr/bin/zerotier-one ] && { echo /usr/local/usr/bin/zerotier-one; return; }
    command -v zerotier-one 2>/dev/null
}
zt_info(){
    CLI="$(find_zt_cli)"; [ -z "$CLI" ] && return 1
    "$CLI" -D/etc/zerotier info 2>/dev/null || "$CLI" -D/usr/local/matrix/zerotier info 2>/dev/null || "$CLI" info 2>/dev/null
}
zt_ip(){
    ip -4 addr show "$ZT_DEV" 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}'
}
zt_route_ok(){
    ip route | grep -q "10.74.91.0/24.*$ZT_DEV"
}
ensure_firewall(){
    if ! uci show firewall 2>/dev/null | grep -q "name='zerotier'"; then
        uci add firewall zone >/dev/null
        Z="$(uci show firewall | grep '=zone' | tail -1 | cut -d. -f2 | cut -d= -f1)"
        uci set firewall.$Z.name='zerotier'
        uci set firewall.$Z.input='ACCEPT'
        uci set firewall.$Z.output='ACCEPT'
        uci set firewall.$Z.forward='ACCEPT'
        uci set firewall.$Z.network='zerotier'
    fi
    add_rule(){
        NAME="$1"; SRCZ="$2"; PORT="$3"
        if ! uci show firewall 2>/dev/null | grep -q "name='$NAME'"; then
            uci add firewall rule >/dev/null
            R="$(uci show firewall | grep '=rule' | tail -1 | cut -d. -f2 | cut -d= -f1)"
            uci set firewall.$R.name="$NAME"
            uci set firewall.$R.src="$SRCZ"
            uci set firewall.$R.proto='tcp'
            uci set firewall.$R.dest_port="$PORT"
            uci set firewall.$R.target='ACCEPT'
        fi
    }
    add_rule 'Allow-Matrix-Toolkit-ZeroTier' 'zerotier' '8080'
    add_rule 'Allow-Matrix-Admin-ZeroTier' 'zerotier' '8081'
    add_rule 'Allow-Matrix-Toolkit-LAN' 'lan' '8080'
    add_rule 'Allow-Matrix-Admin-LAN' 'lan' '8081'
    uci commit firewall 2>/dev/null || true
    /etc/init.d/firewall restart >/dev/null 2>&1 || true
}
start_zt(){
    ONE="$(find_zt_one)"; CLI="$(find_zt_cli)"
    [ -z "$ONE" ] && { log "ZeroTier binary not found"; return 1; }
    mkdir -p /etc/zerotier
    killall zerotier-one 2>/dev/null || true
    sleep 2
    "$ONE" -d /etc/zerotier >/tmp/matrix_zerotier_start.log 2>&1 &
    sleep 5
    [ -n "$CLI" ] && "$CLI" -D/etc/zerotier join "$ZT_NETWORK_ID" >/dev/null 2>&1 || true
    uci set network.zerotier='interface' 2>/dev/null || true
    uci set network.zerotier.proto='none' 2>/dev/null || true
    uci set network.zerotier.device="$ZT_DEV" 2>/dev/null || true
    uci commit network 2>/dev/null || true
    /etc/init.d/network reload >/dev/null 2>&1 || /etc/init.d/network restart >/dev/null 2>&1 || true
}
wait_zt(){
    MAX="${1:-90}"; I=0
    while [ "$I" -lt "$MAX" ]; do
        IP="$(zt_ip)"; INFO="$(zt_info)"
        if [ -n "$IP" ] && echo "$INFO" | grep -q "ONLINE"; then
            ip route | grep -q "10.74.91.0/24.*$ZT_DEV" || ip route add 10.74.91.0/24 dev "$ZT_DEV" 2>/dev/null || true
            log "ZeroTier ready: $IP"
            return 0
        fi
        I=$((I+5))
        log "Waiting for ZeroTier... ${I}/${MAX}"
        sleep 5
    done
    return 1
}

log "======================================"
log " MATRIX SELF-HEAL"
log "======================================"

if ps | grep '[u]httpd' >/dev/null 2>&1 && netstat -lntp 2>/dev/null | grep -q ':8080' && netstat -lntp 2>/dev/null | grep -q ':8081'; then
    log "uhttpd ..................... OK"
else
    log "uhttpd ..................... RESTART"
    /usr/local/bin/matrix-web-reload >/dev/null 2>&1 || true
    sleep 5
fi

ensure_firewall
log "Firewall ................... OK"

INFO="$(zt_info)"; IP="$(zt_ip)"
if echo "$INFO" | grep -q "ONLINE" && [ -n "$IP" ] && zt_route_ok; then
    log "ZeroTier ................... OK $IP"
else
    log "ZeroTier ................... REPAIR"
    start_zt
    wait_zt 90 || log "ZeroTier ................... WARNING still not ready"
fi

IP="$(zt_ip)"
if [ -n "$IP" ]; then
    wget -qO- -T 5 "http://$IP:8080" >/dev/null 2>&1 && log "ZeroTier Toolkit web ....... OK" || log "ZeroTier Toolkit web ....... WARNING"
    wget -qO- -T 5 "http://$IP:8081/cgi-bin/admin_login.sh" >/dev/null 2>&1 && log "ZeroTier Admin web ......... OK" || log "ZeroTier Admin web ......... WARNING"
else
    log "ZeroTier IP ................ WARNING missing"
fi

log "======================================"
log " SELF-HEAL COMPLETED"
log "======================================"
