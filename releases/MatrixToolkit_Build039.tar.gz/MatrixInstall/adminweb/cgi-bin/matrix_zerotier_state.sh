#!/bin/sh
LIB=/usr/local/matrix/lib/zerotier_runtime.sh
LOG="${1:-/tmp/matrix_zerotier_state.log}"
[ -f "$LIB" ] || { echo "Runtime library missing" | tee -a "$LOG"; exit 1; }
. "$LIB"
: >"$LOG" 2>/dev/null || true
log(){ echo "$@" | tee -a "$LOG"; }
progress(){ echo "$1" >/tmp/matrix_update.progress 2>/dev/null || true; }
log "======================================"; log " ZEROTIER PROVISIONING & SELF-HEAL"; log "======================================"
progress "Provisioning and repairing ZeroTier"
HOME="$(zt_repair_if_needed "$LOG")"
[ -n "$HOME" ] || { log "ZeroTier provisioning............ FAILED"; cat /tmp/matrix_zerotier_start.log 2>/dev/null | tee -a "$LOG"; exit 1; }
log "ZeroTier runtime................ $HOME"
log "ZeroTier status................. $(zt_status "$HOME")"
log "Current Node ID................. $(zt_node_id "$HOME")"
log "Stored Node ID.................. $(zt_expected_node_id)"
progress "Checking ZeroTier network"
zt_join_if_missing "$HOME"; zt_wait_network "$HOME"; RC=$?
[ "$RC" -eq 2 ] && { log "Network authorization.......... ACCESS_DENIED"; log "Authorize Node ID.............. $(zt_node_id "$HOME")"; exit 2; }
[ "$RC" -eq 0 ] || { log "ZeroTier network................. FAILED"; exit 1; }
log "Network authorization.......... OK"
if ! zt_validate_network_mapping "$HOME"; then
    log "ZeroTier device parsing......... FAILED"
    log "Network is authorized but device/IP could not be resolved"
    exit 1
fi
progress "Waiting for ZeroTier address"
IP="$(zt_wait_ip "$HOME")"; [ -n "$IP" ] || { log "ZeroTier IPv4 address........... FAILED"; exit 1; }
log "ZeroTier IPv4 address........... $IP"
zt_route_ok "$HOME" && log "ZeroTier route.................. OK" || log "ZeroTier route.................. WARNING"
zt_service_enable
log "Teltonika ZeroTier service....... ENABLED"
log "======================================"; log " ZEROTIER READY"; log "======================================"
