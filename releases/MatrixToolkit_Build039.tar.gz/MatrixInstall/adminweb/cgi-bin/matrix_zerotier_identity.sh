#!/bin/sh
exec /usr/local/bin/matrix-zerotier-state "$@"
