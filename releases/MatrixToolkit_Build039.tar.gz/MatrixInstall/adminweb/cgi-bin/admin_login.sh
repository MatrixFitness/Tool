#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ADMIN LOGIN
# Works on Teltonika uhttpd with Matrix session cookies.
# Password file must be readable by uhttpd, so chmod 644.
# =====================================================

PASS_FILE="/usr/local/matrix/admin_password.txt"
SESSION_DIR="/tmp/matrix_admin_sessions"
DEFAULT_PASS="Matrix2025"
MSG=""
MSG_CLASS="info"

url_decode_common() {
    sed 's/+/ /g; s/%21/!/g; s/%23/#/g; s/%24/\$/g; s/%25/%/g; s/%26/\&/g; s/%2B/+/g; s/%2D/-/g; s/%2E/./g; s/%3A/:/g; s/%3D/=/g; s/%40/@/g; s/%5F/_/g; s/%7E/~/g; s/%2f/\//g; s/%2F/\//g'
}

html_escape() {
    sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'
}

ensure_password_file() {
    mkdir -p /usr/local/matrix
    if [ ! -f "$PASS_FILE" ]; then
        printf '%s' "$DEFAULT_PASS" > "$PASS_FILE"
    fi
    chmod 644 "$PASS_FILE" 2>/dev/null
}

new_session_id() {
    if [ -r /dev/urandom ]; then
        dd if=/dev/urandom bs=24 count=1 2>/dev/null | hexdump -v -e '/1 "%02x"'
    else
        echo "$$$(date +%s)$(hostname)" | md5sum | awk '{print $1}'
    fi
}

ensure_password_file

if [ "$REQUEST_METHOD" = "POST" ]; then
    read POST_DATA

    USER_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^user=' | cut -d= -f2-)"
    PASS_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^password=' | cut -d= -f2-)"
    USER="$(echo "$USER_RAW" | url_decode_common)"
    PASS="$(echo "$PASS_RAW" | url_decode_common)"
    STORED="$(cat "$PASS_FILE" 2>/dev/null)"

    if [ "$USER" = "admin" ] && [ "$PASS" = "$STORED" ]; then
        mkdir -p "$SESSION_DIR"
        chmod 700 "$SESSION_DIR" 2>/dev/null
        SID="$(new_session_id)"
        [ -n "$SID" ] || SID="$(date +%s)$$"
        echo "$(date +%s)" > "$SESSION_DIR/$SID"
        chmod 600 "$SESSION_DIR/$SID" 2>/dev/null

        echo "Set-Cookie: MatrixAdminSession=$SID; Path=/; HttpOnly; SameSite=Lax"
        echo "Content-Type: text/html"
        echo "Cache-Control: no-cache, no-store, must-revalidate"
        echo ""
        cat <<HTML
<html><head>
<meta charset="UTF-8"><title>Login OK</title><meta http-equiv="refresh" content="0;url=/cgi-bin/admin_home.sh"><script>window.location='/cgi-bin/admin_home.sh';</script></head><body>Login OK. <a href="/cgi-bin/admin_home.sh">Open Admin</a></body></html>
HTML
        exit 0
    else
        MSG="Wrong username or password."
        MSG_CLASS="error"
    fi
fi

SAFE_MSG="$(echo "$MSG" | html_escape)"

echo "Content-Type: text/html"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""
cat <<HTML
<html>
<head>
<title>Matrix Admin Login</title>
<style>
body { font-family: Arial, sans-serif; margin:30px; background:#f5f5f5; }
.card { background:white; padding:24px; max-width:420px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.15); }
h1 { margin-top:0; color:#333; }
label { display:block; margin-top:12px; font-weight:bold; }
input { width:100%; box-sizing:border-box; padding:12px; margin-top:6px; font-size:16px; }
button { width:100%; padding:13px; margin-top:16px; font-size:16px; font-weight:bold; border:0; border-radius:6px; cursor:pointer; background:#007bff; color:white; }
.error { color:#b00020; font-weight:bold; margin-top:15px; }
.info { color:#555; margin-top:15px; }
.small { color:#666; font-size:13px; line-height:1.4; }
</style>
</head>
<body>
<div class="card">
<h1>Matrix Admin Login</h1>
<form method="POST" action="/cgi-bin/admin_login.sh">
<label>Username</label>
<input type="text" name="user" value="admin" required autocomplete="username">
<label>Password</label>
<input type="password" name="password" required autocomplete="current-password">
<button type="submit">Login</button>
</form>
<div class="$MSG_CLASS">$SAFE_MSG</div>
<p class="small"><a href="#" onclick="window.location=window.location.protocol + '//' + window.location.hostname + ':8080/index.html'; return false;">Back to Toolkit</a></p>
</div>
</body>
</html>
HTML
