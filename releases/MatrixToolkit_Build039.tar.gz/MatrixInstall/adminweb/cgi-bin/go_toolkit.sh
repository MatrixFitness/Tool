#!/bin/sh
printf "Status: 302 Found\r\n"
printf "Location: http://%s:8080/index.html\r\n\r\n" "${HTTP_HOST%%:*}"
