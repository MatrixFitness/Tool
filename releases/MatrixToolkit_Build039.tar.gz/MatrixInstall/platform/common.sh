#!/bin/sh
ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
ZT_DEV="${ZT_DEV:-ztdiyqsthc}"

zt_cli() {
    if [ -x /usr/local/usr/bin/zerotier-cli ]; then
        /usr/local/usr/bin/zerotier-cli -D/etc/zerotier "$@"
    elif command -v zerotier-cli >/dev/null 2>&1; then
        zerotier-cli -D/etc/zerotier "$@"
    else
        return 127
    fi
}

zt_one_bin() {
    if [ -x /usr/local/usr/bin/zerotier-one ]; then
        echo /usr/local/usr/bin/zerotier-one
    elif command -v zerotier-one >/dev/null 2>&1; then
        command -v zerotier-one
    else
        return 1
    fi
}

zt_ip() {
    ip -4 addr show "$ZT_DEV" 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}'
}

zt_node() {
    [ -f /etc/zerotier/identity.public ] && cut -d: -f1 /etc/zerotier/identity.public 2>/dev/null
}

ensure_zt_interface() {
    uci set network.zerotier='interface'
    uci set network.zerotier.proto='none'
    uci set network.zerotier.device="$ZT_DEV"
    uci commit network
}

restart_zt() {
    killall zerotier-one 2>/dev/null || true
    sleep 2
    Z="$(zt_one_bin 2>/dev/null)"
    [ -n "$Z" ] || return 1
    "$Z" -d /etc/zerotier >/tmp/matrix_zerotier_start.log 2>&1 &
    sleep 5
}

wait_zt_ip() {
    for i in $(seq 1 45); do
        ip -4 addr show "$ZT_DEV" 2>/dev/null | grep -q "inet 10.74." && return 0
        sleep 1
    done
    return 1
}

ensure_zt_route() {
    IP="$(zt_ip)"
    [ -n "$IP" ] || return 1
    ip route | grep -q "10.74.91.0/24 dev $ZT_DEV" && return 0
    ip route add 10.74.91.0/24 dev "$ZT_DEV" 2>/dev/null || true
    ip route | grep -q "10.74.91.0/24 dev $ZT_DEV"
}
