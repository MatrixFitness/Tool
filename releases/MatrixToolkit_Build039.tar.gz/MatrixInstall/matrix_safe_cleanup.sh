#!/bin/sh
# Matrix Toolkit Safe Cleanup
# Removes only known obsolete non-critical files.
# Does NOT remove active .sh scripts, config, survey data, backups or logs.

MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
ADMIN_WEB_DIR="$MATRIX_DIR/adminweb"

echo "Matrix Safe Cleanup started."

REMOVED=0
remove_file() {
    F="$1"
    if [ -f "$F" ]; then
        rm -f "$F" 2>/dev/null
        if [ ! -f "$F" ]; then
            echo "Removed: $F"
            REMOVED=$((REMOVED+1))
        fi
    fi
}

# Old release notes. Keep only PRODUCTION_RELEASE.txt.
for F in "$MATRIX_DIR"/PRODUCTION_RELEASE_v*.txt; do
    [ -e "$F" ] || continue
    remove_file "$F"
done

# Harmless legacy text artifacts in Matrix root only.
for F in "$MATRIX_DIR"/*_old.txt "$MATRIX_DIR"/*_backup.txt "$MATRIX_DIR"/*.bak "$MATRIX_DIR"/*.tmp; do
    [ -e "$F" ] || continue
    remove_file "$F"
done

# Do NOT remove:
# - *.sh scripts
# - version.txt
# - clubname.txt
# - admin_password.txt
# - *.conf
# - survey/
# - Backup/
# - logs/cache files that may be useful for support

echo "Matrix Safe Cleanup completed. Removed files: $REMOVED"
exit 0
