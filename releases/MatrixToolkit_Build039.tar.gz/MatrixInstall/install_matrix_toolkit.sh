#!/bin/sh
# Matrix Toolkit Production Core Installer

SOURCE_DIR="$(dirname "$0")"
MATRIX_DIR="/usr/local/matrix"
WEB="/usr/local/matrix/web/cgi-bin"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
BIN="/usr/local/bin"
ZT_HOME="/usr/local/matrix/zerotier"

mkdir -p "$MATRIX_DIR" "$WEB" "$ADMINWEB" "$BIN" "$ZT_HOME"
chmod 700 "$ZT_HOME" 2>/dev/null

[ -d "$SOURCE_DIR/cgi-bin" ] && cp -f "$SOURCE_DIR/cgi-bin"/*.sh "$WEB/" 2>/dev/null
[ -d "$SOURCE_DIR/cgi-bin_admin" ] && cp -f "$SOURCE_DIR/cgi-bin_admin"/*.sh "$ADMINWEB/" 2>/dev/null
chmod +x "$WEB"/*.sh "$ADMINWEB"/*.sh 2>/dev/null
[ -f "$SOURCE_DIR/version.txt" ] && cp -f "$SOURCE_DIR/version.txt" "$MATRIX_DIR/version.txt"
[ -d "$SOURCE_DIR/web" ] && mkdir -p "$MATRIX_DIR/web" && cp -rf "$SOURCE_DIR/web"/* "$MATRIX_DIR/web/" 2>/dev/null
[ -d "$SOURCE_DIR/web_admin" ] && mkdir -p "$MATRIX_DIR/adminweb" && cp -rf "$SOURCE_DIR/web_admin"/* "$MATRIX_DIR/adminweb/" 2>/dev/null

/etc/init.d/zerotier stop >/dev/null 2>&1
/etc/init.d/zerotier disable >/dev/null 2>&1

if [ ! -f "$ZT_HOME/identity.secret" ]; then
    if [ -f /tmp/run/zerotier/identity.secret ]; then
        cp -f /tmp/run/zerotier/identity.secret "$ZT_HOME/identity.secret"
        cp -f /tmp/run/zerotier/identity.public "$ZT_HOME/identity.public" 2>/dev/null
    elif [ -f /etc/zerotier/identity.secret ]; then
        cp -f /etc/zerotier/identity.secret "$ZT_HOME/identity.secret"
        cp -f /etc/zerotier/identity.public "$ZT_HOME/identity.public" 2>/dev/null
    fi
fi

cat > "$BIN/matrix-zerotier-fix" <<'EOF'
#!/bin/sh
echo repair > /tmp/matrix_zerotier_repair_request
/usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh
cat /tmp/matrix_zerotier_fix.log
EOF
chmod +x "$BIN/matrix-zerotier-fix"

cat > "$BIN/matrix-zerotier-status" <<'EOF'
#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh
cat /tmp/matrix_zerotier_status.cache
EOF
chmod +x "$BIN/matrix-zerotier-status"

TMP="/tmp/matrix_cron_v73.$$"
TMP2="/tmp/matrix_cron_v73_new.$$"
crontab -l > "$TMP" 2>/dev/null || : > "$TMP"
grep -v "zerotier_root_worker.sh" "$TMP" 2>/dev/null | grep -v "zerotier_status_worker.sh" > "$TMP2" 2>/dev/null || : > "$TMP2"
echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh" >> "$TMP2"
echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh" >> "$TMP2"
crontab "$TMP2"
rm -f "$TMP" "$TMP2"

ZT_ONE="/usr/local/usr/bin/zerotier-one"
[ -x /usr/bin/zerotier-one ] && ZT_ONE="/usr/bin/zerotier-one"
cat > /etc/init.d/matrix_zerotier <<EOF
#!/bin/sh /etc/rc.common
START=99
STOP=10
start() {
    /etc/init.d/zerotier stop >/dev/null 2>&1
    mkdir -p $ZT_HOME
    chmod 700 $ZT_HOME 2>/dev/null
    if ! pgrep -f "zerotier-one -d $ZT_HOME" >/dev/null 2>&1; then
        killall zerotier-one >/dev/null 2>&1
        $ZT_ONE -d $ZT_HOME >/tmp/zt_start.log 2>&1 &
    fi
}
stop() {
    killall zerotier-one >/dev/null 2>&1
}
EOF
chmod +x /etc/init.d/matrix_zerotier
/etc/init.d/matrix_zerotier enable >/dev/null 2>&1

echo repair > /tmp/matrix_zerotier_repair_request
[ -x "$ADMINWEB/zerotier_root_worker.sh" ] && "$ADMINWEB/zerotier_root_worker.sh" >/dev/null 2>&1
[ -x "$ADMINWEB/zerotier_status_worker.sh" ] && "$ADMINWEB/zerotier_status_worker.sh" >/dev/null 2>&1

echo "Matrix Toolkit v73 core install completed."
