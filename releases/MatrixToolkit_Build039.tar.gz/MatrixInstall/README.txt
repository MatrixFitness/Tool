Matrix Toolkit WiFi Manager package

Place these files in your GitHub MatrixInstall structure with the same names/locations:

MatrixInstall/
  install.sh
  matrix_wifi_profiles.conf
  web/index.html
  cgi-bin/update_github.sh
  cgi-bin/wifi_manager.sh
  cgi-bin/wifi_profile.sh
  cgi-bin/wifi_profiles_reset.sh

No defaults subdirectory is required.

How it works:
- matrix_wifi_profiles.conf in MatrixInstall is the GitHub/USB master profile file.
- During install/update it is copied to /usr/local/matrix/matrix_wifi_profiles.default.
- The active editable config is /usr/local/matrix/config/matrix_wifi_profiles.conf.
- Normal updates preserve the active editable config.
- Restore Default Profiles copies /usr/local/matrix/matrix_wifi_profiles.default back to the active config.
