#!/bin/sh
REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
LOG="/tmp/matrix_update_github.log"
TECH="/tmp/matrix_update_technical.log"
STATE="/tmp/matrix_update.state"
PROGRESS="/tmp/matrix_update.progress"
PERSIST="/usr/local/matrix/logs/matrix_update_last_status"
HIST="/usr/local/matrix/logs/update_history.log"
BOOTSTRAP_URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/bootstrap.sh"
LATEST_URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/latest.txt"

mkdir -p /usr/local/matrix/logs
[ -f "$REQ" ] || exit 0

if [ -f "$LOCK" ]; then
    OLD="$(cat "$LOCK" 2>/dev/null)"
    [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null && exit 0
fi

echo $$ >"$LOCK"
rm -f "$REQ"
START="$(date +%s)"

state(){
    echo "$1" >"$STATE"
    echo "$2" >"$PROGRESS"
    {
        echo "state=$1"
        echo "message=$2"
        echo "updated=$(date '+%Y-%m-%d %H:%M:%S')"
    } >"$PERSIST"
    echo "[$(echo "$1" | tr a-z A-Z)] $2" >>"$LOG"
}

trap 'rm -f "$LOCK"' EXIT INT TERM
: >"$TECH"
: >"$LOG"

state downloading "Reading latest build"
CURRENT="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
LATEST="$(wget -qO- "$LATEST_URL" 2>>"$TECH" | tr -d '\r\n ')"
echo "Installed Build : ${CURRENT:-Unknown}" >>"$LOG"
echo "Latest Build    : ${LATEST:-Unknown}" >>"$LOG"

[ -n "$LATEST" ] || { state error "Could not read latest.txt"; exit 1; }
[ "$CURRENT" = "$LATEST" ] && { state success "Already up to date"; exit 0; }

state downloading "Downloading bootstrap"
wget -q -O /tmp/bootstrap.sh "$BOOTSTRAP_URL" >>"$TECH" 2>&1 || {
    state error "Bootstrap download failed"
    exit 1
}
chmod 755 /tmp/bootstrap.sh

state installing "Installing Build $LATEST"
SAFE_UPDATE=1 BOOTSTRAP_MODE=update sh /tmp/bootstrap.sh >>"$TECH" 2>&1
RC=$?
tail -n 160 "$TECH" >>"$LOG" 2>/dev/null

[ "$RC" -eq 0 ] || {
    state error "Bootstrap failed with code $RC"
    exit "$RC"
}

INSTALLED="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
[ "$INSTALLED" = "$LATEST" ] || {
    state error "Installed build mismatch: expected $LATEST, found ${INSTALLED:-missing}"
    exit 1
}

state doctor "Running final Matrix Doctor"
/usr/local/bin/matrix-doctor >/tmp/matrix_doctor_after_update.log 2>&1 || true
cat /tmp/matrix_doctor_after_update.log >>"$LOG"

FAILS="$(awk '/^FAIL:/ {print $2}' /tmp/matrix_doctor_after_update.log | tail -1)"
WARNS="$(awk '/^WARN:/ {print $2}' /tmp/matrix_doctor_after_update.log | tail -1)"

# A complete Build installation is successful. ZeroTier may still require
# authorization or a later targeted repair, which Doctor reports separately.
if [ "$FAILS" = "0" ]; then
    END="$(date +%s)"
    DURATION=$((END-START))
    state success "Build $INSTALLED completed successfully"
    echo "$(date '+%F %T') SUCCESS Build $INSTALLED Duration ${DURATION}s Warnings ${WARNS:-0}" >>"$HIST"
    exit 0
fi

state warning "Build $INSTALLED installed; Matrix Doctor reports ${FAILS:-unknown} failure(s)"
exit 0
