#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - POST UPDATE TASKS
# =====================================================
# Safe to run multiple times.
# Creates persistent WiFi Survey storage after GitHub updates.
# =====================================================

MATRIX_DIR="/usr/local/matrix"
SURVEY_DIR="$MATRIX_DIR/survey"

echo "Running Matrix post-update tasks..."

mkdir -p "$SURVEY_DIR"
chmod 777 "$SURVEY_DIR" 2>/dev/null

[ -f "$SURVEY_DIR/locations.txt" ] || touch "$SURVEY_DIR/locations.txt"
[ -f "$SURVEY_DIR/completed.txt" ] || touch "$SURVEY_DIR/completed.txt"
[ -f "$SURVEY_DIR/wifi_survey_results.csv" ] || touch "$SURVEY_DIR/wifi_survey_results.csv"
[ -f "$SURVEY_DIR/survey_state.txt" ] || touch "$SURVEY_DIR/survey_state.txt"

# Backwards compatibility with older file names.
[ -f "$SURVEY_DIR/selected_locations.txt" ] || touch "$SURVEY_DIR/selected_locations.txt"
[ -f "$SURVEY_DIR/completed_locations.txt" ] || touch "$SURVEY_DIR/completed_locations.txt"

chmod 666 "$SURVEY_DIR"/*.txt "$SURVEY_DIR"/*.csv 2>/dev/null
chmod +x "$MATRIX_DIR/web/cgi-bin"/*.sh 2>/dev/null
chmod +x "$MATRIX_DIR/adminweb/cgi-bin"/*.sh 2>/dev/null

echo "OK: survey storage ready at $SURVEY_DIR"
echo "OK: post-update tasks completed."

exit 0

