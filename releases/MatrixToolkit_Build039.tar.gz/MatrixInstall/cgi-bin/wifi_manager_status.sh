#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
. /usr/local/matrix/web/cgi-bin/wifi_page_lib.sh
wifi_page_head "WiFi Status"
HOST="$(uci -q get system.@system[0].hostname)"; [ -n "$HOST" ] || HOST="$(hostname)"
S2="$(uci -q get wireless.default_radio0.ssid)"; D2="$(uci -q get wireless.default_radio0.disabled)"
S5="$(uci -q get wireless.default_radio1.ssid)"; D5="$(uci -q get wireless.default_radio1.disabled)"
WAN="$(ip route 2>/dev/null | awk '/^default/{print;exit}')"
DNS="$(awk '/^nameserver/{printf "%s ",$2}' /tmp/resolv.conf.d/resolv.conf.auto 2>/dev/null)"
ZT="$(/usr/local/usr/bin/zerotier-cli info 2>/dev/null)"
cat <<HTML
<section class="card"><div class="grid">
<div class="item"><div class="label">Router</div><div class="value">$HOST</div></div>
<div class="item"><div class="label">2.4 GHz</div><div class="value">${S2:-Unknown}</div><div>$([ "$D2" = 1 ] && echo Disabled || echo Enabled)</div></div>
<div class="item"><div class="label">5 GHz</div><div class="value">${S5:-Unknown}</div><div>$([ "$D5" = 1 ] && echo Disabled || echo Enabled)</div></div>
<div class="item"><div class="label">Default Route</div><div class="value">${WAN:-None}</div></div>
<div class="item"><div class="label">DNS</div><div class="value">${DNS:-Unknown}</div></div>
<div class="item"><div class="label">ZeroTier</div><div class="value">${ZT:-Unavailable}</div></div>
</div><p><a class="btn grey" href="/cgi-bin/wifi_manager.sh">Back</a></p></section>
HTML
wifi_page_foot
