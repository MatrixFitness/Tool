#!/bin/sh
# Matrix Toolkit Router Discovery endpoint
printf "Content-Type: application/json; charset=UTF-8\n"
printf "Cache-Control: no-cache, no-store, must-revalidate\n\n"

json_escape(){ printf '%s' "$1" | sed 's/\\/\\\\/g;s/"/\\"/g;s/\t/ /g;s/\r/ /g;s/\n/ /g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }

HOSTNAME="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOSTNAME" ] && HOSTNAME="$(hostname 2>/dev/null)"
[ -z "$HOSTNAME" ] && HOSTNAME="MatrixRouter"

COUNTRY="Unknown"
case "$HOSTNAME" in
  JNL*|NL*) COUNTRY="Netherlands" ;;
  JBE*|BE*) COUNTRY="Belgium" ;;
  JDK*|DK*) COUNTRY="Denmark" ;;
esac

MODEL="$(cat /tmp/sysinfo/model 2>/dev/null)"
[ -z "$MODEL" ] && MODEL="$(ubus call system board 2>/dev/null | sed -n 's/.*"model":[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
[ -z "$MODEL" ] && MODEL="Unknown"

FIRMWARE="$(cat /etc/version 2>/dev/null | head -n1)"
[ -z "$FIRMWARE" ] && FIRMWARE="$(cat /etc/openwrt_release 2>/dev/null | grep DISTRIB_DESCRIPTION | cut -d= -f2- | tr -d "'\"")"
[ -z "$FIRMWARE" ] && FIRMWARE="Unknown"

VERSION="$(get_value Version)"; BUILD="$(get_value Build)"; RELEASE="$(get_value Release)"
[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"

ZT_IP="$(ip -4 addr show 2>/dev/null | awk '/zt/ {f=1} f && /inet / {split($2,a,"/"); print a[1]; exit}')"
LAN_IP="$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
WAN_DEV="$(ip route 2>/dev/null | awk '/^default /{print $5; exit}')"
WAN_IP=""
[ -n "$WAN_DEV" ] && WAN_IP="$(ip -4 addr show "$WAN_DEV" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
INTERNET="offline"; ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && INTERNET="online"
UPTIME="$(uptime 2>/dev/null | sed 's/^ *//')"

TOOLKIT_URL=""; ADMIN_URL=""
[ -n "$ZT_IP" ] && TOOLKIT_URL="http://$ZT_IP:8080" && ADMIN_URL="http://$ZT_IP:8081/cgi-bin/admin_login.sh"

cat <<EOF
{
  "matrix_discovery": true,
  "hostname": "$(json_escape "$HOSTNAME")",
  "country": "$(json_escape "$COUNTRY")",
  "model": "$(json_escape "$MODEL")",
  "firmware": "$(json_escape "$FIRMWARE")",
  "toolkit_version": "$(json_escape "$VERSION")",
  "build": "$(json_escape "$BUILD")",
  "release": "$(json_escape "$RELEASE")",
  "zerotier_ip": "$(json_escape "$ZT_IP")",
  "lan_ip": "$(json_escape "$LAN_IP")",
  "wan_ip": "$(json_escape "$WAN_IP")",
  "toolkit_url": "$(json_escape "$TOOLKIT_URL")",
  "admin_url": "$(json_escape "$ADMIN_URL")",
  "internet": "$(json_escape "$INTERNET")",
  "uptime": "$(json_escape "$UPTIME")"
}
EOF
