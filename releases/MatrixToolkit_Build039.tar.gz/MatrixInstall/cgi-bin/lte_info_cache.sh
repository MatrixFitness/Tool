#!/bin/sh

# MATRIX TOOLKIT - LTE INFO CACHE WORKER
# Runs as root from cron.
# CGI pages read /tmp/matrix_lte_info.cache instead of running gsmctl directly.

OUT="/tmp/matrix_lte_info.cache"
TMP="/tmp/matrix_lte_info.cache.tmp"

OPERATOR="$(gsmctl -o 2>/dev/null | grep -v "ERROR:" | grep -v "Couldn't retrieve data")"
TECH="$(gsmctl -t 2>/dev/null | grep -v "ERROR:" | grep -v "Couldn't retrieve data")"
SIGNAL="$(gsmctl -q 2>/dev/null | grep -v "ERROR:" | grep -v "Couldn't retrieve data")"
REGISTRATION="$(gsmctl -j 2>/dev/null | grep -v "ERROR:" | grep -v "Couldn't retrieve data")"

[ -z "$OPERATOR" ] && OPERATOR="Not available"
[ -z "$TECH" ] && TECH="Not available"
[ -z "$SIGNAL" ] && SIGNAL="Not available"
[ -z "$REGISTRATION" ] && REGISTRATION="Unknown"

{
    echo "UPDATED=$(date)"
    echo "OPERATOR=$OPERATOR"
    echo "TECH=$TECH"
    echo "REGISTRATION=$REGISTRATION"
    echo "SIGNAL_START"
    echo "$SIGNAL"
    echo "SIGNAL_END"
} > "$TMP"

mv "$TMP" "$OUT"
chmod 644 "$OUT"

exit 0
