#!/bin/sh

printf "Content-Type: text/html\n\n"

VERSION_FILE="/usr/local/matrix/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | head -n1 | cut -d= -f2-
}

html_escape() {
    sed \
        -e 's/&/\&amp;/g' \
        -e 's/</\&lt;/g' \
        -e 's/>/\&gt;/g' \
        -e 's/"/\&quot;/g'
}

get_section() {
    echo "$QUERY_STRING" | sed -n 's/.*section=\([^&]*\).*/\1/p'
}

find_zt_ip() {
    IP=""

    IP=$(ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)

    if [ -z "$IP" ]; then
        IP=$(ip -4 addr show 2>/dev/null | awk '/scope global/ && /zt/ {print $2}' | cut -d/ -f1 | head -1)
    fi

    if [ -z "$IP" ] && [ -x /usr/local/usr/bin/zerotier-cli ]; then
        IP=$(/usr/local/usr/bin/zerotier-cli -D/etc/zerotier listnetworks 2>/dev/null | awk '/OK/ {
            for (i=1; i<=NF; i++) {
                if ($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\//) {
                    split($i,a,"/"); print a[1]; exit
                }
            }
        }')
    fi

    echo "$IP"
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
GITHUB=$(get_value GitHub)

[ -z "$VERSION" ] && VERSION="0.0"
[ -z "$BUILD" ] && BUILD="0000-00-00"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="unknown@matrixfitness.nl"
[ -z "$GITHUB" ] && GITHUB="Unknown"

VERSION_HTML=$(printf '%s' "$VERSION" | html_escape)
BUILD_HTML=$(printf '%s' "$BUILD" | html_escape)
RELEASE_HTML=$(printf '%s' "$RELEASE" | html_escape)
COMPANY_HTML=$(printf '%s' "$COMPANY" | html_escape)
AUTHOR_HTML=$(printf '%s' "$AUTHOR" | html_escape)
EMAIL_HTML=$(printf '%s' "$EMAIL" | html_escape)
GITHUB_HTML=$(printf '%s' "$GITHUB" | html_escape)

SECTION=$(get_section)
ZT_IP=$(find_zt_ip)
ZT_IP_HTML=$(printf '%s' "$ZT_IP" | html_escape)

if [ "$SECTION" = "creator" ]; then
cat <<HTML_EOF
<b>$COMPANY_HTML</b><br>
Created by $AUTHOR_HTML<br>
$EMAIL_HTML
HTML_EOF
exit 0
fi

if [ "$SECTION" = "toolkit_cards" ]; then
cat <<HTML_EOF
<div class="info-card">
<h2>Toolkit Version</h2>
<b>Matrix Toolkit v$VERSION_HTML</b><br>
Build $BUILD_HTML<br>
Release $RELEASE_HTML
</div>

<div class="info-card">
<h2>ZeroTier Remote Access</h2>
HTML_EOF

if [ -n "$ZT_IP" ]; then
cat <<HTML_EOF
Toolkit:<br>
<a href="http://$ZT_IP_HTML:8080" target="_blank">http://$ZT_IP_HTML:8080</a><br><br>
Admin:<br>
<a href="http://$ZT_IP_HTML:8081/cgi-bin/admin_login.sh" target="_blank">http://$ZT_IP_HTML:8081/cgi-bin/admin_login.sh</a>
HTML_EOF
else
cat <<HTML_EOF
ZeroTier IP: Not available<br>
Run ZeroTier Setup first, or check if the device is authorized in ZeroTier Central.
HTML_EOF
fi

cat <<HTML_EOF
</div>

<div class="info-card">
<h2>Repository</h2>
<a href="$GITHUB_HTML" target="_blank">$GITHUB_HTML</a>
</div>
HTML_EOF
exit 0
fi

# Default output for older pages.
cat <<HTML_EOF
<div style="font-size:13px; line-height:1.5; color:#555;">
<b>Matrix Toolkit v$VERSION_HTML</b><br>
Build $BUILD_HTML<br>
Release $RELEASE_HTML<br><br>
$COMPANY_HTML<br>
Created by $AUTHOR_HTML<br>
$EMAIL_HTML
HTML_EOF

if [ -n "$ZT_IP" ]; then
cat <<HTML_EOF
<br><br>
<b>ZeroTier Remote Access</b><br>
Toolkit:
<a href="http://$ZT_IP_HTML:8080" target="_blank">http://$ZT_IP_HTML:8080</a><br>
Admin:
<a href="http://$ZT_IP_HTML:8081/cgi-bin/admin_login.sh" target="_blank">http://$ZT_IP_HTML:8081/cgi-bin/admin_login.sh</a>
HTML_EOF
fi

cat <<HTML_EOF
<br><br>
Repository:<br>
<a href="$GITHUB_HTML" target="_blank">$GITHUB_HTML</a>
</div>
HTML_EOF
