#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }
is_ip(){ echo "$1" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'; }
clean_num(){ V="$(printf '%s' "$1" | sed 's/[^0-9.]//g')"; [ -z "$V" ] && echo "-" || echo "$V"; }
fmt_ms(){ V="$1"; [ -z "$V" ] || [ "$V" = "-" ] && { echo "-"; return; }; awk -v n="$V" 'BEGIN{printf "%.1f", n}'; }

TMP_DIR="/tmp/matrix_wan_report.$$"
mkdir -p "$TMP_DIR"
trap 'rm -rf "$TMP_DIR"' EXIT

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="MatrixRouter"
VERSION="$(get_value Version)"; [ -z "$VERSION" ] && VERSION="76.2"
NOW="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"

DEFAULT_ROUTE="$(ip route show default 2>/dev/null | head -n1)"
WAN_IF="$(printf '%s' "$DEFAULT_ROUTE" | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
GW="$(printf '%s' "$DEFAULT_ROUTE" | awk '{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}')"
is_ip "$GW" || GW=""
WAN_IP=""; [ -n "$WAN_IF" ] && WAN_IP="$(ip -4 addr show "$WAN_IF" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
DNS_SERVERS="$(awk '/nameserver/{print $2}' /tmp/resolv.conf.d/resolv.conf.auto /etc/resolv.conf 2>/dev/null | grep -v '^::1$' | sort -u | tr '\n' ' ')"
[ -z "$DNS_SERVERS" ] && DNS_SERVERS="Unknown"

score=100; warnings=0; failures=0
penalty(){ case "$1" in small) score=$((score-3));; warn) score=$((score-8)); warnings=$((warnings+1));; fail) score=$((score-20)); failures=$((failures+1));; esac; }
grade_latency(){ V="$1"; [ -z "$V" ] || [ "$V" = "-" ] && { echo "FAIL"; return; }; N="$(awk -v n="$V" 'BEGIN{printf "%.0f", n}')"; [ "$N" -le 20 ] && echo EXCELLENT && return; [ "$N" -le 40 ] && echo GOOD && return; [ "$N" -le 80 ] && echo ACCEPTABLE && return; echo POOR; }
grade_loss(){ V="$1"; [ -z "$V" ] && { echo FAIL; return; }; N="$(awk -v n="$V" 'BEGIN{printf "%.0f", n}')"; [ "$N" -eq 0 ] && echo EXCELLENT && return; [ "$N" -le 1 ] && echo WARNING && return; echo FAIL; }
grade_jitter(){ V="$1"; [ -z "$V" ] || [ "$V" = "-" ] && { echo UNKNOWN; return; }; N="$(awk -v n="$V" 'BEGIN{printf "%.0f", n}')"; [ "$N" -le 3 ] && echo EXCELLENT && return; [ "$N" -le 8 ] && echo GOOD && return; [ "$N" -le 15 ] && echo WARNING && return; echo POOR; }
class_for(){ case "$1" in READY|EXCELLENT|GOOD|PASS|OK) echo ok;; ACCEPTABLE|WARNING|UNKNOWN|MANUAL|OPTIONAL|READY_WITH_NOTES) echo warn;; *) echo fail;; esac; }
apply_grade(){ case "$1" in READY|EXCELLENT|PASS|OK) ;; GOOD) penalty small;; ACCEPTABLE|WARNING|UNKNOWN|MANUAL|OPTIONAL|READY_WITH_NOTES) penalty warn;; POOR|FAIL|CRITICAL|NOT_READY) penalty fail;; esac; }

# Writes raw output to file and returns clean numeric values only:
# loss|min|avg|max|jitter|rx|tx
ping_collect(){
  TARGET="$1"; COUNT="$2"; RAW_FILE="$3"
  ping -c "$COUNT" -W 2 "$TARGET" > "$RAW_FILE" 2>&1

  LOSS="$(awk -F',' '/packet loss/{for(i=1;i<=NF;i++) if($i ~ /packet loss/){gsub(/[^0-9.]/,"",$i); print $i; exit}}' "$RAW_FILE")"
  [ -z "$LOSS" ] && LOSS=100

  TX="$(awk '/packets transmitted/{print $1; exit}' "$RAW_FILE")"; [ -z "$TX" ] && TX="$COUNT"
  RX="$(awk '/packets transmitted/{for(i=1;i<=NF;i++) if($i=="received,"){print $(i-1); exit}}' "$RAW_FILE")"; [ -z "$RX" ] && RX=0

  STATS="$(awk -F'= ' '/round-trip|rtt/{print $2; exit}' "$RAW_FILE")"
  MIN="-"; AVG="-"; MAX="-"
  if [ -n "$STATS" ]; then
    MIN="$(printf '%s' "$STATS" | awk -F'/' '{print $1}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
    AVG="$(printf '%s' "$STATS" | awk -F'/' '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
    MAX="$(printf '%s' "$STATS" | awk -F'/' '{print $3}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
    MIN="$(clean_num "$MIN")"; AVG="$(clean_num "$AVG")"; MAX="$(clean_num "$MAX")"
  fi

  TIMES="$(sed -n 's/.*time=\([0-9.]*\) ms.*/\1/p' "$RAW_FILE")"
  JITTER="-"
  [ -n "$TIMES" ] && JITTER="$(printf '%s\n' "$TIMES" | awk 'NR==1{prev=$1;next}{d=$1-prev;if(d<0)d=-d;sum+=d;c++;prev=$1}END{if(c>0)printf "%.1f",sum/c;else print "-"}')"

  printf '%s|%s|%s|%s|%s|%s|%s' "$LOSS" "$MIN" "$AVG" "$MAX" "$JITTER" "$RX" "$TX"
}

dns_collect(){
  DOMAIN="$1"; RAW_FILE="$2"
  nslookup "$DOMAIN" > "$RAW_FILE" 2>&1
  S=FAIL
  grep -q "Name:" "$RAW_FILE" && grep -q "Address" "$RAW_FILE" && S=PASS
  echo "$S"
}

mtu_collect(){
  if ping -c1 -W2 -s 1472 -M do 8.8.8.8 >/dev/null 2>&1; then echo "1500|PASS|Standard ethernet MTU works"
  elif ping -c1 -W2 -s 1464 -M do 8.8.8.8 >/dev/null 2>&1; then echo "1492|WARNING|Reduced MTU detected, often normal for PPPoE"
  else echo "UNKNOWN|WARNING|Could not verify MTU with DF ping"; fi
}

GW_RAW_FILE="$TMP_DIR/gateway_ping.txt"; INET_RAW_FILE="$TMP_DIR/internet_ping.txt"
DNS_GOOGLE_FILE="$TMP_DIR/dns_google.txt"; DNS_MATRIX_FILE="$TMP_DIR/dns_matrix.txt"; DNS_EGYM_FILE="$TMP_DIR/dns_egym.txt"

if [ -n "$GW" ]; then GW_RESULT="$(ping_collect "$GW" 5 "$GW_RAW_FILE")"; else echo "No valid gateway found" > "$GW_RAW_FILE"; GW_RESULT="100|-|-|-|-|0|5"; fi
INET_RESULT="$(ping_collect 8.8.8.8 10 "$INET_RAW_FILE")"
DNS_GOOGLE_STATUS="$(dns_collect google.com "$DNS_GOOGLE_FILE")"
DNS_MATRIX_STATUS="$(dns_collect matrixfitness.com "$DNS_MATRIX_FILE")"
DNS_EGYM_STATUS="$(dns_collect egym.com "$DNS_EGYM_FILE")"
MTU_RESULT="$(mtu_collect)"

GW_LOSS="$(echo "$GW_RESULT"|cut -d'|' -f1)"; GW_MIN="$(echo "$GW_RESULT"|cut -d'|' -f2)"; GW_AVG="$(echo "$GW_RESULT"|cut -d'|' -f3)"; GW_MAX="$(echo "$GW_RESULT"|cut -d'|' -f4)"; GW_JITTER="$(echo "$GW_RESULT"|cut -d'|' -f5)"; GW_RX="$(echo "$GW_RESULT"|cut -d'|' -f6)"; GW_TX="$(echo "$GW_RESULT"|cut -d'|' -f7)"
INET_LOSS="$(echo "$INET_RESULT"|cut -d'|' -f1)"; INET_MIN="$(echo "$INET_RESULT"|cut -d'|' -f2)"; INET_AVG="$(echo "$INET_RESULT"|cut -d'|' -f3)"; INET_MAX="$(echo "$INET_RESULT"|cut -d'|' -f4)"; INET_JITTER="$(echo "$INET_RESULT"|cut -d'|' -f5)"; INET_RX="$(echo "$INET_RESULT"|cut -d'|' -f6)"; INET_TX="$(echo "$INET_RESULT"|cut -d'|' -f7)"
GW_LAT_GRADE="$(grade_latency "$GW_AVG")"; GW_LOSS_GRADE="$(grade_loss "$GW_LOSS")"; INET_LAT_GRADE="$(grade_latency "$INET_AVG")"; INET_LOSS_GRADE="$(grade_loss "$INET_LOSS")"; INET_JITTER_GRADE="$(grade_jitter "$INET_JITTER")"
MTU_VALUE="$(echo "$MTU_RESULT"|cut -d'|' -f1)"; MTU_STATUS="$(echo "$MTU_RESULT"|cut -d'|' -f2)"; MTU_TEXT="$(echo "$MTU_RESULT"|cut -d'|' -f3-)"
DNS_OVERALL=PASS; [ "$DNS_GOOGLE_STATUS" = PASS ] && [ "$DNS_MATRIX_STATUS" = PASS ] && [ "$DNS_EGYM_STATUS" = PASS ] || DNS_OVERALL=WARNING

for G in "$GW_LAT_GRADE" "$GW_LOSS_GRADE" "$INET_LAT_GRADE" "$INET_LOSS_GRADE" "$INET_JITTER_GRADE" "$DNS_OVERALL" "$MTU_STATUS"; do apply_grade "$G"; done
[ "$score" -lt 0 ] && score=0

FINAL=READY; FINAL_CLASS=ok; FINAL_TEXT="Customer network is suitable for Matrix and EGYM equipment."
[ "$score" -lt 90 ] && FINAL="READY WITH NOTES" && FINAL_CLASS=ok && FINAL_TEXT="Network is usable. Minor points should be checked if problems occur."
[ "$score" -lt 75 ] && FINAL="ATTENTION REQUIRED" && FINAL_CLASS=warn && FINAL_TEXT="Network has warnings. Investigate before final handover."
[ "$score" -lt 60 ] && FINAL="NOT READY" && FINAL_CLASS=fail && FINAL_TEXT="Network does not meet the recommended quality. Resolve issues before installation handover."

box(){ echo "<div class='metric'><div class='metric-label'>$(html_escape "$1")</div><div class='metric-value'>$(html_escape "$2")</div><div class='metric-extra'>$(html_escape "$3")</div></div>"; }
card_open(){ echo "<div class='test-card $3'><div class='test-head'><div><h3>$(html_escape "$1")</h3><p>$(html_escape "$4")</p></div><div class='badge $3'>$(html_escape "$2")</div></div><div class='metric-grid'>"; }
card_close(){ echo "</div><details><summary>Explanation and recommendation</summary><div class='explain'><p><b>Meaning:</b> $(html_escape "$1")</p><p><b>Action:</b> $(html_escape "$2")</p></div></details></div>"; }

cat <<EOF
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Matrix Network Installation Report</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1280px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:#fff;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}.cert{background:#fff;border:1px solid var(--border);border-radius:20px;box-shadow:var(--shadow);padding:20px;margin:18px 0;display:grid;grid-template-columns:240px 1fr;gap:18px;align-items:center}.score-ring{border-radius:18px;background:#f8fafc;border:1px solid var(--border);padding:18px;text-align:center}.score{font-size:44px;font-weight:900}.score small{font-size:18px;color:var(--muted)}.status{font-size:24px;font-weight:900;margin:0 0 8px}.status.ok{color:var(--ok)}.status.warn{color:var(--warn)}.status.fail{color:var(--fail)}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}.sum-card{background:#fff;border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow);padding:15px}.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}.value{margin-top:8px;font-size:18px;font-weight:800;word-break:break-word}.tests{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.test-card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:15px;border-top:6px solid var(--ok)}.test-card.warn{border-top-color:var(--warn)}.test-card.fail{border-top-color:var(--fail)}.test-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.test-card h3{margin:0;font-size:18px}.test-card p{margin:5px 0 0;color:var(--muted);font-size:13px;line-height:1.35}.badge{border-radius:999px;padding:6px 10px;color:#fff;font-size:12px;font-weight:800;background:var(--ok);white-space:nowrap}.badge.warn{background:var(--warn)}.badge.fail{background:var(--fail)}.metric-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:11px}.metric-label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800}.metric-value{font-size:18px;font-weight:900;margin-top:5px}.metric-extra{font-size:12px;color:var(--muted);margin-top:3px}details{margin-top:12px}summary{cursor:pointer;color:#0d3b66;font-weight:800}.explain{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:12px;margin-top:9px;line-height:1.45;color:#344054}.section{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:16px;margin:16px 0}.bigtable{width:100%;border-collapse:collapse}.bigtable td,.bigtable th{border:1px solid var(--border);padding:9px;text-align:left}.bigtable th{background:#f0f6fb}pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px}@media(max-width:1000px){.cert{grid-template-columns:1fr}.summary{grid-template-columns:repeat(2,1fr)}.tests{grid-template-columns:1fr}}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.summary{grid-template-columns:1fr}.metric-grid{grid-template-columns:1fr}.btn{width:100%;text-align:center}.test-head{display:block}.badge{display:inline-block;margin-top:10px}}</style></head><body><div class="page"><div class="hero"><div><h1>Matrix Network Installation Report</h1><div class="sub">WAN quality certification for Matrix & EGYM</div></div><a class="btn" href="/">Back to Toolkit</a></div><div class="cert"><div class="score-ring"><div class="score">$(html_escape "$score")<small>/100</small></div><div class="label">Network Score</div></div><div><div class="status $FINAL_CLASS">$(html_escape "$FINAL")</div><p><b>Final verdict:</b> $(html_escape "$FINAL_TEXT")</p><p><b>Router:</b> $(html_escape "$HOST") &nbsp; <b>Report time:</b> $(html_escape "$NOW")</p></div></div><div class="summary"><div class="sum-card"><div class="label">WAN Interface</div><div class="value">$(html_escape "$WAN_IF")</div></div><div class="sum-card"><div class="label">WAN IP</div><div class="value">$(html_escape "$WAN_IP")</div></div><div class="sum-card"><div class="label">Gateway</div><div class="value">$(html_escape "$GW")</div></div><div class="sum-card"><div class="label">DNS</div><div class="value">$(html_escape "$DNS_SERVERS")</div></div></div><div class="tests">
EOF

C="$(class_for "$GW_LAT_GRADE")"; card_open "Gateway Test" "$GW_LAT_GRADE" "$C" "Local path between router and customer gateway."; box "Average" "$(fmt_ms "$GW_AVG") ms" "Target: $GW"; box "Min / Max" "$(fmt_ms "$GW_MIN") / $(fmt_ms "$GW_MAX") ms" "Local latency"; box "Packet Loss" "${GW_LOSS}%" "$GW_LOSS_GRADE"; box "Jitter" "$(fmt_ms "$GW_JITTER") ms" "Real packet-to-packet jitter"; card_close "The gateway is the first device on the customer network. It should normally respond below 2 ms with 0% packet loss." "If this fails, check cable, switch port, VLAN, modem/router or local customer network."
C="$(class_for "$INET_LAT_GRADE")"; card_open "Internet Latency" "$INET_LAT_GRADE" "$C" "Delay between router and public internet."; box "Average" "$(fmt_ms "$INET_AVG") ms" "Target: 8.8.8.8"; box "Min / Max" "$(fmt_ms "$INET_MIN") / $(fmt_ms "$INET_MAX") ms" "Internet latency"; box "Packets" "$INET_RX / $INET_TX" "received / sent"; box "Impact" "Cloud sync" "Login, updates and remote support"; card_close "This measures how quickly the router reaches the internet. Low latency improves cloud sync, login and remote services." "If latency is high, check ISP, firewall, router load or LTE signal quality."
C="$(class_for "$INET_LOSS_GRADE")"; card_open "Packet Loss" "$INET_LOSS_GRADE" "$C" "Checks whether packets disappear."; box "Loss" "${INET_LOSS}%" "Target: 8.8.8.8"; box "Packets" "$INET_RX / $INET_TX" "received / sent"; box "Result" "$INET_LOSS_GRADE" "0% is expected"; box "Risk" "Disconnects" "Sync and update failures"; card_close "Packet loss is more serious than high latency. Even fast internet becomes unreliable when packets are lost." "If loss is detected, check ISP, cables, switches, WiFi backhaul, firewall load or LTE signal."
C="$(class_for "$INET_JITTER_GRADE")"; card_open "Jitter" "$INET_JITTER_GRADE" "$C" "Checks packet-to-packet latency stability."; box "Jitter" "$(fmt_ms "$INET_JITTER") ms" "Average difference between packets"; box "Min latency" "$(fmt_ms "$INET_MIN") ms" "Best response"; box "Max latency" "$(fmt_ms "$INET_MAX") ms" "Worst response"; box "Result" "$INET_JITTER_GRADE" "Stable is better"; card_close "Jitter means latency variation between packets. Stable latency is important for cloud communication and remote support." "If jitter is high, check congestion, WiFi interference, LTE signal or overloaded network equipment."
C="$(class_for "$DNS_OVERALL")"; card_open "DNS Lookup" "$DNS_OVERALL" "$C" "Checks if cloud names resolve."; box "Google" "$DNS_GOOGLE_STATUS" "google.com"; box "Matrix" "$DNS_MATRIX_STATUS" "matrixfitness.com"; box "EGYM" "$DNS_EGYM_STATUS" "egym.com"; box "Servers" "$DNS_SERVERS" "Configured DNS"; card_close "DNS translates names into IP addresses. If DNS fails, cloud services may not connect even when ping works." "Use reliable DNS servers and check customer firewall DNS rules."
C="$(class_for "$MTU_STATUS")"; card_open "MTU Test" "$MTU_STATUS" "$C" "Checks if normal packet size works."; box "Detected" "$MTU_VALUE" "MTU result"; box "Status" "$MTU_STATUS" "$MTU_TEXT"; box "Normal" "1500" "Standard ethernet"; box "PPPoE" "1492" "Often acceptable"; card_close "MTU controls packet size. Wrong MTU can cause strange HTTPS, VPN or cloud issues." "1500 is normal. 1492 is common on PPPoE. If unknown, investigate only if VPN/cloud issues occur."
card_open "Speed Test" "MANUAL" "warn" "Not run automatically."; box "Status" "Skipped" "Fast report mode"; box "Why" "Can hang" "Teltonika routers"; box "Run when" "Needed" "Bandwidth suspected"; box "Command" "speedtest" "Manual CLI"; card_close "Bandwidth is useful for updates and multiple devices, but this fast report avoids long blocking speedtests." "Run speedtest manually if the customer complains about slow downloads or updates."
card_open "Long Stability Test" "OPTIONAL" "warn" "Not run automatically."; box "Fast test" "$INET_TX pings" "This report"; box "Deep test" "100 pings" "Manual"; box "Use for" "Intermittent issues" "Random disconnects"; box "Command" "ping -c 100 8.8.8.8" "CLI"; card_close "A longer test helps find intermittent packet loss or unstable internet." "Use this when customer reports random offline or sync issues."

cat <<EOF
</div><div class="section"><h2>Installer Summary</h2><table class="bigtable"><tr><th>Area</th><th>Measured values</th><th>Result</th></tr><tr><td>Gateway</td><td>avg $(fmt_ms "$GW_AVG") ms, loss ${GW_LOSS}%</td><td>$GW_LAT_GRADE / $GW_LOSS_GRADE</td></tr><tr><td>Internet</td><td>avg $(fmt_ms "$INET_AVG") ms, min $(fmt_ms "$INET_MIN") ms, max $(fmt_ms "$INET_MAX") ms</td><td>$INET_LAT_GRADE</td></tr><tr><td>Packet Loss</td><td>${INET_LOSS}%</td><td>$INET_LOSS_GRADE</td></tr><tr><td>Jitter</td><td>$(fmt_ms "$INET_JITTER") ms</td><td>$INET_JITTER_GRADE</td></tr><tr><td>DNS</td><td>Google $DNS_GOOGLE_STATUS, Matrix $DNS_MATRIX_STATUS, EGYM $DNS_EGYM_STATUS</td><td>$DNS_OVERALL</td></tr><tr><td>MTU</td><td>$MTU_VALUE - $MTU_TEXT</td><td>$MTU_STATUS</td></tr></table></div><details class="section"><summary><b>Advanced Diagnostics</b></summary><h2>Default Route</h2><pre>$(html_escape "$DEFAULT_ROUTE")</pre><h2>Gateway Ping</h2><pre>$(html_escape "$(cat "$GW_RAW_FILE" 2>/dev/null)")</pre><h2>Internet Ping 8.8.8.8</h2><pre>$(html_escape "$(cat "$INET_RAW_FILE" 2>/dev/null)")</pre><h2>DNS Google</h2><pre>$(html_escape "$(cat "$DNS_GOOGLE_FILE" 2>/dev/null)")</pre><h2>DNS Matrix</h2><pre>$(html_escape "$(cat "$DNS_MATRIX_FILE" 2>/dev/null)")</pre><h2>DNS EGYM</h2><pre>$(html_escape "$(cat "$DNS_EGYM_FILE" 2>/dev/null)")</pre></details></div></body></html>
EOF
