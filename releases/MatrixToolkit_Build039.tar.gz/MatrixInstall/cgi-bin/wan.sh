#!/bin/sh

echo "Content-Type: text/html"
echo ""

HOSTNAME=$(hostname 2>/dev/null)

LANIP=$(ip -4 addr show br-lan 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1 | head -1)
WAN_STATUS=$(ubus call network.interface.wan status 2>/dev/null)

WANIP=$(echo "$WAN_STATUS" | grep -A4 '"ipv4-address"' | grep '"address"' | head -1 | cut -d'"' -f4)
GATEWAY=$(echo "$WAN_STATUS" | grep -A4 '"route"' | grep '"nexthop"' | head -1 | cut -d'"' -f4)
WAN_INTERFACE=$(echo "$WAN_STATUS" | grep '"device"' | head -1 | cut -d'"' -f4)
PROTOCOL=$(echo "$WAN_STATUS" | grep '"proto"' | head -1 | cut -d'"' -f4)
WAN_UPTIME=$(echo "$WAN_STATUS" | grep '"uptime"' | grep -o '[0-9]*' | head -1)

DNS1=$(echo "$WAN_STATUS" | grep -A8 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '1p')
DNS2=$(echo "$WAN_STATUS" | grep -A8 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '2p')

[ -z "$LANIP" ] && LANIP="Not available"
[ -z "$WANIP" ] && WANIP="Not available"
[ -z "$GATEWAY" ] && GATEWAY="Not available"
[ -z "$WAN_INTERFACE" ] && WAN_INTERFACE="Not available"
[ -z "$PROTOCOL" ] && PROTOCOL="Not available"
[ -z "$DNS1" ] && DNS1="Not available"
[ -z "$DNS2" ] && DNS2="Not available"

if [ -n "$WAN_UPTIME" ]; then
    HOURS=$((WAN_UPTIME / 3600))
    MINS=$(((WAN_UPTIME % 3600) / 60))
    WAN_UPTIME_TXT="${HOURS} uur ${MINS} min"
else
    WAN_UPTIME_TXT="Onbekend"
fi

PING_STATUS="FAIL"
DNS_STATUS="FAIL"
FINAL_STATUS="AFGEKEURD"
FINAL_CLASS="bad"
FINAL_TEXT="Internet lijkt niet bereikbaar via de WAN verbinding."
FINAL_ADVICE="Controleer WAN kabel, DHCP, gateway, DNS en internetverbinding van de klant."

if ping -c 3 -W 3 8.8.8.8 >/dev/null 2>&1; then
    PING_STATUS="PASS"
fi

if nslookup google.com >/dev/null 2>&1; then
    DNS_STATUS="PASS"
fi

if [ "$PING_STATUS" = "PASS" ] && [ "$DNS_STATUS" = "PASS" ]; then
    FINAL_STATUS="GOEDGEKEURD"
    FINAL_CLASS="good"
    FINAL_TEXT="Internet bereikbaar."
    FINAL_ADVICE="WAN verbinding is actief en DNS werkt correct."
elif [ "$PING_STATUS" = "PASS" ] && [ "$DNS_STATUS" != "PASS" ]; then
    FINAL_STATUS="WAARSCHUWING"
    FINAL_CLASS="warn"
    FINAL_TEXT="Internet ping werkt, maar DNS lijkt niet goed te werken."
    FINAL_ADVICE="Controleer DNS-instellingen. Advies: 8.8.8.8 en 8.8.4.4 of klant DNS."
fi

badge() {
    STATUS="$1"
    case "$STATUS" in
        PASS|GOEDGEKEURD) echo "<span class='badge good'>$STATUS</span>" ;;
        WAARSCHUWING) echo "<span class='badge warn'>$STATUS</span>" ;;
        *) echo "<span class='badge bad'>$STATUS</span>" ;;
    esac
}

cat <<EOF
<html>
<head>
<title>WAN Status</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
:root {
    --blue:#0b5cab;
    --blue2:#073b73;
    --bg:#eef2f6;
    --card:#ffffff;
    --text:#1f2937;
    --muted:#6b7280;
    --line:#d8dee8;
    --green:#198754;
    --orange:#fd7e14;
    --red:#dc3545;
}
* { box-sizing:border-box; }
body { font-family:Arial, Helvetica, sans-serif; margin:0; background:var(--bg); color:var(--text); }
.header { background:linear-gradient(135deg,var(--blue2),var(--blue)); color:white; padding:26px 30px; }
.header h1 { margin:0; font-size:30px; }
.header p { margin:8px 0 0 0; opacity:.9; }
.wrap { max-width:1080px; margin:24px auto; padding:0 18px; }
.card { background:var(--card); border-radius:14px; padding:20px; box-shadow:0 4px 14px rgba(20,34,64,.10); margin-bottom:20px; border:1px solid rgba(0,0,0,.04); }
.card h2 { margin:0 0 14px 0; font-size:21px; color:#102a43; }
.grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
@media (max-width:820px) { .grid-2 { grid-template-columns:1fr; } }
table { border-collapse:collapse; width:100%; background:white; }
th { background:#eaf2fb; color:#0f335c; text-align:left; padding:10px; border-bottom:1px solid var(--line); }
td { border-bottom:1px solid var(--line); padding:10px; vertical-align:top; }
.badge { display:inline-block; padding:6px 11px; border-radius:999px; font-size:12px; font-weight:bold; color:white; }
.badge.good { background:var(--green); }
.badge.warn { background:var(--orange); }
.badge.bad { background:var(--red); }
.result { border-left:6px solid var(--red); background:#f8fafc; padding:14px; border-radius:8px; }
.result.good { border-left-color:var(--green); }
.result.warn { border-left-color:var(--orange); }
.result.bad { border-left-color:var(--red); }
.result-title { font-size:26px; font-weight:bold; margin-bottom:8px; }
.result.good .result-title { color:var(--green); }
.result.warn .result-title { color:var(--orange); }
.result.bad .result-title { color:var(--red); }
.note { background:#f8fafc; border-left:4px solid var(--blue); padding:12px 14px; border-radius:8px; color:#334155; }
.small { font-size:13px; color:var(--muted); line-height:1.45; }
button, .btn { display:inline-block; min-width:190px; height:46px; line-height:46px; text-align:center; font-size:15px; font-weight:bold; cursor:pointer; border:0; border-radius:8px; margin:6px 8px 6px 0; background:var(--blue); color:white; text-decoration:none; }
.btn.secondary { background:#475569; }
@media(max-width:700px){ .header{padding:22px 18px;} .header h1{font-size:25px;} .wrap{padding:0 12px;} button,.btn{width:100%;} }
</style>
<script>
function goHome(){ window.location='/index.html'; }
function goAdmin(){ window.location = window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_home.sh'; }
</script>
</head>

<body>
<div class="header">
    <h1>WAN Status</h1>
    <p>Router: <b>$HOSTNAME</b> &nbsp; | &nbsp; $(date)</p>
</div>

<div class="wrap">

<div class="grid-2">
    <div class="card">
        <h2>WAN gegevens</h2>
        <table>
            <tr><th>Onderdeel</th><th>Waarde</th></tr>
            <tr><td>WAN IP</td><td>$WANIP</td></tr>
            <tr><td>Gateway</td><td>$GATEWAY</td></tr>
            <tr><td>DNS 1</td><td>$DNS1</td></tr>
            <tr><td>DNS 2</td><td>$DNS2</td></tr>
            <tr><td>LAN IP</td><td>$LANIP</td></tr>
            <tr><td>WAN Interface</td><td>$WAN_INTERFACE</td></tr>
            <tr><td>Protocol</td><td>$PROTOCOL</td></tr>
            <tr><td>WAN Uptime</td><td>$WAN_UPTIME_TXT</td></tr>
        </table>
    </div>

    <div class="card">
        <h2>Connectiviteit</h2>
        <table>
            <tr><th>Test</th><th>Status</th></tr>
            <tr><td>Internet ping 8.8.8.8</td><td>$(badge "$PING_STATUS")</td></tr>
            <tr><td>DNS resolve google.com</td><td>$(badge "$DNS_STATUS")</td></tr>
        </table>
        <br>
        <div class="result $FINAL_CLASS">
            <div class="result-title">$FINAL_STATUS</div>
            <b>$FINAL_TEXT</b><br><br>
            <span>$FINAL_ADVICE</span>
        </div>
    </div>
</div>

<div class="card">
    <h2>Uitleg</h2>
    <div class="note">
        <b>WAN Status</b> controleert of de router via de WAN interface een IP-adres, gateway en DNS-servers heeft gekregen.
        Daarnaast test deze pagina of internet bereikbaar is met een ping naar 8.8.8.8 en of DNS werkt via google.com.
        <br><br>
        <b>GOEDGEKEURD</b> betekent dat zowel internet als DNS bereikbaar zijn.
        <b>WAARSCHUWING</b> betekent meestal dat internet wel werkt maar DNS niet.
        <b>AFGEKEURD</b> betekent dat internet via WAN waarschijnlijk niet werkt.
    </div>
</div>

<div class="card">
    <button onclick="goHome()">Return to Home</button>
    <button onclick="goAdmin()">Return to Admin</button>
</div>

</div>
</body>
</html>
EOF
