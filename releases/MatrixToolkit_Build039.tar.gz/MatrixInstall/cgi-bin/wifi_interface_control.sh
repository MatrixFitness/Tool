#!/bin/sh
# Matrix Toolkit - WiFi Interface Control
# Auto-detects all wireless wifi-iface sections and allows enable/disable per SSID.

LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    sed -e 's/+/ /g' -e 's/%20/ /g' -e 's/%2[Ee]/./g' -e 's/%5[Ff]/_/g' -e 's/%2[Dd]/-/g'
}

qs() {
    FIELD="$1"
    printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode
}

ACTION="$(qs action)"
IFACE="$(qs iface)"

if [ -n "$ACTION" ] && [ -n "$IFACE" ]; then
    SSID="$(uci get wireless.${IFACE}.ssid 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"

    case "$ACTION" in
        enable)
            uci set wireless.${IFACE}.disabled='0'
            uci commit wireless
            wifi reload >/dev/null 2>&1
            echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface enabled iface=$IFACE ssid=$SSID" >> "$LOG"
            ;;
        disable)
            uci set wireless.${IFACE}.disabled='1'
            uci commit wireless
            wifi reload >/dev/null 2>&1
            echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface disabled iface=$IFACE ssid=$SSID" >> "$LOG"
            ;;
    esac
fi

echo "Content-Type: text/html"
echo ""
cat <<'EOF'
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>WiFi Interface Control</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1040px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}
h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}
.blue{background:#007bff}.green{background:#28a745}.red{background:#dc3545}.grey{background:#666}
table{width:100%;border-collapse:collapse;background:white}
th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:middle}
th{background:#f0f6fb;color:#005a9c}
.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.muted{color:#777;font-size:13px}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function confirmToggle(action, iface, ssid){
    return confirm(action + ' WiFi interface?\n\nInterface: ' + iface + '\nSSID: ' + ssid + '\n\nWiFi will reload. Continue?');
}
</script>
</head>
<body>
<div class="page">
<h1>WiFi Interface Control</h1>

<div class="card">
<h2>Detected WiFi Interfaces</h2>
<table>
<tr><th>Interface</th><th>Device</th><th>SSID</th><th>Status</th><th>Action</th></tr>
EOF

# Detect all wifi-iface sections. Examples:
# wireless.default_radio0=wifi-iface
# wireless.default_radio1=wifi-iface
# wireless.1=wifi-iface
uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue

    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    DEVICE="$(uci get wireless.${IFACE_NAME}.device 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"

    [ -z "$SSID" ] && SSID="Unknown"
    [ -z "$DEVICE" ] && DEVICE="-"
    [ -z "$DISABLED" ] && DISABLED="0"

    E_IFACE="$(html_escape "$IFACE_NAME")"
    E_SSID="$(html_escape "$SSID")"
    E_DEVICE="$(html_escape "$DEVICE")"

    if [ "$DISABLED" = "1" ]; then
        STATUS='<span class="err">Disabled</span>'
        ACTION_BTN="<a class=\"btn green\" onclick=\"return confirmToggle('Enable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_interface_control.sh?action=enable&iface=$E_IFACE\">Enable</a>"
    else
        STATUS='<span class="ok">Enabled</span>'
        ACTION_BTN="<a class=\"btn red\" onclick=\"return confirmToggle('Disable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_interface_control.sh?action=disable&iface=$E_IFACE\">Disable</a>"
    fi

    echo "<tr><td><b>$E_IFACE</b></td><td>$E_DEVICE</td><td>$E_SSID</td><td>$STATUS</td><td>$ACTION_BTN</td></tr>"
done

cat <<'EOF'
</table>
<p class="muted">This page only enables or disables existing WiFi interfaces. It does not change saved WiFi profiles.</p>
<p>
<a class="btn blue" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a>
<a class="btn grey" href="/">Back to Toolkit</a>
</p>
</div>

</div>
</body>
</html>
EOF
