#!/bin/sh
HOST_ONLY="${HTTP_HOST%%:*}"
[ -z "$HOST_ONLY" ] && HOST_ONLY="192.168.1.1"
printf "Status: 302 Found\n"
printf "Location: http://%s:8081/cgi-bin/admin_login.sh\n\n" "$HOST_ONLY"
