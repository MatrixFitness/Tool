#!/bin/sh

printf "Content-Type: text/html\n\n"

VERSION_FILE="/usr/local/matrix/version.txt"
ZT_HOME="/etc/zerotier"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | head -n1 | cut -d= -f2-
}

get_block() {
    KEY="$1"
    awk -v key="$KEY" '
        $0 == key "<<END" {show=1; next}
        $0 == "END" && show==1 {exit}
        show==1 {print}
    ' "$VERSION_FILE" 2>/dev/null
}

html_escape() {
    sed \
        -e 's/&/\&amp;/g' \
        -e 's/</\&lt;/g' \
        -e 's/>/\&gt;/g' \
        -e 's/"/\&quot;/g'
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_block Changes)
[ -z "$CHANGES" ] && CHANGES=$(get_value Changes)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
GITHUB=$(get_value GitHub)

# New structure: full multi-line release notes are stored as Notes<<END ... END.
NOTES=$(get_block Notes)
[ -z "$NOTES" ] && NOTES=$(get_value Notes | sed 's/&&&/\
/g; s/\*\*\*/\
/g')

# Backward compatibility for older version.txt files that still use Message.
[ -z "$NOTES" ] && NOTES=$(get_block Message)
[ -z "$NOTES" ] && NOTES=$(get_value Message | sed 's/&&&/\
/g; s/\*\*\*/\
/g')

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="None"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="Unknown"
[ -z "$GITHUB" ] && GITHUB="Unknown"
[ -z "$NOTES" ] && NOTES="No release notes available."

HOSTNAME=$(uci get system.@system[0].hostname 2>/dev/null)
[ -z "$HOSTNAME" ] && HOSTNAME=$(hostname 2>/dev/null)
DEVICE_NAME="$HOSTNAME"
MODEL=$(cat /tmp/sysinfo/model 2>/dev/null)
[ -z "$MODEL" ] && MODEL=$(ubus call system board 2>/dev/null | jsonfilter -e '@.model' 2>/dev/null)
KERNEL=$(ubus call system board 2>/dev/null | jsonfilter -e '@.kernel' 2>/dev/null)
ROUTER_FW=$(cat /etc/version 2>/dev/null)
SERIAL=$(mnf_info serial 2>/dev/null)
LANIP=$(ip -4 addr show br-lan 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1 | head -1)

# Reliable ZeroTier IP lookup. Prefer the known ZeroTier IP range first, then any zt interface.
ZT_IP=$(ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)
[ -z "$ZT_IP" ] && ZT_IP=$(ip -4 addr show 2>/dev/null | awk '/scope global/ && /zt/ {print $2}' | cut -d/ -f1 | head -1)

ZT_STATUS="Not installed"
ZT_NETWORKS=""
if [ -x "$ZT_CLI" ]; then
    ZT_STATUS=$($ZT_CLI -D"$ZT_HOME" info 2>/dev/null)
    ZT_NETWORKS=$($ZT_CLI -D"$ZT_HOME" listnetworks 2>/dev/null)
fi

ZT_URL_TOOLKIT=""
ZT_URL_ADMIN=""
if [ -n "$ZT_IP" ]; then
    ZT_URL_TOOLKIT="http://$ZT_IP:8080"
    ZT_URL_ADMIN="http://$ZT_IP:8081/cgi-bin/admin_login.sh"
fi

[ -z "$DEVICE_NAME" ] && DEVICE_NAME="Unknown"
[ -z "$HOSTNAME" ] && HOSTNAME="Unknown"
[ -z "$MODEL" ] && MODEL="Unknown"
[ -z "$KERNEL" ] && KERNEL="Unknown"
[ -z "$ROUTER_FW" ] && ROUTER_FW="Unknown"
[ -z "$SERIAL" ] && SERIAL="Unknown"
[ -z "$LANIP" ] && LANIP="Unknown"
[ -z "$ZT_IP" ] && ZT_IP="Not connected"
[ -z "$ZT_URL_TOOLKIT" ] && ZT_URL_TOOLKIT="Not available"
[ -z "$ZT_URL_ADMIN" ] && ZT_URL_ADMIN="Not available"
[ -z "$ZT_NETWORKS" ] && ZT_NETWORKS="No ZeroTier network information available."

VERSION_HTML=$(printf '%s' "$VERSION" | html_escape)
BUILD_HTML=$(printf '%s' "$BUILD" | html_escape)
RELEASE_HTML=$(printf '%s' "$RELEASE" | html_escape)
CHANGES_HTML=$(printf '%s' "$CHANGES" | html_escape)
COMPANY_HTML=$(printf '%s' "$COMPANY" | html_escape)
AUTHOR_HTML=$(printf '%s' "$AUTHOR" | html_escape)
EMAIL_HTML=$(printf '%s' "$EMAIL" | html_escape)
GITHUB_HTML=$(printf '%s' "$GITHUB" | html_escape)
NOTES_HTML=$(printf '%s' "$NOTES" | html_escape)
DEVICE_NAME_HTML=$(printf '%s' "$DEVICE_NAME" | html_escape)
HOSTNAME_HTML=$(printf '%s' "$HOSTNAME" | html_escape)
MODEL_HTML=$(printf '%s' "$MODEL" | html_escape)
KERNEL_HTML=$(printf '%s' "$KERNEL" | html_escape)
ROUTER_FW_HTML=$(printf '%s' "$ROUTER_FW" | html_escape)
SERIAL_HTML=$(printf '%s' "$SERIAL" | html_escape)
LANIP_HTML=$(printf '%s' "$LANIP" | html_escape)
ZTIP_HTML=$(printf '%s' "$ZT_IP" | html_escape)
ZT_STATUS_HTML=$(printf '%s' "$ZT_STATUS" | html_escape)
ZT_NETWORKS_HTML=$(printf '%s' "$ZT_NETWORKS" | html_escape)
ZT_URL_TOOLKIT_HTML=$(printf '%s' "$ZT_URL_TOOLKIT" | html_escape)
ZT_URL_ADMIN_HTML=$(printf '%s' "$ZT_URL_ADMIN" | html_escape)

cat <<HTML_EOF
<html>
<head>
<meta charset="UTF-8">
<title>About Matrix Toolkit</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; color: #333; }
.card { background: white; padding: 20px; border-radius: 8px; max-width: 900px; box-shadow: 0 1px 4px rgba(0,0,0,0.12); margin-bottom: 20px; }
h1 { margin-bottom: 5px; }
.version { font-size: 30px; font-weight: bold; color: #007bff; margin-bottom: 5px; }
.subtext { color: #666; margin-bottom: 20px; }
table { border-collapse: collapse; width: 100%; }
th { background: #007bff; color: white; padding: 8px; text-align: left; }
td { border: 1px solid #ddd; padding: 8px; vertical-align: top; }
pre { background: #111; color: #eee; padding: 12px; border-radius: 6px; overflow: auto; white-space: pre-wrap; }
.multiline { white-space: pre-line; line-height: 1.5; }
.release-notes { background: #f8f9fa; border-left: 5px solid #007bff; padding: 15px; margin-top: 10px; white-space: pre-line; word-wrap: break-word; line-height: 1.5; }
button { margin-top: 10px; width: 220px; height: 50px; font-size: 16px; font-weight: bold; cursor: pointer; border: 0; border-radius: 6px; background: #007bff; color: white; margin-right: 10px; }
@media (max-width: 700px) { body { margin: 12px; } .card { padding: 15px; } button { width: 100%; margin-right: 0; } }
</style>
</head>
<body>

<div class="card">
<h1>Matrix Toolkit</h1>
<div class="version">Version $VERSION_HTML</div>
<div class="subtext">Build $BUILD_HTML &bull; Release $RELEASE_HTML</div>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Company</td><td>$COMPANY_HTML</td></tr>
<tr><td>Author</td><td>$AUTHOR_HTML</td></tr>
<tr><td>Email</td><td>$EMAIL_HTML</td></tr>
<tr><td>GitHub</td><td>$GITHUB_HTML</td></tr>
<tr><td>Changes</td><td><div class="multiline">$CHANGES_HTML</div></td></tr>
</table>
</div>

<div class="card">
<h2>Router / Device Info</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Device Name</td><td>$DEVICE_NAME_HTML</td></tr>
<tr><td>Hostname</td><td>$HOSTNAME_HTML</td></tr>
<tr><td>Model</td><td>$MODEL_HTML</td></tr>
<tr><td>Serial Number</td><td>$SERIAL_HTML</td></tr>
<tr><td>Router Firmware</td><td>$ROUTER_FW_HTML</td></tr>
<tr><td>Kernel</td><td>$KERNEL_HTML</td></tr>
<tr><td>LAN IP</td><td>$LANIP_HTML</td></tr>
<tr><td>ZeroTier IP</td><td>$ZTIP_HTML</td></tr>
<tr><td>Toolkit URL</td><td>$ZT_URL_TOOLKIT_HTML</td></tr>
<tr><td>Admin URL</td><td>$ZT_URL_ADMIN_HTML</td></tr>
</table>
</div>

<div class="card">
<h2>ZeroTier Status</h2>
<pre>$ZT_STATUS_HTML</pre>
<h3>ZeroTier Networks</h3>
<pre>$ZT_NETWORKS_HTML</pre>
</div>

<div class="card">
<h2>Release Notes</h2>
<div class="release-notes">$NOTES_HTML</div>
</div>

<button onclick="window.location=window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_login.sh'">Back to Admin</button>
<button onclick="window.location='/index.html'">Home</button>

</body>
</html>
HTML_EOF
