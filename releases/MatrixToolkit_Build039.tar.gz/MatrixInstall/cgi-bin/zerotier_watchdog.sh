#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ZEROTIER WATCHDOG
# =====================================================
# Keeps ZeroTier alive on Teltonika/OpenWRT systems where
# the package binary lives in /usr/local/usr/bin.
# Intended to run from cron every minute.
# =====================================================

ZT_NET="cf719fd5409699a2"
ZT_BIN="/usr/local/usr/bin/zerotier-one"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"
ZT_HOME="/var/lib/zerotier-one"
LOG="/tmp/matrix_zerotier_watchdog.log"

log_msg() {
    echo "$(date) - $1" >> "$LOG"
    tail -50 "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG"
}

# Prefer Teltonika package location.
if [ ! -x "$ZT_BIN" ]; then
    if command -v zerotier-one >/dev/null 2>&1; then
        ZT_BIN="$(command -v zerotier-one)"
    else
        log_msg "zerotier-one not found"
        exit 0
    fi
fi

if [ ! -x "$ZT_CLI" ]; then
    if command -v zerotier-cli >/dev/null 2>&1; then
        ZT_CLI="$(command -v zerotier-cli)"
    else
        log_msg "zerotier-cli not found"
        exit 0
    fi
fi

mkdir -p "$ZT_HOME"

# Start ZeroTier if it is not running.
if ! ps | grep "[z]erotier-one" >/dev/null 2>&1; then
    log_msg "zerotier-one not running, starting"
    "$ZT_BIN" -d
    sleep 8
fi

# Join the Matrix ZeroTier network if missing.
"$ZT_CLI" listnetworks 2>/dev/null | grep "$ZT_NET" >/dev/null 2>&1
if [ $? -ne 0 ]; then
    log_msg "network $ZT_NET not joined, joining"
    "$ZT_CLI" join "$ZT_NET" >/dev/null 2>&1
    sleep 5
fi

# Basic status logging only when not OK.
ZT_STATUS="$("$ZT_CLI" listnetworks 2>/dev/null | grep "$ZT_NET")"
echo "$ZT_STATUS" | grep " OK " >/dev/null 2>&1
if [ $? -ne 0 ]; then
    log_msg "network status not OK: ${ZT_STATUS:-no status}"
fi

exit 0
