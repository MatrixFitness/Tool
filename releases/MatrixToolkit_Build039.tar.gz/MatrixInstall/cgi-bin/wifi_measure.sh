#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

LOCATION=$(echo "$QUERY_STRING" | sed -n 's/.*location=\([^&]*\).*/\1/p' | sed 's/%20/ /g;s/%2F/\//g;s/%26/\&/g;s/%28/(/g;s/%29/)/g;s/+/ /g')

CLIENT_IF=$(ifstatus wan1 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)
IPADDR=$(ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)
IWINFO_OUT=$(iwinfo "$CLIENT_IF" info 2>/dev/null)

# Read the real connected WiFi name from iwinfo.
# On Teltonika/OpenWrt, uci wireless.*.ssid can sometimes point to the wrong field,
# while iwinfo shows the actual connected ESSID, for example: ESSID: "BOSGOET".
SSID=$(echo "$IWINFO_OUT" | sed -n 's/.*ESSID: *"\([^"]*\)".*/\1/p' | head -1)
[ -z "$SSID" ] && SSID=$(uci get wireless.1.ssid 2>/dev/null)
[ -z "$SSID" ] && SSID="Unknown"

SIGNAL=$(echo "$IWINFO_OUT" | grep "Signal:" | awk '{print $2}')
QUALITY=$(echo "$IWINFO_OUT" | grep "Link Quality:" | awk '{print $6}')
BITRATE=$(echo "$IWINFO_OUT" | grep "Bit Rate:" | awk '{print $3" "$4}')
BSSID=$(echo "$IWINFO_OUT" | sed -n 's/.*Access Point: *\([0-9A-Fa-f:][0-9A-Fa-f:]*\).*/\1/p' | head -1)

# Robust channel and band detection for Teltonika / OpenWrt iwinfo output.
# Supported examples:
#   Mode: Client  Channel: 11 (2.462 GHz)  HT Mode: HT20
#   Channel: 36 (5.180 GHz)
#   Frequency: 5.180 GHz (Channel 36)
#   Channel 11
CHANNEL=$(echo "$IWINFO_OUT" | sed -n 's/.*Channel: *\([0-9][0-9]*\).*/\1/p' | head -1)
[ -z "$CHANNEL" ] && CHANNEL=$(echo "$IWINFO_OUT" | sed -n 's/.*Channel *\([0-9][0-9]*\).*/\1/p' | head -1)
[ -z "$CHANNEL" ] && CHANNEL=$(echo "$IWINFO_OUT" | sed -n 's/.*(Channel *\([0-9][0-9]*\)).*/\1/p' | head -1)

FREQ=$(echo "$IWINFO_OUT" | sed -n 's/.*Channel: *[0-9][0-9]* *(\([0-9.][0-9.]*\) GHz).*/\1/p' | head -1)
[ -z "$FREQ" ] && FREQ=$(echo "$IWINFO_OUT" | sed -n 's/.*Frequency: *\([0-9.][0-9.]*\).*/\1/p' | head -1)

BAND="Unknown"
if echo "$FREQ" | grep -q '^2\.'; then BAND="2.4 GHz"; fi
if echo "$FREQ" | grep -q '^5\.'; then BAND="5 GHz"; fi
if echo "$FREQ" | grep -q '^6\.'; then BAND="6 GHz"; fi

# Fallback when frequency is not available but channel is detected.
if [ "$BAND" = "Unknown" ] && echo "$CHANNEL" | grep -q '^[0-9][0-9]*$'; then
  if [ "$CHANNEL" -le 14 ]; then
    BAND="2.4 GHz"
  elif [ "$CHANNEL" -ge 1 ]; then
    BAND="5 GHz"
  fi
fi

[ -z "$BSSID" ] && BSSID="Unknown"
[ -z "$CHANNEL" ] && CHANNEL="Unknown"

DATE=$(date "+%Y-%m-%d %H:%M:%S")

# Normalize the signal value to a clean number.
# Example: "-46", "-46 dBm" or "-46dBm" all become "-46".
SIGNAL_NUM=$(echo "$SIGNAL" | sed 's/[^0-9-]//g')

SIGNAL_RATING="Unknown"
SIGNAL_COMMENT="No signal value was available. Check whether the router is connected as WiFi client."
if echo "$SIGNAL_NUM" | grep -q '^-*[0-9][0-9]*$'; then
  # Important: dBm values are negative. -46 is better than -70.
  if [ "$SIGNAL_NUM" -ge -50 ]; then
    SIGNAL_RATING="Excellent"
    SIGNAL_COMMENT="Excellent WiFi coverage. This location should provide very reliable connectivity for Matrix and EGYM equipment."
  elif [ "$SIGNAL_NUM" -ge -60 ]; then
    SIGNAL_RATING="Good"
    SIGNAL_COMMENT="Good WiFi coverage. Suitable for normal operation."
  elif [ "$SIGNAL_NUM" -ge -70 ]; then
    SIGNAL_RATING="Fair"
    SIGNAL_COMMENT="WiFi coverage is acceptable but could be improved. This location may work but has less margin for roaming or interference."
  else
    SIGNAL_RATING="Weak"
    SIGNAL_COMMENT="WiFi coverage is weak. Additional WiFi coverage or a better AP position is recommended before installing connected equipment."
  fi
fi

INTERNET="FAIL"; DNS="FAIL"; MATRIX="FAIL"
ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"
nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"
curl -s --connect-timeout 10 --max-time 15 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

PING_OUT=$(ping -c 5 -W 2 8.8.8.8 2>&1)
# BusyBox ping example:
# 5 packets transmitted, 5 packets received, 0% packet loss
# round-trip min/avg/max = 5.008/5.109/5.206 ms
PACKET_LOSS=$(echo "$PING_OUT" | sed -n 's/.*received, *\([0-9][0-9]*%\) packet loss.*/\1/p' | head -1)
LATENCY_AVG=$(echo "$PING_OUT" | awk -F'= ' '/round-trip|rtt/ {split($2,a,"/"); print a[2]}' | sed 's/ ms//g' | head -1)
[ -z "$PACKET_LOSS" ] && PACKET_LOSS="Unknown"
[ -z "$LATENCY_AVG" ] && LATENCY_AVG="Unknown"

SPEED_URL="https://speed.cloudflare.com/__down?bytes=5000000"
SPEED_TMP="/tmp/matrix_wifi_speedtest.bin"
SPEED_RESULT=$(curl -L -k -o "$SPEED_TMP" -w "%{speed_download} %{time_total} %{http_code}" --connect-timeout 10 --max-time 30 "$SPEED_URL" 2>/dev/null)
rm -f "$SPEED_TMP" 2>/dev/null
SPEED_BYTES=$(echo "$SPEED_RESULT" | awk '{print $1}')
SPEED_TIME=$(echo "$SPEED_RESULT" | awk '{print $2}')
SPEED_CODE=$(echo "$SPEED_RESULT" | awk '{print $3}')
DOWNLOAD_MBPS="Unknown"
if echo "$SPEED_BYTES" | grep -q '^[0-9]'; then
  DOWNLOAD_MBPS=$(awk "BEGIN {printf \"%.2f\", ($SPEED_BYTES*8)/1000000}")
fi

SPEED_RATING="Unknown"
SPEED_COMMENT="Download throughput could not be measured. Internet may still work but throughput was not available during this test."
if [ "$DOWNLOAD_MBPS" != "Unknown" ]; then
  SPEED_INT=$(echo "$DOWNLOAD_MBPS" | cut -d'.' -f1)
  if [ "$SPEED_INT" -ge 50 ]; then
    SPEED_RATING="Excellent"
    SPEED_COMMENT="Excellent throughput. Suitable for updates, HD streaming, Virtual Active/iFIT and larger deployments."
  elif [ "$SPEED_INT" -ge 20 ]; then
    SPEED_RATING="Good"
    SPEED_COMMENT="Good throughput for normal Matrix Fitness equipment and supported connected solutions and most updates."
  elif [ "$SPEED_INT" -ge 10 ]; then
    SPEED_RATING="Fair"
    SPEED_COMMENT="Usable throughput. Large updates and streaming may take longer."
  elif [ "$SPEED_INT" -ge 5 ]; then
    SPEED_RATING="Poor"
    SPEED_COMMENT="Low throughput. Basic connectivity may work, but update and media performance can be poor."
  else
    SPEED_RATING="Critical"
    SPEED_COMMENT="Critical throughput. This location is not recommended until WiFi or internet capacity is improved."
  fi
fi

QUALITY_RATING="Unknown"
QUALITY_COMMENT="Network quality could not be fully measured."
if [ "$LATENCY_AVG" != "Unknown" ]; then
  LAT_INT=$(echo "$LATENCY_AVG" | cut -d'.' -f1 | sed 's/[^0-9]//g')
  LOSS_INT=$(echo "$PACKET_LOSS" | sed 's/[^0-9]//g')
  [ -z "$LAT_INT" ] && LAT_INT=9999
  [ -z "$LOSS_INT" ] && LOSS_INT=9999
  if [ "$LOSS_INT" -eq 0 ] && [ "$LAT_INT" -lt 20 ]; then
    QUALITY_RATING="Excellent"
    QUALITY_COMMENT="Very responsive connection with no packet loss. This is ideal for Matrix Fitness cloud services and supported internet-connected equipment."
  elif [ "$LOSS_INT" -le 1 ] && [ "$LAT_INT" -lt 50 ]; then
    QUALITY_RATING="Good"
    QUALITY_COMMENT="Stable connection. Latency and packet loss are suitable for Matrix Fitness equipment."
  elif [ "$LOSS_INT" -le 3 ] && [ "$LAT_INT" -lt 100 ]; then
    QUALITY_RATING="Fair"
    QUALITY_COMMENT="Usable but with attention points. Small packet loss or higher latency can cause occasional delay."
  elif [ "$LOSS_INT" -le 5 ] && [ "$LAT_INT" -lt 200 ]; then
    QUALITY_RATING="Poor"
    QUALITY_COMMENT="Unstable connection. Investigate WiFi interference AP load roaming or WAN stability."
  else
    QUALITY_RATING="Critical"
    QUALITY_COMMENT="Critical stability issue. Packet loss or high latency must be fixed before installation."
  fi
fi

OVERALL="PASS"
[ "$INTERNET" = "FAIL" ] && OVERALL="FAIL"
[ "$DNS" = "FAIL" ] && OVERALL="FAIL"
[ "$MATRIX" = "FAIL" ] && OVERALL="FAIL"
[ "$SIGNAL_RATING" = "Weak" ] && OVERALL="ATTENTION"
[ "$SPEED_RATING" = "Poor" ] && OVERALL="ATTENTION"
[ "$SPEED_RATING" = "Critical" ] && OVERALL="FAIL"
[ "$QUALITY_RATING" = "Poor" ] && OVERALL="ATTENTION"
[ "$QUALITY_RATING" = "Critical" ] && OVERALL="FAIL"

case "$OVERALL" in
PASS) RECOMMENDATION="This location is suitable. Signal connectivity and network quality are acceptable for Matrix Fitness equipment and supported connected solutions.";;
ATTENTION) RECOMMENDATION="This location works but has attention points. Improve WiFi coverage or reduce interference if equipment will be used here permanently.";;
FAIL) RECOMMENDATION="This location is not recommended until the failing network items are solved. Check internet DNS Matrix Fitness cloud access signal and packet loss.";;
*) RECOMMENDATION="Review the measured values before installing equipment.";;
esac


rating_class(){
  case "$1" in
    Excellent|PASS) echo "g1";;
    Good) echo "g2";;
    Fair|ATTENTION) echo "y";;
    Poor|Weak) echo "o";;
    Critical|FAIL) echo "r";;
    *) echo "";;
  esac
}
SIG_DOT=$(rating_class "$SIGNAL_RATING")
SPEED_DOT=$(rating_class "$SPEED_RATING")
QUALITY_DOT=$(rating_class "$QUALITY_RATING")
OVERALL_DOT=$(rating_class "$OVERALL")


# Roaming assessment based on measured signal and band.
ROAMING_ASSESSMENT="Unknown"
if echo "$SIGNAL_NUM" | grep -q '^-*[0-9][0-9]*$'; then
  if [ "$SIGNAL_NUM" -ge -60 ]; then
    ROAMING_ASSESSMENT="Good - connected to a suitable access point"
  elif [ "$SIGNAL_NUM" -ge -70 ]; then
    ROAMING_ASSESSMENT="Attention - signal is acceptable but roaming should be checked"
  else
    ROAMING_ASSESSMENT="Poor - device may be connected to a distant access point"
  fi
fi
if [ "$BAND" = "2.4 GHz" ] && [ "$SIGNAL_RATING" = "Excellent" ]; then
  ROAMING_ASSESSMENT="Good - stable 2.4 GHz connection measured"
fi

enc(){ echo "$1" | sed 's/%/%25/g;s/ /%20/g;s/&/%26/g;s/\//%2F/g;s/+/%2B/g;s/#/%23/g'; }
SAVE_URL="/cgi-bin/save_measurement.sh?location=$(enc "$LOCATION")&ssid=$(enc "$SSID")&ipaddr=$(enc "$IPADDR")&signal=$(enc "$SIGNAL_NUM")&rating=$(enc "$SIGNAL_RATING")&quality=$(enc "$QUALITY")&bitrate=$(enc "$BITRATE")&band=$(enc "$BAND")&channel=$(enc "$CHANNEL")&bssid=$(enc "$BSSID")&roaming=$(enc "$ROAMING_ASSESSMENT")&internet=$INTERNET&dns=$DNS&matrix=$MATRIX&latency=$(enc "$LATENCY_AVG")&packetloss=$(enc "$PACKET_LOSS")&download=$(enc "$DOWNLOAD_MBPS")&speedrating=$(enc "$SPEED_RATING")&qualityrating=$(enc "$QUALITY_RATING")&overall=$(enc "$OVERALL")"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>WiFi Measurement Preview</title>
<style>:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333;--blue:#005a9c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1200px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:18px}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:14px}.card h1,.card h2{color:#0d3b66}.status{display:inline-block;border-radius:999px;background:var(--ok);color:#fff;padding:7px 12px;font-weight:800;font-size:13px}.status.warn{background:var(--warn)}.status.fail{background:var(--fail)}table{border-collapse:collapse;width:100%;background:#fff;margin-top:12px}td,th{border:1px solid var(--border);padding:10px;text-align:left}th{background:#f0f6fb;color:#1f2933}.note{background:#fff8d6;border:1px solid #e0c85a;padding:12px;border-radius:13px;margin:15px 0;line-height:1.45}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}button,.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer}.secondary{background:#667085!important}.warning{background:#b35b00!important}.summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:18px 0}.metric{border:1px solid var(--border);border-radius:13px;background:#f8fafc;padding:14px}.label{font-size:12px;color:var(--muted);font-weight:800;text-transform:uppercase}.value{font-size:22px;font-weight:900;margin-top:6px}.badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:bold;font-size:12px;margin-top:8px}.excellent{background:#1f8a3b;color:white}.good{background:#5cb85c;color:white}.fair{background:#f0ad4e;color:#222}.poor{background:#e67e22;color:white}.critical{background:#c0392b;color:white}.unknown{background:#777;color:white}.status-dot{width:14px;height:14px;display:inline-block;border-radius:50%;vertical-align:middle;margin-right:7px;border:1px solid rgba(0,0,0,.18)}.g1{background:#1f8a3b}.g2{background:#5cb85c}.y{background:#f0ad4e}.o{background:#e67e22}.r{background:#c0392b}.small{color:var(--muted);font-size:13px}.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn,button,.btn{width:100%;text-align:center}.actions{display:block}.actions button,.actions .btn{margin:6px 0}}</style>
</head>
<body>
<div class="page">
<section class="hero"><div><h1>WiFi Measurement Preview</h1><div class="sub">Review the measurement before saving it to the survey report</div><div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div></div><a class="top-btn" href="/">Back to Toolkit</a></section>
<div class="card">
<h1>WiFi Measurement Preview</h1>
<div class="sub">Review the measurement and save it to the final survey report.</div>

<h2>Location</h2>
<table>
<tr><th>Location</th><th>Date</th><th>Result</th></tr>
<tr><td><b>$LOCATION</b></td><td>$DATE</td><td><span class="status-dot $OVERALL_DOT"></span><b>$OVERALL</b></td></tr>
</table>

<h2>Measurement Overview</h2>
<div class="summary">
  <div class="metric"><div class="label">Signal Strength</div><div class="value"><span class="status-dot $SIG_DOT"></span>$SIGNAL_NUM dBm</div><div><span class="badge $(echo "$SIGNAL_RATING" | tr 'A-Z' 'a-z')">$SIGNAL_RATING</span></div></div>
  <div class="metric"><div class="label">Download Speed</div><div class="value"><span class="status-dot $SPEED_DOT"></span>$DOWNLOAD_MBPS Mbps</div><div><span class="badge $(echo "$SPEED_RATING" | tr 'A-Z' 'a-z')">$SPEED_RATING</span></div></div>
  <div class="metric"><div class="label">Latency</div><div class="value"><span class="status-dot $QUALITY_DOT"></span>$LATENCY_AVG ms</div><div><span class="badge $(echo "$QUALITY_RATING" | tr 'A-Z' 'a-z')">$QUALITY_RATING</span></div></div>
  <div class="metric"><div class="label">Packet Loss</div><div class="value"><span class="status-dot $QUALITY_DOT"></span>$PACKET_LOSS</div><div><span class="badge $(echo "$QUALITY_RATING" | tr 'A-Z' 'a-z')">Network Quality</span></div></div>
</div>

<h2>Connected WiFi Details</h2>
<table>
<tr><th>Item</th><th>Value</th></tr>
<tr><td><b>SSID</b></td><td>$SSID</td></tr>
<tr><td><b>Band</b></td><td>$BAND</td></tr>
<tr><td><b>Channel</b></td><td>Channel $CHANNEL</td></tr>
<tr><td><b>Connected Access Point (BSSID)</b></td><td>$BSSID</td></tr>
<tr><td><b>Roaming Assessment</b></td><td>$ROAMING_ASSESSMENT</td></tr>
<tr><td><b>Internet / DNS / Matrix Fitness Cloud</b></td><td>$INTERNET / $DNS / $MATRIX</td></tr>
</table>

<div class="note">
This is only a measurement preview. The full professional Matrix Fitness WiFi Survey Report is generated when you choose <b>Finish Survey</b>.
</div>

<div class="actions">
<button onclick="window.location='$SAVE_URL'">Save Measurement</button>
<button class="secondary" onclick="window.location='/cgi-bin/next_location.sh'">Back to Progress</button>
<button class="secondary" onclick="window.location='/cgi-bin/final_report.sh'">Finish Survey</button>
</div>
</div><div class="footer">Matrix Fitness &middot; WiFi Measurement</div></div>
</body>
</html>
HTML
