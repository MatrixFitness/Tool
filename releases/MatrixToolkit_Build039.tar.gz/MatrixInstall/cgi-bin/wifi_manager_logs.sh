#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
. /usr/local/matrix/web/cgi-bin/wifi_page_lib.sh
wifi_page_head "WiFi Logs"
LOG="/usr/local/matrix/logs/wifi_manager.log"
[ -s "$LOG" ] || LOG="/tmp/matrix_wifi_manager.log"
cat <<HTML
<section class="card"><pre>$(tail -n 200 "$LOG" 2>/dev/null)</pre>
<p><a class="btn grey" href="/cgi-bin/wifi_manager.sh">Back</a></p></section>
HTML
wifi_page_foot
