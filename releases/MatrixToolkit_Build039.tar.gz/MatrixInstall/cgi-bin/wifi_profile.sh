#!/bin/sh
TYPE="$(printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep '^type=' | cut -d= -f2-)"
P="$(printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep '^p=' | cut -d= -f2-)"
[ -z "$P" ] && P="$(printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep '^profile=' | cut -d= -f2-)"
[ -z "$TYPE" ] && TYPE="user"
echo "Status: 302 Found"
echo "Location: /cgi-bin/wifi_manager.sh?action=apply&type=$TYPE&p=$P"
echo ""
