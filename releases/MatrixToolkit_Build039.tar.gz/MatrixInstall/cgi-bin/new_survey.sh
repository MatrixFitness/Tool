#!/bin/sh

echo "Content-Type: text/html"
echo ""

SURVEY_DIR="/usr/local/matrix/survey"
LOCATIONS_FILE="$SURVEY_DIR/locations.txt"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"
CSV="$SURVEY_DIR/wifi_survey_results.csv"

html_start(){
cat <<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Start WiFi Survey</title><style>:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333;--blue:#005a9c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1200px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:18px}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:14px}.card h1,.card h2{color:#0d3b66}.status{display:inline-block;border-radius:999px;background:var(--ok);color:#fff;padding:7px 12px;font-weight:800;font-size:13px}.status.warn{background:var(--warn)}.status.fail{background:var(--fail)}table{border-collapse:collapse;width:100%;background:#fff;margin-top:12px}td,th{border:1px solid var(--border);padding:10px;text-align:left}th{background:#f0f6fb;color:#1f2933}.note{background:#fff8d6;border:1px solid #e0c85a;padding:12px;border-radius:13px;margin:15px 0;line-height:1.45}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}button,.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer}.secondary{background:#667085!important}.warning{background:#b35b00!important}.summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:18px 0}.metric{border:1px solid var(--border);border-radius:13px;background:#f8fafc;padding:14px}.label{font-size:12px;color:var(--muted);font-weight:800;text-transform:uppercase}.value{font-size:22px;font-weight:900;margin-top:6px}.badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:bold;font-size:12px;margin-top:8px}.excellent{background:#1f8a3b;color:white}.good{background:#5cb85c;color:white}.fair{background:#f0ad4e;color:#222}.poor{background:#e67e22;color:white}.critical{background:#c0392b;color:white}.unknown{background:#777;color:white}.status-dot{width:14px;height:14px;display:inline-block;border-radius:50%;vertical-align:middle;margin-right:7px;border:1px solid rgba(0,0,0,.18)}.g1{background:#1f8a3b}.g2{background:#5cb85c}.y{background:#f0ad4e}.o{background:#e67e22}.r{background:#c0392b}.small{color:var(--muted);font-size:13px}.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn,button,.btn{width:100%;text-align:center}.actions{display:block}.actions button,.actions .btn{margin:6px 0}}code,pre{background:#f3f3f3;padding:3px 5px;border-radius:4px}pre{padding:12px;white-space:pre-wrap}</style></head>
<body>
<div class="page">
<section class="hero"><div><h1>Start New WiFi Survey</h1><div class="sub">New survey setup and selected locations</div><div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div></div><a class="top-btn" href="/">Back to Toolkit</a></section>
<div class="card">
HTML
}

html_end(){
cat <<HTML
</div><div class="footer">Matrix Fitness &middot; WiFi Survey</div></div></body></html>
HTML
}

url_decode(){
  # Basic URL decode for the characters used by the survey page.
  printf '%s' "$1" | sed 's/%7C/|/g;s/%7c/|/g;s/%20/ /g;s/%2F/\//g;s/%2f/\//g;s/%2D/-/g;s/%2d/-/g;s/%28/(/g;s/%29/)/g;s/%26/\&/g;s/%2B/+/g;s/+/ /g'
}

html_start

echo "<h1>Start New WiFi Survey</h1>"

# Create persistent survey folder. This must be writable by CGI/uhttpd.
if ! mkdir -p "$SURVEY_DIR" 2>/tmp/matrix_survey_mkdir.err; then
  echo "<p class='err'>Cannot create survey folder: $SURVEY_DIR</p>"
  echo "<p>Run this once via SSH as root:</p>"
  cat <<'HTML'
<pre>mkdir -p /usr/local/matrix/survey
chmod 777 /usr/local/matrix/survey</pre>
HTML
  echo "<button onclick=\"window.location='/location_survey.html'\">Back</button>"
  html_end
  exit 0
fi

# Make sure CGI/uhttpd can write survey state.
chmod 777 "$SURVEY_DIR" 2>/dev/null

# Check write permissions before continuing.
if ! touch "$SURVEY_DIR/.write_test" 2>/tmp/matrix_survey_write.err; then
  echo "<p class='err'>Survey folder exists, but CGI cannot write to it.</p>"
  echo "<p>Run this once via SSH as root:</p>"
  echo "<pre>chmod 777 /usr/local/matrix/survey</pre>"
  echo "<button onclick=\"window.location='/location_survey.html'\">Back</button>"
  html_end
  exit 0
fi
rm -f "$SURVEY_DIR/.write_test"

RAW=$(echo "$QUERY_STRING" | sed -n 's/.*locations=\([^&]*\).*/\1/p')
RAW=$(url_decode "$RAW")

if [ -z "$RAW" ]; then
  echo "<p class='err'>No locations selected.</p>"
  echo "<button onclick=\"window.location='/location_survey.html'\">Back</button>"
  html_end
  exit 0
fi

# Reset existing survey and create new persistent state.
rm -f "$LOCATIONS_FILE" "$COMPLETED_FILE" "$CSV"

echo "Date,Location,SSID,IP Address,Signal,Rating,Link Quality,Bit Rate,Band,Channel,BSSID,Roaming Assessment,Internet,DNS,Matrix,Latency,Packet Loss,Download Mbps,Speed Rating,Network Quality,Overall" > "$CSV"
echo "$RAW" | tr '|' '\n' | sed '/^$/d' > "$LOCATIONS_FILE"
: > "$COMPLETED_FILE"

COUNT=$(wc -l < "$LOCATIONS_FILE" 2>/dev/null)

echo "<p class='ok'>New survey started successfully.</p>"
echo "<p><b>Selected locations:</b> $COUNT</p>"
echo "<p>The survey state is stored in:</p>"
echo "<pre>$SURVEY_DIR</pre>"
echo "<p>You can power off the router between locations. After reconnecting WiFi, use <b>Continue Survey</b>.</p>"
echo "<button onclick=\"window.location='/cgi-bin/next_location.sh'\">Continue to First Location</button>"
echo "<button class='secondary' onclick=\"window.location='/location_survey.html'\">Back</button>"

html_end
exit 0
