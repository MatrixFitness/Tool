#!/bin/sh
echo "Content-Type: text/html; charset=UTF-8"
echo ""

IPADDR="$(ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)"
GATEWAY="$(ifstatus wan1 2>/dev/null | grep '"nexthop"' | head -1 | cut -d'"' -f4)"
DEV="$(ifstatus wan1 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)"
IWINFO_OUT=""
[ -n "$DEV" ] && IWINFO_OUT="$(iwinfo "$DEV" info 2>/dev/null)"
SSID="$(echo "$IWINFO_OUT" | sed -n 's/.*ESSID: *"\([^"]*\)".*/\1/p' | head -1)"
SIGNAL="$(echo "$IWINFO_OUT" | awk '/Signal:/ {print $2; exit}')"
AP="$(echo "$IWINFO_OUT" | sed -n 's/.*Access Point: *\([0-9A-Fa-f:][0-9A-Fa-f:]*\).*/\1/p' | head -1)"
[ -z "$IPADDR" ] && IPADDR="-"
[ -z "$GATEWAY" ] && GATEWAY="-"
[ -z "$SSID" ] && SSID="-"
[ -z "$SIGNAL" ] && SIGNAL="Unknown"
[ -z "$AP" ] && AP="-"

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Customer WiFi Status</title>
<style>
body{font-family:Arial;background:#eef2f6;color:#1f2933;margin:0}.page{max-width:900px;margin:0 auto;padding:18px}.hero{background:#005a9c;color:#fff;border-radius:18px;padding:22px}.card{background:#fff;border:1px solid #d9e2ec;border-radius:18px;padding:18px;margin-top:18px}.ok{color:#1f8a3b}.warn{color:#b05a00}.btn{display:inline-block;background:#005a9c;color:#fff;text-decoration:none;border-radius:12px;padding:12px 15px;font-weight:800;margin:8px 8px 0 0}
</style>
EOF
[ "$IPADDR" = "-" ] && echo "<meta http-equiv='refresh' content='5;url=/cgi-bin/wifi_connect_status.sh'>"
cat <<EOF
</head><body><div class="page"><div class="hero"><h1>Customer WiFi Status</h1></div><div class="card">
EOF
if [ "$IPADDR" != "-" ]; then
    echo "<h2 class='ok'>CONNECTED</h2>"
else
    echo "<h2 class='warn'>Still waiting for DHCP lease...</h2>"
fi
cat <<EOF
<p><b>SSID:</b> $SSID</p>
<p><b>IP:</b> $IPADDR</p>
<p><b>Gateway:</b> $GATEWAY</p>
<p><b>Signal:</b> $SIGNAL dBm</p>
<p><b>AP:</b> $AP</p>
<a class="btn" href="/cgi-bin/wifi_manager.sh">Open WiFi Manager</a>
<a class="btn" href="/cgi-bin/wifi_survey.sh">Back to WiFi Wizard</a>
<a class="btn" href="/">Back to Toolkit</a>
</div></div></body></html>
EOF
