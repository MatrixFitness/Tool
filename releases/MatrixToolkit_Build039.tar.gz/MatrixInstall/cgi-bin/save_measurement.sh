#!/bin/sh

printf "Content-Type: text/html\n\n"

SURVEY_DIR="/usr/local/matrix/survey"
CSV="$SURVEY_DIR/wifi_survey_results.csv"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"
LOGO="/matrix_logo.png"

mkdir -p "$SURVEY_DIR" 2>/dev/null
chmod 777 "$SURVEY_DIR" 2>/dev/null
[ -f "$CSV" ] || echo "Date,Location,SSID,IP Address,Signal,Rating,Link Quality,Bit Rate,Band,Channel,BSSID,Roaming Assessment,Internet,DNS,Matrix,Latency,Packet Loss,Download Mbps,Speed Rating,Network Quality,Overall" > "$CSV"
[ -f "$COMPLETED_FILE" ] || : > "$COMPLETED_FILE"

DATE=$(date "+%Y-%m-%d %H:%M:%S")

url_decode(){
  printf '%s' "$1" | sed 's/%20/ /g;s/%2F/\//g;s/%2f/\//g;s/%2D/-/g;s/%2d/-/g;s/%28/(/g;s/%29/)/g;s/%26/\&/g;s/%2B/+/g;s/%2b/+/g;s/%23/#/g;s/%3A/:/g;s/%3a/:/g;s/%25/%/g;s/+/ /g'
}

get_param(){
  # Important: match the exact query parameter name.
  # The old method used .*ssid= and accidentally matched bssid=,
  # causing the AP MAC/BSSID to be saved under SSID.
  printf '%s' "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read -r key value; do
    if [ "$key" = "$1" ]; then
      url_decode "$value"
      break
    fi
  done
}

html_escape(){
  printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

badge_class(){
  case "$1" in
    Excellent|PASS) echo "excellent";;
    Good) echo "good";;
    Fair|ATTENTION) echo "fair";;
    Poor|Weak) echo "poor";;
    Critical|FAIL) echo "critical";;
    *) echo "unknown";;
  esac
}

dot_class(){
  case "$1" in
    Excellent|PASS) echo "dot-excellent";;
    Good) echo "dot-good";;
    Fair|ATTENTION) echo "dot-fair";;
    Poor|Weak) echo "dot-poor";;
    Critical|FAIL) echo "dot-critical";;
    *) echo "dot-unknown";;
  esac
}

LOCATION=$(get_param location)
SSID=$(get_param ssid)
IPADDR=$(get_param ipaddr)
SIGNAL=$(get_param signal)
RATING=$(get_param rating)
QUALITY=$(get_param quality)
BITRATE=$(get_param bitrate)
BAND=$(get_param band)
CHANNEL=$(get_param channel)
BSSID=$(get_param bssid)
ROAMING=$(get_param roaming)
INTERNET=$(get_param internet)
DNS=$(get_param dns)
MATRIX=$(get_param matrix)
LATENCY=$(get_param latency)
PACKETLOSS=$(get_param packetloss)
DOWNLOAD=$(get_param download)
SPEEDRATING=$(get_param speedrating)
QUALITYRATING=$(get_param qualityrating)
OVERALL=$(get_param overall)

[ -z "$LOCATION" ] && LOCATION="Unknown"
[ -z "$SSID" ] && SSID="Unknown"
[ -z "$BAND" ] && BAND="Unknown"
[ -z "$CHANNEL" ] && CHANNEL="Unknown"
[ -z "$BSSID" ] && BSSID="Unknown"
[ -z "$ROAMING" ] && ROAMING="Unknown"
[ -z "$OVERALL" ] && OVERALL="PASS"

# Prevent duplicate save for the same location during resume/retry.
if ! grep -Fxq "$LOCATION" "$COMPLETED_FILE" 2>/dev/null; then
  echo "$DATE,$LOCATION,$SSID,$IPADDR,$SIGNAL,$RATING,$QUALITY,$BITRATE,$BAND,$CHANNEL,$BSSID,$ROAMING,$INTERNET,$DNS,$MATRIX,$LATENCY,$PACKETLOSS,$DOWNLOAD,$SPEEDRATING,$QUALITYRATING,$OVERALL" >> "$CSV"
  echo "$LOCATION" >> "$COMPLETED_FILE"
fi

RC=$(badge_class "$RATING")
SC=$(badge_class "$SPEEDRATING")
QC=$(badge_class "$QUALITYRATING")
OC=$(badge_class "$OVERALL")
RD=$(dot_class "$RATING")
SD=$(dot_class "$SPEEDRATING")
QD=$(dot_class "$QUALITYRATING")
OD=$(dot_class "$OVERALL")

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Measurement Saved</title>
<style>:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333;--blue:#005a9c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1200px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:18px}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:14px}.card h1,.card h2{color:#0d3b66}.status{display:inline-block;border-radius:999px;background:var(--ok);color:#fff;padding:7px 12px;font-weight:800;font-size:13px}.status.warn{background:var(--warn)}.status.fail{background:var(--fail)}table{border-collapse:collapse;width:100%;background:#fff;margin-top:12px}td,th{border:1px solid var(--border);padding:10px;text-align:left}th{background:#f0f6fb;color:#1f2933}.note{background:#fff8d6;border:1px solid #e0c85a;padding:12px;border-radius:13px;margin:15px 0;line-height:1.45}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}button,.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer}.secondary{background:#667085!important}.warning{background:#b35b00!important}.summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:18px 0}.metric{border:1px solid var(--border);border-radius:13px;background:#f8fafc;padding:14px}.label{font-size:12px;color:var(--muted);font-weight:800;text-transform:uppercase}.value{font-size:22px;font-weight:900;margin-top:6px}.badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:bold;font-size:12px;margin-top:8px}.excellent{background:#1f8a3b;color:white}.good{background:#5cb85c;color:white}.fair{background:#f0ad4e;color:#222}.poor{background:#e67e22;color:white}.critical{background:#c0392b;color:white}.unknown{background:#777;color:white}.status-dot{width:14px;height:14px;display:inline-block;border-radius:50%;vertical-align:middle;margin-right:7px;border:1px solid rgba(0,0,0,.18)}.g1{background:#1f8a3b}.g2{background:#5cb85c}.y{background:#f0ad4e}.o{background:#e67e22}.r{background:#c0392b}.small{color:var(--muted);font-size:13px}.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn,button,.btn{width:100%;text-align:center}.actions{display:block}.actions button,.actions .btn{margin:6px 0}}.success{background:#eefaf0;border-left:6px solid var(--ok);padding:14px;border-radius:13px;margin:18px 0;line-height:1.5}.details{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:14px;margin:14px 0;line-height:1.7}</style>
</head>
<body>
<div class="page">
<section class="hero"><div><h1>Measurement Saved</h1><div class="sub">The location measurement has been saved</div><div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div></div><a class="top-btn" href="/">Back to Toolkit</a></section>
<div class="card">
<h1>Measurement Saved</h1>
<div class="success"><b>$LOCATION</b> has been saved to the survey.</div>
<div class="details">
<b>Result:</b> $OVERALL<br>
<b>Signal:</b> $SIGNAL dBm ($RATING)<br>
<b>Download:</b> $DOWNLOAD Mbps ($SPEEDRATING)<br>
<b>Latency / Packet Loss:</b> $LATENCY ms / $PACKETLOSS<br>
<b>SSID:</b> $SSID<br>
<b>Band:</b> $BAND<br>
<b>Channel:</b> Channel $CHANNEL
</div>
<p class="small">You may now move the router to the next location. The final report is created only when you click <b>Finish Survey</b>.</p>
<div class="actions">
<button onclick="window.location='/cgi-bin/next_location.sh'">Next Location</button>
<button class="secondary" onclick="window.location='/cgi-bin/final_report.sh'">Finish Survey</button>
<button class="secondary" onclick="window.location='/location_survey.html'">Survey Home</button>
</div>
</div><div class="footer">Matrix Fitness &middot; WiFi Survey</div></div>
</body>
</html>
HTML
