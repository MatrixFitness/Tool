#!/bin/sh
printf "Content-Type: text/plain; charset=UTF-8\n"
printf "Cache-Control: no-store\n"
printf "Access-Control-Allow-Origin: *\n\n"
LIB="/usr/local/matrix/lib/fleet_status.sh"
if [ -f "$LIB" ]; then
    . "$LIB"
    fleet_local_status
else
    HOST="$(uci -q get system.@system[0].hostname)"
[ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"
printf 'Hostname=%s\n' "$HOST"
    printf 'Status=ONLINE\n'
    printf 'Timestamp=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
fi
