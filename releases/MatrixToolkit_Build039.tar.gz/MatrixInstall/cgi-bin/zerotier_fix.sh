#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_manager.sh
