#!/bin/sh
exec /usr/local/matrix/web/cgi-bin/diag.sh "$@"
