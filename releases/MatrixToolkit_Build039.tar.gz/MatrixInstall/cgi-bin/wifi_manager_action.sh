#!/bin/sh
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"
ensure_wifi_files

ACTION="$(qs action)"
BAND="$(qs band)"
TYPE="$(qs type)"
IDX="$(qs p)"

redirect(){
    printf "Status: 302 Found\n"
    printf "Location: %s\n\n" "$1"
    exit 0
}

valid_password(){
    [ "${#1}" -ge 8 ]
}

case "$ACTION" in
    enable_2g)
        uci set wireless.default_radio0.disabled='0'
        ;;
    disable_2g)
        uci set wireless.default_radio0.disabled='1'
        ;;
    enable_5g)
        uci set wireless.default_radio1.disabled='0'
        ;;
    disable_5g)
        uci set wireless.default_radio1.disabled='1'
        ;;
    enable_both)
        uci set wireless.default_radio0.disabled='0'
        uci set wireless.default_radio1.disabled='0'
        ;;
    disable_both)
        uci set wireless.default_radio0.disabled='1'
        uci set wireless.default_radio1.disabled='1'
        ;;
    restore_matrix)
        restore_matrix_default_wifi
        redirect "/cgi-bin/wifi_manager.sh"
        ;;
    apply)
        profile_apply "$TYPE" "$IDX"
        redirect "/cgi-bin/wifi_manager_profiles.sh"
        ;;
    configure)
        SSID2="$(qs ssid2)"
        PASS2="$(qs pass2)"
        SSID5="$(qs ssid5)"
        PASS5="$(qs pass5)"
        SAME="$(qs same)"

        if [ "$BAND" = "both" ] && [ "$SAME" = "1" ]; then
            SSID5="$SSID2"
            PASS5="$PASS2"
        fi

        case "$BAND" in
            2g)
                [ -n "$SSID2" ] && valid_password "$PASS2" || redirect "/cgi-bin/wifi_manager_configure.sh?band=2g&error=1"
                uci set wireless.default_radio0.ssid="$SSID2"
                uci set wireless.default_radio0.key="$PASS2"
                uci set wireless.default_radio0.encryption='psk2'
                uci set wireless.default_radio0.disabled='0'
                ;;
            5g)
                [ -n "$SSID5" ] && valid_password "$PASS5" || redirect "/cgi-bin/wifi_manager_configure.sh?band=5g&error=1"
                uci set wireless.default_radio1.ssid="$SSID5"
                uci set wireless.default_radio1.key="$PASS5"
                uci set wireless.default_radio1.encryption='psk2'
                uci set wireless.default_radio1.disabled='0'
                ;;
            both)
                [ -n "$SSID2" ] && [ -n "$SSID5" ] && valid_password "$PASS2" && valid_password "$PASS5" || redirect "/cgi-bin/wifi_manager_configure.sh?band=both&error=1"
                uci set wireless.default_radio0.ssid="$SSID2"
                uci set wireless.default_radio0.key="$PASS2"
                uci set wireless.default_radio0.encryption='psk2'
                uci set wireless.default_radio0.disabled='0'
                uci set wireless.default_radio1.ssid="$SSID5"
                uci set wireless.default_radio1.key="$PASS5"
                uci set wireless.default_radio1.encryption='psk2'
                uci set wireless.default_radio1.disabled='0'
                ;;
            *) redirect "/cgi-bin/wifi_manager.sh" ;;
        esac
        ;;
    reload_wifi)
        wifi reload >/dev/null 2>&1
        redirect "/cgi-bin/wifi_manager.sh"
        ;;
    *)
        redirect "/cgi-bin/wifi_manager.sh"
        ;;
esac

uci commit wireless
wifi reload >/dev/null 2>&1
echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi action=$ACTION band=$BAND" >> "$LOG"
redirect "/cgi-bin/wifi_manager.sh"
