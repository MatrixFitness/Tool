# Matrix Toolkit v59.5 Release Notes

This is a safe stable release focused only on the WiFi Manager.

Existing functions such as USB install, GitHub Update, Admin login, LTE Analyse, Matrix tests, ZeroTier and Diagnostics are intentionally left unchanged except for the minimal WiFi Manager integration.

## Installation
Replace `MatrixToolkit.tar.gz` in GitHub and run the normal GitHub Update on the router.

No manual SSH copy, chmod, mkdir or profile file creation should be required.
