#!/bin/sh
mkdir -p /usr/local/matrix/platform /usr/local/bin
[ -d /tmp/MatrixInstall/platform ] && cp -R /tmp/MatrixInstall/platform/* /usr/local/matrix/platform/ 2>/dev/null || true
[ -d /tmp/MatrixInstall/bin ] && cp -f /tmp/MatrixInstall/bin/* /usr/local/bin/ 2>/dev/null || true
chmod +x /usr/local/matrix/platform/*.sh 2>/dev/null || true
chmod +x /usr/local/bin/matrix-* 2>/dev/null || true
