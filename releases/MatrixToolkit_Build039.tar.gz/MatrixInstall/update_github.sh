#!/bin/sh
# Root copy placeholder. Runtime updater is cgi-bin/update_github.sh.
exec /usr/local/matrix/web/cgi-bin/update_github.sh "$@"
