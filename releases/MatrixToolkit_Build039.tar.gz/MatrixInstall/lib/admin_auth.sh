#!/bin/sh
MATRIX_ADMIN_PASSWORD_FILE="${MATRIX_ADMIN_PASSWORD_FILE:-/usr/local/matrix/admin_password.txt}"
MATRIX_ADMIN_DEFAULT_PASSWORD="${MATRIX_ADMIN_DEFAULT_PASSWORD:-Matrix2025}"
MATRIX_ADMIN_SESSION_DIR="${MATRIX_ADMIN_SESSION_DIR:-/tmp/matrix_admin_sessions}"

matrix_admin_password_valid(){ [ -s "$MATRIX_ADMIN_PASSWORD_FILE" ]; }
matrix_admin_password_permissions_ok(){
    [ -e "$MATRIX_ADMIN_PASSWORD_FILE" ] || return 1
    MODE="$(stat -c '%a' "$MATRIX_ADMIN_PASSWORD_FILE" 2>/dev/null)"
    OWNER="$(stat -c '%U:%G' "$MATRIX_ADMIN_PASSWORD_FILE" 2>/dev/null)"
    [ "$MODE" = "644" ] && [ "$OWNER" = "root:root" ]
}
matrix_admin_fix_permissions(){
    chown root:root "$MATRIX_ADMIN_PASSWORD_FILE" 2>/dev/null || true
    chmod 644 "$MATRIX_ADMIN_PASSWORD_FILE"
}
matrix_admin_clear_sessions(){ rm -rf "$MATRIX_ADMIN_SESSION_DIR" 2>/dev/null || true; }
matrix_admin_ensure_password(){
    REPAIRED=0
    mkdir -p "$(dirname "$MATRIX_ADMIN_PASSWORD_FILE")" || return 1
    if ! matrix_admin_password_valid; then
        umask 022
        printf '%s\n' "$MATRIX_ADMIN_DEFAULT_PASSWORD" > "$MATRIX_ADMIN_PASSWORD_FILE" || return 1
        REPAIRED=1
    fi
    if ! matrix_admin_password_permissions_ok; then
        matrix_admin_fix_permissions || return 1
        REPAIRED=1
    fi
    [ "$REPAIRED" -eq 1 ] && return 2
    return 0
}
matrix_admin_finalize_repair(){
    RC="$1"
    [ "$RC" -eq 2 ] || return 0
    matrix_admin_clear_sessions
    if [ "${MATRIX_ADMIN_RESTART_WEB:-0}" = "1" ] && [ -x /etc/init.d/uhttpd ]; then
        /usr/local/bin/matrix-web-reload >/dev/null 2>&1 || true
    fi
}
matrix_admin_restart_web_if_repaired(){ matrix_admin_finalize_repair "$1"; }
