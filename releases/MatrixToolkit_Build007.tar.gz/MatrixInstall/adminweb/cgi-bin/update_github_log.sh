#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
LOG="/tmp/matrix_update_github.log"
TECH="/tmp/matrix_update_technical.log"
HIST="/usr/local/matrix/logs/update_history.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

LOG_TXT="$(cat "$LOG" 2>/dev/null)"
[ -z "$LOG_TXT" ] && LOG_TXT="No update log found yet."
TECH_TXT="$(tail -n 180 "$TECH" 2>/dev/null)"
[ -z "$TECH_TXT" ] && TECH_TXT="No technical details available."
HIST_TXT="$(tail -n 120 "$HIST" 2>/dev/null)"
[ -z "$HIST_TXT" ] && HIST_TXT="No update history available."

STATE="IDLE"
MSG="No update running."
REFRESH=""

if [ -f "$REQ" ]; then
  STATE="WAITING"; MSG="Waiting for root update worker..."; REFRESH='<meta http-equiv="refresh" content="2">'
elif [ -f "$LOCK" ]; then
  OLD="$(cat "$LOCK" 2>/dev/null)"
  if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
    STATE="RUNNING"; MSG="Update is running. The page will reconnect automatically."; REFRESH='<meta http-equiv="refresh" content="2">'
  else
    STATE="STALE"; MSG="Stale lock detected. Refresh or run matrix-update again."
  fi
elif echo "$LOG_TXT" | grep -q "Already up to date"; then
  STATE="UPTODATE"; MSG="Already up to date."
elif echo "$LOG_TXT" | grep -q "UPDATE COMPLETED SUCCESSFULLY"; then
  STATE="SUCCESS"; MSG="Update completed successfully."
elif echo "$LOG_TXT" | grep -q "UPDATE COMPLETED"; then
  STATE="SUCCESS"; MSG="Update completed."
elif echo "$LOG_TXT" | grep -q "UPDATE FAILED\|ERROR:"; then
  STATE="FAILED"; MSG="Update failed. Open technical details for more information."
elif echo "$LOG_TXT" | grep -q "Waiting for root update worker"; then
  STATE="WAITING"; MSG="Waiting for root update worker..."; REFRESH='<meta http-equiv="refresh" content="2">'
fi

CURRENT="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
LATEST="$(wget -qO- https://raw.githubusercontent.com/MatrixFitness/Tool/main/latest.txt 2>/dev/null | tr -d '\r\n ')"
[ -z "$CURRENT" ] && CURRENT="Unknown"
[ -z "$LATEST" ] && LATEST="Unknown"

cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Matrix Cloud Update Log</title><meta name="viewport" content="width=device-width, initial-scale=1">$REFRESH
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}.card{background:white;border-radius:16px;padding:18px;max-width:1100px;margin:14px auto;box-shadow:0 3px 12px #0001}h1{color:#00589c}.badge{display:inline-block;border-radius:999px;padding:8px 13px;font-weight:bold}.WAITING,.RUNNING{background:#fff4ce;color:#8a5a00}.SUCCESS,.UPTODATE{background:#dff3e4;color:#137333}.FAILED,.STALE{background:#fde2e2;color:#a10000}.IDLE{background:#e5e7eb;color:#374151}pre{background:#0f172a;color:#e5e7eb;padding:14px;border-radius:12px;overflow:auto;white-space:pre-wrap}.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:11px 14px;font-weight:bold;margin:4px}.note{background:#eaf4ff;border-left:6px solid #007bff;padding:12px;border-radius:10px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px}.metric{background:#f8fafc;border:1px solid #d9e2ec;border-radius:12px;padding:12px}.metric-label{font-size:12px;text-transform:uppercase;color:#667085;font-weight:bold}.metric-value{font-size:22px;font-weight:900;margin-top:4px}details summary{cursor:pointer;font-weight:bold;color:#00589c;margin:12px 0}@media(max-width:700px){.grid{grid-template-columns:1fr}}
</style></head><body>
<div class="card"><h1>Matrix Cloud Update</h1><p><a class="btn" href="/cgi-bin/admin_home.sh">Back to Admin</a> <a class="btn" href="/cgi-bin/update_github_log.sh">Refresh</a></p><p><span class="badge $STATE">$(html_escape "$STATE")</span></p><div class="note"><b>Message:</b> $(html_escape "$MSG")<br>During update, web/network services may restart. If the page disconnects, wait a few seconds and refresh.</div><div class="grid"><div class="metric"><div class="metric-label">Installed Build</div><div class="metric-value">$(html_escape "$CURRENT")</div></div><div class="metric"><div class="metric-label">Latest Build</div><div class="metric-value">$(html_escape "$LATEST")</div></div><div class="metric"><div class="metric-label">Status</div><div class="metric-value">$(html_escape "$STATE")</div></div></div></div>
<div class="card"><h2>Current Update Log</h2><pre>$(html_escape "$LOG_TXT")</pre></div>
<div class="card"><details><summary>Show Technical Details</summary><pre>$(html_escape "$TECH_TXT")</pre></details></div>
<div class="card"><details><summary>Show Update History</summary><pre>$(html_escape "$HIST_TXT")</pre></details></div>
</body></html>
HTML
