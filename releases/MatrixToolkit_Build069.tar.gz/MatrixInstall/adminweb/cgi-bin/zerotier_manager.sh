#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

VERSION_FILE="/usr/local/matrix/version.txt"
BUILD="$(grep '^Build=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
EDITION="$(grep '^Edition=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
[ -z "$BUILD" ] && BUILD="010"
[ -z "$EDITION" ] && EDITION="Production Edition"

ZT_DEV="${ZT_DEV:-ztdiyqsthc}"
ZT_NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"

CLI=""
[ -x /usr/local/usr/bin/zerotier-cli ] && CLI="/usr/local/usr/bin/zerotier-cli"
[ -z "$CLI" ] && command -v zerotier-cli >/dev/null 2>&1 && CLI="$(command -v zerotier-cli)"
ONE=""
[ -x /usr/local/usr/bin/zerotier-one ] && ONE="/usr/local/usr/bin/zerotier-one"
[ -z "$ONE" ] && command -v zerotier-one >/dev/null 2>&1 && ONE="$(command -v zerotier-one)"

ACTIVE_HOME=""
INFO=""
NETWORKS=""
HOME_STATUS=""

try_home(){
    H="$1"
    [ -z "$CLI" ] && return 1
    if [ -n "$H" ]; then
        OUT="$("$CLI" -D"$H" info 2>/dev/null)"
        NET="$("$CLI" -D"$H" listnetworks 2>/dev/null)"
    else
        OUT="$("$CLI" info 2>/dev/null)"
        NET="$("$CLI" listnetworks 2>/dev/null)"
    fi
    echo "$OUT" | grep -q "^200 info" || return 1
    echo "$OUT" | grep -q "ONLINE" || return 2
    INFO="$OUT"
    NETWORKS="$NET"
    ACTIVE_HOME="$H"
    [ -z "$ACTIVE_HOME" ] && ACTIVE_HOME="default"
    return 0
}

if [ -n "$CLI" ]; then
    try_home "/etc/zerotier" || try_home "/usr/local/matrix/zerotier" || try_home ""
fi

if [ -z "$INFO" ] && [ -n "$CLI" ]; then
    INFO_ETC="$("$CLI" -D/etc/zerotier info 2>/dev/null)"
    INFO_MATRIX="$("$CLI" -D/usr/local/matrix/zerotier info 2>/dev/null)"
    INFO_DEF="$("$CLI" info 2>/dev/null)"
    INFO="$INFO_ETC"
    [ -z "$INFO" ] && INFO="$INFO_MATRIX"
    [ -z "$INFO" ] && INFO="$INFO_DEF"
    HOME_STATUS="Wrong or inactive ZeroTier home detected. IP/route/web reachability are used as final health source."
fi

ZT_IP="$(ip -4 addr show "$ZT_DEV" 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')"
[ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr 2>/dev/null | awk '/10\.74\./ {split($2,a,"/"); print a[1]; exit}')"

ROUTE_OK="NO"
ip route | grep -q "10.74.91.0/24.*$ZT_DEV" && ROUTE_OK="YES"

ONLINE="NO"
echo "$INFO" | grep -q "ONLINE" && ONLINE="YES"

NODE_ID="$(echo "$INFO" | awk '/^200 info/ {print $3; exit}')"
ZT_VER="$(echo "$INFO" | awk '/^200 info/ {print $4; exit}')"
[ -z "$NODE_ID" ] && NODE_ID="-"
[ -z "$ZT_VER" ] && ZT_VER="-"

NETWORK_STATUS="UNKNOWN"
if [ -n "$NETWORKS" ]; then
    NETWORK_STATUS="$(echo "$NETWORKS" | awk -v n="$ZT_NETWORK_ID" '$0 ~ n {print $6; exit}')"
fi
[ -z "$NETWORK_STATUS" ] && NETWORK_STATUS="UNKNOWN"

TOOLKIT_OK="NO"
ADMIN_OK="NO"
if [ -n "$ZT_IP" ]; then
    wget -qO- -T 5 "http://$ZT_IP:8080" >/dev/null 2>&1 && TOOLKIT_OK="YES"
    wget -qO- -T 5 "http://$ZT_IP:8081/cgi-bin/admin_login.sh" >/dev/null 2>&1 && ADMIN_OK="YES"
fi

OVERALL="WARNING"
REASON="ZeroTier status incomplete."
if [ "$ONLINE" = "YES" ] && [ "$NETWORK_STATUS" = "OK" ] && [ -n "$ZT_IP" ] && [ "$ROUTE_OK" = "YES" ] && [ "$TOOLKIT_OK" = "YES" ] && [ "$ADMIN_OK" = "YES" ]; then
    OVERALL="OK"
    REASON="ZeroTier is online, network is authorized, IP/route are present and Toolkit/Admin are reachable."
elif [ -n "$ZT_IP" ] && [ "$ROUTE_OK" = "YES" ] && [ "$TOOLKIT_OK" = "YES" ] && [ "$ADMIN_OK" = "YES" ]; then
    OVERALL="OK"
    REASON="ZeroTier remote access is working. CLI home/status is incomplete but IP, route and web reachability are OK."
fi

BADGE_CLASS="warn"
[ "$OVERALL" = "OK" ] && BADGE_CLASS="ok"

cat <<HTML
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ZeroTier Manager</title><style>
:root{--bg:#edf3f8;--blue1:#0d4778;--blue2:#0878d1;--text:#132238;--muted:#61708a;--border:#d6e1ec;--green:#18843b;--amber:#b66b00;--red:#b42318;--shadow:0 5px 18px rgba(15,23,42,.08)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1400px;margin:auto;padding:18px}.hero{background:linear-gradient(135deg,var(--blue1),var(--blue2));color:#fff;border-radius:20px;padding:14px 20px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}.brand{display:flex;align-items:center;gap:20px;min-width:0}.logoBox{background:#fff;border-radius:12px;padding:10px 14px;display:flex;align-items:center;justify-content:center}.logoBox img{width:165px;max-width:100%;height:42px;object-fit:contain}.hero h1{margin:0;font-size:27px}.meta{margin-top:7px;display:flex;flex-wrap:wrap;gap:5px 12px;font-size:14px}.actions{display:flex;gap:9px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:43px;padding:10px 15px;border-radius:11px;border:1px solid #ffffff80;background:#ffffff18;color:#fff;text-decoration:none;font-weight:800}.btn.primary{background:#fff;color:#075f9d}.btn.dark{background:#667085;border-color:#667085}.panel{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);margin-top:16px;overflow:hidden}.panelHead{padding:15px 19px;background:#0d5f9c;color:#fff;font-size:20px;font-weight:900}.panelBody{padding:18px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:14px;padding:14px;min-width:0}.label{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);font-weight:900}.value{font-size:20px;font-weight:900;margin-top:6px;overflow-wrap:anywhere}.sub{font-size:13px;color:var(--muted);margin-top:5px;overflow-wrap:anywhere}.badge{display:inline-block;padding:6px 11px;border-radius:999px;font-size:12px;font-weight:900}.ok{background:#e1f4e6;color:#116b2d}.warn{background:#fff0cf;color:#8a5200}.fail{background:#fde5e4;color:#a51d17}.note{border-left:5px solid var(--blue2);background:#eaf4ff;border-radius:10px;padding:12px 14px}.tableWrap{overflow:auto}table{width:100%;border-collapse:collapse}th,td{padding:11px 12px;border:1px solid var(--border);text-align:left;vertical-align:top}th{background:#eaf3fa;color:#075f9d}tbody tr:nth-child(even){background:#f9fbfd}pre{margin:0;background:#101828;color:#f2f4f7;padding:16px;border-radius:13px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:560px;overflow:auto}.footer{text-align:center;color:var(--muted);font-size:13px;padding:18px}.statusRow{display:flex;align-items:flex-start;gap:14px}.statusRow .badge{margin-top:2px;white-space:nowrap}details{margin-top:14px;border:1px solid var(--border);border-radius:13px;overflow:hidden}summary{cursor:pointer;background:#eef5fa;color:#075f9d;font-weight:900;padding:13px 15px}details pre{border-radius:0}.empty{color:#8a94a6;font-weight:700}
@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}.hero{align-items:flex-start}.logoBox img{width:170px}}
@media(max-width:620px){.page{padding:10px}.hero{padding:16px;border-radius:15px}.brand{align-items:flex-start;flex-direction:column}.hero h1{font-size:24px}.grid{grid-template-columns:1fr}.actions,.btn{width:100%}.logoBox img{width:190px}}
</style></head><body><main class="page">
<section class="hero"><div class="brand"><div class="logoBox"><img src="/matrix_logo.png" alt="Matrix"></div><div><h1>ZeroTier Manager</h1><div class="meta"><span><b>Router:</b> $(html_escape "$(hostname)")</span><span>|</span><span><b>Toolkit:</b> Build $(html_escape "$BUILD") Stable</span><span>|</span><span><b>ZeroTier IP:</b> $(html_escape "${ZT_IP:-Not available}")</span></div></div></div><div class="actions"><a class="btn primary" href="/cgi-bin/admin_home.sh">Back to Admin</a><a class="btn" href="http://$(html_escape "$ZT_IP"):8080/">Open Toolkit</a><a class="btn" href="/cgi-bin/zerotier_manager.sh">Refresh</a></div></section>
<section class="panel"><div class="panelHead">Remote Access Health</div><div class="panelBody"><div class="statusRow"><span class="badge $BADGE_CLASS">$(html_escape "$OVERALL")</span><div>$(html_escape "$REASON")</div></div></div></section>
<section class="panel"><div class="panelHead">Remote Access Summary</div><div class="panelBody"><div class="grid"><div class="metric"><div class="label">ZeroTier IP</div><div class="value">$(html_escape "${ZT_IP:-Not available}")</div></div><div class="metric"><div class="label">Toolkit URL</div><div class="value">http://$(html_escape "$ZT_IP"):8080</div></div><div class="metric"><div class="label">Admin URL</div><div class="value">http://$(html_escape "$ZT_IP"):8081</div></div></div></div></section>
<section class="panel"><div class="panelHead">Operational Status</div><div class="panelBody tableWrap"><table><tr><th>Check</th><th>Status</th><th>Details</th></tr>
<tr><td>ZeroTier IP</td><td><span class="badge $([ -n "$ZT_IP" ]&&echo ok||echo fail)">$([ -n "$ZT_IP" ]&&echo ASSIGNED||echo MISSING)</span></td><td>$(html_escape "${ZT_IP:-Not available}")</td></tr>
<tr><td>Network</td><td><span class="badge $([ -n "$ZT_IP" ] && [ "$ROUTE_OK" = YES ] && echo ok || echo fail)">$([ -n "$ZT_IP" ] && [ "$ROUTE_OK" = YES ] && echo CONNECTED || echo "NOT CONNECTED")</span></td><td>$(html_escape "$ZT_NETWORK_ID")</td></tr>
<tr><td>Route</td><td><span class="badge $([ "$ROUTE_OK" = YES ]&&echo ok||echo fail)">$(html_escape "$ROUTE_OK")</span></td><td>10.74.91.0/24 via $(html_escape "$ZT_DEV")</td></tr>
<tr><td>Toolkit</td><td><span class="badge $([ "$TOOLKIT_OK" = YES ]&&echo ok||echo fail)">$([ "$TOOLKIT_OK" = YES ]&&echo REACHABLE||echo UNREACHABLE)</span></td><td>http://$(html_escape "$ZT_IP"):8080</td></tr>
<tr><td>Admin</td><td><span class="badge $([ "$ADMIN_OK" = YES ]&&echo ok||echo fail)">$([ "$ADMIN_OK" = YES ]&&echo REACHABLE||echo UNREACHABLE)</span></td><td>http://$(html_escape "$ZT_IP"):8081</td></tr></table>
<details><summary>CLI and identity details</summary><div class="tableWrap"><table><tr><th>Field</th><th>Value</th></tr><tr><td>CLI</td><td>$(html_escape "${CLI:-Not available}")</td></tr><tr><td>Service</td><td>$(html_escape "${ONE:-Not available}")</td></tr><tr><td>Active home</td><td>$(html_escape "${ACTIVE_HOME:-Not detected}")</td></tr><tr><td>Node ID</td><td>$(html_escape "$NODE_ID")</td></tr><tr><td>CLI network state</td><td>$(html_escape "$NETWORK_STATUS")</td></tr></table></div></details></div></section>
<section class="panel"><div class="panelHead">Actions and Diagnostics</div><div class="panelBody"><div class="actions"><a class="btn primary" style="background:#0878d1;color:#fff" href="/cgi-bin/zerotier_manager.sh">Refresh Status</a><a class="btn dark" href="/cgi-bin/zerotier_setup.sh">Repair / Setup</a></div><details><summary>Technical Details</summary><pre>Hostname: $(html_escape "$(hostname)")
Node ID: $(html_escape "$NODE_ID")
Version: $(html_escape "$ZT_VER")
Info:
$(html_escape "$INFO")

Networks:
$(html_escape "$NETWORKS")</pre></details></div></section><div class="footer">Matrix Toolkit · Build $(html_escape "$BUILD") · Created by Rob Bosman</div></main></body></html>
HTML
