#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
esc(){ printf '%s' "$1"|sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
valid(){ [ -n "$1" ] && ! printf '%s' "$1" | grep -qiE 'ERROR:|Couldn.t retrieve data|permission denied|not found'; }
na(){ valid "$1" && printf '%s' "$1" || printf 'Not available'; }
first_valid(){ for V in "$@"; do valid "$V" && { printf '%s' "$V"; return; }; done; }
cache_get(){ [ -r /tmp/matrix_lte_info.cache ] || return; sed -n "s/^$1=//p" /tmp/matrix_lte_info.cache | head -1; }
gsm_read(){ gsmctl "$1" 2>/dev/null | grep -viE 'ERROR:|Couldn.t retrieve data' | head -1; }
VF=/usr/local/matrix/version.txt
BUILD="$(grep '^Build=' "$VF" 2>/dev/null|cut -d= -f2-)"
VERSION="$(grep '^Version=' "$VF" 2>/dev/null|cut -d= -f2-)"
HOST="$(first_valid "$(uci -q get system.@system[0].hostname)" "$(cat /proc/sys/kernel/hostname 2>/dev/null)" "$(hostname 2>/dev/null)")"
BOARD="$(ubus call system board 2>/dev/null)"
MODEL="$(echo "$BOARD"|sed -n 's/.*"model"[ ]*:[ ]*"\([^"]*\)".*/\1/p'|head -1)"; [ -n "$MODEL" ]||MODEL="$(cat /tmp/sysinfo/model 2>/dev/null)"
FW="$(echo "$BOARD"|sed -n 's/.*"description"[ ]*:[ ]*"\([^"]*\)".*/\1/p'|head -1)"; [ -n "$FW" ]||FW="$(grep DISTRIB_DESCRIPTION /etc/openwrt_release 2>/dev/null|cut -d= -f2-|tr -d "'")"
KERNEL="$(uname -r 2>/dev/null)"
UPTIME="$(awk '{u=$1;printf "%dd %dh %dm",int(u/86400),int((u%86400)/3600),int((u%3600)/60)}' /proc/uptime 2>/dev/null)"
DEF="$(ip route 2>/dev/null|awk '/^default/{print;exit}')"
DEV="$(echo "$DEF"|awk '{for(i=1;i<=NF;i++)if($i=="dev")print $(i+1)}')"
GW="$(echo "$DEF"|awk '{for(i=1;i<=NF;i++)if($i=="via")print $(i+1)}')"
WANIP="$(ip -4 addr show "$DEV" 2>/dev/null|awk '/inet /{split($2,a,"/");print a[1];exit}')"; [ -n "$WANIP" ]||WANIP="$(ubus call network.interface.wan status 2>/dev/null|sed -n 's/.*"address"[ ]*:[ ]*"\([0-9.]*\)".*/\1/p'|head -1)"
LANIP="$(ip -4 addr show br-lan 2>/dev/null|awk '/inet /{split($2,a,"/");print a[1];exit}')"
LANMAC="$(cat /sys/class/net/br-lan/address 2>/dev/null)"
DNS="$(awk '/^nameserver/{print $2}' /tmp/resolv.conf.d/resolv.conf.auto /etc/resolv.conf 2>/dev/null | awk 'NF&&!seen[$0]++{a[++n]=$0} END{for(i=1;i<=n;i++)printf "%s%s",(i>1?", ":""),a[i]}')"
S2="$(uci show wireless 2>/dev/null | sed -n "s/.*\.ssid=\x27\([^\x27]*_2G[^\x27]*\)\x27.*/\1/p" | head -1)"; [ -n "$S2" ]||S2="$(uci -q get wireless.default_radio0.ssid)"
S5="$(uci show wireless 2>/dev/null | sed -n "s/.*\.ssid=\x27\([^\x27]*_5G[^\x27]*\)\x27.*/\1/p" | head -1)"; [ -n "$S5" ]||S5="$(uci -q get wireless.default_radio1.ssid)"
OP="$(first_valid "$(cache_get OPERATOR)" "$(gsm_read -o)")"
MODEM="$(first_valid "$(cache_get TECH)" "$(gsm_read -t)")"
RSSI="$(cache_get RSSI)"; RSRP="$(cache_get RSRP)"; RSRQ="$(cache_get RSRQ)"; SINR="$(cache_get SINR)"
SIGNAL=""
[ -n "$RSSI" ] && SIGNAL="RSSI ${RSSI} dBm"
[ -n "$RSRP" ] && SIGNAL="${SIGNAL}${SIGNAL:+ | }RSRP ${RSRP} dBm"
[ -n "$RSRQ" ] && SIGNAL="${SIGNAL}${SIGNAL:+ | }RSRQ ${RSRQ} dB"
[ -n "$SINR" ] && SIGNAL="${SIGNAL}${SIGNAL:+ | }SINR ${SINR} dB"
[ -n "$SIGNAL" ] || SIGNAL="$(gsm_read -q)"
IMEI="$(gsm_read -i)"
ICCID="$(first_valid "$(gsm_read -J)" "$(gsm_read -j)")"
LTEIP="$(ip -4 addr 2>/dev/null|awk '/inet / && ($0 ~ /qmimux|wwan|mob/){split($2,a,"/");print a[1];exit}')"
ZTIP="$(ip -4 addr 2>/dev/null|awk '/10\.74\./{split($2,a,"/");print a[1];exit}')"
ZTCLI=""; for C in /usr/local/usr/bin/zerotier-cli /usr/bin/zerotier-cli zerotier-cli; do [ -x "$C" ] && { ZTCLI="$C"; break; }; done
ZTINFO=""; [ -n "$ZTCLI" ] && ZTINFO="$($ZTCLI info 2>/dev/null)"
ZTN="$(echo "$ZTINFO"|awk '/^200 info/{print $3;exit}')"
[ -n "$ZTN" ] || ZTN="$(cut -c1-10 /var/lib/zerotier-one/identity.public 2>/dev/null | cut -d: -f1)"
[ -n "$ZTN" ] || ZTN="$(cut -c1-10 /usr/local/var/lib/zerotier-one/identity.public 2>/dev/null | cut -d: -f1)"
ZTS="$(echo "$ZTINFO"|awk '/^200 info/{print $5;exit}')"
[ -n "$ZTS" ]||ZTS="$([ -n "$ZTIP" ]&&echo Reachable||echo 'Not available')"
cat <<HTML
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Matrix Router Info</title><style>
:root{--bg:#edf3f8;--blue1:#0d4778;--blue2:#0878d1;--text:#132238;--muted:#61708a;--border:#d6e1ec;--green:#18843b;--amber:#b66b00;--red:#b42318;--shadow:0 5px 18px rgba(15,23,42,.08)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1400px;margin:auto;padding:18px}.hero{background:linear-gradient(135deg,var(--blue1),var(--blue2));color:#fff;border-radius:20px;padding:20px 24px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}.brand{display:flex;align-items:center;gap:20px;min-width:0}.logoBox{background:#fff;border-radius:12px;padding:10px 14px;display:flex;align-items:center;justify-content:center}.logoBox img{width:210px;max-width:100%;height:54px;object-fit:contain}.hero h1{margin:0;font-size:30px}.meta{margin-top:7px;display:flex;flex-wrap:wrap;gap:5px 12px;font-size:14px}.actions{display:flex;gap:9px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:43px;padding:10px 15px;border-radius:11px;border:1px solid #ffffff80;background:#ffffff18;color:#fff;text-decoration:none;font-weight:800}.btn.primary{background:#fff;color:#075f9d}.btn.dark{background:#667085;border-color:#667085}.panel{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);margin-top:16px;overflow:hidden}.panelHead{padding:15px 19px;background:#0d5f9c;color:#fff;font-size:20px;font-weight:900}.panelBody{padding:18px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:14px;padding:14px;min-width:0}.label{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);font-weight:900}.value{font-size:20px;font-weight:900;margin-top:6px;overflow-wrap:anywhere}.sub{font-size:13px;color:var(--muted);margin-top:5px;overflow-wrap:anywhere}.badge{display:inline-block;padding:6px 11px;border-radius:999px;font-size:12px;font-weight:900}.ok{background:#e1f4e6;color:#116b2d}.warn{background:#fff0cf;color:#8a5200}.fail{background:#fde5e4;color:#a51d17}.note{border-left:5px solid var(--blue2);background:#eaf4ff;border-radius:10px;padding:12px 14px}.tableWrap{overflow:auto}table{width:100%;border-collapse:collapse}th,td{padding:11px 12px;border:1px solid var(--border);text-align:left;vertical-align:top}th{background:#eaf3fa;color:#075f9d}tbody tr:nth-child(even){background:#f9fbfd}pre{margin:0;background:#101828;color:#f2f4f7;padding:16px;border-radius:13px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:560px;overflow:auto}.footer{text-align:center;color:var(--muted);font-size:13px;padding:18px}.statusRow{display:flex;align-items:flex-start;gap:14px}.statusRow .badge{margin-top:2px;white-space:nowrap}details{margin-top:14px;border:1px solid var(--border);border-radius:13px;overflow:hidden}summary{cursor:pointer;background:#eef5fa;color:#075f9d;font-weight:900;padding:13px 15px}details pre{border-radius:0}.empty{color:#8a94a6;font-weight:700}
@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}.hero{align-items:flex-start}.logoBox img{width:170px}}
@media(max-width:620px){.page{padding:10px}.hero{padding:16px;border-radius:15px}.brand{align-items:flex-start;flex-direction:column}.hero h1{font-size:24px}.grid{grid-template-columns:1fr}.actions,.btn{width:100%}.logoBox img{width:190px}}
</style></head><body><main class="page"><section class="hero"><div class="brand"><div class="logoBox"><img src="/matrix_logo.png" alt="Matrix"></div><div><h1>Router Information</h1><div class="meta"><span><b>Router:</b> $(esc "$HOST")</span><span>|</span><span><b>Toolkit:</b> Build $(esc "$BUILD") Stable</span><span>|</span><span><b>Model:</b> $(esc "$(na "$MODEL")")</span></div></div></div><div class="actions"><a class="btn primary" href="/cgi-bin/admin_home.sh">Back to Admin</a><a class="btn" href="/cgi-bin/router_info.sh?x=$(date +%s)">Refresh</a></div></section>
<section class="panel"><div class="panelHead">Router and Firmware</div><div class="panelBody"><div class="grid"><div class="metric"><div class="label">Hostname</div><div class="value">$(esc "$HOST")</div></div><div class="metric"><div class="label">Model</div><div class="value">$(esc "$(na "$MODEL")")</div></div><div class="metric"><div class="label">Firmware</div><div class="value">$(esc "$(na "$FW")")</div></div><div class="metric"><div class="label">Kernel</div><div class="value">$(esc "$KERNEL")</div></div><div class="metric"><div class="label">Uptime</div><div class="value">$(esc "$(na "$UPTIME")")</div></div><div class="metric"><div class="label">Toolkit Version</div><div class="value">$(esc "$(na "$VERSION")")</div></div></div></div></section>
<section class="panel"><div class="panelHead">WAN and LAN</div><div class="panelBody"><div class="grid"><div class="metric"><div class="label">Active Interface</div><div class="value">$(esc "$(na "$DEV")")</div></div><div class="metric"><div class="label">WAN IP</div><div class="value">$(esc "$(na "$WANIP")")</div></div><div class="metric"><div class="label">Gateway</div><div class="value">$(esc "$(na "$GW")")</div></div><div class="metric"><div class="label">DNS</div><div class="value">$(esc "$(na "$DNS")")</div></div><div class="metric"><div class="label">LAN IP</div><div class="value">$(esc "$(na "$LANIP")")</div></div><div class="metric"><div class="label">LAN MAC</div><div class="value">$(esc "$(na "$LANMAC")")</div></div></div></div></section>
<section class="panel"><div class="panelHead">WiFi and Mobile</div><div class="panelBody"><div class="grid"><div class="metric"><div class="label">2.4 GHz SSID</div><div class="value">$(esc "$(na "$S2")")</div></div><div class="metric"><div class="label">5 GHz SSID</div><div class="value">$(esc "$(na "$S5")")</div></div><div class="metric"><div class="label">LTE IP</div><div class="value">$(esc "$(na "$LTEIP")")</div></div><div class="metric"><div class="label">Operator</div><div class="value">$(esc "$(na "$OP")")</div></div><div class="metric"><div class="label">Network Type</div><div class="value">$(esc "$(na "$MODEM")")</div></div><div class="metric"><div class="label">Signal</div><div class="value">$(esc "$(na "$SIGNAL")")</div></div><div class="metric"><div class="label">IMEI</div><div class="value">$(esc "$(na "$IMEI")")</div></div><div class="metric"><div class="label">ICCID</div><div class="value">$(esc "$(na "$ICCID")")</div></div></div></div></section>
<section class="panel"><div class="panelHead">ZeroTier</div><div class="panelBody"><div class="grid"><div class="metric"><div class="label">Status</div><div class="value">$(esc "$(na "$ZTS")")</div></div><div class="metric"><div class="label">Node ID</div><div class="value">$(esc "$(na "$ZTN")")</div></div><div class="metric"><div class="label">ZeroTier IP</div><div class="value">$(esc "$(na "$ZTIP")")</div></div></div></div></section><details><summary>Advanced Interfaces</summary><pre>$(esc "$(ip -4 addr 2>/dev/null)")</pre></details><details><summary>Advanced Routes</summary><pre>$(esc "$(ip route 2>/dev/null)")</pre></details><div class="footer">Matrix Toolkit · Build $(esc "$BUILD") · Created by Rob Bosman</div></main></body></html>
HTML
