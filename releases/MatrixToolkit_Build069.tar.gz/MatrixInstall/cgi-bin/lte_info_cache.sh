#!/bin/sh
# Matrix LTE Root Cache Worker - Build 065
OUT="/tmp/matrix_lte_info.cache"
TMP="/tmp/matrix_lte_info.cache.$$"
LOG="/tmp/matrix_lte_info.log"
clean_line(){ printf '%s' "$1" | tr '\r\n' '  ' | sed 's/[[:space:]][[:space:]]*/ /g;s/^ //;s/ $//'; }
run_gsm(){ gsmctl "$1" 2>/dev/null | grep -v "ERROR:" | grep -v "Couldn't retrieve data"; }
OPERATOR="$(run_gsm -o)"; TECH="$(run_gsm -t)"; REGISTRATION="$(run_gsm -j)"
# Firmware releases expose radio data under different gsmctl switches. Collect all harmless read-only variants.
SIGNAL="$(run_gsm -q)"
EXTRA=""
for OPT in -Q -S -K -C -A; do X="$(run_gsm "$OPT")"; [ -n "$X" ] && EXTRA="$EXTRA
[$OPT]
$X"; done
RAW_API=""; [ ! -x /sbin/api ] || RAW_API="$(/sbin/api GET /system/device/status 2>/dev/null)"
ALL_RAW="$(printf '%s
%s
%s' "$SIGNAL" "$EXTRA" "$RAW_API")"
metric(){
 N="$1"
 printf '%s
' "$ALL_RAW" | awk -v n="$N" 'BEGIN{IGNORECASE=1}{line=$0;gsub(/["{},:;=]/," ",line);for(i=1;i<=NF;i++){x=toupper($i);gsub(/[^A-Z0-9_]/,"",x);if(x==toupper(n)){for(j=i+1;j<=NF;j++){v=$j;gsub(/[^0-9.+-]/,"",v);if(v ~ /^-?[0-9]+([.][0-9]+)?$/){print v;exit}}}}}'
}
text_metric(){
 for N in "$@"; do
  V="$(printf '%s
' "$ALL_RAW" | awk -v n="$N" 'BEGIN{IGNORECASE=1}{line=$0;gsub(/["{},:;=]/," ",line);for(i=1;i<=NF;i++){x=toupper($i);gsub(/[^A-Z0-9_]/,"",x);if(x==toupper(n)){for(j=i+1;j<=NF;j++){if($j!=""){print $j;exit}}}}}')"
  [ -z "$V" ] || { printf '%s' "$V"; return; }
 done
}
RSSI="$(metric RSSI)"; RSRP="$(metric RSRP)"; RSRQ="$(metric RSRQ)"; SINR="$(metric SINR)"
[ -n "$SINR" ] || SINR="$(metric SNR)"
BAND="$(text_metric BAND LTE_BAND NR_BAND BANDWIDTH)"
CELL_ID="$(text_metric CELL_ID CELLID CID PCI)"
[ -n "$OPERATOR" ] || OPERATOR="Not available"; [ -n "$TECH" ] || TECH="Not available"; [ -n "$REGISTRATION" ] || REGISTRATION="Unknown"
{
 printf 'UPDATED=%s
' "$(date '+%Y-%m-%d %H:%M:%S')"; printf 'UPDATED_EPOCH=%s
' "$(date +%s)"
 printf 'OPERATOR=%s
' "$(clean_line "$OPERATOR")"; printf 'TECH=%s
' "$(clean_line "$TECH")"; printf 'REGISTRATION=%s
' "$(clean_line "$REGISTRATION")"
 printf 'BAND=%s
' "$(clean_line "$BAND")"; printf 'CELL_ID=%s
' "$(clean_line "$CELL_ID")"
 printf 'RSSI=%s
RSRP=%s
RSRQ=%s
SINR=%s
' "$RSSI" "$RSRP" "$RSRQ" "$SINR"
 echo SIGNAL_START; printf '%s
' "$SIGNAL"; printf '%b
' "$EXTRA"; echo SIGNAL_END
 echo API_START; printf '%s
' "$RAW_API"; echo API_END
} >"$TMP" || exit 1
mv -f "$TMP" "$OUT"; chmod 644 "$OUT"
echo "$(date '+%Y-%m-%d %H:%M:%S') LTE cache updated operator=$(clean_line "$OPERATOR") tech=$(clean_line "$TECH") rssi=$RSSI rsrp=$RSRP rsrq=$RSRQ sinr=$SINR" >>"$LOG"
exit 0
