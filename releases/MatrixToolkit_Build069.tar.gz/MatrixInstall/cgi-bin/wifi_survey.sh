#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
HOST="$(uci -q get system.@system[0].hostname 2>/dev/null)"
[ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"
[ -n "$HOST" ] || HOST="Matrix Router"
[ -n "$VERSION" ] || VERSION="Build057"
[ -n "$BUILD" ] || BUILD="057"
[ -n "$RELEASE" ] || RELEASE="Customer WiFi Login Layout and Official Logo Baseline"
cat <<EOFHTML
<!doctype html><html lang="nl"><head><meta charset="UTF-8"><title>Customer WiFi verbinden</title><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="theme-color" content="#075f9d"><style>
:root{--blue:#0878d1;--dark:#123a63;--bg:#edf3f8;--text:#152033;--muted:#667085;--line:#d6e0ea}
*{box-sizing:border-box}html,body{min-height:100%}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text);display:flex;align-items:center;justify-content:center;padding:18px}
.shell{width:min(100%,590px)}.hero{background:linear-gradient(135deg,var(--dark),var(--blue));color:#fff;border-radius:20px 20px 0 0;padding:24px 24px 23px;box-shadow:0 8px 24px rgba(18,58,99,.18)}
.brand-row{display:flex;align-items:center;gap:15px}.logo-box{background:#fff;border-radius:11px;padding:8px 10px;flex:0 0 auto}.logo{display:block;width:150px;height:52px;object-fit:contain}.step{font-size:13px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;opacity:.92}.hero h1{margin:8px 0 6px;font-size:32px;line-height:1.1}.meta{font-size:15px;line-height:1.5;opacity:.96}
.card{background:#fff;border-radius:0 0 20px 20px;padding:25px 24px 24px;box-shadow:0 8px 24px rgba(15,23,42,.12)}.intro{margin:0 0 15px;color:var(--muted);font-size:15px;line-height:1.5}
label{display:block;margin:17px 0 7px;font-size:14px;font-weight:900}.field{position:relative}input{width:100%;height:56px;border:1px solid var(--line);border-radius:12px;padding:0 15px;font-size:18px;background:#fbfdff;outline:none;color:var(--text)}input:focus{border:2px solid var(--blue);box-shadow:0 0 0 4px rgba(8,120,209,.1)}
.password{padding-right:92px}.toggle{position:absolute;right:7px;top:7px;height:42px;border:0;background:#eaf3fa;color:#075f9d;border-radius:9px;padding:0 15px;font-size:15px;font-weight:900;cursor:pointer}
.primary,.back{display:block;width:100%;min-height:56px;border-radius:12px;font-size:18px;font-weight:900;text-align:center;text-decoration:none}.primary{margin-top:21px;border:0;background:var(--blue);color:#fff;cursor:pointer}.back{margin-top:12px;line-height:56px;background:#5f6670;color:#fff}.note{margin-top:17px;padding:12px 13px;border:1px solid var(--line);border-radius:10px;background:#f8fafc;color:var(--muted);font-size:13px;line-height:1.45;text-align:center}.footer{text-align:center;color:var(--muted);font-size:12px;margin-top:16px}
@media(max-width:600px){body{align-items:flex-start;padding:12px}.shell{width:100%}.hero{padding:22px 20px}.brand-row{align-items:flex-start}.logo{width:125px;height:44px}.hero h1{font-size:28px}.card{padding:23px 20px}input{height:60px;font-size:19px}.toggle{top:9px}.primary,.back{min-height:60px;font-size:18px}.back{line-height:60px}}
@media(max-width:420px){.brand-row{display:block}.logo-box{display:inline-block;margin-bottom:12px}.hero h1{font-size:27px}}
@media(min-height:800px) and (max-width:600px){body{padding-top:6vh}}
</style><script>
function connectWifi(){var s=document.getElementById('ssid').value.trim(),p=document.getElementById('password').value;if(!s){alert('Vul de SSID van het klantnetwerk in.');document.getElementById('ssid').focus();return;}window.location='/cgi-bin/wifi_connect.sh?ssid='+encodeURIComponent(s)+'&password='+encodeURIComponent(p)}
function togglePassword(){var p=document.getElementById('password'),b=document.getElementById('showpass');if(p.type==='password'){p.type='text';b.textContent='Verberg'}else{p.type='password';b.textContent='Toon'}}
</script></head><body><main class="shell"><section class="hero"><div class="brand-row"><div class="logo-box"><img class="logo" src="/matrix_logo.png" alt="Matrix Fitness"></div><div><div class="step">Stap 1 van 2</div><h1>Customer WiFi verbinden</h1><div class="meta"><b>$HOST</b><br>Matrix Toolkit · Build $BUILD</div></div></div></section>
<section class="card"><p class="intro">Maak verbinding met het WiFi-netwerk van de klant. Na een succesvolle verbinding kunt u een snelle WiFi Health Check of een volledige WiFi Survey uitvoeren.</p><label for="ssid">SSID</label><input id="ssid" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Naam van klantnetwerk"><label for="password">Wachtwoord</label><div class="field"><input class="password" id="password" type="password" autocomplete="off" placeholder="WiFi-wachtwoord"><button id="showpass" class="toggle" type="button" onclick="togglePassword()">Toon</button></div><button class="primary" type="button" onclick="connectWifi()">Verbinden met Customer WiFi</button><a class="back" href="/">Terug naar Toolkit</a><div class="note">Na een succesvolle verbinding kunt u de actuele signaalsterkte controleren of een volledige locatiemeting starten.</div></section><div class="footer">Matrix Fitness · Created by Rob Bosman · $RELEASE</div></main></body></html>
EOFHTML
