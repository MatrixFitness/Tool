# Matrix Toolkit Build 046

Build 046 is a focused compatibility fix for Mobile Fleet Node ID detection. Existing Toolkit and Admin functionality is retained.

## Build 063
Signal Reference Guide and Mobile Data Recovery.
