#!/bin/sh
NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
CLI="/usr/local/usr/bin/zerotier-cli"
ONE="/usr/local/usr/bin/zerotier-one"
PERSIST="/usr/local/matrix/zerotier_identity"
DEFAULT_HOME="/tmp/run/zerotier"
LOG="${1:-/tmp/matrix_zerotier_state.log}"

mkdir -p "$PERSIST" "$DEFAULT_HOME" /usr/local/matrix/logs
chmod 700 "$PERSIST" "$DEFAULT_HOME" 2>/dev/null
: > "$LOG" 2>/dev/null || true

log(){ echo "$@" | tee -a "$LOG"; }
progress(){ echo "$1" > /tmp/matrix_update.progress 2>/dev/null || true; }

cli_info(){
    "$CLI" -D"$1" info 2>/dev/null
}
cli_networks(){
    "$CLI" -D"$1" listnetworks 2>/dev/null
}
valid_identity(){
    [ -s "$1/identity.secret" ] && [ -s "$1/identity.public" ]
}
node_from_public(){
    awk -F: 'NF {print $1; exit}' "$1/identity.public" 2>/dev/null
}

detect_process_home(){
    ps w 2>/dev/null | awk '
      /[z]erotier-one/ {
        for(i=1;i<=NF;i++){
          if($i=="-d" && (i+1)<=NF){print $(i+1); exit}
          if($i ~ /^-d\/|^-d=/){
            x=$i; sub(/^-d=?/,"",x); print x; exit
          }
        }
      }'
}

detect_active_home(){
    PH="$(detect_process_home)"
    for H in "$PH" "$DEFAULT_HOME" /etc/zerotier /usr/local/matrix/zerotier; do
        [ -n "$H" ] || continue
        INFO="$(cli_info "$H")"
        echo "$INFO" | grep -q '^200 info ' && { echo "$H"; return 0; }
    done
    return 1
}

backup_identity_once(){
    HOME="$1"
    [ -s "$PERSIST/identity.secret" ] && return 0
    valid_identity "$HOME" || return 1

    cp -f "$HOME/identity.secret" "$PERSIST/identity.secret"
    cp -f "$HOME/identity.public" "$PERSIST/identity.public"
    [ -s "$HOME/authtoken.secret" ] && cp -f "$HOME/authtoken.secret" "$PERSIST/authtoken.secret"
    chmod 600 "$PERSIST/identity.secret" "$PERSIST/authtoken.secret" 2>/dev/null
    chmod 644 "$PERSIST/identity.public" 2>/dev/null

    NODE="$(node_from_public "$PERSIST")"
    [ -n "$NODE" ] && echo "$NODE" > "$PERSIST/node_id.txt"
    log "ZeroTier identity backup........ OK from $HOME"
}

restore_identity(){
    HOME="$1"
    valid_identity "$PERSIST" || return 1
    mkdir -p "$HOME"
    cp -f "$PERSIST/identity.secret" "$HOME/identity.secret"
    cp -f "$PERSIST/identity.public" "$HOME/identity.public"
    [ -s "$PERSIST/authtoken.secret" ] && cp -f "$PERSIST/authtoken.secret" "$HOME/authtoken.secret"
    chmod 600 "$HOME/identity.secret" "$HOME/authtoken.secret" 2>/dev/null
    chmod 644 "$HOME/identity.public" 2>/dev/null
    log "Restoring persistent identity... OK"
}

port_in_use(){
    netstat -ln 2>/dev/null | grep -qE '(^|[.:])9993[[:space:]]'
}

stop_for_recovery(){
    progress "Stopping failed ZeroTier runtime"
    [ -x /etc/init.d/matrix_zerotier ] && /etc/init.d/matrix_zerotier stop >/dev/null 2>&1 || true
    [ -x /etc/init.d/zerotier ] && /etc/init.d/zerotier stop >/dev/null 2>&1 || true
    killall zerotier-one 2>/dev/null || true

    I=0
    while [ "$I" -lt 20 ]; do
        ps w 2>/dev/null | grep -q '[z]erotier-one' || {
            port_in_use || return 0
        }
        sleep 1
        I=$((I+1))
    done
    return 1
}

start_runtime(){
    HOME="$1"
    mkdir -p "$HOME"
    rm -f "$HOME/zerotier-one.pid" "$HOME/zerotier-one.port"
    : > /tmp/matrix_zerotier_start.log
    "$ONE" -d "$HOME" >>/tmp/matrix_zerotier_start.log 2>&1 &
}

wait_control(){
    HOME="$1"
    I=0
    while [ "$I" -lt 90 ]; do
        INFO="$(cli_info "$HOME")"
        if echo "$INFO" | grep -q '^200 info ' && echo "$INFO" | grep -Eq 'ONLINE|TUNNELED'; then
            return 0
        fi
        sleep 3
        I=$((I+3))
        progress "Waiting for ZeroTier control plane ${I}/90"
    done
    return 1
}

ensure_network(){
    HOME="$1"
    NET="$(cli_networks "$HOME")"
    echo "$NET" | grep -q "$NETWORK_ID" || {
        log "ZeroTier network................. JOINING"
        "$CLI" -D"$HOME" join "$NETWORK_ID" >/dev/null 2>&1 || true
    }

    I=0
    while [ "$I" -lt 120 ]; do
        NET="$(cli_networks "$HOME")"
        if echo "$NET" | grep "$NETWORK_ID" | grep -q ' OK '; then
            log "Network authorization.......... OK"
            return 0
        fi
        if echo "$NET" | grep "$NETWORK_ID" | grep -q 'ACCESS_DENIED'; then
            NODE="$(cli_info "$HOME" | awk '/^200 info/ {print $3; exit}')"
            log "Network authorization.......... ACCESS_DENIED"
            log "Authorize Node ID.............. ${NODE:-unknown}"
            return 2
        fi
        sleep 5
        I=$((I+5))
        progress "Waiting for ZeroTier network ${I}/120"
    done
    return 1
}

wait_ip(){
    I=0
    while [ "$I" -lt 120 ]; do
        DEV="$("$CLI" -D"$1" listnetworks 2>/dev/null | awk -v n="$NETWORK_ID" '$2==n {print $7; exit}')"
        [ -z "$DEV" ] && DEV="ztdiyqsthc"
        IP="$(ip -4 addr show "$DEV" 2>/dev/null | awk '/inet / {split($2,a,"/");print a[1];exit}')"
        if [ -n "$IP" ]; then
            log "ZeroTier interface.............. $DEV"
            log "ZeroTier IP..................... $IP"
            ip route | grep -q '10\.74\.' && log "ZeroTier route.................. OK" || log "ZeroTier route.................. WARNING"
            return 0
        fi
        sleep 5
        I=$((I+5))
        progress "Waiting for ZeroTier IP ${I}/120"
    done
    return 1
}

log "======================================"
log " ZEROTIER MULTI-RUNTIME ENGINE"
log "======================================"

progress "Detecting active ZeroTier runtime"
ACTIVE="$(detect_active_home)"

if [ -n "$ACTIVE" ]; then
    log "Active ZeroTier runtime......... $ACTIVE"
    backup_identity_once "$ACTIVE" || true
    HOME="$ACTIVE"
    log "Existing ZeroTier daemon........ REUSED"
else
    log "Active ZeroTier runtime......... NOT RESPONSIVE"

    # Preserve any existing identity before stopping anything.
    for H in "$DEFAULT_HOME" /etc/zerotier /usr/local/matrix/zerotier; do
        if valid_identity "$H"; then
            backup_identity_once "$H" || true
            break
        fi
    done

    stop_for_recovery || {
        log "Port 9993/process cleanup....... FAILED"
        exit 1
    }

    HOME="$DEFAULT_HOME"
    valid_identity "$PERSIST" && restore_identity "$HOME" || true

    progress "Starting one ZeroTier daemon"
    start_runtime "$HOME"
    wait_control "$HOME" || {
        log "ZeroTier control plane.......... FAILED"
        cat /tmp/matrix_zerotier_start.log 2>/dev/null | tee -a "$LOG"
        exit 1
    }
    log "ZeroTier daemon................. STARTED"
fi

INFO="$(cli_info "$HOME")"
NODE="$(echo "$INFO" | awk '/^200 info/ {print $3;exit}')"
STATUS="$(echo "$INFO" | awk '/^200 info/ {print $5;exit}')"
log "ZeroTier status................. ${STATUS:-unknown}"
log "Current Node ID................. ${NODE:-unknown}"

EXPECTED="$(cat "$PERSIST/node_id.txt" 2>/dev/null)"
[ -n "$EXPECTED" ] && log "Stored Node ID.................. $EXPECTED"

# Never overwrite an existing persistent identity automatically.
if [ -z "$EXPECTED" ] && [ -n "$NODE" ] && valid_identity "$PERSIST"; then
    echo "$NODE" > "$PERSIST/node_id.txt"
fi

progress "Checking ZeroTier network"
ensure_network "$HOME"
RC=$?
[ "$RC" -eq 2 ] && exit 2
[ "$RC" -eq 0 ] || exit 1

progress "Waiting for ZeroTier address"
wait_ip "$HOME" || {
    log "ZeroTier IPv4 address........... FAILED"
    exit 1
}

log "======================================"
log " ZEROTIER READY"
log "======================================"
exit 0
