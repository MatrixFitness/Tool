#!/bin/sh
PERSIST="/usr/local/matrix/zerotier_identity"
RUNTIME="/tmp/run/zerotier"
CLI="/usr/local/usr/bin/zerotier-cli"
ONE="/usr/local/usr/bin/zerotier-one"
NETWORK_ID="${ZT_NETWORK_ID:-cf719fd5409699a2}"
LOG="${1:-/tmp/matrix_zerotier_identity.log}"

mkdir -p "$PERSIST" "$RUNTIME"
chmod 700 "$PERSIST" "$RUNTIME" 2>/dev/null
: > "$LOG" 2>/dev/null || true
log(){ echo "$@" | tee -a "$LOG"; }

node_id(){
    "$CLI" -D"$RUNTIME" info 2>/dev/null | awk '/^200 info/ {print $3; exit}'
}

backup_identity(){
    for F in identity.secret identity.public authtoken.secret; do
        [ -f "$RUNTIME/$F" ] && cp -f "$RUNTIME/$F" "$PERSIST/$F"
    done
    chmod 600 "$PERSIST/identity.secret" "$PERSIST/authtoken.secret" 2>/dev/null
    chmod 644 "$PERSIST/identity.public" 2>/dev/null
    N="$(node_id)"
    [ -n "$N" ] && echo "$N" > "$PERSIST/node_id.txt"
}

restore_identity(){
    rm -f "$RUNTIME/identity.secret" "$RUNTIME/identity.public" "$RUNTIME/authtoken.secret"
    for F in identity.secret identity.public authtoken.secret; do
        [ -f "$PERSIST/$F" ] && cp -f "$PERSIST/$F" "$RUNTIME/$F"
    done
    chmod 600 "$RUNTIME/identity.secret" "$RUNTIME/authtoken.secret" 2>/dev/null
    chmod 644 "$RUNTIME/identity.public" 2>/dev/null
}

start_daemon(){
    killall zerotier-one 2>/dev/null || true
    sleep 2
    "$ONE" -d "$RUNTIME" >/tmp/matrix_zerotier_start.log 2>&1 &
    sleep 8
}

wait_online(){
    I=0
    while [ "$I" -lt 90 ]; do
        INFO="$("$CLI" -D"$RUNTIME" info 2>/dev/null)"
        echo "$INFO" | grep -q '^200 info .* ONLINE' && return 0
        I=$((I+5))
        log "Waiting for ZeroTier... ${I}/90"
        sleep 5
    done
    return 1
}

log "======================================"
log " ZEROTIER IDENTITY MANAGER"
log "======================================"

if [ ! -f "$PERSIST/identity.secret" ]; then
    for SRC in "$RUNTIME" /etc/zerotier /usr/local/matrix/zerotier; do
        if [ -f "$SRC/identity.secret" ]; then
            for F in identity.secret identity.public authtoken.secret; do
                [ -f "$SRC/$F" ] && cp -f "$SRC/$F" "$PERSIST/$F"
            done
            break
        fi
    done
fi

EXPECTED="$(cat "$PERSIST/node_id.txt" 2>/dev/null)"
log "Expected Node ID................ ${EXPECTED:-unknown}"

restore_identity
log "Restoring persistent identity... OK"

start_daemon
log "Starting ZeroTier............... OK"

wait_online || { log "ZeroTier online................ WARNING"; exit 1; }

CURRENT="$(node_id)"
log "Current Node ID................. ${CURRENT:-unknown}"

if [ -n "$EXPECTED" ] && [ -n "$CURRENT" ] && [ "$EXPECTED" != "$CURRENT" ]; then
    log "Node ID mismatch................. DETECTED"
    start_daemon
    wait_online || exit 1
    CURRENT="$(node_id)"
    log "Node ID after restore............ ${CURRENT:-unknown}"
fi

[ -z "$EXPECTED" ] && [ -n "$CURRENT" ] && echo "$CURRENT" > "$PERSIST/node_id.txt"

"$CLI" -D"$RUNTIME" join "$NETWORK_ID" >/dev/null 2>&1 || true
sleep 10
NET="$("$CLI" -D"$RUNTIME" listnetworks 2>/dev/null)"
if echo "$NET" | grep "$NETWORK_ID" | grep -q ' OK '; then
    log "Network authorization.......... OK"
elif echo "$NET" | grep "$NETWORK_ID" | grep -q 'ACCESS_DENIED'; then
    log "Network authorization.......... ACCESS_DENIED"
    log "Authorize Node ID: ${CURRENT:-unknown}"
else
    log "Network authorization.......... WARNING"
fi

IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')"
[ -n "$IP" ] && log "ZeroTier IP..................... $IP" || log "ZeroTier IP..................... missing"

backup_identity
log "ZeroTier identity backup........ OK"
log "======================================"
log " IDENTITY CHECK COMPLETED"
log "======================================"
