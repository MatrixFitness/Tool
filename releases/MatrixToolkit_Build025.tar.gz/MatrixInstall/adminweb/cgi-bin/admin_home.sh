#!/bin/sh
printf "Content-Type: text/html\n\n"

VERSION_FILE="/usr/local/matrix/version.txt"
[ -f "$VERSION_FILE" ] || VERSION_FILE="/tmp/MatrixInstall/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

PRODUCT="$(get_value Product)"
EDITION="$(get_value Edition)"
BUILD="$(get_value Build)"
BUILDDATE="$(get_value BuildDate)"
STATUS="$(get_value Status)"

[ -z "$PRODUCT" ] && PRODUCT="Matrix Toolkit"
[ -z "$EDITION" ] && EDITION="Production Edition"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$BUILDDATE" ] && BUILDDATE="Unknown"
[ -z "$STATUS" ] && STATUS="Unknown"

DISPLAY_DATE="$BUILDDATE"
case "$BUILDDATE" in
    ????-??-??)
        Y="$(echo "$BUILDDATE" | cut -d- -f1)"
        M="$(echo "$BUILDDATE" | cut -d- -f2)"
        D="$(echo "$BUILDDATE" | cut -d- -f3)"
        DISPLAY_DATE="$D-$M-$Y"
    ;;
esac

ZT_IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Matrix Toolkit Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}
.header{background:white;border-radius:16px;padding:22px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 3px 12px rgba(0,0,0,.08);margin-bottom:18px}
h1{margin:0;color:#00589c}
.logout{background:#666;color:white;text-decoration:none;border-radius:10px;padding:14px 28px;font-weight:bold}
.grid{display:grid;grid-template-columns:repeat(4,minmax(240px,1fr));gap:18px}
.card{background:white;border-radius:16px;padding:18px;box-shadow:0 3px 10px rgba(0,0,0,.07);border-top:7px solid #007bff;min-height:300px}
.card.green{border-top-color:#24a148}.card.purple{border-top-color:#7048c8}.card.orange{border-top-color:#ff7a1a}
.title{font-size:23px;font-weight:800;margin-bottom:6px}
.desc{color:#52606d;margin-bottom:16px}
.btn{display:block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:13px;margin:10px 0;font-weight:bold}
.green .btn{background:#24a148}.purple .btn{background:#7048c8}.orange .btn{background:#ff7a1a}
small{display:block;font-weight:normal;margin-top:4px}
.info{background:white;border-radius:16px;padding:18px;margin-top:18px;box-shadow:0 3px 10px rgba(0,0,0,.07)}
.status{display:inline-block;background:#e6f6ea;color:#0b6b2b;border-radius:999px;padding:6px 12px;font-weight:bold}
@media(max-width:1100px){.grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:650px){.grid{grid-template-columns:1fr}.header{display:block}.logout{display:inline-block;margin-top:16px}}

.router-directory{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin:18px 0}
.router-card{background:#fff;border:1px solid #d7e0ea;border-radius:16px;padding:18px;box-shadow:0 3px 12px rgba(0,0,0,.08);display:grid;grid-template-columns:1fr auto;gap:14px;align-items:center}
.router-card.current{border:2px solid #0b7cff;box-shadow:0 3px 16px rgba(11,124,255,.18)}
.router-head{display:flex;align-items:center;gap:9px}.router-flag{font-size:27px}.router-name{font-size:21px;font-weight:900}
.router-status{display:inline-flex;align-items:center;gap:7px;border-radius:999px;padding:5px 10px;font-weight:800;font-size:13px;background:#e7f7eb;color:#15803d;margin:7px 0}
.router-status.offline{background:#fdecec;color:#b42318}.router-dot{width:9px;height:9px;border-radius:50%;background:#22a447}.router-status.offline .router-dot{background:#d92d20}
.router-meta{color:#52606f;margin-top:5px}.router-actions{display:flex;flex-direction:column;gap:8px;min-width:110px}
.router-link{display:block;text-align:center;text-decoration:none;border-radius:10px;padding:9px 12px;font-weight:800;border:1px solid #0b7cff;color:#0b5fad;background:#fff}
.router-link.primary{background:#0b7cff;color:#fff}
@media(max-width:900px){.router-directory{grid-template-columns:1fr}.router-card{grid-template-columns:1fr}.router-actions{flex-direction:row}.router-link{flex:1}}

</style>
</head>
<body>
<div class="header">
<div><h1>Matrix Toolkit Admin</h1><p>Matrix Fitness | Created by Rob Bosman | rob.bosman@matrixfitness.nl</p></div>
<a class="logout" href="/cgi-bin/admin_logout.sh">Logout</a>
</div>


<div class="router-directory" id="matrix-router-directory">
  <div class="router-card" data-host="JNLMatrix" data-ip="10.74.91.3">
    <div><div class="router-head"><span class="router-flag">🇳🇱</span><span class="router-name">JNLMatrix</span></div>
    <div class="router-status"><span class="router-dot"></span><span class="router-status-text">Checking...</span></div>
    <div class="router-meta">Netherlands</div><div class="router-meta">10.74.91.3</div></div>
    <div class="router-actions"><a class="router-link primary" href="http://10.74.91.3:8080/" target="_blank">Toolkit</a><a class="router-link" href="http://10.74.91.3:8081/cgi-bin/admin_login.sh" target="_blank">Admin</a></div>
  </div>
  <div class="router-card" data-host="JBEMatrix" data-ip="10.74.91.116">
    <div><div class="router-head"><span class="router-flag">🇧🇪</span><span class="router-name">JBEMatrix</span></div>
    <div class="router-status"><span class="router-dot"></span><span class="router-status-text">Checking...</span></div>
    <div class="router-meta">Belgium</div><div class="router-meta">10.74.91.116</div></div>
    <div class="router-actions"><a class="router-link primary" href="http://10.74.91.116:8080/" target="_blank">Toolkit</a><a class="router-link" href="http://10.74.91.116:8081/cgi-bin/admin_login.sh" target="_blank">Admin</a></div>
  </div>
  <div class="router-card" data-host="JDKMatrix" data-ip="10.74.91.51">
    <div><div class="router-head"><span class="router-flag">🇩🇰</span><span class="router-name">JDKMatrix</span></div>
    <div class="router-status"><span class="router-dot"></span><span class="router-status-text">Checking...</span></div>
    <div class="router-meta">Denmark</div><div class="router-meta">10.74.91.51</div></div>
    <div class="router-actions"><a class="router-link primary" href="http://10.74.91.51:8080/" target="_blank">Toolkit</a><a class="router-link" href="http://10.74.91.51:8081/cgi-bin/admin_login.sh" target="_blank">Admin</a></div>
  </div>
</div>

<div class="grid">
<div class="card green">
<div class="title">Toolkit</div>
<div class="desc">Open and test the Matrix Toolkit.</div>
<a class="btn" href="http://__HOST__:8080/index.html">Open Toolkit<small>Port 8080</small></a>
<a class="btn" href="/cgi-bin/about.sh">Toolkit Information<small>Version and system information</small></a>
<a class="btn" href="/cgi-bin/matrix_health.sh">Matrix Health Check<small>Router and internet health</small></a>
</div>

<div class="card">
<div class="title">Cloud Maintenance</div>
<div class="desc">Update, repair and verify the platform.</div>
<a class="btn" href="/cgi-bin/update_github.sh">Cloud Update & Repair<small>Download latest release, run Recovery and Doctor</small></a>
<a class="btn" href="/cgi-bin/matrix_doctor.sh">Run Matrix Doctor<small>Check complete system health</small></a>
<a class="btn" href="/cgi-bin/matrix_recovery.sh">Run Matrix Recovery<small>Repair platform services</small></a>
</div>

<div class="card purple">
<div class="title">ZeroTier</div>
<div class="desc">Remote access, IP address and repair.</div>
<a class="btn" href="/cgi-bin/zerotier_manager.sh">ZeroTier Manager<small>Status, IP address and diagnostics</small></a>
<a class="btn" href="/cgi-bin/zerotier_setup.sh">ZeroTier Repair<small>Repair or restart ZeroTier</small></a>
<a class="btn" href="/cgi-bin/update_github_log.sh">Update Log<small>Show cloud update progress</small></a>
</div>

<div class="card orange">
<div class="title">Backup & Security</div>
<div class="desc">Backups and administrator security.</div>
<a class="btn" href="/cgi-bin/router_config_backup.sh">Router Config Backup<small>Save router configuration</small></a>
<a class="btn" href="/cgi-bin/toolkit_backup.sh">Toolkit Backup<small>Save Toolkit files</small></a>
<a class="btn" href="/cgi-bin/admin_change_password.sh">Change Admin Password<small>Update administrator password</small></a>
</div>
</div>

<div class="info">
<h2>Toolkit Version</h2>
<p><b>$PRODUCT</b></p>
<p>$EDITION | Build $BUILD | $DISPLAY_DATE</p>
<p><span class="status">$STATUS</span></p>
HTML

if [ -n "$ZT_IP" ]; then
cat <<HTML
<p>Toolkit: <a href="http://$ZT_IP:8080">http://$ZT_IP:8080</a></p>
<p>Admin: <a href="http://$ZT_IP:8081/cgi-bin/admin_login.sh">http://$ZT_IP:8081/cgi-bin/admin_login.sh</a></p>
HTML
fi

cat <<HTML
<p>Cloud updates use latest.txt and the release package from GitHub.</p>
</div>

<script>document.body.innerHTML = document.body.innerHTML.replaceAll('__HOST__', window.location.hostname);</script>
<a class="btn blue" href="/cgi-bin/system_info.sh"><b>System Information</b><br><span>Router and Toolkit details</span></a>

<script>
(function(){
  var host=(window.location.hostname||'').toLowerCase();
  var map={'10.74.91.3':'jnlmatrix','10.74.91.116':'jbematrix','10.74.91.51':'jdkmatrix'};
  document.querySelectorAll('.router-card').forEach(function(card){
    var expected=card.dataset.host.toLowerCase();
    if(host===expected || map[host]===expected){card.classList.add('current');}
    var badge=card.querySelector('.router-status'), text=card.querySelector('.router-status-text'), ip=card.dataset.ip;
    var timer=setTimeout(function(){badge.classList.add('offline');text.textContent='OFFLINE';},3000);
    fetch('http://'+ip+':8080/',{mode:'no-cors',cache:'no-store'}).then(function(){
      clearTimeout(timer);text.textContent='ONLINE';
    }).catch(function(){
      clearTimeout(timer);badge.classList.add('offline');text.textContent='OFFLINE';
    });
  });
})();
</script>

</body>
</html>
HTML
