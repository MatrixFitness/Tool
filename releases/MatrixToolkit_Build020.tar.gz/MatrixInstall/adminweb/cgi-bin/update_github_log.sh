#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
LOG="/tmp/matrix_update_github.log"
TECH="/tmp/matrix_update_technical.log"
HIST="/usr/local/matrix/logs/update_history.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

LOG_TXT="$(cat "$LOG" 2>/dev/null)"
[ -z "$LOG_TXT" ] && LOG_TXT="No update log found yet."
TECH_TXT="$(tail -n 180 "$TECH" 2>/dev/null)"
[ -z "$TECH_TXT" ] && TECH_TXT="No technical details available."
HIST_TXT="$(tail -n 120 "$HIST" 2>/dev/null)"
[ -z "$HIST_TXT" ] && HIST_TXT="No update history available."

STATE="IDLE"
MSG="No update running."
REFRESH=""

if [ -f "$REQ" ]; then
  STATE="WAITING"; MSG="Waiting for root update worker..."; REFRESH='<meta http-equiv="refresh" content="2">'
elif [ -f "$LOCK" ]; then
  OLD="$(cat "$LOCK" 2>/dev/null)"
  if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
    STATE="RUNNING"; MSG="Update is running. The page will reconnect automatically."; REFRESH='<meta http-equiv="refresh" content="2">'
  else
    STATE="STALE"; MSG="Stale lock detected. Refresh or run matrix-update again."
  fi
elif echo "$LOG_TXT" | grep -q "Already up to date"; then
  STATE="UPTODATE"; MSG="Already up to date."
elif echo "$LOG_TXT" | grep -q "UPDATE COMPLETED SUCCESSFULLY"; then
  STATE="SUCCESS"; MSG="Update completed successfully."
elif echo "$LOG_TXT" | grep -q "UPDATE COMPLETED"; then
  STATE="SUCCESS"; MSG="Update completed."
elif echo "$LOG_TXT" | grep -q "BOOTSTRAP COMPLETED\|SELF-HEAL COMPLETED\|SYSTEM HEALTH: OK\|Installed: Production Edition Build"; then
  STATE="SUCCESS"; MSG="Update completed successfully."
elif echo "$LOG_TXT" | grep -q "UPDATE FAILED\|ERROR:"; then
  STATE="FAILED"; MSG="Update failed. Open technical details for more information."
elif echo "$LOG_TXT" | grep -q "Waiting for root update worker"; then
  STATE="WAITING"; MSG="Waiting for root update worker..."; REFRESH='<meta http-equiv="refresh" content="2">'
fi

CURRENT="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
LATEST="$(wget -qO- https://raw.githubusercontent.com/MatrixFitness/Tool/main/latest.txt 2>/dev/null | tr -d '\r\n ')"
[ -z "$CURRENT" ] && CURRENT="Unknown"
[ -z "$LATEST" ] && LATEST="Unknown"

cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Matrix Cloud Update Log</title><meta name="viewport" content="width=device-width, initial-scale=1">$REFRESH
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;margin:0;padding:16px;color:#122033}.card{background:white;border-radius:16px;padding:18px;max-width:1100px;margin:14px auto;box-shadow:0 3px 12px #0001}h1{color:#00589c}.badge{display:inline-block;border-radius:999px;padding:8px 13px;font-weight:bold}.WAITING,.RUNNING{background:#fff4ce;color:#8a5a00}.SUCCESS,.UPTODATE{background:#dff3e4;color:#137333}.FAILED,.STALE{background:#fde2e2;color:#a10000}.IDLE{background:#e5e7eb;color:#374151}pre{background:#0f172a;color:#e5e7eb;padding:14px;border-radius:12px;overflow:auto;white-space:pre-wrap}.btn{display:inline-block;background:#007bff;color:white;text-decoration:none;border-radius:10px;padding:11px 14px;font-weight:bold;margin:4px}.note{background:#eaf4ff;border-left:6px solid #007bff;padding:12px;border-radius:10px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px}.metric{background:#f8fafc;border:1px solid #d9e2ec;border-radius:12px;padding:12px}.metric-label{font-size:12px;text-transform:uppercase;color:#667085;font-weight:bold}.metric-value{font-size:22px;font-weight:900;margin-top:4px}details summary{cursor:pointer;font-weight:bold;color:#00589c;margin:12px 0}@media(max-width:700px){.grid{grid-template-columns:1fr}}

.router-directory{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin:18px 0}
.router-card{background:#fff;border:1px solid #d7e0ea;border-radius:16px;padding:18px;box-shadow:0 3px 12px rgba(0,0,0,.08);display:grid;grid-template-columns:1fr auto;gap:14px;align-items:center}
.router-card.current{border:2px solid #0b7cff;box-shadow:0 3px 16px rgba(11,124,255,.18)}
.router-head{display:flex;align-items:center;gap:9px}.router-flag{font-size:27px}.router-name{font-size:21px;font-weight:900}
.router-status{display:inline-flex;align-items:center;gap:7px;border-radius:999px;padding:5px 10px;font-weight:800;font-size:13px;background:#e7f7eb;color:#15803d;margin:7px 0}
.router-status.offline{background:#fdecec;color:#b42318}.router-dot{width:9px;height:9px;border-radius:50%;background:#22a447}.router-status.offline .router-dot{background:#d92d20}
.router-meta{color:#52606f;margin-top:5px}.router-actions{display:flex;flex-direction:column;gap:8px;min-width:110px}
.router-link{display:block;text-align:center;text-decoration:none;border-radius:10px;padding:9px 12px;font-weight:800;border:1px solid #0b7cff;color:#0b5fad;background:#fff}
.router-link.primary{background:#0b7cff;color:#fff}
@media(max-width:900px){.router-directory{grid-template-columns:1fr}.router-card{grid-template-columns:1fr}.router-actions{flex-direction:row}.router-link{flex:1}}

</style></head><body>
<div class="card"><h1>Matrix Cloud Update</h1><p><a class="btn" href="/cgi-bin/admin_home.sh">Back to Admin</a> <a class="btn" href="/cgi-bin/update_github_log.sh">Refresh</a></p>
<div class="router-directory" id="matrix-router-directory">
  <div class="router-card" data-host="JNLMatrix" data-ip="10.74.91.3">
    <div><div class="router-head"><span class="router-flag">🇳🇱</span><span class="router-name">JNLMatrix</span></div>
    <div class="router-status"><span class="router-dot"></span><span class="router-status-text">Checking...</span></div>
    <div class="router-meta">Netherlands</div><div class="router-meta">10.74.91.3</div></div>
    <div class="router-actions"><a class="router-link primary" href="http://10.74.91.3:8080/" target="_blank">Toolkit</a><a class="router-link" href="http://10.74.91.3:8081/cgi-bin/admin_login.sh" target="_blank">Admin</a></div>
  </div>
  <div class="router-card" data-host="JBEMatrix" data-ip="10.74.91.116">
    <div><div class="router-head"><span class="router-flag">🇧🇪</span><span class="router-name">JBEMatrix</span></div>
    <div class="router-status"><span class="router-dot"></span><span class="router-status-text">Checking...</span></div>
    <div class="router-meta">Belgium</div><div class="router-meta">10.74.91.116</div></div>
    <div class="router-actions"><a class="router-link primary" href="http://10.74.91.116:8080/" target="_blank">Toolkit</a><a class="router-link" href="http://10.74.91.116:8081/cgi-bin/admin_login.sh" target="_blank">Admin</a></div>
  </div>
  <div class="router-card" data-host="JDKMatrix" data-ip="10.74.91.51">
    <div><div class="router-head"><span class="router-flag">🇩🇰</span><span class="router-name">JDKMatrix</span></div>
    <div class="router-status"><span class="router-dot"></span><span class="router-status-text">Checking...</span></div>
    <div class="router-meta">Denmark</div><div class="router-meta">10.74.91.51</div></div>
    <div class="router-actions"><a class="router-link primary" href="http://10.74.91.51:8080/" target="_blank">Toolkit</a><a class="router-link" href="http://10.74.91.51:8081/cgi-bin/admin_login.sh" target="_blank">Admin</a></div>
  </div>
</div>
<p><span class="badge $STATE">$(html_escape "$STATE")</span></p><div class="note"><b>Message:</b> $(html_escape "$MSG")<br>During update, web/network services may restart. If the page disconnects, wait a few seconds and refresh.</div><div class="grid"><div class="metric"><div class="metric-label">Installed Build</div><div class="metric-value">$(html_escape "$CURRENT")</div></div><div class="metric"><div class="metric-label">Latest Build</div><div class="metric-value">$(html_escape "$LATEST")</div></div><div class="metric"><div class="metric-label">Status</div><div class="metric-value">$(html_escape "$STATE")</div></div></div></div>
<div class="card"><h2>Current Update Log</h2><pre>$(html_escape "$LOG_TXT")</pre></div>
<div class="card"><details><summary>Show Technical Details</summary><pre>$(html_escape "$TECH_TXT")</pre></details></div>
<div class="card"><details><summary>Show Update History</summary><pre>$(html_escape "$HIST_TXT")</pre></details></div>

<script>
(function(){
  var host=(window.location.hostname||'').toLowerCase();
  var map={'10.74.91.3':'jnlmatrix','10.74.91.116':'jbematrix','10.74.91.51':'jdkmatrix'};
  document.querySelectorAll('.router-card').forEach(function(card){
    var expected=card.dataset.host.toLowerCase();
    if(host===expected || map[host]===expected){card.classList.add('current');}
    var badge=card.querySelector('.router-status'), text=card.querySelector('.router-status-text'), ip=card.dataset.ip;
    var timer=setTimeout(function(){badge.classList.add('offline');text.textContent='OFFLINE';},3000);
    fetch('http://'+ip+':8080/',{mode:'no-cors',cache:'no-store'}).then(function(){
      clearTimeout(timer);text.textContent='ONLINE';
    }).catch(function(){
      clearTimeout(timer);badge.classList.add('offline');text.textContent='OFFLINE';
    });
  });
})();
</script>

</body></html>
HTML
