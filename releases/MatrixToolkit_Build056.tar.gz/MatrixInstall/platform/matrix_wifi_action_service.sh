#!/bin/sh
# Matrix WiFi Quick Action Loop - Build 044

WORKER="/usr/local/matrix/matrix_wifi_action_worker.sh"
REQ="/tmp/matrix_wifi_action.request"
LTE_WORKER="/usr/local/matrix/lte_info_cache.sh"
LTE_REQ="/tmp/matrix_lte_refresh.request"
DOCTOR_REQ="/tmp/matrix_doctor.request"
DOCTOR_LOG="/tmp/matrix_doctor_web.log"
DOCTOR_STATE="/tmp/matrix_doctor_web.state"
RECOVERY_REQ="/tmp/matrix_recovery.request"
RECOVERY_LOG="/tmp/matrix_recovery_web.log"
RECOVERY_STATE="/tmp/matrix_recovery_web.state"

while true; do
    if [ -f "$REQ" ] && [ -x "$WORKER" ]; then
        "$WORKER"
    fi
    if [ -f "$LTE_REQ" ] && [ -x "$LTE_WORKER" ]; then
        rm -f "$LTE_REQ"
        "$LTE_WORKER" >/dev/null 2>&1
    fi
    if [ -f "$DOCTOR_REQ" ]; then
        rm -f "$DOCTOR_REQ"
        printf 'RUNNING
' >"$DOCTOR_STATE"
        chmod 666 "$DOCTOR_STATE" 2>/dev/null || true
        if /usr/local/bin/matrix-doctor-check >"$DOCTOR_LOG" 2>&1; then
            printf 'SUCCESS
' >"$DOCTOR_STATE"
        else
            printf 'ERROR
' >"$DOCTOR_STATE"
        fi
        chmod 644 "$DOCTOR_LOG" 2>/dev/null || true
        chmod 666 "$DOCTOR_STATE" 2>/dev/null || true
    fi
    if [ -f "$RECOVERY_REQ" ]; then
        rm -f "$RECOVERY_REQ"
        printf 'RUNNING
' >"$RECOVERY_STATE"
        chmod 666 "$RECOVERY_STATE" 2>/dev/null || true
        if /usr/local/bin/matrix-recovery >"$RECOVERY_LOG" 2>&1; then
            printf 'SUCCESS
' >"$RECOVERY_STATE"
        else
            printf 'ERROR
' >"$RECOVERY_STATE"
        fi
        chmod 644 "$RECOVERY_LOG" 2>/dev/null || true
        chmod 666 "$RECOVERY_STATE" 2>/dev/null || true
    fi
    sleep 1
done
