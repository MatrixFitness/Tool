#!/bin/sh
FLEET_CACHE_DIR="${FLEET_CACHE_DIR:-/usr/local/matrix/fleet-cache}"

zt_identity_node(){
    ZHOME="$1"

    # 1. Runtime directory name, for example:
    # /var/run/zerotier/lib/zerotier-one_<NODEID>_matrix_network
    for RDIR in "$ZHOME" /var/run/zerotier/lib/zerotier-one_*_matrix_network; do
        [ -d "$RDIR" ] || continue
        BASE="$(basename "$RDIR")"
        NODE="$(printf '%s' "$BASE" | sed -n 's/^zerotier-one_\([0-9a-fA-F][0-9a-fA-F]*\)_matrix_network$/\1/p')"
        case "$NODE" in
            [0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F]*)
                printf '%s\n' "$NODE" | tr 'A-F' 'a-f'
                return 0
                ;;
        esac
    done

    # 2. identity.public in all known locations.
    for IDFILE in         "$ZHOME/identity.public"         /etc/zerotier/identity.public         /usr/local/matrix/zerotier/identity.public         /var/lib/zerotier-one/identity.public         /var/run/zerotier/lib/zerotier-one*/identity.public
    do
        [ -s "$IDFILE" ] || continue
        NODE="$(cut -d: -f1 "$IDFILE" 2>/dev/null | head -1 | tr 'A-F' 'a-f')"
        [ -n "$NODE" ] || continue
        printf '%s\n' "$NODE"
        return 0
    done
    return 1
}

zt_cli_node(){
    for CLI in /usr/local/usr/bin/zerotier-cli /usr/bin/zerotier-cli zerotier-cli; do
        command -v "$CLI" >/dev/null 2>&1 || [ -x "$CLI" ] || continue
        OUT="$("$CLI" info 2>/dev/null)"
        NODE="$(printf '%s\n' "$OUT" | awk '/^200[[:space:]]+info[[:space:]]+/ {print $3; exit}')"
        [ -n "$NODE" ] || NODE="$(printf '%s\n' "$OUT" | sed -n 's/.*[Nn]ode[[:space:]_-]*[Ii][Dd][:=[:space:]]*\([0-9a-fA-F][0-9a-fA-F]*\).*/\1/p' | head -1)"
        [ -n "$NODE" ] || continue
        printf '%s\n' "$NODE" | tr 'A-F' 'a-f'
        return 0
    done
    return 1
}

fleet_local_status() {
    VF="/usr/local/matrix/version.txt"
    HOST="$(uci -q get system.@system[0].hostname)"
    [ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"
    BUILD="$(grep '^Build=' "$VF" 2>/dev/null | cut -d= -f2-)"
    VERSION="$(grep '^Version=' "$VF" 2>/dev/null | cut -d= -f2-)"
    FIRMWARE="$(cat /etc/version 2>/dev/null | head -1)"
    UPTIME="$(cut -d. -f1 /proc/uptime 2>/dev/null)"
    ZT_IP=""
    ZT_NODE=""
    ZT_STATE="OFFLINE"

    if [ -f /usr/local/matrix/lib/zerotier_runtime.sh ]; then
        . /usr/local/matrix/lib/zerotier_runtime.sh
        ZH="$(zt_detect_home 2>/dev/null)"
        if [ -n "$ZH" ]; then
            ZT_IP="$(zt_ip "$ZH" 2>/dev/null)"
            ZT_NODE="$(zt_node_id "$ZH" 2>/dev/null)"
            ZS="$(zt_status "$ZH" 2>/dev/null)"
            if [ "$ZS" = "ONLINE" ] || [ "$ZS" = "TUNNELED" ]; then
                ZT_STATE="ONLINE"
            fi
        fi
    fi

    if [ -z "$ZT_NODE" ] || [ "$ZT_NODE" = "unknown" ]; then
        ZT_NODE="$(zt_cli_node 2>/dev/null)"
    fi

    if [ -z "$ZT_NODE" ] || [ "$ZT_NODE" = "unknown" ]; then
        ZT_NODE="$(matrix-zerotier 2>/dev/null | awk '
            /^200[[:space:]]+info[[:space:]]+/ {print $3; exit}
            /[Nn]ode[[:space:]_-]*[Ii][Dd]/ {
                for (i=1;i<=NF;i++) if ($i ~ /^[0-9a-fA-F]{10,}$/) {print $i; exit}
            }')"
    fi

    if [ -z "$ZT_NODE" ] || [ "$ZT_NODE" = "unknown" ]; then
        ZT_NODE="$(zt_identity_node "$ZH" 2>/dev/null)"
    fi

    [ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr 2>/dev/null | awk '/inet 10\.74\.91\./{split($2,a,"/");print a[1];exit}')"
    [ -n "$ZT_IP" ] && ZT_STATE="ONLINE"

    printf 'Hostname=%s\n' "$HOST"
    printf 'Build=%s\n' "${BUILD:-unknown}"
    printf 'Version=%s\n' "${VERSION:-unknown}"
    printf 'ZeroTierIP=%s\n' "${ZT_IP:-none}"
    printf 'NodeID=%s\n' "${ZT_NODE:-unknown}"
    printf 'Status=%s\n' "$ZT_STATE"
    printf 'Firmware=%s\n' "${FIRMWARE:-unknown}"
    printf 'UptimeSeconds=%s\n' "${UPTIME:-0}"
    printf 'Timestamp=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
}

fleet_fetch_remote() {
    IP="$1"
    [ -n "$IP" ] || return 1
    DATA="$(wget -q -O - -T 4 "http://$IP:8080/cgi-bin/fleet_status.sh" 2>/dev/null)"
    [ -n "$DATA" ] || return 1
    printf '%s\n' "$DATA" | grep -q '^Hostname=' || return 1
    printf '%s\n' "$DATA"
}

fleet_toolkit_online() {
    IP="$1"
    [ -n "$IP" ] || return 1
    wget -q -O /dev/null -T 3 "http://$IP:8080/" 2>/dev/null
}

fleet_cache_save() {
    HOST="$1"; DATA="$2"
    [ -n "$HOST" ] && [ -n "$DATA" ] || return 1
    mkdir -p "$FLEET_CACHE_DIR"
    printf '%s\n' "$DATA" > "$FLEET_CACHE_DIR/$HOST.status"
    chmod 644 "$FLEET_CACHE_DIR/$HOST.status" 2>/dev/null || true
}

fleet_cache_read() {
    HOST="$1"
    [ -s "$FLEET_CACHE_DIR/$HOST.status" ] || return 1
    cat "$FLEET_CACHE_DIR/$HOST.status"
}
