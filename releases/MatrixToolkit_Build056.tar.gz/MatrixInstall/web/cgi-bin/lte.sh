#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"

CACHE="/tmp/matrix_lte_info.cache"
getv(){ grep "^$1=" "$CACHE" 2>/dev/null | head -1 | cut -d= -f2-; }
esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

UPDATED="$(getv UPDATED)"
OPERATOR="$(getv OPERATOR)"
TECH="$(getv TECH)"
REG="$(getv REGISTRATION)"
RSSI="$(getv RSSI)"
RSRP="$(getv RSRP)"
RSRQ="$(getv RSRQ)"
SINR="$(getv SINR)"
RAW="$(awk '/SIGNAL_START/{f=1;next}/SIGNAL_END/{f=0}f' "$CACHE" 2>/dev/null)"

[ -n "$UPDATED" ] || UPDATED="Not available"
[ -n "$OPERATOR" ] || OPERATOR="Not available"
[ -n "$TECH" ] || TECH="Not available"
[ -n "$REG" ] || REG="Unknown"
[ -n "$RAW" ] || RAW="Not available"

isnum(){ case "$1" in ''|*[!0-9.-]*) return 1;; *) return 0;; esac; }
quality(){
    NAME="$1"; V="$2"
    if ! isnum "$V"; then echo "Not available|neutral"; return; fi
    case "$NAME" in
      RSSI) [ "$V" -ge -65 ] && echo "Excellent|good" && return; [ "$V" -ge -75 ] && echo "Good|good" && return; [ "$V" -ge -85 ] && echo "Fair|warn" && return ;;
      RSRP) [ "$V" -ge -90 ] && echo "Excellent|good" && return; [ "$V" -ge -100 ] && echo "Good|good" && return; [ "$V" -ge -110 ] && echo "Fair|warn" && return ;;
      RSRQ) [ "$V" -ge -10 ] && echo "Excellent|good" && return; [ "$V" -ge -14 ] && echo "Good|good" && return; [ "$V" -ge -20 ] && echo "Fair|warn" && return ;;
      SINR) [ "$V" -ge 20 ] && echo "Excellent|good" && return; [ "$V" -ge 13 ] && echo "Good|good" && return; [ "$V" -ge 0 ] && echo "Fair|warn" && return ;;
    esac
    echo "Poor|bad"
}
unit(){ case "$1" in RSSI|RSRP) echo dBm;; RSRQ|SINR) echo dB;; esac; }

metric_card(){
    N="$1"; V="$2"; Q="$(quality "$N" "$V")"; TXT="${Q%%|*}"; CLS="${Q##*|}"
    [ -n "$V" ] || V="Not available"
    cat <<HTML
<div class="metric $CLS"><div class="metric-name">$N</div><div class="metric-value">$(esc "$V") $(unit "$N")</div><div class="metric-quality">$TXT</div></div>
HTML
}

GOOD=0; WARN=0; BAD=0; NODATA=0
for P in "RSSI:$RSSI" "RSRP:$RSRP" "RSRQ:$RSRQ" "SINR:$SINR"; do
    N="${P%%:*}"; V="${P#*:}"; Q="$(quality "$N" "$V")"; C="${Q##*|}"
    case "$C" in good) GOOD=$((GOOD+1));; warn) WARN=$((WARN+1));; bad) BAD=$((BAD+1));; *) NODATA=$((NODATA+1));; esac
done
FINAL="Attention"; FCLASS="warn"; FTEXT="LTE is connected, but one or more signal values can be improved."
if [ "$NODATA" -eq 4 ]; then FINAL="No radio data"; FCLASS="neutral"; FTEXT="The modem is connected, but no RSSI, RSRP, RSRQ or SINR measurements were returned. Refresh LTE Data or check modem diagnostics."
elif [ "$OPERATOR" = "Not available" ]; then FINAL="No LTE data"; FCLASS="neutral"; FTEXT="Refresh the LTE cache and check the modem worker."
elif [ "$BAD" -ge 2 ]; then FINAL="Poor"; FCLASS="bad"; FTEXT="Multiple signal values are weak. Check router location and antennas."
elif [ "$GOOD" -ge 3 ] && [ "$BAD" -eq 0 ]; then FINAL="Good"; FCLASS="good"; FTEXT="LTE signal and quality are suitable for normal use."
fi

cat <<HTML
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>LTE Analysis</title>
<style>
:root{--bg:#edf3f8;--panel:#fff;--text:#152033;--muted:#667085;--line:#d7e1eb;--blue:#0878d1;--green:#17833a;--orange:#d97706;--red:#b42318}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial;color:var(--text)}.page{max-width:1240px;margin:auto;padding:16px}
.hero{background:linear-gradient(135deg,#123a63,var(--blue));color:#fff;border-radius:18px;padding:22px;display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap}.hero h1{margin:0}.hero p{margin:7px 0 0}.btn{display:inline-block;padding:11px 15px;border-radius:11px;color:#fff;text-decoration:none;font-weight:800;border:1px solid #ffffff88}.btn.orange{background:var(--orange);border-color:var(--orange)}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:16px}.card,.section{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:16px;box-shadow:0 4px 14px rgba(15,23,42,.06)}.label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800}.value{font-size:21px;font-weight:900;margin-top:7px;overflow-wrap:anywhere}
.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.metric{border-radius:15px;padding:17px;color:#fff}.metric.good{background:var(--green)}.metric.warn{background:var(--orange)}.metric.bad{background:var(--red)}.metric.neutral{background:#667085}.metric-name{font-size:13px;font-weight:900}.metric-value{font-size:24px;font-weight:900;margin-top:8px}.metric-quality{margin-top:5px;font-weight:800}
.section{margin-top:16px}.section h2{margin-top:0}.result{border-left:7px solid var(--orange);background:#fff8eb;padding:16px;border-radius:12px}.result.good{border-color:var(--green);background:#edf8ef}.result.bad{border-color:var(--red);background:#fdecec}.result.neutral{border-color:#667085;background:#f2f4f7}
details{margin-top:16px;background:#fff;border:1px solid var(--line);border-radius:15px;overflow:hidden}summary{padding:15px 17px;font-weight:900;color:#075f9d;cursor:pointer;background:#eef5fa}pre{margin:0;padding:15px;background:#101828;color:#f2f4f7;white-space:pre-wrap}
table{border-collapse:collapse;width:100%}th,td{padding:10px;border-bottom:1px solid var(--line);text-align:left}
@media(max-width:900px){.grid,.metrics{grid-template-columns:repeat(2,1fr)}}@media(max-width:620px){.grid,.metrics{grid-template-columns:1fr}.btn{display:block;margin-top:8px}.page{padding:10px}}
</style></head><body><div class="page">
<section class="hero"><div><h1>LTE Analysis</h1><p>Last update: $(esc "$UPDATED")</p></div><div><a class="btn" href="/">Back to Toolkit</a> <a class="btn orange" href="/cgi-bin/lte_refresh.sh">Refresh LTE Data</a></div></section>
<div class="grid">
<div class="card"><div class="label">Operator</div><div class="value">$(esc "$OPERATOR")</div></div>
<div class="card"><div class="label">Technology</div><div class="value">$(esc "$TECH")</div></div>
<div class="card"><div class="label">Registration</div><div class="value">$(esc "$REG")</div></div>
<div class="card"><div class="label">Cache</div><div class="value">$(esc "$UPDATED")</div></div>
</div>
<section class="section"><h2>Signal Analysis</h2><div class="metrics">
$(metric_card RSSI "$RSSI")
$(metric_card RSRP "$RSRP")
$(metric_card RSRQ "$RSRQ")
$(metric_card SINR "$SINR")
</div></section>
<section class="section"><h2>Final Assessment</h2><div class="result $FCLASS"><h3>$FINAL</h3><p>$FTEXT</p></div></section>
<details><summary>Raw modem data</summary><pre>$(esc "$RAW")</pre></details>
<details><summary>Reference values</summary><table>
<tr><th>Metric</th><th>Excellent</th><th>Good</th><th>Fair</th><th>Poor</th></tr>
<tr><td>RSSI</td><td>&gt; -65</td><td>-65 to -75</td><td>-75 to -85</td><td>&lt; -85</td></tr>
<tr><td>RSRP</td><td>&gt; -90</td><td>-90 to -100</td><td>-100 to -110</td><td>&lt; -110</td></tr>
<tr><td>RSRQ</td><td>&gt; -10</td><td>-10 to -14</td><td>-15 to -20</td><td>&lt; -20</td></tr>
<tr><td>SINR</td><td>&gt; 20</td><td>13 to 20</td><td>0 to 13</td><td>&lt; 0</td></tr>
</table></details>
</div></body></html>
HTML
