# Matrix Toolkit v59.5

## Changed
- Added stable WiFi Manager integration without changing the existing USB install flow.
- WiFi Manager now uses `/usr/local/matrix/matrix_wifi_profiles.conf` as the active local profile file.
- Local profile edits are preserved during GitHub updates.
- Missing WiFi profile files are automatically created.
- Older test location `/usr/local/matrix/config/matrix_wifi_profiles.conf` is migrated if found.

## Fixed
- Edit Profiles save now writes back to the active profile file.
- Applying a WiFi profile no longer shows a false error when `wifi reload` returns a non-zero code but the SSID was applied.
- Restore Default Profiles recreates defaults if the default file is missing.

## Build 047 - 2026-07-18
- Added a unified Matrix & EGYM Connectivity Report.
- Added separate network, Matrix and EGYM scoring with a technician conclusion.
- Added print/save-as-PDF report layout and bandwidth recommendation.
- Removed duplicate test tiles while keeping legacy URLs as safe redirects.
