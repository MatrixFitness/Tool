#!/bin/sh
PASS_FILE="/usr/local/matrix/admin_password.txt"
SESSION_DIR="/tmp/matrix_admin_sessions"
DEFAULT_PASS="Matrix2025"
MSG=""
MSG_CLASS="info"

url_decode_common(){ sed 's/+/ /g; s/%21/!/g; s/%23/#/g; s/%24/\$/g; s/%25/%/g; s/%26/\&/g; s/%2B/+/g; s/%2D/-/g; s/%2E/./g; s/%3A/:/g; s/%3D/=/g; s/%40/@/g; s/%5F/_/g; s/%7E/~/g; s/%2f/\//g; s/%2F/\//g'; }
html_escape(){ sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'; }
ensure_password_file(){ mkdir -p /usr/local/matrix; [ -f "$PASS_FILE" ] || printf '%s' "$DEFAULT_PASS" >"$PASS_FILE"; chmod 644 "$PASS_FILE" 2>/dev/null || true; }
new_session_id(){ if [ -r /dev/urandom ]; then dd if=/dev/urandom bs=24 count=1 2>/dev/null | hexdump -v -e '/1 "%02x"'; else echo "$$$(date +%s)$(hostname)" | md5sum | awk '{print $1}'; fi; }

ensure_password_file
HOST="$(uci -q get system.@system[0].hostname)"; [ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"; [ -n "$HOST" ] || HOST="Matrix Router"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"; [ -n "$BUILD" ] || BUILD="044"
EDITION="$(grep '^Edition=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"; [ -n "$EDITION" ] || EDITION="Production Edition"

if [ "$REQUEST_METHOD" = "POST" ]; then
    read POST_DATA
    USER_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^user=' | cut -d= -f2-)"
    PASS_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^password=' | cut -d= -f2-)"
    USER="$(echo "$USER_RAW" | url_decode_common)"
    PASS="$(echo "$PASS_RAW" | url_decode_common)"
    STORED="$(cat "$PASS_FILE" 2>/dev/null)"
    if [ "$USER" = "admin" ] && [ "$PASS" = "$STORED" ]; then
        mkdir -p "$SESSION_DIR"; chmod 700 "$SESSION_DIR" 2>/dev/null || true
        SID="$(new_session_id)"; [ -n "$SID" ] || SID="$(date +%s)$$"
        echo "$(date +%s)" >"$SESSION_DIR/$SID"; chmod 600 "$SESSION_DIR/$SID" 2>/dev/null || true
        echo "Set-Cookie: MatrixAdminSession=$SID; Path=/; HttpOnly; SameSite=Lax"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "Cache-Control: no-cache, no-store, must-revalidate"
        echo ""
        echo '<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=/cgi-bin/admin_home.sh"><script>window.location="/cgi-bin/admin_home.sh";</script></head><body>Login OK.</body></html>'
        exit 0
    else
        MSG="Wrong username or password."
        MSG_CLASS="error"
    fi
fi
SAFE_MSG="$(echo "$MSG" | html_escape)"
echo "Content-Type: text/html; charset=UTF-8"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""
cat <<HTML
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="theme-color" content="#075f9d"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default">
<title>Matrix Admin · $(echo "$HOST" | html_escape)</title><style>
:root{--blue:#0878d1;--dark:#123a63;--bg:#edf3f8;--text:#152033;--muted:#667085;--red:#b42318;--line:#d6e0ea}
*{box-sizing:border-box}html,body{min-height:100%}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text);display:flex;align-items:center;justify-content:center;padding:18px}
.shell{width:min(100%,560px)}.hero{background:linear-gradient(135deg,var(--dark),var(--blue));color:white;border-radius:20px 20px 0 0;padding:25px 24px;box-shadow:0 8px 24px rgba(18,58,99,.18)}
.brand{font-size:13px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;opacity:.9}.hero h1{margin:8px 0 7px;font-size:34px}.meta{font-size:16px;line-height:1.55}.card{background:white;border-radius:0 0 20px 20px;padding:26px 24px;box-shadow:0 8px 24px rgba(15,23,42,.12)}
label{display:block;margin:17px 0 7px;font-size:15px;font-weight:900}input{width:100%;height:56px;border:1px solid var(--line);border-radius:12px;padding:0 15px;font-size:18px;background:#fbfdff;outline:none}input:focus{border:2px solid var(--blue);box-shadow:0 0 0 4px rgba(8,120,209,.1)}
button,.back{display:block;width:100%;min-height:56px;border-radius:12px;font-size:18px;font-weight:900;text-align:center;text-decoration:none}.login{margin-top:21px;border:0;background:var(--blue);color:white;cursor:pointer}.back{margin-top:12px;line-height:56px;background:#5f6670;color:white}.error{margin-top:16px;padding:13px;border-radius:10px;background:#fdecec;color:var(--red);font-weight:800}.info:empty,.error:empty{display:none}
@media(max-width:600px){body{align-items:flex-start;padding:12px}.shell{width:100%}.hero{padding:25px 21px}.hero h1{font-size:31px}.card{padding:24px 20px}input{height:60px;font-size:19px}button,.back{min-height:60px;font-size:19px}.back{line-height:60px}}
@media(min-height:780px) and (max-width:600px){body{padding-top:7vh}}
</style></head><body><main class="shell"><section class="hero"><div class="brand">Matrix Fitness</div><h1>Matrix Admin</h1><div class="meta"><b>$(echo "$HOST" | html_escape)</b><br>$(echo "$EDITION" | html_escape) · Build $(echo "$BUILD" | html_escape)</div></section>
<section class="card"><form method="POST" action="/cgi-bin/admin_login.sh"><label for="user">Username</label><input id="user" type="text" name="user" value="admin" required autocomplete="username" autocapitalize="none"><label for="password">Password</label><input id="password" type="password" name="password" required autocomplete="current-password"><button class="login" type="submit">Login</button></form><div class="$MSG_CLASS">$SAFE_MSG</div><a class="back" href="#" onclick="window.location=window.location.protocol+'//'+window.location.hostname+':8080/';return false;">Back to Toolkit</a></section></main></body></html>
HTML
