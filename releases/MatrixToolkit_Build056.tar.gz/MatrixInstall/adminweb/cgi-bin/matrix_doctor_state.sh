#!/bin/sh
printf "Content-Type: application/json; charset=UTF-8\nCache-Control: no-store\n\n"
STATE="$(cat /tmp/matrix_doctor_web.state 2>/dev/null)"
[ -n "$STATE" ] || STATE="IDLE"
REPORT="$(cat /tmp/matrix_doctor_web.log 2>/dev/null)"
json(){ printf '%s' "$1" | sed ':a;N;$!ba;s/\\/\\\\/g;s/"/\\"/g;s/\r//g;s/\n/\\n/g'; }
printf '{"state":"%s","report":"%s"}\n' "$(json "$STATE")" "$(json "$REPORT")"
