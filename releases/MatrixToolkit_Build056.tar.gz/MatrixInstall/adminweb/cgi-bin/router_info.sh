#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

HOST="$(uci -q get system.@system[0].hostname)"
[ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"
[ -n "$HOST" ] || HOST="Unknown"

MODEL="$(cat /tmp/sysinfo/model 2>/dev/null)"
[ -n "$MODEL" ] || MODEL="$(ubus call system board 2>/dev/null | sed -n 's/.*"model":[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
[ -n "$MODEL" ] || MODEL="RUTX50"

FIRMWARE="$(cat /etc/version 2>/dev/null | head -1)"
[ -n "$FIRMWARE" ] || FIRMWARE="$(ubus call system board 2>/dev/null | sed -n 's/.*"release":[[:space:]]*{\([^}]*\)}.*/\1/p')"
[ -n "$FIRMWARE" ] || FIRMWARE="Unknown"

KERNEL="$(uname -r 2>/dev/null)"
UPTIME="$(uptime 2>/dev/null | sed 's/.*up //;s/, *load average.*//')"
VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"

ROUTE="$(ip route 2>/dev/null | awk '$1=="default"{print;exit}')"
WANDEV="$(printf '%s\n' "$ROUTE" | awk '{for(i=1;i<=NF;i++)if($i=="dev"){print $(i+1);exit}}')"
GW="$(printf '%s\n' "$ROUTE" | awk '{for(i=1;i<=NF;i++)if($i=="via"){print $(i+1);exit}}')"
WANIP="$(ip -4 addr show "$WANDEV" 2>/dev/null | awk '/inet /{split($2,a,"/");print a[1];exit}')"

# LTE routes do not always expose "via"; use the UBUS route nexthop when available.
if [ -z "$GW" ]; then
    GW="$(ubus call network.interface.wan status 2>/dev/null | awk -F'"' '/"nexthop"/{print $4;exit}')"
fi

INTERNET="Offline"
ping -c1 -W2 8.8.8.8 >/dev/null 2>&1 && INTERNET="Online"

TYPE="Unknown"
case "$WANDEV" in
    eth*|wan*) TYPE="Ethernet WAN" ;;
    wlan*|phy*) TYPE="Customer WiFi WAN" ;;
    qmimux*|wwan*|usb*|mobile*|lte*) TYPE="LTE / Mobile WAN" ;;
esac

DNS="$(awk '/^nameserver[[:space:]]/{print $2}' \
    /tmp/resolv.conf.d/resolv.conf.auto \
    /tmp/resolv.conf.auto \
    /etc/resolv.conf 2>/dev/null | grep -E '^[0-9a-fA-F:.]+$' | sort -u | tr '\n' ' ' | sed 's/ *$//')"
[ -n "$DNS" ] || DNS="$(ubus call network.interface.wan status 2>/dev/null | grep -A8 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | tr '\n' ' ' | sed 's/ *$//')"
[ -n "$DNS" ] || DNS="Not detected"

LANIP="$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{print $2;exit}')"
LANMAC="$(cat /sys/class/net/br-lan/address 2>/dev/null)"
S2="$(uci -q get wireless.default_radio0.ssid)"
S5="$(uci -q get wireless.default_radio1.ssid)"
D2="$(uci -q get wireless.default_radio0.disabled)"
D5="$(uci -q get wireless.default_radio1.disabled)"
[ -n "$D2" ] || D2=0
[ -n "$D5" ] || D5=0
LTEIP="$(ip -4 addr show qmimux0 2>/dev/null | awk '/inet /{print $2;exit}')"
[ -n "$LTEIP" ] || LTEIP="$(ip -4 addr 2>/dev/null | awk '/inet 10\./ && /qmimux|wwan/{print $2;exit}')"

ZTH="-"
ZTS="Not connected"
ZTN="-"
ZTIP="-"

if [ -f /usr/local/matrix/lib/zerotier_runtime.sh ]; then
    . /usr/local/matrix/lib/zerotier_runtime.sh
    DETECTED="$(zt_detect_home 2>/dev/null)"
    [ -n "$DETECTED" ] && ZTH="$DETECTED"
    if [ -n "$DETECTED" ]; then
        V="$(zt_status "$DETECTED" 2>/dev/null)"; [ -n "$V" ] && ZTS="$V"
        V="$(zt_node_id "$DETECTED" 2>/dev/null)"; [ -n "$V" ] && ZTN="$V"
        V="$(zt_ip "$DETECTED" 2>/dev/null)"; [ -n "$V" ] && ZTIP="$V"
    fi
fi

ZTINFO="$(/usr/local/usr/bin/zerotier-cli info 2>/dev/null)"
if printf '%s\n' "$ZTINFO" | grep -q '^200 info '; then
    ZTN="$(printf '%s\n' "$ZTINFO" | awk '/^200 info /{print $3;exit}')"
    ZTS="$(printf '%s\n' "$ZTINFO" | awk '/^200 info /{print $5;exit}')"
fi

[ "$ZTN" != "-" ] || ZTN="$(matrix-zerotier 2>/dev/null | awk '/^200 info /{print $3;exit}')"
[ -n "$ZTN" ] || ZTN="-"
[ "$ZTIP" != "-" ] || ZTIP="$(ip -4 addr 2>/dev/null | awk '/inet 10\.74\.91\./{split($2,a,"/");print a[1];exit}')"
[ -n "$ZTIP" ] || ZTIP="-"
[ "$ZTIP" = "-" ] || [ "$ZTS" = "ONLINE" ] || ZTS="ONLINE"

cat <<EOF
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Matrix Router Info</title><style>
:root{--bg:#edf3f8;--c:#fff;--t:#152033;--m:#667085;--b:#d7e1eb;--blue:#0878d1;--green:#17833a;--red:#bd2525;--shadow:0 5px 18px rgba(15,23,42,.08)}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial;color:var(--t)}.page{max-width:1280px;margin:auto;padding:16px}.hero{background:linear-gradient(135deg,#123a63,var(--blue));color:#fff;border-radius:18px;padding:21px;display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap}.hero h1{margin:0;font-size:29px}.hero p{margin:7px 0 0}.btn{min-height:44px;padding:11px 15px;border:1px solid #ffffff88;border-radius:11px;color:#fff;text-decoration:none;font-weight:800;display:inline-flex;align-items:center}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:16px 0}.section{background:#fff;border:1px solid var(--b);border-radius:18px;overflow:hidden;box-shadow:var(--shadow);margin:16px 0}.head{background:#0d5f9c;color:#fff;padding:14px 17px;font-weight:900}.body{padding:16px}.cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.card{background:#fff;border:1px solid var(--b);border-radius:15px;padding:15px;min-width:0}.label{font-size:11px;text-transform:uppercase;color:var(--m);font-weight:800;letter-spacing:.05em}.value{font-size:19px;font-weight:900;margin-top:6px;overflow-wrap:anywhere;word-break:break-word}.sub{font-size:12px;color:var(--m);margin-top:5px;overflow-wrap:anywhere}.pill{display:inline-block;margin-top:7px;padding:6px 10px;border-radius:999px;background:#e6f5ea;color:#176b2c;font-size:12px;font-weight:900}.pill.bad{background:#fde5e5;color:#a51414}details{background:#fff;border:1px solid var(--b);border-radius:15px;margin:14px 0;overflow:hidden}summary{padding:14px 16px;font-weight:900;color:#0d5f9c;background:#eef5fa;cursor:pointer}pre{margin:0;padding:15px;white-space:pre-wrap;overflow-wrap:anywhere;background:#111827;color:#e5e7eb;font-size:12px}@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}.cards{grid-template-columns:repeat(2,1fr)}}@media(max-width:650px){.page{padding:10px}.hero{padding:16px;border-radius:14px}.hero h1{font-size:23px}.btn{width:100%;justify-content:center}.grid,.cards{grid-template-columns:1fr}.body{padding:12px}.value{font-size:18px}}
</style></head><body><div class="page"><section class="hero"><div><h1>Matrix Router Info</h1><p>$(esc "$HOST") · $(esc "$MODEL")</p></div><div><a class="btn" href="/">Back to Toolkit</a> <a class="btn" href="/cgi-bin/router_info.sh?x=$(date +%s)">Refresh</a></div></section>
<div class="grid"><div class="card"><div class="label">Router</div><div class="value">$(esc "$HOST")</div><div class="sub">$(esc "$MODEL")</div></div><div class="card"><div class="label">Internet</div><div class="value">$INTERNET</div><div class="pill $([ "$INTERNET" = Online ]||echo bad)">$TYPE</div></div><div class="card"><div class="label">Toolkit</div><div class="value">$(esc "$VERSION")</div><div class="sub">Build $(esc "$BUILD")</div></div><div class="card"><div class="label">ZeroTier</div><div class="value">$(esc "$ZTS")</div><div class="sub">$(esc "$ZTIP")</div></div></div>
<section class="section"><div class="head">System</div><div class="body"><div class="cards"><div class="card"><div class="label">Firmware</div><div class="value">$(esc "$FIRMWARE")</div></div><div class="card"><div class="label">Kernel</div><div class="value">$(esc "$KERNEL")</div></div><div class="card"><div class="label">Uptime</div><div class="value">$(esc "$UPTIME")</div></div></div></div></section>
<section class="section"><div class="head">WAN / Internet</div><div class="body"><div class="cards"><div class="card"><div class="label">Active Path</div><div class="value">$(esc "$TYPE")</div><div class="sub">Device $(esc "$WANDEV")</div></div><div class="card"><div class="label">WAN IP</div><div class="value">$(esc "${WANIP:--}")</div></div><div class="card"><div class="label">Gateway</div><div class="value">$(esc "${GW:--}")</div></div><div class="card"><div class="label">DNS</div><div class="value">$(esc "$DNS")</div></div></div></div></section>
<section class="section"><div class="head">LAN</div><div class="body"><div class="cards"><div class="card"><div class="label">LAN Address</div><div class="value">$(esc "${LANIP:--}")</div></div><div class="card"><div class="label">LAN MAC</div><div class="value">$(esc "${LANMAC:--}")</div></div></div></div></section>
<section class="section"><div class="head">Router WiFi</div><div class="body"><div class="cards"><div class="card"><div class="label">2.4 GHz</div><div class="value">$(esc "${S2:--}")</div><div class="pill $([ "$D2" = 1 ]&&echo bad)">$([ "$D2" = 1 ]&&echo Disabled||echo Enabled)</div></div><div class="card"><div class="label">5 GHz</div><div class="value">$(esc "${S5:--}")</div><div class="pill $([ "$D5" = 1 ]&&echo bad)">$([ "$D5" = 1 ]&&echo Disabled||echo Enabled)</div></div><div class="card"><div class="label">WiFi Manager</div><div class="value"><a href="/cgi-bin/wifi_manager.sh">Open</a></div></div></div></div></section>
<section class="section"><div class="head">LTE / Mobile</div><div class="body"><div class="cards"><div class="card"><div class="label">LTE Address</div><div class="value">$(esc "${LTEIP:--}")</div></div><div class="card"><div class="label">LTE Analysis</div><div class="value"><a href="/cgi-bin/lte_analysis.sh">Open</a></div></div></div></div></section>
<section class="section"><div class="head">ZeroTier</div><div class="body"><div class="cards"><div class="card"><div class="label">Runtime</div><div class="value">$(esc "${ZTH:--}")</div></div><div class="card"><div class="label">Node ID</div><div class="value">$(esc "$ZTN")</div></div><div class="card"><div class="label">IP</div><div class="value">$(esc "$ZTIP")</div></div></div></div></section>
<details><summary>Advanced interfaces</summary><pre>$(esc "$(ip -4 addr 2>/dev/null)")</pre></details><details><summary>Advanced routes</summary><pre>$(esc "$(ip route 2>/dev/null)")</pre></details><details><summary>Wireless configuration</summary><pre>$(esc "$(uci show wireless 2>/dev/null)")</pre></details></div></body></html>
EOF
