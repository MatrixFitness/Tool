#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
printf '%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" >/tmp/matrix_doctor.request
chmod 666 /tmp/matrix_doctor.request 2>/dev/null || true
printf 'QUEUED\n' >/tmp/matrix_doctor_web.state
chmod 666 /tmp/matrix_doctor_web.state 2>/dev/null || true
cat <<'HTML'
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Matrix Doctor</title><style>
body{font-family:Arial;background:#edf3f8;margin:0;padding:16px;color:#152033}.card{max-width:1000px;margin:auto;background:#fff;border-radius:17px;padding:20px;box-shadow:0 4px 14px rgba(15,23,42,.08)}
h1{color:#075f9d}.status{padding:14px;border-radius:11px;background:#fff4ce;font-size:20px;font-weight:900}.status.success{background:#edf8ef;color:#17833a}.status.error{background:#fdecec;color:#b42318}
pre{background:#101828;color:#f2f4f7;padding:15px;border-radius:12px;white-space:pre-wrap;min-height:220px}.btn{display:inline-block;background:#0878d1;color:#fff;text-decoration:none;padding:11px 14px;border-radius:9px;font-weight:bold;margin:5px}.grey{background:#5f6670}
</style></head><body><div class="card"><h1>Matrix Doctor</h1><div id="state" class="status">QUEUED</div><pre id="report">Waiting for root service...</pre>
<a class="btn grey" href="/cgi-bin/admin_home.sh">Back to Admin</a>
<script>
(function(){let n=0;function poll(){fetch('/cgi-bin/matrix_doctor_state.sh?x='+Date.now(),{cache:'no-store'}).then(r=>r.json()).then(d=>{
let s=document.getElementById('state');s.textContent=d.state;s.className='status '+(d.state==='SUCCESS'?'success':(d.state==='ERROR'?'error':''));
document.getElementById('report').textContent=d.report||'Waiting...';
n++;if(d.state!=='SUCCESS'&&d.state!=='ERROR'&&n<240)setTimeout(poll,500);
}).catch(()=>{n++;if(n<240)setTimeout(poll,500);});}setTimeout(poll,300);})();
</script></div></body></html>
HTML
