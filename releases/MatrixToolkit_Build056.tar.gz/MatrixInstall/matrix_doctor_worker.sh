#!/bin/sh
REQ="/tmp/matrix_doctor.request"
LOCK="/tmp/matrix_doctor_worker.lock"
STATE="/tmp/matrix_doctor_web.state"
LOG="/tmp/matrix_doctor_web.log"
[ -f "$REQ" ] || exit 0
if [ -f "$LOCK" ]; then
  PID="$(cat "$LOCK" 2>/dev/null)"
  [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null && exit 0
  rm -f "$LOCK"
fi
echo $$ > "$LOCK"
trap 'rm -f "$LOCK"' EXIT INT TERM
rm -f "$REQ"
printf 'RUNNING\n' > "$STATE"
printf 'Matrix Doctor started at %s\n\n' "$(date)" > "$LOG"
# Self-heal survey storage before diagnostics.
mkdir -p /usr/local/matrix/survey >>"$LOG" 2>&1
chmod 777 /usr/local/matrix/survey >>"$LOG" 2>&1
for f in selected_locations.txt completed_locations.txt locations.txt completed.txt wifi_survey_results.csv survey_state.txt; do
  [ -e "/usr/local/matrix/survey/$f" ] || : > "/usr/local/matrix/survey/$f"
done
chmod 666 /usr/local/matrix/survey/*.txt /usr/local/matrix/survey/*.csv 2>/dev/null
if [ -x /usr/local/bin/matrix-doctor ]; then
  /usr/local/bin/matrix-doctor >>"$LOG" 2>&1
  RC=$?
else
  echo "Matrix Doctor command missing: /usr/local/bin/matrix-doctor" >>"$LOG"
  RC=127
fi
[ "$RC" -eq 0 ] && printf 'SUCCESS\n' > "$STATE" || printf 'ERROR\n' > "$STATE"
printf '\nFinished at %s (exit %s)\n' "$(date)" "$RC" >> "$LOG"
chmod 666 "$STATE" "$LOG" 2>/dev/null
exit 0
