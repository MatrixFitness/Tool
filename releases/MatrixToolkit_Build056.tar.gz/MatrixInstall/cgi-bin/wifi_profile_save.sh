#!/bin/sh
# Matrix WiFi Profile Save v66

LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
if [ ! -f "$LIB" ]; then
    printf "Content-Type: text/html; charset=UTF-8\n\n"
    printf '<html><body><h1>WiFi library missing</h1></body></html>\n'
    exit 0
fi
. "$LIB"
ensure_wifi_files

ACTION="$(qs action)"
IDX="$(qs profile)"

redirect(){
    printf "Status: 302 Found
"
    printf "Location: /cgi-bin/wifi_manager_profiles.sh

"
    exit 0
}

case "$ACTION" in
    add)
        NEW="$(user_profile_next)"
        backup_user_profiles
        {
            echo ""
            echo "PROFILE${NEW}_NAME=New User Profile"
            echo "PROFILE${NEW}_LOCKED=0"
            echo "PROFILE${NEW}_R0_ACTION=KEEP"
            echo "PROFILE${NEW}_R0_SSID="
            echo "PROFILE${NEW}_R0_PASSWORD="
            echo "PROFILE${NEW}_R1_ACTION=SET"
            echo "PROFILE${NEW}_R1_SSID=NewSSID_5G"
            echo "PROFILE${NEW}_R1_PASSWORD=password"
        } >> "$USER_PROFILES"
        chmod 666 "$USER_PROFILES" 2>/dev/null
        echo "$(date '+%Y-%m-%d %H:%M:%S') Added user WiFi profile $NEW" >> "$LOG"
        printf "Status: 302 Found\n"
        printf "Location: /cgi-bin/wifi_profile_edit.sh?type=user&p=%s\n\n" "$NEW"
        exit 0
        ;;
    save)
        [ -n "$IDX" ] || IDX="$(user_profile_next)"
        FILE="$USER_PROFILES"
        COUNT="$(profile_count_file "$FILE")"; [ -z "$COUNT" ] && COUNT=0
        [ "$IDX" -gt "$COUNT" ] 2>/dev/null && COUNT="$IDX"
        NAME="$(qs name)"; [ -z "$NAME" ] && NAME="User Profile $IDX"
        R0A="$(normalize_action "$(qs r0_action)")"; R0S="$(qs r0_ssid)"; R0P="$(qs r0_password)"
        R1A="$(normalize_action "$(qs r1_action)")"; R1S="$(qs r1_ssid)"; R1P="$(qs r1_password)"
        TMP="/tmp/matrix_wifi_user_profiles_save.$$"
        backup_user_profiles
        : > "$TMP"
        i=1
        while [ "$i" -le "$COUNT" ]; do
            if [ "$i" = "$IDX" ]; then
                echo "PROFILE${i}_NAME=$NAME" >> "$TMP"
                echo "PROFILE${i}_LOCKED=0" >> "$TMP"
                echo "PROFILE${i}_R0_ACTION=$R0A" >> "$TMP"
                echo "PROFILE${i}_R0_SSID=$R0S" >> "$TMP"
                echo "PROFILE${i}_R0_PASSWORD=$R0P" >> "$TMP"
                echo "PROFILE${i}_R1_ACTION=$R1A" >> "$TMP"
                echo "PROFILE${i}_R1_SSID=$R1S" >> "$TMP"
                echo "PROFILE${i}_R1_PASSWORD=$R1P" >> "$TMP"
                echo "" >> "$TMP"
            else
                ONAME="$(profile_value_file "$FILE" "$i" NAME)"
                if [ -n "$ONAME" ]; then
                    echo "PROFILE${i}_NAME=$ONAME" >> "$TMP"
                    echo "PROFILE${i}_LOCKED=0" >> "$TMP"
                    echo "PROFILE${i}_R0_ACTION=$(profile_value_file "$FILE" "$i" R0_ACTION)" >> "$TMP"
                    echo "PROFILE${i}_R0_SSID=$(profile_value_file "$FILE" "$i" R0_SSID)" >> "$TMP"
                    echo "PROFILE${i}_R0_PASSWORD=$(profile_value_file "$FILE" "$i" R0_PASSWORD)" >> "$TMP"
                    echo "PROFILE${i}_R1_ACTION=$(profile_value_file "$FILE" "$i" R1_ACTION)" >> "$TMP"
                    echo "PROFILE${i}_R1_SSID=$(profile_value_file "$FILE" "$i" R1_SSID)" >> "$TMP"
                    echo "PROFILE${i}_R1_PASSWORD=$(profile_value_file "$FILE" "$i" R1_PASSWORD)" >> "$TMP"
                    echo "" >> "$TMP"
                fi
            fi
            i=$((i+1))
        done
        cat "$TMP" > "$USER_PROFILES"; rm -f "$TMP"; chmod 666 "$USER_PROFILES" 2>/dev/null
        echo "$(date '+%Y-%m-%d %H:%M:%S') Saved user WiFi profile $IDX ($NAME)" >> "$LOG"
        redirect "Profile saved."
        ;;
    delete)
        FILE="$USER_PROFILES"; COUNT="$(profile_count_file "$FILE")"; [ -z "$COUNT" ] && COUNT=0
        TMP="/tmp/matrix_wifi_user_profiles_delete.$$"; NEW=1
        backup_user_profiles; : > "$TMP"
        i=1
        while [ "$i" -le "$COUNT" ]; do
            if [ "$i" != "$IDX" ]; then
                NAME="$(profile_value_file "$FILE" "$i" NAME)"
                if [ -n "$NAME" ]; then
                    echo "PROFILE${NEW}_NAME=$NAME" >> "$TMP"
                    echo "PROFILE${NEW}_LOCKED=0" >> "$TMP"
                    echo "PROFILE${NEW}_R0_ACTION=$(profile_value_file "$FILE" "$i" R0_ACTION)" >> "$TMP"
                    echo "PROFILE${NEW}_R0_SSID=$(profile_value_file "$FILE" "$i" R0_SSID)" >> "$TMP"
                    echo "PROFILE${NEW}_R0_PASSWORD=$(profile_value_file "$FILE" "$i" R0_PASSWORD)" >> "$TMP"
                    echo "PROFILE${NEW}_R1_ACTION=$(profile_value_file "$FILE" "$i" R1_ACTION)" >> "$TMP"
                    echo "PROFILE${NEW}_R1_SSID=$(profile_value_file "$FILE" "$i" R1_SSID)" >> "$TMP"
                    echo "PROFILE${NEW}_R1_PASSWORD=$(profile_value_file "$FILE" "$i" R1_PASSWORD)" >> "$TMP"
                    echo "" >> "$TMP"; NEW=$((NEW+1))
                fi
            fi
            i=$((i+1))
        done
        cat "$TMP" > "$USER_PROFILES"; rm -f "$TMP"; chmod 666 "$USER_PROFILES" 2>/dev/null
        echo "$(date '+%Y-%m-%d %H:%M:%S') Deleted user WiFi profile $IDX" >> "$LOG"
        redirect "Profile deleted."
        ;;
    *) redirect "No action." ;;
esac
