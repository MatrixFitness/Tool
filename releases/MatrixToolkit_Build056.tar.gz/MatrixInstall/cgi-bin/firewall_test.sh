#!/bin/sh
printf "Status: 302 Found\r\nLocation: /cgi-bin/matrix_connectivity.sh\r\n\r\n"
