#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
STATUS="/tmp/matrix_wifi_action.status"
LOG="/tmp/matrix_wifi_action.log"
CURRENT="$(cat "$STATUS" 2>/dev/null)"
[ -n "$CURRENT" ] || CURRENT="No WiFi action has been queued."
cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WiFi Action Status</title><style>
body{font-family:Arial;background:#eef3f8;padding:18px}.card{max-width:800px;margin:auto;background:white;padding:22px;border-radius:15px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
pre{white-space:pre-wrap;background:#101828;color:white;padding:14px;border-radius:10px}.btn{display:inline-block;background:#0878d1;color:white;text-decoration:none;padding:11px 14px;border-radius:9px;font-weight:bold;margin:5px}
.grey{background:#5f6670}
</style></head><body><div class="card"><h1>WiFi Action Status</h1><pre>$(printf '%s' "$CURRENT")</pre><h2>Recent Log</h2><pre>$(tail -n 50 "$LOG" 2>/dev/null)</pre>
<a class="btn" href="/cgi-bin/wifi_manager_action_status.sh">Refresh Status</a><a class="btn grey" href="/cgi-bin/wifi_manager.sh">Back</a></div></body></html>
HTML
