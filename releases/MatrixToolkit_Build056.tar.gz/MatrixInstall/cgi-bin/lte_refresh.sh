#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
REQ="/tmp/matrix_lte_refresh.request"
printf '%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" >"$REQ"
chmod 666 "$REQ" 2>/dev/null || true
cat <<'HTML'
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Refresh LTE Data</title>
<style>body{font-family:Arial;background:#eef3f8;padding:18px}.card{max-width:720px;margin:auto;background:#fff;padding:22px;border-radius:15px;box-shadow:0 3px 14px rgba(0,0,0,.08)}.btn{display:inline-block;background:#0878d1;color:#fff;text-decoration:none;padding:11px 14px;border-radius:9px;font-weight:bold;margin:5px}</style>
</head><body><div class="card"><h1>LTE refresh requested</h1><p>The root service will rebuild the LTE cache within a few seconds.</p><a class="btn" href="/cgi-bin/lte_analysis.sh">Back to LTE Analyse</a><a class="btn" href="/cgi-bin/diagnostics.sh">Back to Diagnostics</a></div></body></html>
HTML
