#!/bin/sh
printf "Status: 302 Found\r\nLocation: /cgi-bin/egym_connectivity.sh\r\n\r\n"
