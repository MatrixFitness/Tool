#!/bin/sh
printf "Content-Type: application/json; charset=UTF-8\nCache-Control: no-store\n\n"
STATE="/tmp/matrix_wifi_action.state"
getv(){ sed -n "s/^$1=//p" "$STATE" 2>/dev/null | head -n1; }
json_escape(){ printf '%s' "$1" | sed 's/\\/\\\\/g;s/"/\\"/g;s/\r//g;s/\n/ /g'; }
PHASE="$(getv PHASE)"; [ -n "$PHASE" ] || PHASE="IDLE"
MESSAGE="$(getv MESSAGE)"; [ -n "$MESSAGE" ] || MESSAGE="No active action"
ELAPSED="$(getv ELAPSED)"; [ -n "$ELAPSED" ] || ELAPSED="0"
RADIO2="$(uci -q get wireless.default_radio0.disabled)"; [ -n "$RADIO2" ] || RADIO2="0"
RADIO5="$(uci -q get wireless.default_radio1.disabled)"; [ -n "$RADIO5" ] || RADIO5="0"
UPDATED="$(getv UPDATED)"
printf '{"phase":"%s","message":"%s","elapsed":"%s","radio2":"%s","radio5":"%s","updated":"%s"}\n' \
 "$(json_escape "$PHASE")" "$(json_escape "$MESSAGE")" "$(json_escape "$ELAPSED")" \
 "$(json_escape "$RADIO2")" "$(json_escape "$RADIO5")" "$(json_escape "$UPDATED")"
