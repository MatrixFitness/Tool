#!/bin/sh
printf 'Status: 302 Found\r\n'
printf 'Location: /cgi-bin/connectivity_report.sh\r\n'
printf 'Content-Type: text/html\r\n\r\n'
printf '<html><body><a href="/cgi-bin/connectivity_report.sh">Open Matrix &amp; EGYM Connectivity Report</a></body></html>\n'
