#!/bin/sh
MATRIX_DIR="/usr/local/matrix"
SURVEY_DIR="$MATRIX_DIR/survey"

echo "Running Matrix post-update tasks..."

mkdir -p "$SURVEY_DIR"
chmod 777 "$SURVEY_DIR" 2>/dev/null
for f in locations.txt completed.txt wifi_survey_results.csv survey_state.txt selected_locations.txt completed_locations.txt; do
  [ -e "$SURVEY_DIR/$f" ] || : > "$SURVEY_DIR/$f"
done
chmod 666 "$SURVEY_DIR"/*.txt "$SURVEY_DIR"/*.csv 2>/dev/null
chmod +x "$MATRIX_DIR/web/cgi-bin"/*.sh "$MATRIX_DIR/adminweb/cgi-bin"/*.sh 2>/dev/null

# Install/repair Matrix Doctor worker after GitHub update.
if [ -f "$MATRIX_DIR/matrix_doctor_worker.sh" ]; then
  chmod +x "$MATRIX_DIR/matrix_doctor_worker.sh"
fi
if command -v crontab >/dev/null 2>&1; then
  (crontab -l 2>/dev/null | grep -v 'matrix_doctor_worker.sh'; echo '* * * * * /usr/local/matrix/matrix_doctor_worker.sh') | crontab -
fi
/etc/init.d/cron enable >/dev/null 2>&1
/etc/init.d/cron restart >/dev/null 2>&1

# Build071: ALWAYS apply the Matrix standard network policy on update/install.
# This fixes existing routers that still had JNL/JBE/JDEMatrix_2G from older builds.
NETWORK_STANDARD="/usr/local/bin/matrix-network-standard"
if [ -x "$NETWORK_STANDARD" ]; then
  echo "Applying Matrix standard WiFi and Internet priority..."
  "$NETWORK_STANDARD" >/tmp/matrix_network_standard.log 2>&1 || true
else
  echo "WARNING: matrix-network-standard not found"
fi

echo "OK: survey storage, Matrix Doctor worker and Matrix network standard ready."
exit 0
