#!/bin/sh
# MATRIX_CONNECTION_MONITOR_WEB_BUILD103_MULTI_DURATION_PDF
# MATRIX_CONNECTION_MONITOR_WEB_BUILD104_SAFE_PROGRESS_REFRESH
# MATRIX_CONNECTION_MONITOR_WEB_BUILD105_PDF_RECOVERY_ACTION
# MATRIX_CONNECTION_MONITOR_WEB_BUILD107_VISIBLE_PDF_RECOVERY
# MATRIX_CONNECTION_MONITOR_WEB_BUILD108_REPORT_STORAGE
# MATRIX_CONNECTION_MONITOR_WEB_BUILD109_POST_CLEANUP_STORAGE
# MATRIX_CONNECTION_MONITOR_WEB_BUILD110_ROOT_WORKER_STORAGE
# MATRIX_CONNECTION_MONITOR_WEB_BUILD111_EXPLAINED_CONNECTION_PATH
# MATRIX_CONNECTION_MONITOR_WEB_BUILD112_JDK_ENGLISH_REPORTS
# MATRIX_CONNECTION_MONITOR_WEB_BUILD114_EMAIL_REPORT_COMPOSER
# MATRIX_CONNECTION_MONITOR_WEB_BUILD115_MULTILINGUAL_EMAIL_UI
# MATRIX_CONNECTION_MONITOR_WEB_BUILD116_FORM_REFRESH_PAUSE
# MATRIX_CONNECTION_MONITOR_WEB_BUILD117_NO_META_REFRESH
# MATRIX_CONNECTION_MONITOR_WEB_BUILD118_VALIDATED_EML_ATTACHMENTS
# MATRIX_CONNECTION_MONITOR_WEB_BUILD119_OPENSSL_BASE64_FALLBACK
MON=/usr/local/bin/matrix-connection-monitor
[ ! -x "$MON" ] && MON=/usr/local/matrix/bin/matrix-connection-monitor
ACTION=$(printf '%s' "$QUERY_STRING" | sed -n 's/.*action=\([^&]*\).*/\1/p')
FILE=$(printf '%s' "$QUERY_STRING" | sed -n 's/.*file=\([^&]*\).*/\1/p')
REPORT_DIR=/etc/matrix-connection-reports
url_decode(){ printf '%s' "$1" | awk 'BEGIN{hex="0123456789ABCDEF"}{gsub(/\+/," ");s=$0;out="";for(i=1;i<=length(s);i++){c=substr(s,i,1);if(c=="%"&&i+2<=length(s)){a=toupper(substr(s,i+1,1));b=toupper(substr(s,i+2,1));x=index(hex,a)-1;y=index(hex,b)-1;if(x>=0&&y>=0){out=out sprintf("%c",x*16+y);i+=2}else out=out c}else out=out c}printf "%s",out}'; }
query_value(){ printf '%s' "$QUERY_STRING" | tr '&' '\n' | sed -n "s/^$1=//p" | head -1; }
safe_header(){ printf '%s' "$1" | tr -d '\r\n' | cut -c1-160; }
if [ "$ACTION" = email ]; then
 NAME=$(safe_header "$(url_decode "$(query_value name)")")
 TO=$(safe_header "$(url_decode "$(query_value to)")")
 CLUB=$(safe_header "$(url_decode "$(query_value club)")")
 TECH=$(safe_header "$(url_decode "$(query_value tech)")")
 NOTE=$(url_decode "$(query_value note)" | tr -d '\r' | cut -c1-800)
 LANG=$(safe_header "$(url_decode "$(query_value lang)")")
 case "$LANG" in
  en)
   [ -n "$NAME" ] && GREETING="Dear $NAME," || GREETING='Dear Sir/Madam,'
   [ -n "$CLUB" ] && SUBJECT="Connection report $CLUB" || SUBJECT='Matrix connection report'
   NOTE_LABEL='Additional comment:'; CLOSING='Kind regards,';;
  de)
   [ -n "$NAME" ] && GREETING="Hallo $NAME," || GREETING='Sehr geehrte Damen und Herren,'
   [ -n "$CLUB" ] && SUBJECT="Verbindungsbericht $CLUB" || SUBJECT='Matrix Verbindungsbericht'
   NOTE_LABEL='Zusätzliche Anmerkung:'; CLOSING='Mit freundlichen Grüßen,';;
  fr)
   [ -n "$NAME" ] && GREETING="Bonjour $NAME," || GREETING='Madame, Monsieur,'
   [ -n "$CLUB" ] && SUBJECT="Rapport de connexion $CLUB" || SUBJECT='Rapport de connexion Matrix'
   NOTE_LABEL='Remarque complémentaire :'; CLOSING='Cordialement,';;
  *)
   LANG=nl
   [ -n "$NAME" ] && GREETING="Beste $NAME," || GREETING='Beste heer/mevrouw,'
   [ -n "$CLUB" ] && SUBJECT="Verbindingsrapport $CLUB" || SUBJECT='Matrix verbindingsrapport'
   NOTE_LABEL='Aanvullende opmerking:'; CLOSING='Met vriendelijke groet,';;
 esac
 BOUNDARY="MATRIX_REPORT_$(date +%s)_$$"
 SELECTED=$(printf '%s' "$QUERY_STRING" | tr '&' '\n' | sed -n 's/^report=//p')
 [ -n "$SELECTED" ] || { echo 'Status: 400 Bad Request'; echo 'Content-Type: text/plain'; echo; echo 'Selecteer minimaal één rapport.'; exit; }
 if command -v base64 >/dev/null 2>&1; then
  BASE64_TOOL=base64
 elif command -v openssl >/dev/null 2>&1; then
  BASE64_TOOL=openssl
 else
  echo 'Status: 500 Internal Server Error'; echo 'Content-Type: text/plain; charset=UTF-8'; echo; echo 'EML kon niet worden gemaakt: base64 en OpenSSL ontbreken op de router.'; exit
 fi
 encode_attachment(){
  case "$BASE64_TOOL" in
   base64) base64 "$1";;
   openssl) openssl base64 -in "$1";;
  esac
 }
 ATTACH_LIST="/tmp/matrix_email_attachments_$$.list"
 MAIL_TMP="/tmp/matrix_email_$$.eml"
 : > "$ATTACH_LIST" || { echo 'Status: 500 Internal Server Error'; echo 'Content-Type: text/plain; charset=UTF-8'; echo; echo 'EML kon niet worden voorbereid.'; exit; }
 trap 'rm -f "$ATTACH_LIST" "$MAIL_TMP"' EXIT HUP INT TERM
 ATTACH_COUNT=0; PDF_BYTES=0; INVALID=''
 for RAW in $SELECTED; do
  F=$(url_decode "$RAW")
  case "$F" in Matrix_Verbindingsrapport_*.pdf|Matrix_Connection_Report_*.pdf) ;; *) INVALID="$F"; continue;; esac
  P="$REPORT_DIR/$F"
  [ -f "$P" ] && [ -r "$P" ] && [ -s "$P" ] || { INVALID="$F"; continue; }
  MAGIC=$(dd if="$P" bs=4 count=1 2>/dev/null)
  [ "$MAGIC" = '%PDF' ] || { INVALID="$F"; continue; }
  BYTES=$(wc -c < "$P" 2>/dev/null); BYTES=${BYTES:-0}
  [ "$BYTES" -gt 100 ] || { INVALID="$F"; continue; }
  printf '%s\n' "$P" >> "$ATTACH_LIST"
  ATTACH_COUNT=$((ATTACH_COUNT + 1)); PDF_BYTES=$((PDF_BYTES + BYTES))
 done
 if [ "$ATTACH_COUNT" -eq 0 ] || [ -n "$INVALID" ]; then
  echo 'Status: 422 Unprocessable Entity'; echo 'Content-Type: text/html; charset=UTF-8'; echo
  echo '<!doctype html><html><body style="font-family:Segoe UI,Arial;padding:28px"><h2>Het e-mailconcept is niet gemaakt</h2><p>Minimaal één geselecteerde PDF is leeg, onleesbaar of geen geldig PDF-bestand.</p><p>De rapporten zijn niet beschadigd of verwijderd. Ga terug, download de PDF afzonderlijk en probeer het daarna opnieuw.</p></body></html>'
  exit
 fi
 {
 echo "To: $TO"
 echo "Subject: $SUBJECT"
 echo 'X-Unsent: 1'
 echo 'MIME-Version: 1.0'
 echo "Content-Type: multipart/mixed; boundary=\"$BOUNDARY\""
 echo
 echo "--$BOUNDARY"
 echo 'Content-Type: text/plain; charset=UTF-8'
 echo 'Content-Transfer-Encoding: 8bit'
 echo
 echo "$GREETING"
 echo
 case "$LANG" in
  en)
   echo 'Please find attached the results of the connection measurement.'; echo
   echo 'The report checks internet and DNS availability during the selected measurement period. It also records which connection was active: Ethernet WAN, 5G/LTE or customer Wi-Fi.'; echo
   echo 'Important: when a connected WAN cable provides an active WAN route and the internet checks succeed, the measurement considers this connection OK. It does not perform a separate physical cable test. An active WAN route therefore does not prove that the cable itself has been fully tested.'; echo
   echo 'The final conclusion indicates whether the connection was GOOD, ATTENTION, UNSTABLE, VERY POOR or CRITICAL.';;
  de)
   echo 'Anbei erhalten Sie die Ergebnisse der durchgeführten Verbindungsmessung.'; echo
   echo 'Der Bericht prüft während des gewählten Messzeitraums die Erreichbarkeit von Internet und DNS. Außerdem wird erfasst, welche Verbindung aktiv war: Ethernet-WAN, 5G/LTE oder Kunden-WLAN.'; echo
   echo 'Wichtig: Wenn ein angeschlossenes WAN-Kabel eine aktive WAN-Route bereitstellt und die Internetprüfungen erfolgreich sind, bewertet die Messung diese Verbindung als OK. Eine separate physische Kabelprüfung wird nicht durchgeführt. Eine aktive WAN-Route beweist daher nicht, dass das Kabel selbst vollständig geprüft wurde.'; echo
   echo 'Die Schlussbewertung zeigt, ob die Verbindung GUT, AUFMERKSAMKEIT, INSTABIL, SEHR SCHLECHT oder KRITISCH war.';;
  fr)
   echo 'Veuillez trouver ci-joint les résultats de la mesure de connexion effectuée.'; echo
   echo 'Le rapport vérifie la disponibilité d’Internet et du DNS pendant la période sélectionnée. Il enregistre également la connexion active : WAN Ethernet, 5G/LTE ou Wi-Fi du client.'; echo
   echo 'Important : lorsqu’un câble WAN connecté fournit une route WAN active et que les contrôles Internet réussissent, la mesure considère cette connexion comme correcte. Elle n’effectue pas de test physique séparé du câble. Une route WAN active ne prouve donc pas que le câble lui-même a été entièrement testé.'; echo
   echo 'La conclusion finale indique si la connexion était BONNE, À SURVEILLER, INSTABLE, TRÈS MAUVAISE ou CRITIQUE.';;
  *)
   echo 'Bijgevoegd vindt u de resultaten van de uitgevoerde verbindingsmeting.'; echo
   echo 'Het rapport controleert tijdens de geselecteerde meetperiode de bereikbaarheid van internet en DNS. Ook wordt geregistreerd welke verbinding actief was: Ethernet-WAN, 5G/LTE of klant-Wi-Fi.'; echo
   echo 'Belangrijk: wanneer een aangesloten WAN-kabel een actieve WAN-route geeft en de internetcontroles slagen, beschouwt de meting deze verbinding als OK. De meting voert geen afzonderlijke fysieke kabeltest uit. Een actieve WAN-route bewijst daarom niet dat de kabel technisch volledig is doorgemeten.'; echo
   echo 'De eindconclusie geeft aan of de verbinding GOED, AANDACHT, INSTABIEL, ZEER SLECHT of KRITIEK was.';;
 esac
 [ -n "$NOTE" ] && { echo; echo "$NOTE_LABEL"; echo "$NOTE"; }
 echo
 [ -n "$TECH" ] && echo "$CLOSING" && echo "$TECH"
 while IFS= read -r P; do
  [ -n "$P" ] || continue
  F=${P##*/}
  echo
  echo "--$BOUNDARY"
  echo "Content-Type: application/pdf; name=\"$F\""
  echo 'Content-Transfer-Encoding: base64'
  echo "Content-Disposition: attachment; filename=\"$F\"; size=$(wc -c < "$P")"
  echo
  encode_attachment "$P"
 done < "$ATTACH_LIST"
 echo
 echo "--$BOUNDARY--"
 } > "$MAIL_TMP"
 MAIL_BYTES=$(wc -c < "$MAIL_TMP" 2>/dev/null); MAIL_BYTES=${MAIL_BYTES:-0}
 WRITTEN_ATTACHMENTS=$(grep -c '^Content-Disposition: attachment;' "$MAIL_TMP" 2>/dev/null); WRITTEN_ATTACHMENTS=${WRITTEN_ATTACHMENTS:-0}
 if [ "$MAIL_BYTES" -le "$PDF_BYTES" ] || [ "$WRITTEN_ATTACHMENTS" -ne "$ATTACH_COUNT" ]; then
  echo 'Status: 500 Internal Server Error'; echo 'Content-Type: text/html; charset=UTF-8'; echo
  echo '<!doctype html><html><body style="font-family:Segoe UI,Arial;padding:28px"><h2>Het e-mailconcept is geblokkeerd</h2><p>De controle kon niet bevestigen dat alle PDF-bijlagen volledig zijn opgenomen. Er is geen leeg EML-bestand aangeboden.</p></body></html>'
  exit
 fi
 echo 'Content-Type: message/rfc822'
 echo 'Content-Disposition: attachment; filename="Matrix_verbindingsrapport_email.eml"'
 echo "Content-Length: $MAIL_BYTES"
 echo 'Cache-Control: no-store'
 echo
 cat "$MAIL_TMP"
 exit
fi
if [ "$ACTION" = download ]; then case "$FILE" in Matrix_Verbindingsrapport_*.pdf|Matrix_Connection_Report_*.pdf) ;; *) echo 'Status: 400 Bad Request'; echo; exit;; esac; [ -f "$REPORT_DIR/$FILE" ] || { echo 'Status: 404 Not Found'; echo; exit; }; echo 'Content-Type: application/pdf'; echo 'Content-Disposition: attachment; filename="'"$FILE"'"'; echo; cat "$REPORT_DIR/$FILE"; exit; fi
case "$ACTION" in
 start5) "$MON" start 5m >/dev/null 2>&1;;
 start60) "$MON" start 1h >/dev/null 2>&1;;
 start24) "$MON" start 24h >/dev/null 2>&1;;
 stop) "$MON" stop >/dev/null 2>&1;;
 sample) "$MON" sample >/dev/null 2>&1;;
 pdfnow)
  echo 'BEZIG|PDF wordt opnieuw opgebouwd met Build112.' > /tmp/matrix_connection_monitor_pdf.state
  RECOVERY_OUTPUT=$($MON pdf-now 2>&1); RECOVERY_RC=$?
  CURRENT_PDF_STATE=$(cat /tmp/matrix_connection_monitor_pdf.state 2>/dev/null)
  if [ "$RECOVERY_RC" -ne 0 ] && printf '%s' "$CURRENT_PDF_STATE" | grep -q '^BEZIG|'; then
   SHORT_ERROR=$(printf '%s' "$RECOVERY_OUTPUT" | tr '\r\n' ' ' | cut -c1-240)
   echo "FOUT|Build112 herstelopdracht mislukt (code=$RECOVERY_RC): ${SHORT_ERROR:-geen uitvoer}. Meetgegevens zijn behouden." > /tmp/matrix_connection_monitor_pdf.state
  fi
 ;;
esac
if [ -n "$ACTION" ]; then echo 'Status: 303 See Other'; echo 'Location: '"${SCRIPT_NAME:-/cgi-bin/connection_monitor.sh}"; echo 'Cache-Control: no-store'; echo; exit; fi
STATUS=$($MON status 2>/dev/null); GENERATOR=$($MON version 2>/dev/null); GENERATOR=${GENERATOR:-ONBEKEND}; COUNT=$(cat /tmp/matrix_connection_monitor_session.count 2>/dev/null); COUNT=${COUNT:-0}; TARGET=$(cat /tmp/matrix_connection_monitor_session.target 2>/dev/null); TARGET=${TARGET:-0}; LABEL=$(cat /tmp/matrix_connection_monitor_session.label 2>/dev/null); LABEL=${LABEL:-Geen_test_geselecteerd}; START=$(cat /tmp/matrix_connection_monitor_session.start 2>/dev/null); START=${START:-Nog_niet_gestart}; PDFSTATE=$(cat /tmp/matrix_connection_monitor_pdf.state 2>/dev/null)
PCT=0; [ "$TARGET" -gt 0 ] && PCT=$((COUNT * 100 / TARGET)); [ "$PCT" -gt 100 ] && PCT=100
echo 'Content-Type: text/html'; echo
echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Matrix Verbinding Monitor</title><style>body{font-family:Segoe UI,Arial;background:#f2f6fa;color:#10233b;margin:0}.h{background:#0a4c83;color:#fff;padding:22px}.w{max-width:1200px;margin:20px auto;padding:0 16px}.c{background:#fff;border:1px solid #d7e1eb;border-radius:14px;padding:18px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}.choice{border:2px solid #d8e5ef;border-radius:12px;padding:16px}.b{display:inline-block;padding:11px 16px;margin:4px;text-decoration:none;border:0;border-radius:9px;background:#0878d1;color:#fff;font-weight:700;cursor:pointer}.disabled{background:#8b99a5;cursor:not-allowed}.stop{background:#a52a2a}.bar{height:18px;background:#dce5ec;border-radius:9px;overflow:hidden}.fill{height:100%;background:#16803a}.ok{color:#16803a;font-weight:800}.err{color:#b3261e;font-weight:800}.field{display:block;margin:8px 0}.field input,.field textarea{width:100%;max-width:620px;box-sizing:border-box;padding:9px;border:1px solid #aebdca;border-radius:7px;font:inherit}.report{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #e6edf3}.hint{color:#52677a;font-size:.92em}pre{white-space:pre-wrap;word-break:break-word;background:#101820;color:#eaf2f8;padding:14px;border-radius:10px;max-height:420px;overflow:auto}</style></head><body>'
echo '<style>.emailpanel{background:#f7fafc;border:1px solid #d8e5ef;border-radius:12px;padding:18px}.emailgrid{display:grid;grid-template-columns:repeat(2,minmax(260px,1fr));gap:16px}.field{font-weight:700;color:#17334f}.field input,.field textarea,.field select{display:block;width:100%;max-width:none;margin-top:6px;box-sizing:border-box;padding:11px 12px;border:1px solid #aebdca;border-radius:8px;background:#fff;font:inherit;color:#10233b}.field textarea{min-height:100px;resize:vertical}.reports{margin-top:18px}.report{display:grid;grid-template-columns:28px minmax(0,1fr) auto;align-items:center;gap:10px;padding:12px;background:#fff;border:1px solid #e0e8ef;border-radius:9px;margin:8px 0}.report input{width:18px;height:18px}.filename{overflow-wrap:anywhere}.step{margin:4px 0 12px}.mail{background:#16803a}.hint{line-height:1.45}@media(max-width:720px){.emailgrid{grid-template-columns:1fr}.report{grid-template-columns:28px minmax(0,1fr)}.report .b{grid-column:2;margin-left:0;width:max-content}}</style>'
echo '<div class="h"><h1>VERBINDING MONITOR</h1><div>Internet • DNS • 5G/LTE • Wi-Fi • uptime • automatisch PDF-rapport</div></div><div class="w">'
echo '<div class="c"><h2>Kies de duur van de meting</h2><div class="grid">'
if [ "$STATUS" = RUNNING ]; then
 echo '<div class="choice"><h3>5 MINUTEN</h3><p>Snelle controle of de meting en PDF goed werken.</p><span class="b disabled">METING ACTIEF</span></div><div class="choice"><h3>1 UUR</h3><p>Korte diagnose voor terugkerende verbindingsproblemen.</p><span class="b disabled">METING ACTIEF</span></div><div class="choice"><h3>24 UUR</h3><p>Volledige analyse van een hele dag en nacht.</p><span class="b disabled">METING ACTIEF</span></div>'
else
 echo '<div class="choice"><h3>5 MINUTEN</h3><p>Snelle controle of de meting en PDF goed werken.</p><a class="b" href="?action=start5">START 5 MINUTEN</a></div><div class="choice"><h3>1 UUR</h3><p>Korte diagnose voor terugkerende verbindingsproblemen.</p><a class="b" href="?action=start60">START 1 UUR</a></div><div class="choice"><h3>24 UUR</h3><p>Volledige analyse van een hele dag en nacht.</p><a class="b" href="?action=start24">START 24 UUR</a></div>'
fi
echo '</div></div>'
echo '<div class="c"><b>Status:</b> <span class="ok">'"$STATUS"'</span><br><b>Actieve test:</b> '"$LABEL"'<br><b>Gestart:</b> '"$START"'<br><b>Voortgang:</b> '"$COUNT"' van '"$TARGET"' minuutmetingen ('"$PCT"'%)<div class="bar"><div class="fill" style="width:'"$PCT"'%"></div></div><p>Na de laatste meting wordt de PDF automatisch gemaakt en hieronder opgeslagen.</p><a class="b stop" href="?action=stop">STOP METING</a><a class="b" href="?action=sample">NU METEN</a>'
[ "$GENERATOR" = BUILD112_JDK_ENGLISH_REPORTS ] && echo '<p class="ok"><b>PDF-generator:</b> Build112 actief</p>' || echo '<p class="err"><b>PDF-generator:</b> '"$GENERATOR"' (niet Build112)</p>'
[ -n "$PDFSTATE" ] && echo '<p><b>Laatste PDF-status:</b> '"$PDFSTATE"'</p>'
[ -s /tmp/matrix_connection_monitor_session.log ] && printf '%s' "$PDFSTATE" | grep -q '^FOUT|' && echo '<p><a class="b" href="?action=pdfnow">HERSTEL PDF VAN BEWAARDE METING</a></p>'
echo '</div><div class="c"><h2>Opgeslagen PDF-rapporten en e-mailconcept</h2>'
echo '<form method="get" target="_blank" class="emailpanel"><input type="hidden" name="action" value="email"><h3 class="step">1. Vul de e-mailgegevens in</h3><div class="emailgrid"><label class="field">Taal van de e-mail<select name="lang"><option value="nl">Nederlands</option><option value="en">English</option><option value="de">Deutsch</option><option value="fr">Français</option></select></label><label class="field">Naam ontvanger<input name="name" placeholder="bijvoorbeeld Rene"></label><label class="field">E-mailadres<input type="email" name="to" placeholder="naam@bedrijf.nl"></label><label class="field">Klant of club<input name="club" placeholder="optioneel"></label><label class="field">Naam afzender<input name="tech" placeholder="bijvoorbeeld Rob Bosman"></label></div><label class="field">Aanvullende opmerking<textarea name="note" rows="3" placeholder="optioneel"></textarea></label><div class="reports"><h3 class="step">2. Selecteer één of meerdere rapporten</h3><p class="hint">De knop bouwt en controleert eerst het volledige e-mailconcept. Alleen wanneer alle PDF’s geldig en volledig als bijlage zijn opgenomen, wordt het .eml-bestand gedownload.</p>'
FOUND=0; for P in $(ls -1t "$REPORT_DIR"/Matrix_Verbindingsrapport_*.pdf "$REPORT_DIR"/Matrix_Connection_Report_*.pdf 2>/dev/null); do F=${P##*/}; FOUND=1; B=$(wc -c < "$P" 2>/dev/null); B=${B:-0}; K=$(( (B + 1023) / 1024 )); echo '<div class="report"><input type="checkbox" name="report" value="'"$F"'"><span class="filename">'"$F"' <small>('"$K"' KB)</small></span><a class="b" href="?action=download&amp;file='"$F"'">DOWNLOAD PDF</a></div>'; done; if [ "$FOUND" = 0 ]; then echo '<p>Nog geen compleet rapport beschikbaar. Test eerst de 5-minutenmeting.</p>'; else echo '<p><button class="b mail" type="submit">3. MAAK GECONTROLEERD E-MAILCONCEPT</button></p>'; fi; echo '</div></form>'
echo '</div><div class="c"><h2>Storingsgebeurtenissen</h2><pre>'; "$MON" events 200 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'; echo '</pre></div><div class="c"><h2>Laatste metingen</h2><pre>'; "$MON" report 240 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'; echo '</pre></div></div>'
if [ "$STATUS" = RUNNING ]; then
 echo '<script>(function(){var timer=null;var form=document.querySelector(".emailpanel");if(!form)return;var note=document.createElement("div");note.style.display="none";note.style.marginBottom="14px";note.style.padding="10px 12px";note.style.borderRadius="8px";note.style.background="#fff4ce";note.style.color="#664d03";note.textContent="Automatisch verversen is gepauzeerd terwijl u het formulier invult.";form.insertBefore(note,form.firstChild);var stop=function(){if(timer){clearTimeout(timer);timer=null;}note.style.display="block";};form.addEventListener("keydown",stop,true);form.addEventListener("pointerdown",stop,true);form.addEventListener("input",stop,true);form.addEventListener("change",stop,true);timer=setTimeout(function(){location.reload();},10000);})();</script>'
fi
echo '</body></html>'