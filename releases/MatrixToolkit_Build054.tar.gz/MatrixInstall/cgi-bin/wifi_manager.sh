#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"

HOST="$(uci -q get system.@system[0].hostname)"
[ -n "$HOST" ] || HOST="$(hostname)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"

S2="$(uci -q get wireless.default_radio0.ssid)"
S5="$(uci -q get wireless.default_radio1.ssid)"
D2="$(uci -q get wireless.default_radio0.disabled)"
D5="$(uci -q get wireless.default_radio1.disabled)"
[ "$D2" = "1" ] && ST2="Disabled" || ST2="Enabled"
[ "$D5" = "1" ] && ST5="Disabled" || ST5="Enabled"
[ "$D2" = "1" ] && CL2="off" || CL2="on"
[ "$D5" = "1" ] && CL5="off" || CL5="on"

STATE="/tmp/matrix_wifi_action.state"
getv(){ sed -n "s/^$1=//p" "$STATE" 2>/dev/null | head -n1; }
LAST_ACTION="$(getv ACTION)"
LAST_RESULT="$(getv RESULT)"
LAST_TIME="$(getv ELAPSED)"
LAST_UPDATED="$(getv UPDATED)"
[ -n "$LAST_ACTION" ] || LAST_ACTION="None"
[ -n "$LAST_RESULT" ] || LAST_RESULT="Idle"
[ -n "$LAST_TIME" ] || LAST_TIME="0"

cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Matrix WiFi Manager</title><style>
body{font-family:Arial;background:#eef3f8;color:#172033;margin:0;padding:16px}.wrap{max-width:1120px;margin:auto}
.hero,.card{background:white;border-radius:16px;padding:20px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
.hero{background:linear-gradient(135deg,#123a63,#0878d1);color:white}.card{margin-top:16px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.band{border:1px solid #d6e0ea;border-radius:14px;padding:16px;background:#f8fafc}
.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:bold}.value{font-size:22px;font-weight:900;margin-top:6px}
.state{display:inline-block;margin-top:8px;padding:7px 11px;border-radius:999px;font-weight:900}.state.on{background:#dff3e4;color:#137333}.state.off{background:#fde2e2;color:#a10000}
.actions{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;margin-top:14px}.btn{display:block;text-decoration:none;border-radius:10px;padding:11px 12px;font-weight:bold;text-align:center;background:#0878d1;color:white}
.green{background:#17833a}.orange{background:#d97706}.red{background:#b42318}.grey{background:#5f6670}
.notice{border-left:6px solid #17833a;background:#edf8ef;padding:14px;border-radius:10px}
.quick{border:2px solid #0878d1}.quick h2{color:#075f9d}.result-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.result{background:#f8fafc;border:1px solid #d6e0ea;border-radius:11px;padding:12px}.result .v{font-size:18px;font-weight:900;margin-top:5px;overflow-wrap:anywhere}
.section-actions{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:14px}
@media(max-width:760px){.grid,.actions,.result-grid,.section-actions{grid-template-columns:1fr}}
</style>
<script>
function ask(t){return confirm(t);}
</script></head><body><div class="wrap">
<section class="hero"><h1>Matrix WiFi Manager</h1><p>${HOST} · Build ${BUILD:-041}</p><p>Quick Test WiFi Control</p></section>

<section class="card quick">
<h2>Current Radio Status</h2>
<div class="grid">
<div class="band"><div class="label">2.4 GHz SSID</div><div class="value">${S2:-Unknown}</div><span class="state $CL2">$ST2</span>
<div class="actions">
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=enable_2g">Enable</a>
<a class="btn red" onclick="return ask('Disable 2.4 GHz immediately?')" href="/cgi-bin/wifi_manager_action.sh?action=disable_2g">Disable</a>
<a class="btn" href="/cgi-bin/wifi_manager_configure.sh?band=2g">Configure</a>
</div></div>
<div class="band"><div class="label">5 GHz SSID</div><div class="value">${S5:-Unknown}</div><span class="state $CL5">$ST5</span>
<div class="actions">
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=enable_5g">Enable</a>
<a class="btn red" onclick="return ask('Disable 5 GHz immediately?')" href="/cgi-bin/wifi_manager_action.sh?action=disable_5g">Disable</a>
<a class="btn" href="/cgi-bin/wifi_manager_configure.sh?band=5g">Configure</a>
</div></div>
</div>

<h2>Both Radios</h2>
<div class="section-actions">
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=enable_both">Enable Both</a>
<a class="btn red" onclick="return ask('Disable both WiFi radios immediately?')" href="/cgi-bin/wifi_manager_action.sh?action=disable_both">Disable Both</a>
<a class="btn orange" href="/cgi-bin/wifi_manager_configure.sh?band=both">Configure Both</a>
<a class="btn green" onclick="return ask('Restore Matrix Default WiFi?')" href="/cgi-bin/wifi_manager_action.sh?action=restore_matrix">Restore Matrix Default</a>
</div>
</section>

<section class="card">
<h2>Last WiFi Action</h2>
<div class="result-grid">
<div class="result"><div class="label">Action</div><div class="v">$LAST_ACTION</div></div>
<div class="result"><div class="label">Result</div><div class="v">$LAST_RESULT</div></div>
<div class="result"><div class="label">Execution time</div><div class="v">${LAST_TIME} s</div></div>
<div class="result"><div class="label">Completed</div><div class="v">${LAST_UPDATED:--}</div></div>
</div>
</section>

<section class="card"><div class="notice">De root-service controleert elke seconde op een nieuwe opdracht. Alleen tijdens een actieve actie wordt de statuspagina kort automatisch bijgewerkt.</div>
<div class="section-actions">
<a class="btn" href="/cgi-bin/wifi_manager_status.sh">Technical Status</a>
<a class="btn green" href="/cgi-bin/wifi_manager_profiles.sh">Profiles</a>
<a class="btn orange" href="/cgi-bin/wifi_manager_logs.sh">Logs</a>
<a class="btn grey" href="/">Back to Toolkit</a>
</div>
</section></div></body></html>
HTML
