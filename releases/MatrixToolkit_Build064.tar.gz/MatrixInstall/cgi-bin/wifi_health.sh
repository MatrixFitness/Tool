#!/bin/sh
printf 'Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n'

esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
getv(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | head -1 | cut -d= -f2-; }
HOST="$(uci -q get system.@system[0].hostname 2>/dev/null)"; [ -n "$HOST" ] || HOST="$(hostname 2>/dev/null)"; [ -n "$HOST" ] || HOST="Matrix Router"
BUILD="$(getv Build)"; [ -n "$BUILD" ] || BUILD=064

# Detect the connected customer-WiFi client interface. wan1 is normally the
# Matrix customer-WiFi uplink, but use safe fallbacks for different RutOS builds.
CLIENT_IF="$(ifstatus wan1 2>/dev/null | sed -n 's/.*"device"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
[ -n "$CLIENT_IF" ] || CLIENT_IF="$(ubus call network.interface.wan1 status 2>/dev/null | sed -n 's/.*"device"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
[ -n "$CLIENT_IF" ] || CLIENT_IF="$(iw dev 2>/dev/null | awk '/Interface/{i=$2}/type managed/{print i;exit}')"
[ -n "$CLIENT_IF" ] || CLIENT_IF="$(iwinfo 2>/dev/null | awk '/ESSID:/{gsub(/ /,"",$1);print $1;exit}')"

IWINFO_OUT=""; [ -n "$CLIENT_IF" ] && IWINFO_OUT="$(iwinfo "$CLIENT_IF" info 2>/dev/null)"
IPADDR="$(ifstatus wan1 2>/dev/null | sed -n 's/.*"address"[[:space:]]*:[[:space:]]*"\([0-9.]*\)".*/\1/p' | head -1)"
[ -n "$IPADDR" ] || IPADDR="$(ip -4 addr show "$CLIENT_IF" 2>/dev/null | awk '/inet /{split($2,a,"/");print a[1];exit}')"
GATEWAY="$(ip route 2>/dev/null | awk -v d="$CLIENT_IF" '$1=="default" && $0~d {print $3;exit}')"
[ -n "$GATEWAY" ] || GATEWAY="$(ip route 2>/dev/null | awk '$1=="default"{print $3;exit}')"

SSID="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*ESSID: *"\([^"]*\)".*/\1/p' | head -1)"
[ -n "$SSID" ] || SSID="Niet verbonden"
BSSID="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*Access Point: *\([0-9A-Fa-f:][0-9A-Fa-f:]*\).*/\1/p' | head -1)"
SIGNAL="$(printf '%s\n' "$IWINFO_OUT" | awk '/Signal:/{print $2;exit}')"
SIGNAL_NUM="$(printf '%s' "$SIGNAL" | sed 's/[^0-9-]//g')"
QUALITY="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*Link Quality: *\([^ ]*\).*/\1/p' | head -1)"
BITRATE="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*Bit Rate: *\([^ ]* [^ ]*\).*/\1/p' | head -1)"
CHANNEL="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*Channel: *\([0-9][0-9]*\).*/\1/p' | head -1)"
[ -n "$CHANNEL" ] || CHANNEL="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*(Channel *\([0-9][0-9]*\)).*/\1/p' | head -1)"
FREQ="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*Channel: *[0-9][0-9]* *(\([0-9.][0-9.]*\) GHz).*/\1/p' | head -1)"
[ -n "$FREQ" ] || FREQ="$(printf '%s\n' "$IWINFO_OUT" | sed -n 's/.*Frequency: *\([0-9.][0-9.]*\).*/\1/p' | head -1)"
BAND="Niet beschikbaar"
case "$FREQ" in 2.*) BAND="2.4 GHz";; 5.*) BAND="5 GHz";; 6.*) BAND="6 GHz";; esac
if [ "$BAND" = "Niet beschikbaar" ] && echo "$CHANNEL" | grep -q '^[0-9][0-9]*$'; then
  [ "$CHANNEL" -le 14 ] && BAND="2.4 GHz" || BAND="5 GHz"
fi

RATING="Geen data"; CLASS="nodata"; ADVICE="De router lijkt niet als WiFi-client verbonden. Verbind eerst met het klantnetwerk en voer daarna de test opnieuw uit."; SCORE="-"
if echo "$SIGNAL_NUM" | grep -q '^-[0-9][0-9]*$'; then
  if [ "$SIGNAL_NUM" -ge -50 ]; then RATING="Uitstekend"; CLASS="excellent"; SCORE=100; ADVICE="Uitstekend signaal. Geschikt voor Matrix- en EGYM-apparatuur, updates en media.";
  elif [ "$SIGNAL_NUM" -ge -60 ]; then RATING="Goed"; CLASS="good"; SCORE=90; ADVICE="Goed signaal. Aanbevolen voor normale, betrouwbare werking.";
  elif [ "$SIGNAL_NUM" -ge -67 ]; then RATING="Redelijk"; CLASS="fair"; SCORE=75; ADVICE="Bruikbaar signaal. Controleer bij kritische apparatuur ook roaming, storing en stabiliteit.";
  elif [ "$SIGNAL_NUM" -ge -70 ]; then RATING="Minimum"; CLASS="minimum"; SCORE=60; ADVICE="Minimum bruikbaar niveau. Er is weinig marge voor storing of roaming; verbeter AP-plaatsing indien mogelijk.";
  elif [ "$SIGNAL_NUM" -ge -80 ]; then RATING="Onbetrouwbaar"; CLASS="weak"; SCORE=40; ADVICE="Zwak en mogelijk onbetrouwbaar. Verplaats het access point of plaats extra dekking.";
  elif [ "$SIGNAL_NUM" -ge -90 ]; then RATING="Slecht"; CLASS="poor"; SCORE=20; ADVICE="Slecht signaal. Connected apparatuur kan uitvallen of langzaam reageren.";
  else RATING="Zeer slecht"; CLASS="critical"; SCORE=5; ADVICE="Geen bruikbaar WiFi-signaal. Los de dekking op voordat apparatuur wordt geïnstalleerd."; fi
fi

PING_TARGET="${GATEWAY:-1.1.1.1}"
PING_OUT="$(ping -c 4 -W 2 "$PING_TARGET" 2>&1)"
LOSS="$(printf '%s\n' "$PING_OUT" | sed -n 's/.*received, *\([0-9][0-9]*%\) packet loss.*/\1/p' | head -1)"
LATENCY="$(printf '%s\n' "$PING_OUT" | awk -F'= ' '/round-trip|rtt/{split($2,a,"/");print a[2];exit}')"
[ -n "$LOSS" ] || LOSS="Niet beschikbaar"
[ -n "$LATENCY" ] && LATENCY="${LATENCY} ms" || LATENCY="Niet beschikbaar"
INTERNET="Niet bereikbaar"; ping -c 1 -W 2 1.1.1.1 >/dev/null 2>&1 && INTERNET="Bereikbaar"
MATRIX="Niet bereikbaar"; (curl -skI --connect-timeout 5 --max-time 8 https://am4.matrixfitness.com 2>/dev/null | head -1 | grep -q 'HTTP/') && MATRIX="Bereikbaar"

sig="$(esc "$SIGNAL_NUM")"; [ -n "$SIGNAL_NUM" ] && sig="$sig dBm" || sig="Geen data"
cat <<EOFHTML
<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WiFi Health Check</title>
<style>
:root{--blue:#0878d1;--dark:#123a63;--bg:#eef3f8;--card:#fff;--line:#d7e1eb;--text:#172033;--muted:#667085;--green:#16843a;--yellow:#d8bd00;--orange:#e98700;--red:#d92d20}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1180px;margin:auto;padding:14px}.hero{background:linear-gradient(135deg,var(--dark),var(--blue));color:#fff;border-radius:19px;padding:18px 20px;display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap}.hero h1{margin:0 0 5px;font-size:30px}.meta{font-size:14px;opacity:.96}.btn{display:inline-block;text-decoration:none;border:1px solid rgba(255,255,255,.38);background:rgba(255,255,255,.14);color:#fff;border-radius:11px;padding:11px 15px;font-weight:900}.main{display:grid;grid-template-columns:minmax(280px,.85fr) minmax(0,1.6fr);gap:15px;margin-top:15px}.card{background:#fff;border:1px solid var(--line);border-radius:17px;padding:18px;box-shadow:0 4px 14px #1420330d}.gauge{text-align:center}.signal{font-size:58px;font-weight:900;line-height:1;margin:14px 0 8px}.pill{display:inline-block;border-radius:999px;padding:8px 14px;font-weight:900}.excellent,.good{background:#dff3e5;color:#08752c}.fair{background:#fff8c9;color:#786900}.minimum{background:#ffedc2;color:#955400}.weak{background:#ffe2c7;color:#aa4900}.poor,.critical{background:#fde2df;color:#b42318}.nodata{background:#edf0f4;color:#667085}.advice{line-height:1.5;color:#475467;margin:15px 0 0}.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:11px}.metric{background:#f8fafc;border:1px solid var(--line);border-radius:13px;padding:13px;min-width:0}.label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:900}.value{font-size:18px;font-weight:900;margin-top:6px;overflow-wrap:anywhere}.section-title{margin:0 0 13px;color:#075f9d}.reference{margin-top:15px}.scale{display:grid;grid-template-columns:repeat(7,1fr);border-radius:13px;overflow:hidden}.seg{min-height:86px;padding:11px 6px;color:#fff;text-align:center;font-weight:900;font-size:12px;display:flex;flex-direction:column;justify-content:center}.s1{background:#159947}.s2{background:#72bd32}.s3{background:#d7ca00}.s4{background:#f5a000}.s5{background:#f47b20}.s6{background:#ef4c22}.s7{background:#e51b23}.seg small{font-size:10px;margin-top:6px}.refcards{display:none}.tip{margin-top:13px;border-left:5px solid var(--blue);background:#eef7ff;border-radius:10px;padding:12px 14px;line-height:1.45}.actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:14px}.action{display:inline-block;text-decoration:none;background:var(--blue);color:#fff;border-radius:10px;padding:11px 14px;font-weight:900}.secondary{background:#667085}.footer{text-align:center;color:var(--muted);font-size:12px;margin:18px}
@media(max-width:800px){.main{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.page{padding:9px}.hero{padding:16px}.hero h1{font-size:25px}.btn{width:100%;text-align:center}.signal{font-size:48px}.metrics{grid-template-columns:1fr 1fr}.scale{display:none}.refcards{display:grid;gap:8px}.ref{display:flex;justify-content:space-between;gap:12px;border-radius:10px;padding:11px 12px;color:#fff;font-weight:900}.ref small{font-weight:700}.actions{display:grid}.action{text-align:center}.card{padding:15px}}
</style></head><body><main class="page">
<section class="hero"><div><h1>WiFi Health Check</h1><div class="meta">Router: $(esc "$HOST") &nbsp;|&nbsp; Toolkit: Build $(esc "$BUILD") &nbsp;|&nbsp; Actueel klant-WiFi</div></div><a class="btn" href="/cgi-bin/index.sh">Terug naar Toolkit</a></section>
<div class="main"><section class="card gauge"><div class="label">Actuele signaalsterkte</div><div class="signal">$sig</div><div class="pill $CLASS">$(esc "$RATING")</div><p class="advice">$(esc "$ADVICE")</p><div class="actions"><a class="action" href="/cgi-bin/wifi_health.sh">Opnieuw meten</a><a class="action secondary" href="/cgi-bin/wifi_survey.sh">Volledige WiFi Survey</a></div></section>
<section class="card"><h2 class="section-title">Huidige WiFi-verbinding</h2><div class="metrics">
<div class="metric"><div class="label">SSID</div><div class="value">$(esc "$SSID")</div></div><div class="metric"><div class="label">BSSID / AP</div><div class="value">$(esc "${BSSID:-Niet beschikbaar}")</div></div><div class="metric"><div class="label">Band</div><div class="value">$(esc "$BAND")</div></div><div class="metric"><div class="label">Kanaal</div><div class="value">$(esc "${CHANNEL:-Niet beschikbaar}")</div></div><div class="metric"><div class="label">Linkkwaliteit</div><div class="value">$(esc "${QUALITY:-Niet beschikbaar}")</div></div><div class="metric"><div class="label">Bitrate</div><div class="value">$(esc "${BITRATE:-Niet beschikbaar}")</div></div><div class="metric"><div class="label">IP-adres</div><div class="value">$(esc "${IPADDR:-Niet beschikbaar}")</div></div><div class="metric"><div class="label">Gateway latency</div><div class="value">$(esc "$LATENCY")</div></div><div class="metric"><div class="label">Packet loss</div><div class="value">$(esc "$LOSS")</div></div><div class="metric"><div class="label">Internet</div><div class="value">$(esc "$INTERNET")</div></div><div class="metric"><div class="label">Matrix Cloud</div><div class="value">$(esc "$MATRIX")</div></div><div class="metric"><div class="label">Kwaliteitsscore</div><div class="value">$(esc "$SCORE")$( [ "$SCORE" != "-" ] && printf '%%' )</div></div>
</div></section></div>
<section class="card reference"><h2 class="section-title">WiFi-signaal in één oogopslag</h2><div class="scale"><div class="seg s1">Uitstekend<small>-30 t/m -50 dBm</small></div><div class="seg s2">Goed<small>-51 t/m -60</small></div><div class="seg s3">Redelijk<small>-61 t/m -67</small></div><div class="seg s4">Minimum<small>-68 t/m -70</small></div><div class="seg s5">Onbetrouwbaar<small>-71 t/m -80</small></div><div class="seg s6">Slecht<small>-81 t/m -90</small></div><div class="seg s7">Zeer slecht<small>lager dan -90</small></div></div>
<div class="refcards"><div class="ref s1"><span>Uitstekend</span><small>-30 t/m -50 dBm</small></div><div class="ref s2"><span>Goed</span><small>-51 t/m -60 dBm</small></div><div class="ref s3"><span>Redelijk</span><small>-61 t/m -67 dBm</small></div><div class="ref s4"><span>Minimum</span><small>-68 t/m -70 dBm</small></div><div class="ref s5"><span>Onbetrouwbaar</span><small>-71 t/m -80 dBm</small></div><div class="ref s6"><span>Slecht</span><small>-81 t/m -90 dBm</small></div><div class="ref s7"><span>Zeer slecht</span><small>lager dan -90 dBm</small></div></div>
<div class="tip"><b>Monteurstip:</b> meet op de plaats waar het toestel werkelijk komt te staan. Voor stabiele Matrix- en EGYM-connectiviteit is <b>-67 dBm of beter</b> een praktisch streefdoel. Een goed RSSI-getal garandeert niet automatisch een stabiele verbinding; controleer daarom ook packet loss, latency, kanaalgebruik en roaming.</div></section>
<div class="footer">Matrix Fitness · Created by Rob Bosman · WiFi Health Check Build $(esc "$BUILD")</div></main></body></html>
EOFHTML
