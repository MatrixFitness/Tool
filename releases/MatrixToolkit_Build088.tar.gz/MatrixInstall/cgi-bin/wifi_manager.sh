<!-- MATRIX_WIFI_BUILD089_DASHBOARD -->
#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"

HOST="$(uci -q get system.@system[0].hostname)"
[ -n "$HOST" ] || HOST="$(hostname)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
[ -n "$RELEASE" ] || RELEASE="Stable"
esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

S2="$(uci -q get wireless.default_radio0.ssid)"
S5="$(uci -q get wireless.default_radio1.ssid)"
D2="$(uci -q get wireless.default_radio0.disabled)"
D5="$(uci -q get wireless.default_radio1.disabled)"
[ "$D2" = "1" ] && ST2="Disabled" || ST2="Enabled"
[ "$D5" = "1" ] && ST5="Disabled" || ST5="Enabled"
[ "$D2" = "1" ] && CL2="off" || CL2="on"
[ "$D5" = "1" ] && CL5="off" || CL5="on"

# Practical radio information for technicians.
CH2="$(uci -q get wireless.radio0.channel)"; [ -n "$CH2" ] || CH2="Auto"
CH5="$(uci -q get wireless.radio1.channel)"; [ -n "$CH5" ] || CH5="Auto"
BW2="$(uci -q get wireless.radio0.htmode)"; [ -n "$BW2" ] || BW2="Auto"
BW5="$(uci -q get wireless.radio1.htmode)"; [ -n "$BW5" ] || BW5="Auto"
SEC2="$(uci -q get wireless.default_radio0.encryption)"; [ -n "$SEC2" ] || SEC2="Open / unknown"
SEC5="$(uci -q get wireless.default_radio1.encryption)"; [ -n "$SEC5" ] || SEC5="Open / unknown"
HID2="$(uci -q get wireless.default_radio0.hidden)"; [ "$HID2" = "1" ] && HID2="Yes" || HID2="No"
HID5="$(uci -q get wireless.default_radio1.hidden)"; [ "$HID5" = "1" ] && HID5="Yes" || HID5="No"
DEV2="$(uci -q get wireless.default_radio0.device)"; [ -n "$DEV2" ] || DEV2="radio0"
DEV5="$(uci -q get wireless.default_radio1.device)"; [ -n "$DEV5" ] || DEV5="radio1"
CLIENTS2="$(iwinfo "$DEV2" assoclist 2>/dev/null | grep -c '^[0-9A-Fa-f][0-9A-Fa-f]:' )"; [ -n "$CLIENTS2" ] || CLIENTS2="0"
CLIENTS5="$(iwinfo "$DEV5" assoclist 2>/dev/null | grep -c '^[0-9A-Fa-f][0-9A-Fa-f]:' )"; [ -n "$CLIENTS5" ] || CLIENTS5="0"

STATE="/tmp/matrix_wifi_action.state"
getv(){ sed -n "s/^$1=//p" "$STATE" 2>/dev/null | head -n1; }
LAST_ACTION="$(getv ACTION)"
LAST_RESULT="$(getv RESULT)"
LAST_TIME="$(getv ELAPSED)"
LAST_UPDATED="$(getv UPDATED)"
[ -n "$LAST_ACTION" ] || LAST_ACTION="None"
[ -n "$LAST_RESULT" ] || LAST_RESULT="Idle"
[ -n "$LAST_TIME" ] || LAST_TIME="0"

cat <<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Matrix WiFi Manager</title><style>
body{font-family:Arial;background:#eef3f8;color:#172033;margin:0;padding:16px}.wrap{max-width:1120px;margin:auto}
.hero,.card{background:white;border-radius:16px;padding:20px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
.hero{background:linear-gradient(135deg,#123a63,#0878d1);color:white}.card{margin-top:16px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.band{border:1px solid #d6e0ea;border-radius:14px;padding:16px;background:#f8fafc}
.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:bold}.value{font-size:22px;font-weight:900;margin-top:6px}
.state{display:inline-block;margin-top:8px;padding:7px 11px;border-radius:999px;font-weight:900}.state.on{background:#dff3e4;color:#137333}.state.off{background:#fde2e2;color:#a10000}
.actions{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;margin-top:14px}.btn{display:block;text-decoration:none;border-radius:10px;padding:11px 12px;font-weight:bold;text-align:center;background:#0878d1;color:white}
.green{background:#17833a}.orange{background:#d97706}.red{background:#b42318}.grey{background:#5f6670}
.notice{border-left:6px solid #17833a;background:#edf8ef;padding:14px;border-radius:10px}
.quick{border:2px solid #0878d1}.service-safe-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.service-safe-box{background:#f8fafc;border:1px solid #d6e0ea;border-radius:14px;padding:14px}.service-safe-box .value{font-size:21px;font-weight:900;margin-top:5px;overflow-wrap:anywhere}.service-buttons{grid-template-columns:repeat(3,1fr)}.quick h2{color:#075f9d}.result-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.result{background:#f8fafc;border:1px solid #d6e0ea;border-radius:11px;padding:12px}.result .v{font-size:18px;font-weight:900;margin-top:5px;overflow-wrap:anywhere}
.section-actions{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:14px}.configuration-title{margin-top:18px}.quick-actions-top{grid-template-columns:repeat(4,minmax(0,1fr));gap:6px}.quick-actions-top .btn{min-width:0;padding:10px 4px;font-size:11px;line-height:1.15;display:flex;align-items:center;justify-content:center;min-height:54px;overflow-wrap:anywhere}.hero-row{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.hero-link{color:white;text-decoration:none;font-weight:800}.details{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:12px}.detail{background:white;border:1px solid #d6e0ea;border-radius:9px;padding:9px}.detail b{display:block;font-size:12px;color:#667085;text-transform:uppercase;margin-bottom:4px}
@media(max-width:760px){.service-safe-grid{grid-template-columns:1fr}.service-buttons{grid-template-columns:1fr}.grid,.actions,.result-grid,.details{grid-template-columns:1fr}.section-actions:not(.quick-actions-top){grid-template-columns:1fr}.quick-actions-top{grid-template-columns:repeat(4,minmax(0,1fr));gap:5px}.quick-actions-top .btn{padding:9px 3px;font-size:10px;min-height:52px}.hero-row{display:block}.hero-link{display:inline-block;margin-top:8px}}

/* MATRIX_WIFI_BUILD089_DASHBOARD */
body{background:#f2f6fa;color:#10233b}.wrap{max-width:1500px;margin:0 auto}
.hero{background:linear-gradient(120deg,#0a4c83,#0878d1);border-radius:0 0 22px 22px;box-shadow:0 8px 24px rgba(9,50,92,.12)}
.card{border:1px solid #d7e1eb;border-radius:18px;box-shadow:0 8px 22px rgba(25,55,85,.06)}
.quick{border:1px solid #cbdbea}.service-safe-box{background:#fff;border:1px solid #d7e1eb;border-radius:16px;box-shadow:0 4px 12px rgba(25,55,85,.04)}
.btn{border-radius:12px;min-height:44px;display:flex;align-items:center;justify-content:center}
</style>
<script>
function ask(t){return confirm(t);}
</script></head><body><div class="wrap">
<section class="hero"><div class="hero-row"><div><h1>Matrix WiFi Manager</h1><p><b>Router:</b> $(esc "$HOST") &middot; <b>Toolkit:</b> Build ${BUILD:-056} ${RELEASE}</p><p>Quick Test WiFi Control</p></div><a class="hero-link" href="/">Back to Toolkit</a></div></section>

<!-- MATRIX_WIFI_SERVICE_SAFE_TOOLKIT_UI -->
<section class="card quick">
<h2>WiFi Service Controls</h2>
<div class="service-safe-grid">
<div class="service-safe-box">
<div class="label">EGYM WIFI - 2.4 GHz</div>
<div class="value">$(esc "${S2:-Unknown}")</div>
<p>Apparatuur / test WiFi. Deze mag tijdens een servicetest AAN of UIT.</p>
<div class="section-actions service-buttons">
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=enable_2g">EGYM AAN</a>
<a class="btn red" onclick="return ask('EGYM 2.4 GHz uitschakelen? De Matrix 5 GHz service-WiFi blijft aan.')" href="/cgi-bin/wifi_manager_action.sh?action=disable_2g">EGYM UIT</a>
</div>
</div>
<div class="service-safe-box">
<div class="label">MATRIX SERVICE WIFI - 5 GHz</div>
<div class="value">$(esc "${S5:-Unknown}")</div>
<p>Beheerverbinding voor Toolkit / Admin. Radio blijft normaal altijd AAN.</p>
<div class="section-actions service-buttons">
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=enable_5g">SERVICE WIFI AAN</a>
<a class="btn" href="/cgi-bin/wifi_manager_configure.sh?band=5g">NAAM WIJZIGEN</a>
<a class="btn" href="/cgi-bin/wifi_manager_action.sh?action=hide_5g">SSID VERBERGEN</a>
<a class="btn grey" href="/cgi-bin/wifi_manager_action.sh?action=show_5g">SSID ZICHTBAAR</a>
</div>
</div>
</div>
<div class="section-actions" style="margin-top:14px">
<a class="btn green" onclick="return ask('Restore Matrix Default WiFi? 2.4 GHz wordt egym AAN; 5 GHz wordt service-WiFi AAN en verborgen.')" href="/cgi-bin/wifi_manager_action.sh?action=restore_matrix">RESTORE MATRIX DEFAULT WIFI</a>
</div>
<p class="notice" style="margin-top:14px"><b>Service Safe:</b> verbergen schakelt alleen de SSID-broadcast uit; de 5 GHz radio blijft actief.</p>


<h2 class="configuration-title">Current WiFi Configuration</h2>
<div class="grid">
<div class="band"><div class="label">2.4 GHz Router WiFi</div><div class="value">$(esc "${S2:-Unknown}")</div><span class="state $CL2">$ST2</span>
<div class="details">
<div class="detail"><b>Channel</b>$(esc "$CH2")</div><div class="detail"><b>Mode / width</b>$(esc "$BW2")</div>
<div class="detail"><b>Security</b>$(esc "$SEC2")</div><div class="detail"><b>Clients</b>$(esc "$CLIENTS2")</div>
<div class="detail"><b>Hidden SSID</b>$(esc "$HID2")</div><div class="detail"><b>Radio</b>$(esc "$DEV2")</div>
</div>
<div class="actions">
<a class="btn" href="/cgi-bin/wifi_manager_configure.sh?band=2g">Configure</a>
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=enable_2g">EGYM AAN</a>
<a class="btn red" onclick="return ask('EGYM 2.4 GHz uitschakelen? De 5 GHz service-WiFi blijft actief.')" href="/cgi-bin/wifi_manager_action.sh?action=disable_2g">EGYM UIT</a>
</div></div>
<div class="band"><div class="label">5 GHz Router WiFi</div><div class="value">$(esc "${S5:-Unknown}")</div><span class="state $CL5">$ST5</span>
<div class="details">
<div class="detail"><b>Channel</b>$(esc "$CH5")</div><div class="detail"><b>Mode / width</b>$(esc "$BW5")</div>
<div class="detail"><b>Security</b>$(esc "$SEC5")</div><div class="detail"><b>Clients</b>$(esc "$CLIENTS5")</div>
<div class="detail"><b>Hidden SSID</b>$(esc "$HID5")</div><div class="detail"><b>Radio</b>$(esc "$DEV5")</div>
</div>
<div class="actions">
<a class="btn" href="/cgi-bin/wifi_manager_configure.sh?band=5g">Configure</a>
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=enable_5g">Service WiFi AAN</a>
<a class="btn" href="/cgi-bin/wifi_manager_action.sh?action=hide_5g">SSID VERBERGEN</a>
<a class="btn grey" href="/cgi-bin/wifi_manager_action.sh?action=show_5g">SSID ZICHTBAAR</a>

</div></div>
</div>

</section>
<section class="card">
<h2>Last WiFi Action</h2>
<div class="result-grid">
<div class="result"><div class="label">Action</div><div class="v">$LAST_ACTION</div></div>
<div class="result"><div class="label">Result</div><div class="v">$LAST_RESULT</div></div>
<div class="result"><div class="label">Execution time</div><div class="v">${LAST_TIME} s</div></div>
<div class="result"><div class="label">Completed</div><div class="v">${LAST_UPDATED:--}</div></div>
</div>
</section>

<section class="card"><div class="notice">De root-service controleert elke seconde op een nieuwe opdracht. Alleen tijdens een actieve actie wordt de statuspagina kort automatisch bijgewerkt.</div>
<div class="section-actions">
<a class="btn" href="/cgi-bin/wifi_manager_status.sh">Technical Status</a>
<a class="btn green" href="/cgi-bin/wifi_manager_profiles.sh">Profiles</a>
<a class="btn orange" href="/cgi-bin/wifi_manager_logs.sh">Logs</a>
<a class="btn grey" href="/">Back to Toolkit</a>
</div>
</section></div></body></html>
HTML
