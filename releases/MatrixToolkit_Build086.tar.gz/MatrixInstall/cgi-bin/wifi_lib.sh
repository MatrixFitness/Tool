#!/bin/sh
# Matrix WiFi Library v67

MATRIX_DIR="/usr/local/matrix"
SYSTEM_PROFILES="$MATRIX_DIR/matrix_wifi_system_profiles.conf"
SYSTEM_DEFAULTS="$MATRIX_DIR/matrix_wifi_system_profiles.default"
USER_PROFILES="$MATRIX_DIR/matrix_wifi_user_profiles.conf"
LEGACY_PROFILES="$MATRIX_DIR/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

url_decode(){
sed -e 's/+/ /g' -e 's/%0[Dd]//g' -e 's/%0[Aa]/ /g' -e 's/%3[Dd]/=/g' \
-e 's/%7[Bb]/{/g' -e 's/%7[Dd]/}/g' -e 's/%20/ /g' -e 's/%21/!/g' \
-e 's/%23/#/g' -e 's/%24/$/g' -e 's/%25/%/g' -e 's/%26/\&/g' \
-e 's/%28/(/g' -e 's/%29/)/g' -e 's/%2[Aa]/*/g' -e 's/%2[Bb]/+/g' \
-e 's/%2[Cc]/,/g' -e 's/%2[Dd]/-/g' -e 's/%2[Ee]/./g' -e 's/%2[Ff]/\//g' \
-e 's/%3[Aa]/:/g' -e 's/%3[Bb]/;/g' -e 's/%3[Ff]/?/g' -e 's/%40/@/g' \
-e 's/%5[Bb]/[/g' -e 's/%5[Dd]/]/g' -e 's/%5[Ee]/^/g' -e 's/%5[Ff]/_/g' \
-e 's/%7[Cc]/|/g' -e 's/%7[Ee]/~/g'
}

qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode; }

write_system_defaults(){
cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Standard
PROFILE1_LOCKED=1
PROFILE1_R0_ACTION=SET
PROFILE1_R0_SSID=egym
PROFILE1_R0_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2
PROFILE1_R1_ACTION=SET
PROFILE1_R1_SSID={HOSTNAME}_5G
PROFILE1_R1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM
PROFILE2_LOCKED=1
PROFILE2_R0_ACTION=SET
PROFILE2_R0_SSID=egym
PROFILE2_R0_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2
PROFILE2_R1_ACTION=KEEP
PROFILE2_R1_SSID=
PROFILE2_R1_PASSWORD=

PROFILE3_NAME=Matrix + EGYM
PROFILE3_LOCKED=1
PROFILE3_R0_ACTION=SET
PROFILE3_R0_SSID=egym
PROFILE3_R0_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2
PROFILE3_R1_ACTION=SET
PROFILE3_R1_SSID={HOSTNAME}_5G
PROFILE3_R1_PASSWORD=matrixfitness
DEFEOF
}

ensure_wifi_files(){
    mkdir -p "$MATRIX_DIR" 2>/dev/null
    [ -f "$SYSTEM_DEFAULTS" ] || write_system_defaults "$SYSTEM_DEFAULTS"
    # Always keep system profiles aligned with Toolkit defaults.
    cp -f "$SYSTEM_DEFAULTS" "$SYSTEM_PROFILES" 2>/dev/null || write_system_defaults "$SYSTEM_PROFILES"
    [ -f "$USER_PROFILES" ] || : > "$USER_PROFILES"
    chmod 666 "$SYSTEM_PROFILES" "$SYSTEM_DEFAULTS" "$USER_PROFILES" 2>/dev/null
}

hostname_value(){
    H="$(uci get system.@system[0].hostname 2>/dev/null)"
    [ -z "$H" ] && H="$(hostname 2>/dev/null)"
    [ -z "$H" ] && H="Matrix"
    echo "$H"
}

resolve_ssid(){
    RAW="$1"
    HOST="$(hostname_value)"
    printf '%s' "$RAW" | sed "s/{HOSTNAME}/$HOST/g"
}

normalize_action(){
    A="$(printf '%s' "$1" | tr 'a-z' 'A-Z')"
    case "$A" in SET|DISABLE|KEEP) echo "$A";; *) echo KEEP;; esac
}

profile_count_file(){
    FILE="$1"
    grep -o "^PROFILE[0-9][0-9]*_" "$FILE" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1
}

profile_value_file(){
    FILE="$1"; IDX="$2"; KEY="$3"
    grep "^PROFILE${IDX}_${KEY}=" "$FILE" 2>/dev/null | head -n1 | cut -d= -f2-
}

user_profile_next(){
    COUNT="$(profile_count_file "$USER_PROFILES")"
    [ -z "$COUNT" ] && COUNT=0
    echo $((COUNT+1))
}

backup_user_profiles(){
    cp -f "$USER_PROFILES" "$MATRIX_DIR/matrix_wifi_user_profiles.previous" 2>/dev/null
    cp -f "$USER_PROFILES" "$MATRIX_DIR/matrix_wifi_user_profiles.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
}

profile_label_to_file(){
    TYPE="$1"
    case "$TYPE" in
        system) echo "$SYSTEM_PROFILES" ;;
        user) echo "$USER_PROFILES" ;;
        *) echo "" ;;
    esac
}

profile_apply(){
    TYPE="$1"; IDX="$2"
    FILE="$(profile_label_to_file "$TYPE")"
    [ -f "$FILE" ] || return 1

    NAME="$(profile_value_file "$FILE" "$IDX" NAME)"
    [ -z "$NAME" ] && return 1

    R0A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R0_ACTION)")"
    R1A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R1_ACTION)")"

    R0S="$(resolve_ssid "$(profile_value_file "$FILE" "$IDX" R0_SSID)")"
    R0P="$(profile_value_file "$FILE" "$IDX" R0_PASSWORD)"
    R1S="$(resolve_ssid "$(profile_value_file "$FILE" "$IDX" R1_SSID)")"
    R1P="$(profile_value_file "$FILE" "$IDX" R1_PASSWORD)"

    case "$R0A" in
        SET)
            uci set wireless.default_radio0.ssid="$R0S"
            uci set wireless.default_radio0.key="$R0P"
            uci set wireless.default_radio0.encryption='psk2'
            uci set wireless.default_radio0.disabled='0'
            ;;
        DISABLE)
            uci set wireless.default_radio0.disabled='1'
            ;;
    esac

    case "$R1A" in
        SET)
            uci set wireless.default_radio1.ssid="$R1S"
            uci set wireless.default_radio1.key="$R1P"
            uci set wireless.default_radio1.encryption='psk2'
            uci set wireless.default_radio1.disabled='0'
            ;;
        DISABLE)
            uci set wireless.default_radio1.disabled='1'
            ;;
    esac

    uci commit wireless
    wifi reload >/dev/null 2>&1
    sleep 2
    echo "$(date '+%Y-%m-%d %H:%M:%S') Applied $TYPE profile $IDX ($NAME) r0=$R0A/$R0S r1=$R1A/$R1S" >> "$LOG"
    return 0
}

restore_matrix_default_wifi(){
    HOST="$(hostname_value)"
    SSID_2G="egym"
    SSID_5G="${HOST}_5G"
    PASS="matrixfitness"

    uci set wireless.default_radio0.ssid="$SSID_2G"
    uci set wireless.default_radio0.key="$PASS"
    uci set wireless.default_radio0.encryption='psk2'
    uci set wireless.default_radio0.disabled='0'
    uci set wireless.default_radio1.ssid="$SSID_5G"
    uci set wireless.default_radio1.key="$PASS"
    uci set wireless.default_radio1.encryption='psk2'
    uci set wireless.default_radio1.disabled='0'
    uci commit wireless
    wifi reload >/dev/null 2>&1
    echo "$(date '+%Y-%m-%d %H:%M:%S') Emergency restored Matrix Default WiFi new2=$SSID_2G new5=$SSID_5G" >> "$LOG"
}

profile_expected(){
    FILE="$1"; IDX="$2"; R="$3"; FIELD="$4"
    ACTION="$(normalize_action "$(profile_value_file "$FILE" "$IDX" ${R}_ACTION)")"
    case "$FIELD" in
        action) echo "$ACTION";;
        ssid)
            if [ "$ACTION" = "SET" ]; then resolve_ssid "$(profile_value_file "$FILE" "$IDX" ${R}_SSID)"; elif [ "$ACTION" = "DISABLE" ]; then echo "Disabled"; else echo "Keep current"; fi
            ;;
        pass)
            if [ "$ACTION" = "SET" ]; then profile_value_file "$FILE" "$IDX" ${R}_PASSWORD; else echo ""; fi
            ;;
    esac
}

profile_same_result(){
    FILE="$1"; IDX="$2"
    CUR0="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
    CUR1="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
    CUR0P="$(uci get wireless.default_radio0.key 2>/dev/null)"
    CUR1P="$(uci get wireless.default_radio1.key 2>/dev/null)"
    DIS0="$(uci get wireless.default_radio0.disabled 2>/dev/null)"; [ -z "$DIS0" ] && DIS0="0"
    DIS1="$(uci get wireless.default_radio1.disabled 2>/dev/null)"; [ -z "$DIS1" ] && DIS1="0"

    R0A="$(profile_expected "$FILE" "$IDX" R0 action)"
    R1A="$(profile_expected "$FILE" "$IDX" R1 action)"
    R0S="$(profile_expected "$FILE" "$IDX" R0 ssid)"
    R1S="$(profile_expected "$FILE" "$IDX" R1 ssid)"
    R0P="$(profile_expected "$FILE" "$IDX" R0 pass)"
    R1P="$(profile_expected "$FILE" "$IDX" R1 pass)"

    SAME=1
    if [ "$R0A" = "SET" ]; then [ "$CUR0" != "$R0S" ] && SAME=0; [ "$CUR0P" != "$R0P" ] && SAME=0; [ "$DIS0" = "1" ] && SAME=0; fi
    if [ "$R1A" = "SET" ]; then [ "$CUR1" != "$R1S" ] && SAME=0; [ "$CUR1P" != "$R1P" ] && SAME=0; [ "$DIS1" = "1" ] && SAME=0; fi
    if [ "$R0A" = "DISABLE" ] && [ "$DIS0" != "1" ]; then SAME=0; fi
    if [ "$R1A" = "DISABLE" ] && [ "$DIS1" != "1" ]; then SAME=0; fi
    echo "$SAME"
}

active_system_profile_name(){
    SC="$(profile_count_file "$SYSTEM_PROFILES")"; [ -z "$SC" ] && SC=0
    i=1
    FIRST_SAME=""
    while [ "$i" -le "$SC" ]; do
        if [ "$(profile_same_result "$SYSTEM_PROFILES" "$i")" = "1" ]; then
            NAME="$(profile_value_file "$SYSTEM_PROFILES" "$i" NAME)"
            [ -z "$FIRST_SAME" ] && FIRST_SAME="$NAME"
            LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
            if echo "$LAST" | grep -q "Applied system profile $i ($NAME)"; then
                echo "$NAME"
                return
            fi
        fi
        i=$((i+1))
    done
    if [ -n "$FIRST_SAME" ]; then echo "$FIRST_SAME"; else echo "Custom Configuration"; fi
}

profile_status_badge(){
    FILE="$1"; IDX="$2"; TYPE="$3"
    if [ "$(profile_same_result "$FILE" "$IDX")" != "1" ]; then
        echo "<span class=\"badge available\">AVAILABLE</span>"
        return
    fi
    NAME="$(profile_value_file "$FILE" "$IDX" NAME)"
    LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
    if echo "$LAST" | grep -q "Applied $TYPE profile $IDX ($NAME)"; then
        echo "<span class=\"badge active\">ACTIVE</span>"
    else
        echo "<span class=\"badge same\">SAME RESULT</span>"
    fi
}

system_profile_card(){
    IDX="$1"
    NAME="$(profile_value_file "$SYSTEM_PROFILES" "$IDX" NAME)"
    R0A="$(profile_expected "$SYSTEM_PROFILES" "$IDX" R0 action)"
    R1A="$(profile_expected "$SYSTEM_PROFILES" "$IDX" R1 action)"
    R0S="$(profile_expected "$SYSTEM_PROFILES" "$IDX" R0 ssid)"
    R1S="$(profile_expected "$SYSTEM_PROFILES" "$IDX" R1 ssid)"
    STATUS="$(profile_status_badge "$SYSTEM_PROFILES" "$IDX" system)"

    E_NAME="$(html_escape "$NAME")"; E_R0S="$(html_escape "$R0S")"; E_R1S="$(html_escape "$R1S")"
    [ "$R0A" = "KEEP" ] && E_R0S="Keep current"
    [ "$R1A" = "KEEP" ] && E_R1S="Keep current"
    [ "$R0A" = "DISABLE" ] && E_R0S="Disabled"
    [ "$R1A" = "DISABLE" ] && E_R1S="Disabled"

    cat <<EOF
<div class="profile-simple-card">
  <div class="profile-simple-header">
    <div class="profile-simple-title">$E_NAME</div>
    <div>$STATUS</div>
  </div>
  <div class="profile-simple-row"><span>2.4 GHz</span><b>$E_R0S</b></div>
  <div class="profile-simple-row"><span>5 GHz</span><b>$E_R1S</b></div>
  <div class="profile-actions"><a class="btn green" onclick="return confirmApply('$E_NAME')" href="/cgi-bin/wifi_manager.sh?action=apply&type=system&p=$IDX">Apply</a></div>
</div>
EOF
}

user_profile_card(){
    IDX="$1"
    NAME="$(profile_value_file "$USER_PROFILES" "$IDX" NAME)"
    [ -z "$NAME" ] && NAME="User Profile $IDX"
    R0A="$(profile_expected "$USER_PROFILES" "$IDX" R0 action)"
    R1A="$(profile_expected "$USER_PROFILES" "$IDX" R1 action)"
    R0S="$(profile_expected "$USER_PROFILES" "$IDX" R0 ssid)"
    R1S="$(profile_expected "$USER_PROFILES" "$IDX" R1 ssid)"
    STATUS="$(profile_status_badge "$USER_PROFILES" "$IDX" user)"
    E_NAME="$(html_escape "$NAME")"; E_R0S="$(html_escape "$R0S")"; E_R1S="$(html_escape "$R1S")"
    [ "$R0A" = "KEEP" ] && E_R0S="Keep current"; [ "$R1A" = "KEEP" ] && E_R1S="Keep current"
    [ "$R0A" = "DISABLE" ] && E_R0S="Disabled"; [ "$R1A" = "DISABLE" ] && E_R1S="Disabled"

    cat <<EOF
<div class="profile-simple-card">
  <div class="profile-simple-header">
    <div class="profile-simple-title">$E_NAME</div>
    <div>$STATUS</div>
  </div>
  <div class="profile-simple-row"><span>2.4 GHz</span><b>$E_R0S</b></div>
  <div class="profile-simple-row"><span>5 GHz</span><b>$E_R1S</b></div>
  <div class="profile-actions"><a class="btn blue" href="/cgi-bin/wifi_profile_edit.sh?type=user&p=$IDX">Edit</a><a class="btn green" onclick="return confirmApply('$E_NAME')" href="/cgi-bin/wifi_manager.sh?action=apply&type=user&p=$IDX">Apply</a><a class="btn red" onclick="return confirmDelete('$E_NAME')" href="/cgi-bin/wifi_profile_save.sh?action=delete&type=user&profile=$IDX">Delete</a></div>
</div>
EOF
}


wifi_iface_mode(){
    IFACE="$1"
    uci get wireless.${IFACE}.mode 2>/dev/null
}

wifi_client_remove(){
    IFACE="$1"
    SSID="$(uci get wireless.${IFACE}.ssid 2>/dev/null)"
    MODE="$(uci get wireless.${IFACE}.mode 2>/dev/null)"

    # Safety: only remove STA/client interfaces, never AP interfaces.
    if [ "$MODE" = "sta" ]; then
        uci delete wireless.${IFACE}
        uci commit wireless
        wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') Removed WiFi client interface iface=$IFACE ssid=$SSID" >> "$LOG"
        return 0
    fi

    echo "$(date '+%Y-%m-%d %H:%M:%S') Refused to remove non-client WiFi interface iface=$IFACE mode=$MODE ssid=$SSID" >> "$LOG"
    return 1
}
