#!/bin/sh
# Matrix Fleet Status Endpoint - Build 030
printf "Content-Type: text/plain; charset=UTF-8\n"
printf "Cache-Control: no-store\n"
printf "Access-Control-Allow-Origin: *\n\n"

VERSION_FILE="/usr/local/matrix/version.txt"
HOST="$(hostname 2>/dev/null)"
BUILD="$(grep '^Build=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
VERSION="$(grep '^Version=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
FIRMWARE="$(cat /etc/version 2>/dev/null | head -1)"
UPTIME="$(cut -d. -f1 /proc/uptime 2>/dev/null)"
ZT_IP=""
ZT_NODE=""
ZT_STATE="OFFLINE"

if [ -f /usr/local/matrix/lib/zerotier_runtime.sh ]; then
    . /usr/local/matrix/lib/zerotier_runtime.sh
    ZH="$(zt_detect_home 2>/dev/null)"
    if [ -n "$ZH" ]; then
        ZT_IP="$(zt_ip "$ZH" 2>/dev/null)"
        ZT_NODE="$(zt_node_id "$ZH" 2>/dev/null)"
        ZS="$(zt_status "$ZH" 2>/dev/null)"
        [ "$ZS" = "ONLINE" ] || [ "$ZS" = "TUNNELED" ] && ZT_STATE="ONLINE"
    fi
fi

[ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr 2>/dev/null | awk '/inet 10\.74\.91\./{split($2,a,"/");print a[1];exit}')"
[ -n "$ZT_IP" ] && ZT_STATE="ONLINE"

printf 'Hostname=%s\n' "$HOST"
printf 'Build=%s\n' "${BUILD:-unknown}"
printf 'Version=%s\n' "${VERSION:-unknown}"
printf 'ZeroTierIP=%s\n' "${ZT_IP:-none}"
printf 'NodeID=%s\n' "${ZT_NODE:-unknown}"
printf 'Status=%s\n' "$ZT_STATE"
printf 'Firmware=%s\n' "${FIRMWARE:-unknown}"
printf 'UptimeSeconds=%s\n' "${UPTIME:-0}"
printf 'Timestamp=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
