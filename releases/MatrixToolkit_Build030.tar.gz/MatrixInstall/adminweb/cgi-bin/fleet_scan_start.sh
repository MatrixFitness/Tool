#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

if ! ps w 2>/dev/null | grep '[m]atrix-fleet-scan' >/dev/null 2>&1; then
    rm -f /tmp/matrix_fleet_scan.state /tmp/matrix_fleet_scan.log
    /usr/local/bin/matrix-fleet-scan >/tmp/matrix_fleet_scan.runner.log 2>&1 &
fi

cat <<'HTML'
<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="2;url=/cgi-bin/fleet_scan_status.sh">
<title>Matrix Fleet Scan</title>
<style>body{font-family:Arial;background:#eef3f8;color:#172033;padding:25px}.box{max-width:720px;margin:auto;background:white;border-radius:16px;padding:24px;box-shadow:0 4px 18px rgba(0,0,0,.1)}h1{color:#075f9d}.spin{font-size:32px}</style>
</head><body><div class="box"><div class="spin">🔍</div><h1>Matrix Fleet Scan gestart</h1><p>Het ZeroTier-subnet wordt parallel onderzocht. De pagina wordt automatisch bijgewerkt.</p></div></body></html>
HTML
