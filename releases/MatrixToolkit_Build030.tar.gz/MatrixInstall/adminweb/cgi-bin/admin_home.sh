#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

VERSION_FILE="/usr/local/matrix/version.txt"
FLEET_CONF="/usr/local/matrix/fleet.conf"
FLEET_DEFAULT="/usr/local/matrix/fleet.conf.default"

[ -s "$FLEET_CONF" ] || [ ! -s "$FLEET_DEFAULT" ] || cp -f "$FLEET_DEFAULT" "$FLEET_CONF"

get_value(){ grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-; }
fleet_ip(){ awk -F= -v h="$1" '$1==h{print $2;exit}' "$FLEET_CONF" 2>/dev/null; }
esc(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

PRODUCT="$(get_value Product)"
EDITION="$(get_value Edition)"
BUILD="$(get_value Build)"
BUILDDATE="$(get_value BuildDate)"
STATUS="$(get_value Status)"
CURRENT_HOST="$(hostname 2>/dev/null)"

fetch_status(){
    IP="$1"
    [ -n "$IP" ] || return 1
    wget -qO- -T 2 "http://$IP:8080/cgi-bin/fleet_status.sh" 2>/dev/null
}

router_card(){
    HOST="$1"; COUNTRY="$2"; FLAG="$3"
    IP="$(fleet_ip "$HOST")"
    DATA="$(fetch_status "$IP")"

    ONLINE=0
    REMOTE_BUILD="-"
    NODE="-"
    LAST="-"
    FIRMWARE="-"

    if [ -n "$DATA" ]; then
        RH="$(printf '%s\n' "$DATA" | awk -F= '$1=="Hostname"{print $2;exit}')"
        if [ "$RH" = "$HOST" ]; then
            ONLINE=1
            REMOTE_BUILD="$(printf '%s\n' "$DATA" | awk -F= '$1=="Build"{print $2;exit}')"
            NODE="$(printf '%s\n' "$DATA" | awk -F= '$1=="NodeID"{print $2;exit}')"
            LAST="$(printf '%s\n' "$DATA" | awk -F= '$1=="Timestamp"{print $2;exit}')"
            FIRMWARE="$(printf '%s\n' "$DATA" | awk -F= '$1=="Firmware"{print $2;exit}')"
        fi
    fi

    CLASS=""
    [ "$CURRENT_HOST" = "$HOST" ] && CLASS=" current"

    if [ "$ONLINE" -eq 1 ]; then
        STATUS_CLASS=""
        STATUS_TEXT="ONLINE"
    else
        STATUS_CLASS=" offline"
        STATUS_TEXT="OFFLINE"
    fi

    cat <<HTML
<div class="router-card$CLASS">
 <div class="router-main">
  <div class="router-head"><span class="router-flag">$FLAG</span><span class="router-name">$(esc "$HOST")</span></div>
  <div class="router-status$STATUS_CLASS"><span class="router-dot"></span>$STATUS_TEXT</div>
  <div class="ip-label">ZeroTier IP</div>
  <div class="router-ip">$(esc "${IP:-Unknown}")</div>
  <div class="router-details">
   <span>Land: $(esc "$COUNTRY")</span>
   <span>Build: $(esc "$REMOTE_BUILD")</span>
   <span>Node: $(esc "$NODE")</span>
   <span>Firmware: $(esc "$FIRMWARE")</span>
   <span>Last seen: $(esc "$LAST")</span>
  </div>
 </div>
 <div class="router-actions">
  <a class="router-link primary" href="http://$(esc "$IP"):8080/" target="_blank">Toolkit</a>
  <a class="router-link" href="http://$(esc "$IP"):8081/cgi-bin/admin_login.sh" target="_blank">Admin</a>
  <button class="router-link copy" type="button" data-copy="ssh root@$(esc "$IP")">Copy SSH</button>
 </div>
</div>
HTML
}

DISPLAY_DATE="$BUILDDATE"
case "$BUILDDATE" in
 ????-??-??) DISPLAY_DATE="$(echo "$BUILDDATE" | awk -F- '{print $3"-"$2"-"$1}')" ;;
esac

cat <<HTML
<!doctype html>
<html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<title>Matrix Toolkit Admin</title>
<style>
:root{--blue:#0878d1;--dark:#123a63;--green:#17833a;--red:#b42318;--bg:#eef3f8;--border:#d6e0ea}
*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;background:var(--bg);margin:0;padding:16px;color:#142033}
.header{background:white;border-radius:16px;padding:20px;display:flex;justify-content:space-between;align-items:center;gap:14px;box-shadow:0 3px 12px rgba(0,0,0,.08)}
h1{margin:0;color:#075f9d}.logout,.scan{display:inline-block;color:white;text-decoration:none;border-radius:10px;padding:12px 17px;font-weight:bold}.logout{background:#5f6670}.scan{background:#17833a}
.header-actions{display:flex;gap:9px;flex-wrap:wrap}.section-title{display:flex;justify-content:space-between;align-items:center;margin:22px 2px 12px}
.router-directory{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}
.router-card{background:white;border:1px solid var(--border);border-radius:17px;padding:18px;box-shadow:0 3px 12px rgba(0,0,0,.08);display:grid;grid-template-columns:1fr auto;gap:13px}
.router-card.current{border:2px solid var(--blue)}.router-head{display:flex;align-items:center;gap:8px}.router-flag{font-size:25px}.router-name{font-size:21px;font-weight:900}
.router-status{display:inline-flex;align-items:center;gap:7px;border-radius:999px;padding:5px 10px;background:#e6f5ea;color:#176b2c;font-weight:900;font-size:12px;margin:8px 0}
.router-status.offline{background:#fde8e8;color:var(--red)}.router-dot{width:8px;height:8px;border-radius:50%;background:#1e963f}.offline .router-dot{background:#d92d20}
.ip-label{font-size:11px;color:#677386;text-transform:uppercase;font-weight:800;margin-top:5px}.router-ip{font-size:24px;font-weight:900;color:#075f9d;overflow-wrap:anywhere}
.router-details{display:grid;gap:4px;margin-top:11px;font-size:12px;color:#5e6978}.router-actions{display:flex;flex-direction:column;gap:8px;min-width:105px}
.router-link{display:block;border:1px solid var(--blue);background:#fff;color:#075f9d;text-align:center;text-decoration:none;padding:9px 11px;border-radius:9px;font-weight:800;cursor:pointer}
.router-link.primary{background:var(--blue);color:#fff}.grid{display:grid;grid-template-columns:repeat(4,minmax(220px,1fr));gap:16px;margin-top:18px}
.card,.info{background:white;border-radius:16px;padding:18px;box-shadow:0 3px 10px rgba(0,0,0,.07)}.card{border-top:7px solid var(--blue)}
.title{font-size:22px;font-weight:900}.desc{color:#596678;margin:7px 0 14px}.btn{display:block;background:var(--blue);color:white;text-decoration:none;border-radius:10px;padding:12px;margin:9px 0;font-weight:bold}
small{display:block;font-weight:normal;margin-top:4px}.info{margin-top:18px}.health{display:inline-block;background:#e6f5ea;color:#176b2c;border-radius:999px;padding:6px 11px;font-weight:bold}
@media(max-width:1100px){.grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:900px){.router-directory{grid-template-columns:1fr}.router-card{grid-template-columns:1fr}.router-actions{flex-direction:row}.router-link{flex:1}}
@media(max-width:650px){body{padding:10px}.header{display:block}.header-actions{margin-top:13px}.grid{grid-template-columns:1fr}.section-title{display:block}.scan{margin-top:8px}.router-ip{font-size:21px}}
</style>
</head><body>
<div class="header">
 <div><h1>Matrix Toolkit Admin</h1><p>Matrix Fitness | Created by Rob Bosman</p></div>
 <div class="header-actions"><a class="scan" href="/cgi-bin/fleet_scan_start.sh">Scan Fleet</a><a class="logout" href="/cgi-bin/admin_logout.sh">Logout</a></div>
</div>

<div class="section-title"><div><h2>Matrix Fleet</h2><div>Actuele adressen uit <code>fleet.conf</code>. Gebruik Scan Fleet na herautorisatie of IP-wijziging.</div></div><a class="scan" href="/cgi-bin/admin_home.sh">Refresh Status</a></div>
<div class="router-directory">
HTML

router_card JNLMatrix Netherlands "🇳🇱"
router_card JBEMatrix Belgium "🇧🇪"
router_card JDKMatrix Denmark "🇩🇰"

cat <<HTML
</div>

<div class="grid">
 <div class="card"><div class="title">Toolkit</div><div class="desc">Open and test the Matrix Toolkit.</div><a class="btn" href="http://__HOST__:8080/">Open Toolkit<small>Port 8080</small></a><a class="btn" href="/cgi-bin/router_info.sh">Router Information</a></div>
 <div class="card"><div class="title">Cloud Maintenance</div><div class="desc">Update, repair and verify.</div><a class="btn" href="/cgi-bin/update_github.sh">Cloud Update & Repair</a><a class="btn" href="/cgi-bin/matrix_doctor.sh">Run Matrix Doctor</a><a class="btn" href="/cgi-bin/matrix_recovery.sh">Run Matrix Recovery</a></div>
 <div class="card"><div class="title">ZeroTier</div><div class="desc">Remote access and diagnostics.</div><a class="btn" href="/cgi-bin/zerotier_manager.sh">ZeroTier Manager</a><a class="btn" href="/cgi-bin/update_github_log.sh">Update Log</a></div>
 <div class="card"><div class="title">Security</div><div class="desc">Administrator security.</div><a class="btn" href="/cgi-bin/admin_change_password.sh">Change Admin Password</a><a class="btn" href="/cgi-bin/system_info.sh">System Information</a></div>
</div>

<div class="info"><h2>Toolkit Version</h2><p><b>$(esc "$PRODUCT")</b></p><p>$(esc "$EDITION") | Build $(esc "$BUILD") | $(esc "$DISPLAY_DATE")</p><p><span class="health">$(esc "$STATUS")</span></p></div>

<script>
document.body.innerHTML=document.body.innerHTML.replaceAll('__HOST__',window.location.hostname);
document.querySelectorAll('[data-copy]').forEach(function(b){b.addEventListener('click',function(){
 var v=b.getAttribute('data-copy');
 if(navigator.clipboard){navigator.clipboard.writeText(v).then(function(){b.textContent='Copied';setTimeout(function(){b.textContent='Copy SSH'},1400);});}
 else{window.prompt('Copy SSH command:',v);}
});});
</script>
</body></html>
HTML
