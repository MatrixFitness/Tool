#!/bin/sh
# MATRIX_CONNECTION_MONITOR_WEB_BUILD098
MON=/usr/local/bin/matrix-connection-monitor
[ ! -x "$MON" ] && MON=/usr/local/matrix/bin/matrix-connection-monitor
ACTION=$(printf '%s' "$QUERY_STRING" | sed -n 's/.*action=\([^&]*\).*/\1/p')
case "$ACTION" in start) "$MON" start >/dev/null 2>&1;; stop) "$MON" stop >/dev/null 2>&1;; sample) "$MON" sample >/dev/null 2>&1;; esac
STATUS=$($MON status 2>/dev/null)
echo 'Content-Type: text/html'; echo ''
echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="60"><title>Matrix Connection Monitor</title><style>body{font-family:Segoe UI,Arial;background:#f2f6fa;color:#10233b;margin:0}.h{background:#0a4c83;color:white;padding:22px}.w{max-width:1200px;margin:20px auto;padding:0 16px}.c{background:white;border:1px solid #d7e1eb;border-radius:14px;padding:18px;margin-bottom:16px}.b{display:inline-block;padding:11px 16px;margin:4px;text-decoration:none;border-radius:9px;background:#0878d1;color:white;font-weight:700}.stop{background:#a52a2a}pre{white-space:pre-wrap;word-break:break-word;background:#101820;color:#eaf2f8;padding:14px;border-radius:10px;max-height:520px;overflow:auto}.ok{color:#16803a;font-weight:800}</style></head><body>'
echo '<div class="h"><h1>VERBINDING MONITOR</h1><div>Matrix Router • Internet • DNS • 5G/LTE • Wi-Fi • uptime</div></div><div class="w">'
echo '<div class="c"><b>Status:</b> <span class="ok">'"$STATUS"'</span><br><br><a class="b" href="?action=start">START MONITORING</a><a class="b stop" href="?action=stop">STOP MONITORING</a><a class="b" href="?action=sample">NU METEN</a></div>'
echo '<div class="c"><h2>Storingsgebeurtenissen</h2><pre>'
$MON events 200 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'
echo '</pre></div><div class="c"><h2>Laatste metingen</h2><pre>'
$MON report 240 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'
echo '</pre></div></div></body></html>'