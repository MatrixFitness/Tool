#!/bin/sh
printf "Content-Type: text/html\n\n"

VERSION_FILE="/usr/local/matrix/version.txt"
[ -f "$VERSION_FILE" ] || VERSION_FILE="/tmp/MatrixInstall/version.txt"

get_value() {
    KEY="$1"
    grep "^$KEY=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

VERSION="$(get_value Version)"
BUILD="$(get_value Build)"
RELEASE="$(get_value Release)"
CHANGES="$(get_value Changes)"
[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"

ZT_IP="$(ip -4 addr show ztdiyqsthc 2>/dev/null | awk '/inet / {split($2,a,"/"); print a[1]; exit}')"
[ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr 2>/dev/null | awk '/ztd/ && /inet / {split($2,a,"/"); print a[1]; exit}')"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Matrix Toolkit Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{
  --blue:#007bff;
  --green:#24a148;
  --purple:#7048c8;
  --orange:#ff7a1a;
  --dark:#5f6368;
  --border:#d9e2ec;
  --bg:#f4f7fb;
  --text:#122033;
}
*{box-sizing:border-box}
body{font-family:Arial,Helvetica,sans-serif;background:var(--bg);margin:0;padding:16px;color:var(--text)}
.header{background:#fff;border:1px solid var(--border);border-radius:16px;padding:22px 26px;display:flex;align-items:center;justify-content:space-between;gap:20px;box-shadow:0 3px 12px rgba(0,0,0,.08);margin-bottom:18px}
.header h1{margin:0;color:#00589c;font-size:34px;line-height:1.1}
.header p{margin:8px 0 0;color:#52606d}
.logout{background:#666;color:#fff;text-decoration:none;border-radius:10px;padding:16px 34px;font-weight:bold;font-size:18px}
.grid{display:grid;grid-template-columns:repeat(4,minmax(240px,1fr));gap:18px}
.card{background:#fff;border:1px solid var(--border);border-radius:16px;padding:18px;box-shadow:0 3px 10px rgba(0,0,0,.07);min-height:310px}
.card.green{border-top:7px solid var(--green)}
.card.blue{border-top:7px solid var(--blue)}
.card.purple{border-top:7px solid var(--purple)}
.card.orange{border-top:7px solid var(--orange)}
.card.grey{border-top:7px solid var(--dark)}
.card-head{display:flex;align-items:flex-start;gap:12px;margin-bottom:16px}
.icon{font-size:28px;line-height:1;width:34px;text-align:center;flex:none}
.card-title{font-size:23px;font-weight:800;margin:0;color:#111827}
.card-desc{font-size:14px;color:#52606d;margin:5px 0 0;line-height:1.35}
.btn{display:block;text-decoration:none;color:#fff;border-radius:10px;padding:13px 14px;margin:10px 0;font-weight:800;font-size:17px}
.btn small{display:block;font-weight:500;font-size:13px;opacity:.95;margin-top:4px}
.green .btn{background:var(--green)}
.blue .btn{background:var(--blue)}
.purple .btn{background:var(--purple)}
.orange .btn{background:var(--orange)}
.grey .btn{background:var(--dark)}
.info-grid{display:grid;grid-template-columns:repeat(4,minmax(240px,1fr));gap:18px;margin-top:18px}
.info{background:#fff;border:1px solid var(--border);border-radius:16px;padding:20px;box-shadow:0 3px 10px rgba(0,0,0,.07);min-height:210px}
.info h2{margin:0 0 16px;color:#00589c;font-size:22px}
.info p{color:#52606d;line-height:1.45;margin:8px 0}
a{color:#005eb8}
.status{display:inline-block;background:#e6f6ea;color:#0b6b2b;border-radius:999px;padding:6px 12px;font-weight:bold;margin-top:6px}
@media(max-width:1100px){.grid,.info-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:650px){body{padding:10px}.header{display:block}.logout{display:inline-block;margin-top:18px}.grid,.info-grid{grid-template-columns:1fr}.header h1{font-size:28px}}
</style>
</head>
<body>

<div class="header">
  <div>
    <h1>Matrix Toolkit Admin</h1>
    <p><strong>Matrix Fitness</strong> | Created by Rob Bosman | <a href="mailto:rob.bosman@matrixfitness.nl">rob.bosman@matrixfitness.nl</a></p>
  </div>
  <a class="logout" href="/cgi-bin/admin_logout.sh">Logout</a>
</div>

<div class="grid">

  <div class="card green">
    <div class="card-head">
      <div class="icon">✓</div>
      <div>
        <div class="card-title">Toolkit</div>
        <div class="card-desc">Open and test the Matrix Toolkit.</div>
      </div>
    </div>
    <a class="btn" href="http://__HOST__:8080/index.html">Open Toolkit<small>Port 8080</small></a>
    <a class="btn" href="/cgi-bin/about.sh">Toolkit Information<small>Version and system information</small></a>
    <a class="btn" href="/cgi-bin/matrix_health_check.sh">Matrix Health Check<small>Router and Toolkit health status</small></a>
  </div>

  <div class="card blue">
    <div class="card-head">
      <div class="icon">↻</div>
      <div>
        <div class="card-title">Update & Install</div>
        <div class="card-desc">Update, repair or install the Toolkit.</div>
      </div>
    </div>
    <a class="btn" href="/cgi-bin/update_github.sh">Cloud Update & Repair<small>Download latest release, repair platform and run doctor</small></a>
    <a class="btn" href="/cgi-bin/install_usb.sh">USB Installation<small>Install Toolkit from USB</small></a>
    <a class="btn" href="/cgi-bin/update_github_log.sh">Update Log<small>Show cloud update progress</small></a>
  </div>

  <div class="card purple">
    <div class="card-head">
      <div class="icon">◎</div>
      <div>
        <div class="card-title">ZeroTier</div>
        <div class="card-desc">Remote access, IP address and repair.</div>
      </div>
    </div>
    <a class="btn" href="/cgi-bin/zerotier_manager.sh">ZeroTier Manager<small>Status, IP address and diagnostics</small></a>
    <a class="btn" href="/cgi-bin/zerotier_setup.sh">ZeroTier Repair<small>Repair or restart ZeroTier</small></a>
    <a class="btn" href="/cgi-bin/update_github_log.sh">Remote Update Log<small>Check remote update status</small></a>
  </div>

  <div class="card orange">
    <div class="card-head">
      <div class="icon">▣</div>
      <div>
        <div class="card-title">Backup & Security</div>
        <div class="card-desc">Backups and administrator security.</div>
      </div>
    </div>
    <a class="btn" href="/cgi-bin/router_config_backup.sh">Router Config Backup<small>Save router configuration</small></a>
    <a class="btn" href="/cgi-bin/toolkit_backup.sh">Toolkit Backup<small>Save Toolkit files</small></a>
    <a class="btn" href="/cgi-bin/admin_change_password.sh">Change Admin Password<small>Update administrator password</small></a>
  </div>

</div>

<div class="info-grid">
  <div class="info">
    <h2>Toolkit Version</h2>
    <p><strong>Matrix Toolkit v$VERSION</strong></p>
    <p>Build $BUILD</p>
    <p>Release $RELEASE</p>
    <span class="status">Production Ready</span>
  </div>

  <div class="info">
    <h2>Backup Location</h2>
    <p>Backups are saved on the USB stick connected to the router.</p>
    <p><strong>Router path:</strong><br>/usr/local/mnt/sda1/Backup</p>
  </div>

  <div class="info">
    <h2>ZeroTier Remote Access</h2>
HTML

if [ -n "$ZT_IP" ]; then
cat <<HTML
    <p>Toolkit:<br><a href="http://$ZT_IP:8080">http://$ZT_IP:8080</a></p>
    <p>Admin:<br><a href="http://$ZT_IP:8081/cgi-bin/admin_login.sh">http://$ZT_IP:8081/cgi-bin/admin_login.sh</a></p>
HTML
else
cat <<HTML
    <p>ZeroTier IP not available yet.</p>
    <p>Open ZeroTier Manager or run <strong>matrix-recovery</strong>.</p>
HTML
fi

cat <<HTML
  </div>

  <div class="info">
    <h2>Repository</h2>
    <p><a href="https://github.com/MatrixFitness/Tool">Open GitHub Repository</a></p>
    <p>Cloud updates use the stable release defined in <strong>latest.txt</strong>.</p>
  </div>
</div>

<script>
document.body.innerHTML = document.body.innerHTML.replaceAll('__HOST__', window.location.hostname);
</script>

</body>
</html>
HTML
