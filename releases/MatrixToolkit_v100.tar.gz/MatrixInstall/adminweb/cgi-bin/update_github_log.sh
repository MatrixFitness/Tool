#!/bin/sh
printf "Content-Type: text/html\n\n"
LOG="/tmp/matrix_update_github.log"
cat <<HTML
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Matrix Cloud Update Log</title>
<meta http-equiv="refresh" content="5">
<style>
body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0;padding:24px;color:#102033}
.card{background:white;border-radius:14px;padding:22px;box-shadow:0 3px 12px rgba(0,0,0,.1)}
pre{background:#111827;color:#e5e7eb;padding:16px;border-radius:10px;overflow:auto;white-space:pre-wrap}
a{color:#005eb8}
</style></head><body><div class="card">
<h1>Matrix Cloud Update Log</h1>
<p><a href="/cgi-bin/admin_home.sh">Back to Admin</a></p>
<pre>
HTML
[ -f "$LOG" ] && cat "$LOG" || echo "No update log available yet."
cat <<HTML
</pre></div></body></html>
HTML
