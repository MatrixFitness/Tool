#!/bin/sh
# MATRIX_CONNECTION_MONITOR_WEB_BUILD102_PDF_RECOVERY
MON=/usr/local/bin/matrix-connection-monitor
[ ! -x "$MON" ] && MON=/usr/local/matrix/bin/matrix-connection-monitor
ACTION=$(printf '%s' "$QUERY_STRING" | sed -n 's/.*action=\([^&]*\).*/\1/p')
FILE=$(printf '%s' "$QUERY_STRING" | sed -n 's/.*file=\([^&]*\).*/\1/p')
REPORT_DIR=/etc/matrix-connection-reports
if [ "$ACTION" = download ]; then
 case "$FILE" in Matrix_Verbindingsrapport_*.pdf) ;; *) echo 'Status: 400 Bad Request'; echo; exit;; esac
 [ -f "$REPORT_DIR/$FILE" ] || { echo 'Status: 404 Not Found'; echo; exit; }
 echo 'Content-Type: application/pdf'; echo 'Content-Disposition: attachment; filename="'"$FILE"'"'; echo ''; cat "$REPORT_DIR/$FILE"; exit
fi
case "$ACTION" in start) "$MON" start >/dev/null 2>&1;; stop) "$MON" stop >/dev/null 2>&1;; sample) "$MON" sample >/dev/null 2>&1;; recover) "$MON" recover-previous >/dev/null 2>&1;; esac
STATUS=$($MON status 2>/dev/null)
COUNT=$(cat /tmp/matrix_connection_monitor_session.count 2>/dev/null); COUNT=${COUNT:-0}
PCT=$((COUNT * 100 / 1440)); [ "$PCT" -gt 100 ] && PCT=100
START=$(cat /tmp/matrix_connection_monitor_session.start 2>/dev/null); START=${START:-Nog_niet_gestart}
PDF_ERROR=$(cat /tmp/matrix_connection_monitor_pdf_error.log 2>/dev/null)
PDF_STATUS=$(cat /tmp/matrix_connection_monitor_pdf_status.log 2>/dev/null)
echo 'Content-Type: text/html'; echo ''
echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="60"><title>Matrix Connection Monitor</title><style>body{font-family:Segoe UI,Arial;background:#f2f6fa;color:#10233b;margin:0}.h{background:#0a4c83;color:white;padding:22px}.w{max-width:1200px;margin:20px auto;padding:0 16px}.c{background:white;border:1px solid #d7e1eb;border-radius:14px;padding:18px;margin-bottom:16px}.b{display:inline-block;padding:11px 16px;margin:4px;text-decoration:none;border-radius:9px;background:#0878d1;color:white;font-weight:700}.stop{background:#a52a2a}pre{white-space:pre-wrap;word-break:break-word;background:#101820;color:#eaf2f8;padding:14px;border-radius:10px;max-height:520px;overflow:auto}.ok{color:#16803a;font-weight:800}</style></head><body>'
echo '<div class="h"><h1>VERBINDING MONITOR</h1><div>Matrix Router • Internet • DNS • 5G/LTE • Wi-Fi • uptime</div></div><div class="w">'
echo '<div class="c"><b>Status:</b> <span class="ok">'"$STATUS"'</span><br>24-uursmeting gestart: '"$START"'<br>Voortgang: '"$COUNT"' van 1440 metingen ('"$PCT"'%). Na 1440 metingen wordt automatisch een PDF opgeslagen.<br><br><a class="b" href="?action=start">START MONITORING</a><a class="b stop" href="?action=stop">STOP MONITORING</a><a class="b" href="?action=sample">NU METEN</a></div>'
echo '<div class="c"><h2>Opgeslagen 24-uurs PDF-rapporten</h2>'
[ -n "$PDF_STATUS" ] && echo '<p class="ok">Laatste PDF-status: '"$PDF_STATUS"'</p>'
[ -n "$PDF_ERROR" ] && echo '<p style="color:#a52a2a;font-weight:800">PDF-fout: '"$PDF_ERROR"'</p>'
echo '<p><a class="b" href="?action=recover">VORIG 24-UURSRAPPORT HERSTELLEN</a></p>'
FOUND=0
for P in $(ls -1t "$REPORT_DIR"/Matrix_Verbindingsrapport_*.pdf 2>/dev/null); do F=${P##*/}; FOUND=1; echo '<div><a class="b" href="?action=download&amp;file='"$F"'">DOWNLOAD '"$F"'</a></div>'; done
[ "$FOUND" = 0 ] && echo '<p>Nog geen compleet 24-uursrapport beschikbaar.</p>'
echo '</div>'
echo '<div class="c"><h2>Storingsgebeurtenissen</h2><pre>'
$MON events 200 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'
echo '</pre></div><div class="c"><h2>Laatste metingen</h2><pre>'
$MON report 240 2>/dev/null | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'
echo '</pre></div></div></body></html>'