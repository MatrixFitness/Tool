# Matrix Toolkit Build 045

Matrix Toolkit - Production Edition
Build: 045
Build Date: 2026-07-17
Status: Stable

BUILD 045 - MOBILE FLEET THREE-ROUTER ADMIN FIX

Mobile Fleet:
- Adds a clearly visible Direct naar Admin section with three separate buttons:
  Admin JNL, Admin JBE and Admin JDK.
- Every router card keeps its own Toolkit, Admin and Copy SSH action.
- Admin buttons now include the router name, preventing confusion on a phone.
- All links are built from the current IP values in fleet.conf.
- Manual refresh only; no permanent background polling.

Retained:
- Build 044 responsive Mobile Fleet design.
- Responsive Admin Login.
- Matrix Doctor WiFi health-check cleanup.
- Existing recovery, Fleet, LTE and WiFi functionality.
