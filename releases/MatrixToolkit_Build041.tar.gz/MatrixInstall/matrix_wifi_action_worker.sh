#!/bin/sh
# Matrix WiFi Root Action Worker - Build 041

REQ="/tmp/matrix_wifi_action.request"
LOCK="/tmp/matrix_wifi_action_worker.lock"
STATUS="/tmp/matrix_wifi_action.status"
STATE="/tmp/matrix_wifi_action.state"
LOG="/tmp/matrix_wifi_action.log"
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"

[ -f "$REQ" ] || exit 0
mkdir "$LOCK" 2>/dev/null || exit 0
trap 'rm -rf "$LOCK"' EXIT INT TERM

write_state(){
    PHASE="$1"
    MESSAGE="$2"
    RESULT="$3"
    ELAPSED="$4"
    ACTION_VALUE="$5"
    {
        printf 'PHASE=%s\n' "$PHASE"
        printf 'MESSAGE=%s\n' "$MESSAGE"
        printf 'RESULT=%s\n' "$RESULT"
        printf 'ELAPSED=%s\n' "$ELAPSED"
        printf 'ACTION=%s\n' "$ACTION_VALUE"
        printf 'RADIO2=%s\n' "$(uci -q get wireless.default_radio0.disabled)"
        printf 'RADIO5=%s\n' "$(uci -q get wireless.default_radio1.disabled)"
        printf 'UPDATED=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    } >"$STATE"
    chmod 666 "$STATE" 2>/dev/null || true
    printf '%s: %s\n' "$PHASE" "$MESSAGE" >"$STATUS"
    chmod 666 "$STATUS" 2>/dev/null || true
}

[ -f "$LIB" ] || {
    write_state "ERROR" "wifi_lib.sh missing" "ERROR" "0" "unknown"
    rm -f "$REQ"
    exit 1
}
. "$LIB"
ensure_wifi_files

getv(){ sed -n "s/^$1=//p" "$REQ" | head -n1; }

ACTION="$(getv ACTION)"
BAND="$(getv BAND)"
TYPE="$(getv TYPE)"
IDX="$(getv IDX)"
SSID2="$(getv SSID2)"
PASS2="$(getv PASS2)"
SSID5="$(getv SSID5)"
PASS5="$(getv PASS5)"
START="$(date +%s)"

write_state "RUNNING" "Executing $ACTION" "RUNNING" "0" "$ACTION"
echo "$(date '+%Y-%m-%d %H:%M:%S') start action=$ACTION band=$BAND type=$TYPE idx=$IDX" >>"$LOG"

elapsed(){
    NOW="$(date +%s)"
    echo $((NOW-START))
}

valid_password(){ [ "${#1}" -ge 8 ]; }
fail(){
    E="$(elapsed)"
    write_state "ERROR" "$1" "ERROR" "$E" "$ACTION"
    echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR action=$ACTION elapsed=${E}s message=$1" >>"$LOG"
    rm -f "$REQ"
    exit 1
}

NEED_RELOAD=0
case "$ACTION" in
    enable_2g)
        uci set wireless.default_radio0.disabled='0' || fail "Could not enable 2.4 GHz"
        NEED_RELOAD=1
        ;;
    disable_2g)
        uci set wireless.default_radio0.disabled='1' || fail "Could not disable 2.4 GHz"
        NEED_RELOAD=1
        ;;
    enable_5g)
        uci set wireless.default_radio1.disabled='0' || fail "Could not enable 5 GHz"
        NEED_RELOAD=1
        ;;
    disable_5g)
        uci set wireless.default_radio1.disabled='1' || fail "Could not disable 5 GHz"
        NEED_RELOAD=1
        ;;
    enable_both)
        uci set wireless.default_radio0.disabled='0' || fail "Could not enable 2.4 GHz"
        uci set wireless.default_radio1.disabled='0' || fail "Could not enable 5 GHz"
        NEED_RELOAD=1
        ;;
    disable_both)
        uci set wireless.default_radio0.disabled='1' || fail "Could not disable 2.4 GHz"
        uci set wireless.default_radio1.disabled='1' || fail "Could not disable 5 GHz"
        NEED_RELOAD=1
        ;;
    restore_matrix)
        HOST="$(hostname_value)"
        uci set wireless.default_radio0.ssid="${HOST}_2G" || fail "Could not restore 2.4 GHz SSID"
        uci set wireless.default_radio0.key='matrixfitness'
        uci set wireless.default_radio0.encryption='psk2'
        uci set wireless.default_radio0.disabled='0'
        uci set wireless.default_radio1.ssid="${HOST}_5G" || fail "Could not restore 5 GHz SSID"
        uci set wireless.default_radio1.key='matrixfitness'
        uci set wireless.default_radio1.encryption='psk2'
        uci set wireless.default_radio1.disabled='0'
        NEED_RELOAD=1
        ;;
    configure)
        case "$BAND" in
            2g)
                [ -n "$SSID2" ] && valid_password "$PASS2" || fail "Invalid 2.4 GHz SSID or password"
                uci set wireless.default_radio0.ssid="$SSID2"
                uci set wireless.default_radio0.key="$PASS2"
                uci set wireless.default_radio0.encryption='psk2'
                uci set wireless.default_radio0.disabled='0'
                ;;
            5g)
                [ -n "$SSID5" ] && valid_password "$PASS5" || fail "Invalid 5 GHz SSID or password"
                uci set wireless.default_radio1.ssid="$SSID5"
                uci set wireless.default_radio1.key="$PASS5"
                uci set wireless.default_radio1.encryption='psk2'
                uci set wireless.default_radio1.disabled='0'
                ;;
            both)
                [ -n "$SSID2" ] && [ -n "$SSID5" ] && valid_password "$PASS2" && valid_password "$PASS5" || fail "Invalid dual-band SSID or password"
                uci set wireless.default_radio0.ssid="$SSID2"
                uci set wireless.default_radio0.key="$PASS2"
                uci set wireless.default_radio0.encryption='psk2'
                uci set wireless.default_radio0.disabled='0'
                uci set wireless.default_radio1.ssid="$SSID5"
                uci set wireless.default_radio1.key="$PASS5"
                uci set wireless.default_radio1.encryption='psk2'
                uci set wireless.default_radio1.disabled='0'
                ;;
            *) fail "Unknown WiFi band" ;;
        esac
        NEED_RELOAD=1
        ;;
    apply)
        profile_apply "$TYPE" "$IDX" || fail "Could not apply profile"
        NEED_RELOAD=0
        ;;
    reload_wifi)
        NEED_RELOAD=1
        ;;
    *)
        fail "Unknown WiFi action"
        ;;
esac

if [ "$NEED_RELOAD" = "1" ]; then
    uci commit wireless || fail "Could not commit wireless configuration"
    wifi reload >>"$LOG" 2>&1 || fail "WiFi reload failed"
fi

E="$(elapsed)"
write_state "SUCCESS" "$ACTION completed" "SUCCESS" "$E" "$ACTION"
echo "$(date '+%Y-%m-%d %H:%M:%S') success action=$ACTION elapsed=${E}s" >>"$LOG"
rm -f "$REQ"
exit 0
