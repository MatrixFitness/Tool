#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"
ensure_wifi_files

cat <<'HTML'
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WiFi Profiles</title><style>
body{font-family:Arial;background:#eef3f8;color:#172033;margin:0;padding:16px}.wrap{max-width:1050px;margin:auto}
.hero,.card{background:white;border-radius:16px;padding:20px;box-shadow:0 3px 14px rgba(0,0,0,.08)}.hero{background:linear-gradient(135deg,#123a63,#0878d1);color:white}.card{margin-top:16px}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:13px}.profile{border:1px solid #d6e0ea;border-radius:13px;padding:15px;background:#f8fafc}.name{font-size:19px;font-weight:900;color:#075f9d}.row{display:flex;justify-content:space-between;gap:10px;padding:7px 0;border-bottom:1px solid #e5e7eb}
.btn{display:inline-block;text-decoration:none;border-radius:9px;padding:10px 12px;font-weight:bold;margin:4px 2px;background:#0878d1;color:white}.green{background:#17833a}.orange{background:#d97706}.red{background:#b42318}.grey{background:#5f6670}
@media(max-width:850px){.grid{grid-template-columns:1fr}}
</style><script>function del(n){return confirm('Delete profile: '+n+'?');}</script></head><body><div class="wrap">
<section class="hero"><h1>WiFi Profiles</h1><p>Build 041</p></section>
HTML

echo '<section class="card"><h2>Matrix System Profiles</h2><div class="grid">'
COUNT="$(profile_count_file "$SYSTEM_PROFILES")"; [ -n "$COUNT" ] || COUNT=0
i=1
while [ "$i" -le "$COUNT" ]; do
    NAME="$(profile_value_file "$SYSTEM_PROFILES" "$i" NAME)"
    R0="$(profile_expected "$SYSTEM_PROFILES" "$i" R0 ssid)"
    R1="$(profile_expected "$SYSTEM_PROFILES" "$i" R1 ssid)"
    cat <<HTML
<div class="profile"><div class="name">$(html_escape "$NAME")</div>
<div class="row"><span>2.4 GHz</span><b>$(html_escape "$R0")</b></div>
<div class="row"><span>5 GHz</span><b>$(html_escape "$R1")</b></div>
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=apply&type=system&p=$i">Apply</a></div>
HTML
    i=$((i+1))
done
echo '</div></section>'

echo '<section class="card"><h2>User Profiles</h2><p><a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add">+ Add New Profile</a></p><div class="grid">'
COUNT="$(profile_count_file "$USER_PROFILES")"; [ -n "$COUNT" ] || COUNT=0
if [ "$COUNT" -eq 0 ]; then
    echo '<p>No user profiles yet.</p>'
else
    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(profile_value_file "$USER_PROFILES" "$i" NAME)"
        if [ -n "$NAME" ]; then
            R0="$(profile_expected "$USER_PROFILES" "$i" R0 ssid)"
            R1="$(profile_expected "$USER_PROFILES" "$i" R1 ssid)"
            cat <<HTML
<div class="profile"><div class="name">$(html_escape "$NAME")</div>
<div class="row"><span>2.4 GHz</span><b>$(html_escape "$R0")</b></div>
<div class="row"><span>5 GHz</span><b>$(html_escape "$R1")</b></div>
<a class="btn green" href="/cgi-bin/wifi_manager_action.sh?action=apply&type=user&p=$i">Apply</a>
<a class="btn" href="/cgi-bin/wifi_profile_edit.sh?type=user&p=$i">Edit</a>
<a class="btn red" onclick="return del('$(html_escape "$NAME")')" href="/cgi-bin/wifi_profile_save.sh?action=delete&profile=$i">Delete</a></div>
HTML
        fi
        i=$((i+1))
    done
fi
echo '</div><p><a class="btn grey" href="/cgi-bin/wifi_manager.sh">Back</a></p></section></div></body></html>'
