#!/bin/sh
# Matrix WiFi Quick Action Loop - Build 041

WORKER="/usr/local/matrix/matrix_wifi_action_worker.sh"
REQ="/tmp/matrix_wifi_action.request"

while true; do
    if [ -f "$REQ" ] && [ -x "$WORKER" ]; then
        "$WORKER"
    fi
    sleep 1
done
