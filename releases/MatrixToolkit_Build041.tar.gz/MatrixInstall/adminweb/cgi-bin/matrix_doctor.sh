#!/bin/sh
VERSION_FILE="/usr/local/matrix/version.txt"
BUILD="$(grep '^Build=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
EDITION="$(grep '^Edition=' "$VERSION_FILE" 2>/dev/null | cut -d= -f2-)"
[ -z "$BUILD" ] && BUILD="012"
[ -z "$EDITION" ] && EDITION="Production Edition"

PASS=0; FAIL=0; WARN=0
line(){ printf "%-42s %s\n" "$1" "$2"; }
ok(){ line "$1" "OK"; PASS=$((PASS+1)); }
fail(){ line "$1" "FAIL  -> $2"; FAIL=$((FAIL+1)); }
warn(){ line "$1" "WARNING  -> $2"; WARN=$((WARN+1)); }

echo "======================================"
echo " MATRIX DOCTOR"
echo " $EDITION"
echo " Build $BUILD"
echo "======================================"

[ -d /usr/local/matrix ] && ok "Matrix folder" || fail "Matrix folder" "missing"
[ -d /usr/local/matrix/web ] && ok "Toolkit web folder" || fail "Toolkit web folder" "missing"
[ -d /usr/local/matrix/adminweb ] && ok "Admin web folder" || fail "Admin web folder" "missing"
[ -f /usr/local/matrix/version.txt ] && ok "Version file" || fail "Version file" "missing"
[ -f /usr/local/matrix/web/index.html ] && ok "Toolkit index" || fail "Toolkit index" "missing"

# Build 041 canonical Admin authentication check
if [ -f /usr/local/matrix/lib/admin_auth.sh ]; then
    . /usr/local/matrix/lib/admin_auth.sh
    matrix_admin_ensure_password
    ADMIN_CHECK_RC=$?
    if [ "$ADMIN_CHECK_RC" -eq 0 ] || [ "$ADMIN_CHECK_RC" -eq 2 ]; then
        ok "Admin authentication"
    else
        fail "Admin authentication" "password repair failed"
    fi
else
    fail "Admin authentication" "library missing"
fi

[ -f /usr/local/matrix/adminweb/cgi-bin/admin_login.sh ] && ok "Admin login" || fail "Admin login" "missing"
[ -f /usr/local/matrix/web/cgi-bin/wifi_manager.sh ] && ok "WiFi Manager" || warn "WiFi Manager" "missing"
[ -f /usr/local/matrix/web/cgi-bin/wifi_survey.sh ] && ok "WiFi Survey" || warn "WiFi Survey" "missing"

BAD_CGI="$(find /usr/local/matrix/web/cgi-bin /usr/local/matrix/adminweb/cgi-bin -type f -name '*.sh' ! -perm -111 2>/dev/null | head -1)"
[ -z "$BAD_CGI" ] && ok "CGI executable" || fail "CGI executable" "$BAD_CGI"

[ -x /usr/local/bin/matrix-update ] && ok "CLI matrix-update" || fail "CLI matrix-update" "missing"
[ -x /usr/local/bin/matrix-version ] && ok "CLI matrix-version" || fail "CLI matrix-version" "missing"
[ -x /usr/local/bin/matrix-zerotier ] && ok "CLI matrix-zerotier" || warn "CLI matrix-zerotier" "missing"

ps | grep '[u]httpd' >/dev/null 2>&1 && ok "uhttpd running" || fail "uhttpd running" "not running"
netstat -lntp 2>/dev/null | grep -q ':8080' && ok "Toolkit port 8080" || fail "Toolkit port 8080" "not listening"
netstat -lntp 2>/dev/null | grep -q ':8081' && ok "Admin port 8081" || fail "Admin port 8081" "not listening"

[ -x /usr/local/matrix/matrix_update_worker.sh ] && ok "Update worker" || fail "Update worker" "missing"
crontab -l 2>/dev/null | grep -q '/usr/local/matrix/matrix_update_worker.sh' && ok "Cron worker" || fail "Cron worker" "matrix_update_worker.sh missing"

[ -f /usr/local/matrix/web/cgi-bin/update_github.sh ] && /bin/sh -n /usr/local/matrix/web/cgi-bin/update_github.sh 2>/dev/null && ok "Update wrapper syntax" || fail "Update wrapper syntax" "update_github.sh"
[ -f /usr/local/matrix/adminweb/cgi-bin/update_github.sh ] && /bin/sh -n /usr/local/matrix/adminweb/cgi-bin/update_github.sh 2>/dev/null && ok "Admin update wrapper syntax" || fail "Admin update wrapper syntax" "admin update"

uci show firewall 2>/dev/null | grep -q '8080' && ok "Firewall 8080" || warn "Firewall 8080" "rule not found"
uci show firewall 2>/dev/null | grep -q '8081' && ok "Firewall 8081" || warn "Firewall 8081" "rule not found"

ZTCLI=""
[ -x /usr/local/usr/bin/zerotier-cli ] && ZTCLI="/usr/local/usr/bin/zerotier-cli"
[ -z "$ZTCLI" ] && command -v zerotier-cli >/dev/null 2>&1 && ZTCLI="$(command -v zerotier-cli)"
opkg list-installed 2>/dev/null | grep -q '^zerotier ' && ok "ZeroTier package" || fail "ZeroTier package" "not installed"
[ -x /etc/init.d/zerotier ] && ok "ZeroTier service" || fail "ZeroTier service" "missing"
LIB="/usr/local/matrix/lib/zerotier_runtime.sh"
if [ -f "$LIB" ]; then
    ok "ZeroTier runtime library"
    . "$LIB"
    ZT_HOME="$(zt_detect_home)"
    if [ -n "$ZT_HOME" ]; then
        ok "ZeroTier daemon"
        ok "ZeroTier runtime -> $ZT_HOME"
        ZT_STATUS="$(zt_status "$ZT_HOME")"
        ZT_NODE="$(zt_node_id "$ZT_HOME")"
        ZT_EXPECTED="$(zt_expected_node_id)"
        ZT_NET_STATE="$(zt_network_state "$ZT_HOME")"
        ZT_IP_ADDR="$(zt_ip "$ZT_HOME")"
        if [ "$ZT_STATUS" = ONLINE ] || [ "$ZT_STATUS" = TUNNELED ]; then ok "ZeroTier online -> $ZT_STATUS"; else warn "ZeroTier online" "${ZT_STATUS:-unknown}"; fi
        [ -n "$ZT_NODE" ] && ok "ZeroTier Node ID -> $ZT_NODE" || warn "ZeroTier Node ID" "unknown"
        if [ -n "$ZT_EXPECTED" ] && [ "$ZT_NODE" = "$ZT_EXPECTED" ]; then ok "ZeroTier identity matches backup"; elif [ -n "$ZT_EXPECTED" ]; then fail "ZeroTier identity mismatch" "expected $ZT_EXPECTED, current ${ZT_NODE:-unknown}"; else warn "ZeroTier persistent identity" "not stored"; fi
        case "$ZT_NET_STATE" in
          OK) ok "ZeroTier network joined"; ok "ZeroTier authorization" ;;
          ACCESS_DENIED) ok "ZeroTier network joined"; warn "ZeroTier authorization" "ACCESS_DENIED" ;;
          JOINED) ok "ZeroTier network joined"; warn "ZeroTier authorization" "pending" ;;
          *) warn "ZeroTier network joined" "network not shown"; warn "ZeroTier authorization" "unknown" ;;
        esac
        [ -n "$ZT_IP_ADDR" ] && ok "ZeroTier IPv4 address -> $ZT_IP_ADDR" || fail "ZeroTier IPv4 address" "no assigned address"
        zt_route_ok "$ZT_HOME" && ok "ZeroTier subnet route" || warn "ZeroTier subnet route" "missing"
        if [ -n "$ZT_IP_ADDR" ]; then
          wget -qO- -T 4 "http://$ZT_IP_ADDR:8081/cgi-bin/admin_login.sh" >/dev/null 2>&1 && ok "ZeroTier local admin web test" || warn "ZeroTier local admin web test" "no response"
          wget -qO- -T 4 "http://$ZT_IP_ADDR:8080/" >/dev/null 2>&1 && ok "ZeroTier local toolkit web test" || warn "ZeroTier local toolkit web test" "no response"
        else
          warn "ZeroTier local admin web test" "no IP"
          warn "ZeroTier local toolkit web test" "no IP"
        fi
    else
        fail "ZeroTier daemon" "no responsive runtime"
        warn "ZeroTier online" "unknown"
        warn "ZeroTier Node ID" "unknown"
        warn "ZeroTier network joined" "network not shown"
        warn "ZeroTier authorization" "unknown"
        fail "ZeroTier IPv4 address" "no assigned address"
        warn "ZeroTier subnet route" "missing"
        warn "ZeroTier local admin web test" "no IP"
        warn "ZeroTier local toolkit web test" "no IP"
    fi
else
    fail "ZeroTier runtime library" "missing"
fi

ip route | grep -q '^default' && ok "WAN route" || fail "WAN route" "no default route"
wget -qO- -T 5 http://127.0.0.1:8080 >/dev/null 2>&1 && ok "Local Toolkit response" || fail "Local Toolkit response" "no response"
wget -qO- -T 5 http://127.0.0.1:8081/cgi-bin/admin_login.sh >/dev/null 2>&1 && ok "Local Admin response" || fail "Local Admin response" "no response"

uci show uhttpd 2>/dev/null | grep -q "lua_prefix='='" && fail "uhttpd Lua prefix" "invalid '=' found" || ok "uhttpd Lua prefix"

echo "======================================"
echo "PASS: $PASS"
echo "FAIL: $FAIL"
echo "WARN: $WARN"
[ "$FAIL" -eq 0 ] && echo "SYSTEM HEALTH: OK" || echo "SYSTEM HEALTH: REPAIR ADVISED"
[ -n "$NODE_ID" ] && echo "ZeroTier Node ID: $NODE_ID"
[ -n "$ZT_IP" ] && echo "Toolkit ZeroTier URL: http://$ZT_IP:8080" && echo "Admin ZeroTier URL: http://$ZT_IP:8081/cgi-bin/admin_login.sh"
echo "======================================"


[ -x /usr/local/bin/matrix-fleet-scan ] && ok "Fleet scanner" || fail "Fleet scanner" "missing"
[ -s /usr/local/matrix/fleet.conf ] && ok "Fleet configuration" || warn "Fleet configuration" "missing or empty"
[ -x /usr/local/matrix/web/cgi-bin/fleet_status.sh ] && ok "Fleet status endpoint" || fail "Fleet status endpoint" "missing"

[ -x /usr/local/matrix/lib/fleet_status.sh ] && ok "Fleet status library" || fail "Fleet status library" "missing"
[ -d /usr/local/matrix/fleet-cache ] && ok "Fleet cache directory" || warn "Fleet cache directory" "missing"

TOOLKIT_TIMEOUT="$(uci -q get uhttpd.matrix_toolkit.script_timeout)"
[ "$TOOLKIT_TIMEOUT" -ge 120 ] 2>/dev/null && ok "Toolkit CGI timeout" || warn "Toolkit CGI timeout" "expected at least 120 seconds"

WIFI_HEALTH="$(wget -q -O - -T 10 'http://127.0.0.1:8080/cgi-bin/wifi_manager.sh?health=1' 2>/dev/null)"
printf '%s' "$WIFI_HEALTH" | grep -q 'WIFI_MANAGER_OK' && ok "WiFi Manager HTTP response" || fail "WiFi Manager HTTP response" "blank or invalid CGI response"

[ -x /usr/local/bin/matrix-web-reload ] && ok "Web reload lock helper" || fail "Web reload lock helper" "missing"

if grep -qi 'http-equiv=.*refresh' /usr/local/matrix/adminweb/cgi-bin/admin_home.sh 2>/dev/null; then
    warn "Fleet automatic refresh" "still configured"
else
    ok "Fleet automatic refresh disabled"
fi

if grep -Eq 'setInterval|location\.reload|window\.setTimeout' /usr/local/matrix/adminweb/cgi-bin/admin_home.sh 2>/dev/null; then
    warn "Fleet background polling" "automatic refresh code found"
else
    ok "Fleet background polling disabled"
fi


ROOT_CRON="/etc/crontabs/root"
UHTTPD_CRON="/etc/crontabs/uhttpd"

if grep -q '/usr/local/matrix/matrix_update_worker.sh' "$ROOT_CRON" 2>/dev/null; then
    ok "Update worker root cron"
else
    fail "Update worker root cron" "missing"
fi

if grep -q 'matrix_update_worker.sh' "$UHTTPD_CRON" 2>/dev/null; then
    warn "Update worker uhttpd cron" "worker must run as root only"
else
    ok "Update worker removed from uhttpd cron"
fi

DIRECT_RESTARTS="$(grep -RIlE '/etc/init\.d/uhttpd (restart|reload|start|stop)|killall[[:space:]]+uhttpd' \
    /usr/local/matrix/web/cgi-bin \
    /usr/local/matrix/adminweb/cgi-bin \
    /usr/local/matrix/lib \
    2>/dev/null | grep -v '/matrix-web-reload$' | wc -l)"

if [ "${DIRECT_RESTARTS:-0}" -eq 0 ]; then
    ok "Centralized web control"
else
    warn "Centralized web control" "$DIRECT_RESTARTS direct uhttpd control file(s) found"
fi

WIFI_LIGHT="$(wget -q -O - -T 10 'http://127.0.0.1:8080/cgi-bin/wifi_manager.sh' 2>/dev/null)"
printf '%s' "$WIFI_LIGHT" | grep -q 'Low Resource Edition' && ok "WiFi Manager lightweight page" || fail "WiFi Manager lightweight page" "blank or invalid"


if [ -e /usr/local/matrix/web/cgi-bin/admin_login.sh ]; then
    warn "Toolkit/Admin CGI separation" "admin_login.sh still exists in Toolkit web"
else
    ok "Toolkit/Admin CGI separation"
fi

FLEET_STATUS="$(wget -q -O - -T 10 'http://127.0.0.1:8080/cgi-bin/fleet_status.sh' 2>/dev/null)"
FLEET_HOST="$(printf '%s\n' "$FLEET_STATUS" | awk -F= '$1=="Hostname"{print $2;exit}')"
FLEET_NODE="$(printf '%s\n' "$FLEET_STATUS" | awk -F= '$1=="NodeID"{print $2;exit}')"
[ -n "$FLEET_HOST" ] && ok "Fleet hostname" || fail "Fleet hostname" "empty"
if [ -n "$FLEET_NODE" ] && [ "$FLEET_NODE" != "unknown" ]; then
    ok "Fleet Node ID"
else
    fail "Fleet Node ID" "unknown"
fi

[ -x /usr/local/matrix/web/cgi-bin/wifi_manager_status.sh ] && ok "WiFi Manager status module" || fail "WiFi Manager status module" "missing"
[ -x /usr/local/matrix/web/cgi-bin/wifi_manager_profiles.sh ] && ok "WiFi Manager profiles module" || fail "WiFi Manager profiles module" "missing"
[ -x /usr/local/matrix/web/cgi-bin/wifi_manager_action.sh ] && ok "WiFi Manager action module" || fail "WiFi Manager action module" "missing"
[ -x /usr/local/matrix/web/cgi-bin/wifi_manager_logs.sh ] && ok "WiFi Manager logs module" || fail "WiFi Manager logs module" "missing"

if grep -Eq '10\.74\.91\.[0-9]+' /usr/local/matrix/adminweb/cgi-bin/update_github_log.sh 2>/dev/null; then
    warn "Update Log dynamic Fleet IPs" "hardcoded ZeroTier address found"
else
    ok "Update Log dynamic Fleet IPs"
fi

[ -x /usr/local/matrix/web/cgi-bin/wifi_manager_configure.sh ] && ok "WiFi Manager configure module" || fail "WiFi Manager configure module" "missing"
[ -x /usr/local/matrix/web/cgi-bin/wifi_profile_edit.sh ] && ok "WiFi profile editor" || fail "WiFi profile editor" "missing"
[ -x /usr/local/matrix/web/cgi-bin/wifi_profile_save.sh ] && ok "WiFi profile save endpoint" || fail "WiFi profile save endpoint" "missing"

[ -x /usr/local/matrix/matrix_wifi_action_worker.sh ] && ok "WiFi action root worker" || fail "WiFi action root worker" "missing"
[ -x /usr/local/matrix/web/cgi-bin/wifi_web_lib.sh ] && ok "WiFi central web library" || fail "WiFi central web library" "missing"
[ -x /usr/local/matrix/web/cgi-bin/wifi_manager_action_status.sh ] && ok "WiFi action status page" || fail "WiFi action status page" "missing"

if grep -q 'matrix_wifi_action_worker.sh' /etc/crontabs/root 2>/dev/null; then
    ok "WiFi action worker root cron"
else
    fail "WiFi action worker root cron" "missing"
fi

if grep -Eq 'uci set wireless|wifi reload' /usr/local/matrix/web/cgi-bin/wifi_manager_action.sh 2>/dev/null; then
    warn "WiFi CGI privilege separation" "direct WiFi control still present"
else
    ok "WiFi CGI privilege separation"
fi

if [ -x /etc/init.d/matrix_wifi_action ]; then
    ok "WiFi Quick Action service"
else
    fail "WiFi Quick Action service" "missing"
fi

if /etc/init.d/matrix_wifi_action status >/dev/null 2>&1; then
    ok "WiFi Quick Action service running"
else
    fail "WiFi Quick Action service running" "inactive"
fi

[ -x /usr/local/matrix/web/cgi-bin/wifi_manager_action_state.sh ] && ok "WiFi live action state endpoint" || fail "WiFi live action state endpoint" "missing"

if ps w 2>/dev/null | grep -q '[m]atrix_wifi_action_service.sh'; then
    ok "WiFi one-second action watcher"
else
    fail "WiFi one-second action watcher" "not running"
fi
