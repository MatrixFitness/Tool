#!/bin/sh
# Matrix WiFi Action API - Build 043

WEB_LIB="/usr/local/matrix/web/cgi-bin/wifi_web_lib.sh"
if [ ! -f "$WEB_LIB" ]; then
    printf "Content-Type: text/html; charset=UTF-8\n\n"
    printf '<html><body><h1>WiFi library missing</h1></body></html>\n'
    exit 0
fi
. "$WEB_LIB"

ACTION="$(qs action)"
BAND="$(qs band)"
TYPE="$(qs type)"
IDX="$(qs p)"
SSID2="$(qs ssid2)"
PASS2="$(qs pass2)"
SSID5="$(qs ssid5)"
PASS5="$(qs pass5)"
SAME="$(qs same)"

[ -n "$ACTION" ] || wifi_error "Missing action" "No WiFi action was supplied."

if [ "$ACTION" = "configure" ] && [ "$BAND" = "both" ] && [ "$SAME" = "1" ]; then
    SSID5="$SSID2"
    PASS5="$PASS2"
fi

case "$ACTION" in
    enable_2g|disable_2g|enable_5g|disable_5g|enable_both|disable_both|restore_matrix|reload_wifi)
        ;;
    configure)
        case "$BAND" in 2g|5g|both) ;; *) wifi_error "Invalid band" "Unknown WiFi band." ;; esac
        ;;
    apply)
        case "$TYPE" in system|user) ;; *) wifi_error "Invalid profile" "Unknown profile type." ;; esac
        [ -n "$IDX" ] || wifi_error "Invalid profile" "No profile number was supplied."
        ;;
    *)
        wifi_error "Invalid action" "The requested WiFi action is not supported."
        ;;
esac

wifi_queue_action "$ACTION" "$BAND" "$TYPE" "$IDX" "$SSID2" "$PASS2" "$SSID5" "$PASS5" \
    || wifi_error "Queue failed" "The WiFi action could not be queued."

wifi_queued "Action $ACTION has been accepted."
