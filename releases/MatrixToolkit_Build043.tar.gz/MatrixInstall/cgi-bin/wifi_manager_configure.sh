#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\nCache-Control: no-store\n\n"

LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"

BAND="$(qs band)"
case "$BAND" in 2g|5g|both) ;; *) BAND="both" ;; esac

S2="$(uci -q get wireless.default_radio0.ssid)"
P2="$(uci -q get wireless.default_radio0.key)"
S5="$(uci -q get wireless.default_radio1.ssid)"
P5="$(uci -q get wireless.default_radio1.key)"

SHOW2=0
SHOW5=0
case "$BAND" in
  2g) SHOW2=1 ;;
  5g) SHOW5=1 ;;
  both) SHOW2=1; SHOW5=1 ;;
esac

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Configure WiFi</title>
<style>
body{font-family:Arial;background:#eef3f8;margin:0;padding:16px;color:#172033}
.wrap{max-width:820px;margin:auto}
.hero,.card{background:white;border-radius:16px;padding:20px;box-shadow:0 3px 14px rgba(0,0,0,.08)}
.hero{background:linear-gradient(135deg,#123a63,#0878d1);color:white}
.card{margin-top:16px}
.field{margin:14px 0}
.field label{display:block;font-size:12px;color:#667085;font-weight:bold;margin-bottom:5px}
.field input{width:100%;padding:12px;border:1px solid #cfd8e3;border-radius:9px;box-sizing:border-box;font-size:16px}
.band{border:1px solid #d6e0ea;border-radius:12px;padding:15px;margin:14px 0;background:#f8fafc}
.btn{display:inline-block;border:0;border-radius:10px;padding:12px 16px;font-weight:bold;text-decoration:none;cursor:pointer}
.primary{background:#0878d1;color:white}
.grey{background:#5f6670;color:white}
.check{display:flex;gap:8px;align-items:center;margin:14px 0}
</style>
<script>
function sameCredentials(){
  var c=document.getElementById('same');
  var s2=document.getElementById('ssid2');
  var p2=document.getElementById('pass2');
  var s5=document.getElementById('ssid5');
  var p5=document.getElementById('pass5');
  if(c && c.checked && s2 && p2 && s5 && p5){
    s5.value=s2.value;
    p5.value=p2.value;
  }
}
</script>
</head>
<body>
<div class="wrap">
<section class="hero"><h1>Configure WiFi</h1><p>Build 043</p></section>
<section class="card">
<form method="get" action="/cgi-bin/wifi_manager_action.sh" onsubmit="sameCredentials();return confirm('Save WiFi settings and reload WiFi?');">
<input type="hidden" name="action" value="configure">
<input type="hidden" name="band" value="$BAND">
HTML

if [ "$SHOW2" = "1" ]; then
cat <<HTML
<div class="band">
<h2>2.4 GHz</h2>
<div class="field"><label>SSID</label><input id="ssid2" type="text" name="ssid2" value="$(html_escape "$S2")" required></div>
<div class="field"><label>Password</label><input id="pass2" type="password" name="pass2" value="$(html_escape "$P2")" minlength="8" required></div>
</div>
HTML
fi

if [ "$SHOW5" = "1" ]; then
cat <<HTML
<div class="band">
<h2>5 GHz</h2>
<div class="field"><label>SSID</label><input id="ssid5" type="text" name="ssid5" value="$(html_escape "$S5")" required></div>
<div class="field"><label>Password</label><input id="pass5" type="password" name="pass5" value="$(html_escape "$P5")" minlength="8" required></div>
</div>
HTML
fi

if [ "$BAND" = "both" ]; then
cat <<HTML
<label class="check"><input id="same" type="checkbox" name="same" value="1"> Use the same SSID and password for both radios</label>
HTML
fi

cat <<HTML
<p>
<button class="btn primary" type="submit">Save and Reload WiFi</button>
<a class="btn grey" href="/cgi-bin/wifi_manager.sh">Cancel</a>
</p>
</form>
</section>
</div>
</body>
</html>
HTML
