#!/bin/sh
WEB="/usr/local/matrix/web/cgi-bin"
mkdir -p "$WEB"

for f in wifi_manager.sh wifi_lib.sh; do
    if [ -f "$WEB/$f" ]; then
        cp -f "$WEB/$f" "$WEB/$f.bak.v653.$(date +%Y%m%d%H%M%S)"
    fi
    cp -f "$f" "$WEB/$f"
    chmod +x "$WEB/$f"
done

echo "WiFi Manager v65.3 installed."
