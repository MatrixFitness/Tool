#!/bin/sh
# Matrix Toolkit v70.1 ZeroTier runtime fix installer

SOURCE_DIR="$(dirname "$0")"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
WEB="/usr/local/matrix/web/cgi-bin"

mkdir -p "$ADMINWEB" "$WEB"

if [ -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" "$ADMINWEB/zerotier_manager.sh"
    chmod +x "$ADMINWEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" "$WEB/zerotier_manager.sh"
    chmod +x "$WEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh"
    chmod +x "$WEB/zerotier_fix.sh"
fi

cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_manager.sh "$@"
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix

echo "Matrix Toolkit v70.1 ZeroTier runtime fix installed."
