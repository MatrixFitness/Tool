#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ZEROTIER ROOT WORKER
# =====================================================
# Runs from cron as root. The Admin web page only creates
# /tmp/matrix_zerotier_request. This worker performs the
# real ZeroTier setup with root rights.
# =====================================================

REQ="/tmp/matrix_zerotier_request"
LOCK="/tmp/matrix_zerotier_worker.lock"
LOG="/tmp/matrix_zerotier.log"
DEFAULT_NETWORK_ID="cf719fd5409699a2"
ZT_HOME="/etc/zerotier"
MATRIX_WEB_PORT="8080"
MATRIX_ADMIN_PORT="8081"

[ -f "$REQ" ] || exit 0

if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        exit 0
    fi
fi

echo "$$" > "$LOCK"
trap 'rm -f "$LOCK"' EXIT INT TERM

NETWORK_ID="$(cat "$REQ" 2>/dev/null | head -n1)"
[ -n "$NETWORK_ID" ] || NETWORK_ID="$DEFAULT_NETWORK_ID"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

find_zt_one() {
    for p in /usr/local/usr/bin/zerotier-one /usr/bin/zerotier-one /overlay/root/upper/usr/bin/zerotier-one; do
        [ -x "$p" ] && echo "$p" && return
    done
    command -v zerotier-one 2>/dev/null
}

find_zt_cli() {
    for p in /usr/local/usr/bin/zerotier-cli /usr/bin/zerotier-cli /overlay/root/upper/usr/bin/zerotier-cli; do
        [ -x "$p" ] && echo "$p" && return
    done
    command -v zerotier-cli 2>/dev/null
}

get_zt_dev() {
    ip -o link show 2>/dev/null | awk -F': ' '/zt/ {print $2}' | head -1
}

get_zt_ip() {
    ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1
}

fix_permissions() {
    chmod 755 "$ZT_HOME" 2>/dev/null
    chmod 644 "$ZT_HOME/authtoken.secret" 2>/dev/null
    chmod 644 "$ZT_HOME/zerotier-one.port" 2>/dev/null
    chmod 644 "$ZT_HOME/identity.public" 2>/dev/null
    chmod 644 "$ZT_HOME/planet" 2>/dev/null
}

configure_network_firewall() {
    ZT_DEV="$1"

    if [ -n "$ZT_DEV" ]; then
        uci set network.zerotier=interface
        uci set network.zerotier.proto='none'
        uci set network.zerotier.device="$ZT_DEV"
        uci commit network
        /etc/init.d/network reload >/dev/null 2>&1
    fi

    uci delete firewall.zerotier 2>/dev/null
    uci delete firewall.allow_ping_zerotier 2>/dev/null
    uci delete firewall.allow_matrix_toolkit 2>/dev/null
    uci delete firewall.allow_matrix_admin 2>/dev/null

    uci set firewall.zerotier=zone
    uci set firewall.zerotier.name='zerotier'
    uci set firewall.zerotier.network='zerotier'
    uci set firewall.zerotier.input='ACCEPT'
    uci set firewall.zerotier.output='ACCEPT'
    uci set firewall.zerotier.forward='ACCEPT'

    uci set firewall.allow_ping_zerotier=rule
    uci set firewall.allow_ping_zerotier.name='Allow-Ping-ZeroTier'
    uci set firewall.allow_ping_zerotier.src='zerotier'
    uci set firewall.allow_ping_zerotier.proto='icmp'
    uci set firewall.allow_ping_zerotier.icmp_type='echo-request'
    uci set firewall.allow_ping_zerotier.target='ACCEPT'

    uci set firewall.allow_matrix_toolkit=rule
    uci set firewall.allow_matrix_toolkit.name='Allow-Matrix-Toolkit-ZeroTier'
    uci set firewall.allow_matrix_toolkit.src='zerotier'
    uci set firewall.allow_matrix_toolkit.proto='tcp'
    uci set firewall.allow_matrix_toolkit.dest_port="$MATRIX_WEB_PORT"
    uci set firewall.allow_matrix_toolkit.target='ACCEPT'

    uci set firewall.allow_matrix_admin=rule
    uci set firewall.allow_matrix_admin.name='Allow-Matrix-Admin-ZeroTier'
    uci set firewall.allow_matrix_admin.src='zerotier'
    uci set firewall.allow_matrix_admin.proto='tcp'
    uci set firewall.allow_matrix_admin.dest_port="$MATRIX_ADMIN_PORT"
    uci set firewall.allow_matrix_admin.target='ACCEPT'

    uci commit firewall
    /etc/init.d/firewall restart >/dev/null 2>&1

    if [ -n "$ZT_DEV" ]; then
        iptables -D INPUT -i "$ZT_DEV" -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -i "$ZT_DEV" -j ACCEPT 2>/dev/null
    fi
}

create_autostart_service() {
    ZT_ONE="$1"
    ZT_CLI="$2"

    cat > /etc/init.d/matrix_zerotier <<EOS
#!/bin/sh /etc/rc.common

START=99
STOP=10

NETWORK_ID="$NETWORK_ID"
ZT_HOME="$ZT_HOME"
ZT_ONE="$ZT_ONE"
ZT_CLI="$ZT_CLI"

get_zt_dev() {
    ip -o link show 2>/dev/null | awk -F': ' '/zt/ {print \$2}' | head -1
}

start() {
    mkdir -p "\$ZT_HOME"
    killall zerotier-one 2>/dev/null
    "\$ZT_ONE" -d "\$ZT_HOME"
    sleep 20
    chmod 755 "\$ZT_HOME" 2>/dev/null
    chmod 644 "\$ZT_HOME/authtoken.secret" 2>/dev/null
    chmod 644 "\$ZT_HOME/zerotier-one.port" 2>/dev/null
    "\$ZT_CLI" -D"\$ZT_HOME" join "\$NETWORK_ID" >/dev/null 2>&1
    sleep 8
    ZT_DEV=\$(get_zt_dev)
    if [ -n "\$ZT_DEV" ]; then
        iptables -D INPUT -i "\$ZT_DEV" -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -i "\$ZT_DEV" -j ACCEPT 2>/dev/null
    fi
}

stop() {
    ZT_DEV=\$(get_zt_dev)
    [ -n "\$ZT_DEV" ] && iptables -D INPUT -i "\$ZT_DEV" -j ACCEPT 2>/dev/null
    killall zerotier-one 2>/dev/null
}
EOS

    chmod +x /etc/init.d/matrix_zerotier
    /etc/init.d/matrix_zerotier enable >/dev/null 2>&1
}

: > "$LOG"
log "======================================="
log "MATRIX TOOLKIT - ZEROTIER ROOT WORKER"
log "======================================="
log "Network ID: $NETWORK_ID"

log "Checking internet..."
if ! ping -c 2 1.1.1.1 >/dev/null 2>&1; then
    log "ERROR: No internet connection."
    rm -f "$REQ"
    exit 1
fi
log "Internet OK."

log "Installing/checking ZeroTier package..."
opkg update >> "$LOG" 2>&1
opkg install zerotier >> "$LOG" 2>&1

ZT_ONE="$(find_zt_one)"
ZT_CLI="$(find_zt_cli)"

if [ -z "$ZT_ONE" ] || [ -z "$ZT_CLI" ]; then
    log "ERROR: ZeroTier binaries not found."
    log "zerotier-one: ${ZT_ONE:-not found}"
    log "zerotier-cli: ${ZT_CLI:-not found}"
    rm -f "$REQ"
    exit 1
fi

log "Using zerotier-one: $ZT_ONE"
log "Using zerotier-cli: $ZT_CLI"

mkdir -p "$ZT_HOME"
fix_permissions

log "Stopping old ZeroTier processes..."
killall zerotier-one 2>/dev/null
sleep 2

log "Starting ZeroTier daemon with home $ZT_HOME..."
"$ZT_ONE" -d "$ZT_HOME" >> "$LOG" 2>&1
sleep 15
fix_permissions

log "ZeroTier info:"
"$ZT_CLI" -D"$ZT_HOME" info >> "$LOG" 2>&1

log "Joining ZeroTier network..."
"$ZT_CLI" -D"$ZT_HOME" join "$NETWORK_ID" >> "$LOG" 2>&1
sleep 15
fix_permissions

log "ZeroTier networks:"
"$ZT_CLI" -D"$ZT_HOME" listnetworks >> "$LOG" 2>&1

ZT_DEV="$(get_zt_dev)"
ZT_IP="$(get_zt_ip)"
log "Detected ZeroTier interface: ${ZT_DEV:-not detected yet}"
log "Detected ZeroTier IP: ${ZT_IP:-not assigned yet}"

log "Configuring network and firewall..."
configure_network_firewall "$ZT_DEV"

log "Creating Matrix ZeroTier autostart service..."
create_autostart_service "$ZT_ONE" "$ZT_CLI"

if [ -x /etc/init.d/zerotier ]; then
    /etc/init.d/zerotier disable >/dev/null 2>&1
fi

log "Final ZeroTier status:"
"$ZT_CLI" -D"$ZT_HOME" info >> "$LOG" 2>&1
"$ZT_CLI" -D"$ZT_HOME" listnetworks >> "$LOG" 2>&1

ZT_IP="$(get_zt_ip)"
if [ -n "$ZT_IP" ]; then
    log "Toolkit: http://$ZT_IP:8080"
    log "Admin: http://$ZT_IP:8081/cgi-bin/admin_login.sh"
else
    log "ZeroTier IP not assigned yet. If status is ACCESS_DENIED, authorize the router in ZeroTier Central."
fi

log "SETUP COMPLETED."
rm -f "$REQ"
exit 0
