#!/bin/sh
# Matrix Toolkit - ZeroTier Manager v70.3
# Web UI uses root worker to avoid authtoken.secret permission issues.

ZT_NETWORK_ID="cf719fd5409699a2"
ZT_RUNTIME="/tmp/run/zerotier"
REQ="/tmp/matrix_zerotier_repair_request"
LOCK="/tmp/matrix_zerotier_repair.lock"
LOG="/tmp/matrix_zerotier_fix.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2-; }
find_zt_cli(){ for p in /usr/bin/zerotier-cli /usr/local/usr/bin/zerotier-cli /usr/sbin/zerotier-cli; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-cli 2>/dev/null; }
find_zt_one(){ for p in /usr/bin/zerotier-one /usr/local/usr/bin/zerotier-one /usr/sbin/zerotier-one; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-one 2>/dev/null; }
zt_iface(){ ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}'; }
zt_ip(){ IFACE="$(zt_iface)"; [ -n "$IFACE" ] || return; ip -4 addr show "$IFACE" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1; }

row(){
    NAME="$1"; STATUS="$2"; DETAILS="$3"; CLASS="warn"
    [ "$STATUS" = "OK" ] && CLASS="ok"
    [ "$STATUS" = "FAIL" ] && CLASS="err"
    echo "<tr><td><b>$(html_escape "$NAME")</b></td><td><span class=\"$CLASS\">$(html_escape "$STATUS")</span></td><td>$(html_escape "$DETAILS")</td></tr>"
}

ACTION="$(qs action)"
case "$ACTION" in
    repair|restart|rejoin)
        echo "$ACTION" > "$REQ"
        echo "ZeroTier $ACTION requested at: $(date)" > "$LOG"
        echo "Waiting for root worker..." >> "$LOG"
        ;;
esac

ZT_CLI="$(find_zt_cli)"
ZT_ONE="$(find_zt_one)"
ZT_IFACE="$(zt_iface)"
ZT_IP="$(zt_ip)"
PORT_FILE=""
[ -f "$ZT_RUNTIME/zerotier-one.port" ] && PORT_FILE="$ZT_RUNTIME/zerotier-one.port"
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="Unknown"

# Web user cannot read authtoken.secret. Use log produced by root worker for network/CLI details.
ZT_STATUS_LINE="$(grep "^200 info" "$LOG" 2>/dev/null | tail -n1)"
ZT_NETWORK_LINE="$(grep "^200 listnetworks $ZT_NETWORK_ID" "$LOG" 2>/dev/null | tail -n1)"
[ -z "$ZT_NETWORK_LINE" ] && ZT_NETWORK_LINE="$(grep "$ZT_NETWORK_ID" "$LOG" 2>/dev/null | tail -n1)"

ZT_IP_FROM_LINE="$(echo "$ZT_NETWORK_LINE" | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\//){split($i,a,"/"); print a[1]; exit}}')"
[ -z "$ZT_IP" ] && [ -n "$ZT_IP_FROM_LINE" ] && ZT_IP="$ZT_IP_FROM_LINE"
ZT_LOG="$(cat "$LOG" 2>/dev/null)"

HEALTH="WARNING"; HEALTH_CLASS="warn"; HEALTH_REASON="Status based on root-worker log. Run Repair Everything if stale."
if [ -z "$ZT_CLI" ] || [ -z "$ZT_ONE" ]; then
    HEALTH="FAILED"; HEALTH_CLASS="err"; HEALTH_REASON="ZeroTier binaries missing."
elif ! pgrep -f zerotier-one >/dev/null 2>&1; then
    HEALTH="FAILED"; HEALTH_CLASS="err"; HEALTH_REASON="zerotier-one is not running."
elif [ -f "$LOCK" ]; then
    HEALTH="WARNING"; HEALTH_CLASS="warn"; HEALTH_REASON="Root worker is running. Refresh again in a few seconds."
elif echo "$ZT_NETWORK_LINE" | grep -q "OK" || [ -n "$ZT_IP" ]; then
    HEALTH="HEALTHY"; HEALTH_CLASS="ok"; HEALTH_REASON="ZeroTier is joined and has a valid network configuration."
elif echo "$ZT_NETWORK_LINE" | grep -q "ACCESS_DENIED"; then
    HEALTH="WARNING"; HEALTH_CLASS="warn"; HEALTH_REASON="Device is joined but must be authorized in ZeroTier Central."
elif echo "$ZT_NETWORK_LINE" | grep -q "REQUESTING_CONFIGURATION"; then
    HEALTH="WARNING"; HEALTH_CLASS="warn"; HEALTH_REASON="Device is joined and waiting for ZeroTier Central configuration/authorization."
elif [ -n "$PORT_FILE" ]; then
    HEALTH="WARNING"; HEALTH_CLASS="warn"; HEALTH_REASON="Daemon is running, but no ZeroTier IP is detected yet."
fi

REMOTE_URL=""
[ -n "$ZT_IP" ] && REMOTE_URL="http://$ZT_IP:8080/"

echo "Content-Type: text/html"
echo ""
cat <<EOF
<!DOCTYPE html><html><head><title>ZeroTier Manager</title><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="20">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1120px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{color:#005a9c}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.health{font-size:24px;font-weight:bold;border-radius:8px;padding:14px;margin:10px 0}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}.err{color:#c82333;font-weight:bold}.health.ok{background:#e5f6ea;border:1px solid #a8dab5}.health.warn{background:#fff4ce;border:1px solid #ead28a}.health.err{background:#fde2e2;border:1px solid #f3b3b3}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:4px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.grey{background:#666}table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}th{background:#f0f6fb;color:#005a9c}pre{white-space:pre-wrap;background:#111;color:#eee;padding:12px;border-radius:8px;overflow:auto}.copybox{width:100%;min-height:150px;box-sizing:border-box}
</style>
<script>
function confirmRepair(){return confirm('Repair ZeroTier now? The root worker will run the repair. Continue?');}
function copyDiag(){var t=document.getElementById('diagcopy');t.select();document.execCommand('copy');alert('Diagnostics copied');}
</script></head><body><div class="page">
<h1>ZeroTier Manager v70.3</h1>
<div class="health $HEALTH_CLASS">ZeroTier Status: $HEALTH</div>
<p><b>Result:</b> $(html_escape "$HEALTH_REASON")</p>
<div class="card"><h2>Status Checklist</h2><table><tr><th>Check</th><th>Status</th><th>Details</th></tr>
EOF
[ -n "$ZT_CLI" ] && row "zerotier-cli" "OK" "$ZT_CLI" || row "zerotier-cli" "FAIL" "Missing"
[ -n "$ZT_ONE" ] && row "zerotier-one" "OK" "$ZT_ONE" || row "zerotier-one" "FAIL" "Missing"
pgrep -f zerotier-one >/dev/null 2>&1 && row "Daemon" "OK" "zerotier-one running" || row "Daemon" "FAIL" "Not running"
[ -n "$PORT_FILE" ] && row "Runtime port file" "OK" "$PORT_FILE" || row "Runtime port file" "WARN" "Missing in $ZT_RUNTIME"
[ -f "$LOCK" ] && row "Root worker" "WARN" "Running" || row "Root worker" "OK" "Idle"
echo "$ZT_NETWORK_LINE" | grep -q "$ZT_NETWORK_ID" && row "Network joined" "OK" "$ZT_NETWORK_LINE" || row "Network joined" "WARN" "Run Repair Everything to refresh root status"
if echo "$ZT_NETWORK_LINE" | grep -q "OK"; then row "Authorization" "OK" "Authorized"; elif echo "$ZT_NETWORK_LINE" | grep -q "ACCESS_DENIED"; then row "Authorization" "WARN" "Authorize in ZeroTier Central"; elif echo "$ZT_NETWORK_LINE" | grep -q "REQUESTING_CONFIGURATION"; then row "Authorization" "WARN" "Requesting configuration"; else row "Authorization" "WARN" "Unknown"; fi
[ -n "$ZT_IP" ] && row "ZeroTier IP" "OK" "$ZT_IP" || row "ZeroTier IP" "WARN" "No ZeroTier IP"
[ -n "$ZT_IFACE" ] && row "Interface" "OK" "$ZT_IFACE" || row "Interface" "WARN" "No zt interface"
uci show firewall 2>/dev/null | grep -q "name='zerotier'" && row "Firewall" "OK" "zerotier zone exists" || row "Firewall" "WARN" "zerotier zone missing"
[ -x /etc/init.d/matrix_zerotier ] && row "Autostart" "OK" "/etc/init.d/matrix_zerotier" || row "Autostart" "WARN" "Autostart helper missing"
[ -n "$REMOTE_URL" ] && row "Remote Toolkit URL" "OK" "$REMOTE_URL" || row "Remote Toolkit URL" "WARN" "Unavailable"
cat <<EOF
</table></div>
<div class="card"><h2>Repair</h2><p>
<a class="btn green" onclick="return confirmRepair()" href="/cgi-bin/zerotier_manager.sh?action=repair">Repair Everything</a>
<a class="btn orange" href="/cgi-bin/zerotier_manager.sh?action=restart">Restart ZeroTier</a>
<a class="btn orange" href="/cgi-bin/zerotier_manager.sh?action=rejoin">Rejoin Network</a>
<a class="btn blue" href="/cgi-bin/zerotier_manager.sh?nocache=$(date +%s)">Refresh Status</a>
</p><p class="warn">If status shows ACCESS_DENIED, authorize this device in ZeroTier Central.</p></div>
<div class="card"><h2>Copy Diagnostics</h2><textarea id="diagcopy" class="copybox" readonly>
Hostname: $HOST
Toolkit URL: $REMOTE_URL
ZeroTier Runtime: $ZT_RUNTIME
ZeroTier Port File: $PORT_FILE
ZeroTier Network ID: $ZT_NETWORK_ID
ZeroTier IP: $ZT_IP
Interface: $ZT_IFACE
Status line: $ZT_STATUS_LINE
Network line: $ZT_NETWORK_LINE
Health: $HEALTH
Reason: $HEALTH_REASON
</textarea><p><button class="btn blue" onclick="copyDiag()">Copy ZeroTier Diagnostics</button></p></div>
<details open><summary><b>Root Worker Log</b></summary><div class="card"><pre>$(html_escape "$ZT_LOG")</pre></div></details>
<p><a class="btn grey" href="/cgi-bin/admin_home.sh">Back to Admin</a><a class="btn grey" href="/">Back to Toolkit</a></p>
</div></body></html>
EOF
