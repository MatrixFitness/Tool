#!/bin/sh
# Matrix Toolkit - ZeroTier Manager v70

ZT_NETWORK_ID="cf719fd5409699a2"
LOG="/tmp/matrix_zerotier_fix.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2-; }
find_zt_cli(){ for p in /usr/bin/zerotier-cli /usr/local/usr/bin/zerotier-cli /usr/sbin/zerotier-cli; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-cli 2>/dev/null; }
find_zt_one(){ for p in /usr/bin/zerotier-one /usr/local/usr/bin/zerotier-one /usr/sbin/zerotier-one; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-one 2>/dev/null; }
zt_iface(){ ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}'; }
zt_ip(){ IFACE="$(zt_iface)"; [ -n "$IFACE" ] || return; ip -4 addr show "$IFACE" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1; }

row(){
    NAME="$1"; STATUS="$2"; DETAILS="$3"; CLASS="warn"
    [ "$STATUS" = "OK" ] && CLASS="ok"
    [ "$STATUS" = "FAIL" ] && CLASS="err"
    echo "<tr><td><b>$(html_escape "$NAME")</b></td><td><span class=\"$CLASS\">$(html_escape "$STATUS")</span></td><td>$(html_escape "$DETAILS")</td></tr>"
}

write_cli_helper(){
cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_manager.sh "$@"
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix 2>/dev/null
}

write_autostart(){
    ZT_ONE="$1"; [ -n "$ZT_ONE" ] || return 1
cat > /etc/init.d/matrix_zerotier <<EOF
#!/bin/sh /etc/rc.common
START=99
STOP=10
start() {
    if ! pgrep -f zerotier-one >/dev/null 2>&1; then
        $ZT_ONE -d >/dev/null 2>&1
    fi
}
stop() {
    killall zerotier-one >/dev/null 2>&1
}
EOF
chmod +x /etc/init.d/matrix_zerotier
/etc/init.d/matrix_zerotier enable >/dev/null 2>&1
}

ensure_firewall(){
    if ! uci show firewall 2>/dev/null | grep -q "name='zerotier'"; then
        uci add firewall zone >/dev/null
        uci set firewall.@zone[-1].name='zerotier'
        uci set firewall.@zone[-1].input='ACCEPT'
        uci set firewall.@zone[-1].output='ACCEPT'
        uci set firewall.@zone[-1].forward='ACCEPT'
        uci set firewall.@zone[-1].masq='1'
        uci set firewall.@zone[-1].mtu_fix='1'
        uci add_list firewall.@zone[-1].network='zerotier'
        uci add firewall forwarding >/dev/null
        uci set firewall.@forwarding[-1].src='zerotier'
        uci set firewall.@forwarding[-1].dest='lan'
        uci add firewall forwarding >/dev/null
        uci set firewall.@forwarding[-1].src='lan'
        uci set firewall.@forwarding[-1].dest='zerotier'
        uci commit firewall
    fi
    /etc/init.d/firewall reload >/dev/null 2>&1
}

ensure_network_interface(){
    IFACE="$(zt_iface)"; [ -n "$IFACE" ] || return 1
    uci set network.zerotier='interface'
    uci set network.zerotier.proto='none'
    uci set network.zerotier.device="$IFACE"
    uci commit network
    /etc/init.d/network reload >/dev/null 2>&1
}

repair_all(){
    : > "$LOG"
    echo "ZeroTier Manager repair started at $(date)" >> "$LOG"
    ZT_CLI="$(find_zt_cli)"; ZT_ONE="$(find_zt_one)"
    if [ -z "$ZT_CLI" ] || [ -z "$ZT_ONE" ]; then
        if command -v opkg >/dev/null 2>&1; then
            opkg update >> "$LOG" 2>&1
            opkg install zerotier >> "$LOG" 2>&1
        fi
    fi
    ZT_CLI="$(find_zt_cli)"; ZT_ONE="$(find_zt_one)"
    if [ -n "$ZT_ONE" ] && ! pgrep -f zerotier-one >/dev/null 2>&1; then "$ZT_ONE" -d >> "$LOG" 2>&1; sleep 3; fi
    [ -n "$ZT_ONE" ] && write_autostart "$ZT_ONE" >> "$LOG" 2>&1
    write_cli_helper >> "$LOG" 2>&1
    if [ -n "$ZT_CLI" ]; then
        "$ZT_CLI" join "$ZT_NETWORK_ID" >> "$LOG" 2>&1
        sleep 2
        "$ZT_CLI" status >> "$LOG" 2>&1
        "$ZT_CLI" listnetworks >> "$LOG" 2>&1
    fi
    ensure_network_interface >> "$LOG" 2>&1
    ensure_firewall >> "$LOG" 2>&1
    echo "Repair finished at $(date)" >> "$LOG"
}

ACTION="$(qs action)"
case "$ACTION" in
    repair) repair_all ;;
    restart) killall zerotier-one >/dev/null 2>&1; sleep 2; ZT_ONE="$(find_zt_one)"; [ -n "$ZT_ONE" ] && "$ZT_ONE" -d >/dev/null 2>&1 ;;
    rejoin) ZT_CLI="$(find_zt_cli)"; [ -n "$ZT_CLI" ] && "$ZT_CLI" join "$ZT_NETWORK_ID" >> "$LOG" 2>&1 ;;
esac

ZT_CLI="$(find_zt_cli)"; ZT_ONE="$(find_zt_one)"
ZT_STATUS="$([ -n "$ZT_CLI" ] && "$ZT_CLI" status 2>&1)"
ZT_INFO="$([ -n "$ZT_CLI" ] && "$ZT_CLI" info 2>&1)"
ZT_NETWORKS="$([ -n "$ZT_CLI" ] && "$ZT_CLI" listnetworks 2>&1)"
ZT_LINE="$(echo "$ZT_NETWORKS" | grep "$ZT_NETWORK_ID" | head -n1)"
ZT_IP="$(zt_ip)"; ZT_IFACE="$(zt_iface)"
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="Unknown"

HEALTH="HEALTHY"; HEALTH_CLASS="ok"; HEALTH_REASON="ZeroTier appears operational."
[ -z "$ZT_CLI" ] && HEALTH="FAILED" && HEALTH_CLASS="err" && HEALTH_REASON="zerotier-cli missing."
[ -z "$ZT_ONE" ] && HEALTH="FAILED" && HEALTH_CLASS="err" && HEALTH_REASON="zerotier-one missing."
if ! pgrep -f zerotier-one >/dev/null 2>&1; then HEALTH="FAILED"; HEALTH_CLASS="err"; HEALTH_REASON="zerotier-one is not running."; fi
if echo "$ZT_LINE" | grep -q "ACCESS_DENIED"; then HEALTH="WARNING"; HEALTH_CLASS="warn"; HEALTH_REASON="Device joined but must be authorized in ZeroTier Central."; fi
if [ -z "$ZT_IP" ] && [ "$HEALTH" = "HEALTHY" ]; then HEALTH="WARNING"; HEALTH_CLASS="warn"; HEALTH_REASON="No ZeroTier IP detected yet."; fi
REMOTE_URL=""; [ -n "$ZT_IP" ] && REMOTE_URL="http://$ZT_IP:8080/"

echo "Content-Type: text/html"
echo ""
cat <<EOF
<!DOCTYPE html><html><head><title>ZeroTier Manager</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1120px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{color:#005a9c}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.health{font-size:24px;font-weight:bold;border-radius:8px;padding:14px;margin:10px 0}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}.err{color:#c82333;font-weight:bold}.health.ok{background:#e5f6ea;border:1px solid #a8dab5}.health.warn{background:#fff4ce;border:1px solid #ead28a}.health.err{background:#fde2e2;border:1px solid #f3b3b3}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:4px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.grey{background:#666}table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}th{background:#f0f6fb;color:#005a9c}pre{white-space:pre-wrap;background:#111;color:#eee;padding:12px;border-radius:8px;overflow:auto}.copybox{width:100%;min-height:130px;box-sizing:border-box}
</style>
<script>
function confirmRepair(){return confirm('Repair ZeroTier now? This may start services, join the network, and update firewall/interface settings. Continue?');}
function copyDiag(){var t=document.getElementById('diagcopy');t.select();document.execCommand('copy');alert('Diagnostics copied');}
</script></head><body><div class="page">
<h1>ZeroTier Manager</h1>
<div class="health $HEALTH_CLASS">ZeroTier Status: $HEALTH</div>
<p><b>Result:</b> $(html_escape "$HEALTH_REASON")</p>
<div class="card"><h2>Status Checklist</h2><table><tr><th>Check</th><th>Status</th><th>Details</th></tr>
EOF
[ -n "$ZT_CLI" ] && row "zerotier-cli" "OK" "$ZT_CLI" || row "zerotier-cli" "FAIL" "Missing"
[ -n "$ZT_ONE" ] && row "zerotier-one" "OK" "$ZT_ONE" || row "zerotier-one" "FAIL" "Missing"
pgrep -f zerotier-one >/dev/null 2>&1 && row "Daemon" "OK" "zerotier-one running" || row "Daemon" "FAIL" "Not running"
echo "$ZT_LINE" | grep -q "$ZT_NETWORK_ID" && row "Network joined" "OK" "$ZT_LINE" || row "Network joined" "WARN" "Network not visible"
if echo "$ZT_LINE" | grep -q "ACCESS_DENIED"; then row "Authorization" "WARN" "Authorize in ZeroTier Central"; elif echo "$ZT_LINE" | grep -q "OK"; then row "Authorization" "OK" "Authorized"; else row "Authorization" "WARN" "Unknown"; fi
[ -n "$ZT_IP" ] && row "ZeroTier IP" "OK" "$ZT_IP" || row "ZeroTier IP" "WARN" "No ZeroTier IP"
[ -n "$ZT_IFACE" ] && row "Interface" "OK" "$ZT_IFACE" || row "Interface" "WARN" "No zt interface"
uci show firewall 2>/dev/null | grep -q "name='zerotier'" && row "Firewall" "OK" "zerotier zone exists" || row "Firewall" "WARN" "zerotier zone missing"
[ -x /etc/init.d/matrix_zerotier ] && row "Autostart" "OK" "/etc/init.d/matrix_zerotier" || row "Autostart" "WARN" "Autostart helper missing"
[ -n "$REMOTE_URL" ] && row "Remote Toolkit URL" "OK" "$REMOTE_URL" || row "Remote Toolkit URL" "WARN" "Unavailable"
cat <<EOF
</table></div>
<div class="card"><h2>Repair</h2><p>
<a class="btn green" onclick="return confirmRepair()" href="/cgi-bin/zerotier_manager.sh?action=repair">Repair Everything</a>
<a class="btn orange" href="/cgi-bin/zerotier_manager.sh?action=restart">Restart ZeroTier</a>
<a class="btn orange" href="/cgi-bin/zerotier_manager.sh?action=rejoin">Rejoin Network</a>
<a class="btn blue" href="/cgi-bin/zerotier_manager.sh?nocache=$(date +%s)">Refresh Status</a>
</p><p class="warn">If status shows ACCESS_DENIED, authorize this device in ZeroTier Central.</p></div>
<div class="card"><h2>Copy Diagnostics</h2><textarea id="diagcopy" class="copybox" readonly>
Hostname: $HOST
Toolkit URL: $REMOTE_URL
ZeroTier Network ID: $ZT_NETWORK_ID
ZeroTier IP: $ZT_IP
Interface: $ZT_IFACE
Status: $ZT_STATUS
Info: $ZT_INFO
Network: $ZT_LINE
Health: $HEALTH
Reason: $HEALTH_REASON
</textarea><p><button class="btn blue" onclick="copyDiag()">Copy ZeroTier Diagnostics</button></p></div>
<details><summary><b>Advanced Diagnostics</b></summary><div class="card">
<h2>zerotier-cli status</h2><pre>$(html_escape "$ZT_STATUS")</pre>
<h2>zerotier-cli info</h2><pre>$(html_escape "$ZT_INFO")</pre>
<h2>zerotier-cli listnetworks</h2><pre>$(html_escape "$ZT_NETWORKS")</pre>
<h2>Repair log</h2><pre>$(html_escape "$(cat "$LOG" 2>/dev/null)")</pre>
</div></details>
<p><a class="btn grey" href="/cgi-bin/admin_home.sh">Back to Admin</a><a class="btn grey" href="/">Back to Toolkit</a></p>
</div></body></html>
EOF
