#!/bin/sh
SOURCE_DIR="$(dirname "$0")"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
WEB="/usr/local/matrix/web/cgi-bin"
ZT_HOME="/usr/local/matrix/zerotier"
mkdir -p "$ADMINWEB" "$WEB" "$ZT_HOME"
chmod 700 "$ZT_HOME" 2>/dev/null
for f in zerotier_manager.sh zerotier_root_worker.sh zerotier_status_worker.sh; do [ -f "$SOURCE_DIR/cgi-bin_admin/$f" ] && cp -f "$SOURCE_DIR/cgi-bin_admin/$f" "$ADMINWEB/$f" && chmod +x "$ADMINWEB/$f"; done
[ -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" ] && cp -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" "$WEB/zerotier_manager.sh" && chmod +x "$WEB/zerotier_manager.sh"
[ -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" ] && cp -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh" && chmod +x "$WEB/zerotier_fix.sh"
cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
echo repair > /tmp/matrix_zerotier_repair_request
/usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh
cat /tmp/matrix_zerotier_fix.log
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix
cat > /usr/local/bin/matrix-zerotier-status <<'EOF'
#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh
cat /tmp/matrix_zerotier_status.cache
EOF
chmod +x /usr/local/bin/matrix-zerotier-status
TMP="/tmp/matrix_cron_zt.$$"; TMP2="/tmp/matrix_cron_zt_new.$$"; crontab -l > "$TMP" 2>/dev/null || : > "$TMP"; grep -v "zerotier_root_worker.sh" "$TMP" 2>/dev/null | grep -v "zerotier_status_worker.sh" > "$TMP2" 2>/dev/null || : > "$TMP2"; echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh" >> "$TMP2"; echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh" >> "$TMP2"; crontab "$TMP2"; rm -f "$TMP" "$TMP2"
/etc/init.d/zerotier stop >/dev/null 2>&1
/etc/init.d/zerotier disable >/dev/null 2>&1
echo repair > /tmp/matrix_zerotier_repair_request
/usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh >/dev/null 2>&1 || true
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh >/dev/null 2>&1 || true
echo "Matrix Toolkit v72.1 Final ZeroTier Repair installed."
