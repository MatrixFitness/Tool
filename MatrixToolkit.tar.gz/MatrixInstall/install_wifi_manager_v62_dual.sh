#!/bin/sh
# Matrix WiFi Manager v62 Dual Profiles installer

SRC="$(dirname "$0")"
WEB="/usr/local/matrix/web/cgi-bin"

mkdir -p "$WEB" /usr/local/matrix

for f in wifi_manager.sh wifi_profile_edit.sh wifi_profile_save.sh wifi_profile.sh wifi_profiles_restore_previous.sh wifi_profiles_reset.sh; do
    if [ -f "$SRC/cgi-bin/$f" ]; then
        cp -f "$SRC/cgi-bin/$f" "$WEB/$f"
        chmod +x "$WEB/$f"
    fi
done

if [ -f "$SRC/matrix_wifi_profiles.default" ]; then
    cp -f "$SRC/matrix_wifi_profiles.default" /usr/local/matrix/matrix_wifi_profiles.default
fi

if [ ! -f /usr/local/matrix/matrix_wifi_profiles.conf ]; then
    cp -f /usr/local/matrix/matrix_wifi_profiles.default /usr/local/matrix/matrix_wifi_profiles.conf 2>/dev/null
fi

[ -f /usr/local/matrix/matrix_wifi_profiles.previous ] || cat /usr/local/matrix/matrix_wifi_profiles.conf > /usr/local/matrix/matrix_wifi_profiles.previous 2>/dev/null

chmod 666 /usr/local/matrix/matrix_wifi_profiles.conf /usr/local/matrix/matrix_wifi_profiles.default /usr/local/matrix/matrix_wifi_profiles.previous 2>/dev/null

# Trigger migration once by opening manager locally if wget exists
if command -v wget >/dev/null 2>&1; then
    wget -q -O /dev/null http://127.0.0.1:8080/cgi-bin/wifi_manager.sh 2>/dev/null || true
fi

echo "Matrix WiFi Manager v62 Dual Profiles installed."
