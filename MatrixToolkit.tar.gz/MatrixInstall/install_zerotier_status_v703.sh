#!/bin/sh
# Matrix Toolkit v70.3 ZeroTier Manager status parser fix installer

SOURCE_DIR="$(dirname "$0")"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
WEB="/usr/local/matrix/web/cgi-bin"
mkdir -p "$ADMINWEB" "$WEB"

if [ -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" "$ADMINWEB/zerotier_manager.sh"
    chmod +x "$ADMINWEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin_admin/zerotier_root_worker.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin_admin/zerotier_root_worker.sh" "$ADMINWEB/zerotier_root_worker.sh"
    chmod +x "$ADMINWEB/zerotier_root_worker.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" "$WEB/zerotier_manager.sh"
    chmod +x "$WEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh"
    chmod +x "$WEB/zerotier_fix.sh"
fi

TMPCRON="/tmp/matrix_cron_zt.$$"
crontab -l 2>/dev/null | grep -v "zerotier_root_worker.sh" > "$TMPCRON"
echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh" >> "$TMPCRON"
crontab "$TMPCRON"
rm -f "$TMPCRON"

echo "Matrix Toolkit v70.3 ZeroTier status parser fix installed."
