#!/bin/sh
# Install Matrix WiFi Manager v67

SRC="$(dirname "$0")"
WEB="/usr/local/matrix/web/cgi-bin"
MATRIX="/usr/local/matrix"
mkdir -p "$WEB" "$MATRIX"

for f in wifi_lib.sh wifi_manager.sh wifi_profile.sh wifi_profile_edit.sh wifi_profile_save.sh; do
    if [ -f "$SRC/cgi-bin/$f" ]; then
        cp -f "$SRC/cgi-bin/$f" "$WEB/$f"
        chmod +x "$WEB/$f"
    fi
done

if [ -f "$SRC/matrix_wifi_system_profiles.default" ]; then
    cp -f "$SRC/matrix_wifi_system_profiles.default" "$MATRIX/matrix_wifi_system_profiles.default"
    cp -f "$SRC/matrix_wifi_system_profiles.default" "$MATRIX/matrix_wifi_system_profiles.conf"
elif [ -f "$SRC/matrix_wifi_profiles.default" ]; then
    cp -f "$SRC/matrix_wifi_profiles.default" "$MATRIX/matrix_wifi_system_profiles.default"
    cp -f "$SRC/matrix_wifi_profiles.default" "$MATRIX/matrix_wifi_system_profiles.conf"
fi

[ -f "$MATRIX/matrix_wifi_user_profiles.conf" ] || : > "$MATRIX/matrix_wifi_user_profiles.conf"
chmod 666 "$MATRIX"/matrix_wifi_*profiles*.conf "$MATRIX"/matrix_wifi_*profiles*.default 2>/dev/null
echo "Matrix WiFi Manager v67 installed."
