#!/bin/sh
# Matrix Toolkit v70 component installer

SOURCE_DIR="$(dirname "$0")"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
WEB="/usr/local/matrix/web/cgi-bin"
MATRIX="/usr/local/matrix"

mkdir -p "$ADMINWEB" "$WEB" "$MATRIX"

# Admin home and ZeroTier Manager
if [ -f "$SOURCE_DIR/cgi-bin_admin/admin_home.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin_admin/admin_home.sh" "$ADMINWEB/admin_home.sh"
    chmod +x "$ADMINWEB/admin_home.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" "$ADMINWEB/zerotier_manager.sh"
    chmod +x "$ADMINWEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" "$WEB/zerotier_manager.sh"
    chmod +x "$WEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh"
    chmod +x "$WEB/zerotier_fix.sh"
fi

cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_manager.sh "$@"
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix

echo "Matrix Toolkit v70 components installed."
