#!/bin/sh
SOURCE_DIR="$(dirname "$0")"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
WEB="/usr/local/matrix/web/cgi-bin"
mkdir -p "$ADMINWEB" "$WEB"
for f in zerotier_manager.sh zerotier_root_worker.sh zerotier_status_worker.sh; do
    [ -f "$SOURCE_DIR/cgi-bin_admin/$f" ] && cp -f "$SOURCE_DIR/cgi-bin_admin/$f" "$ADMINWEB/$f" && chmod +x "$ADMINWEB/$f"
done
[ -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" ] && cp -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" "$WEB/zerotier_manager.sh" && chmod +x "$WEB/zerotier_manager.sh"
[ -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" ] && cp -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh" && chmod +x "$WEB/zerotier_fix.sh"
cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
echo repair > /tmp/matrix_zerotier_repair_request
/usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh
cat /tmp/matrix_zerotier_fix.log
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix
cat > /usr/local/bin/matrix-zerotier-status <<'EOF'
#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh
cat /tmp/matrix_zerotier_status.cache
EOF
chmod +x /usr/local/bin/matrix-zerotier-status
TMP="/tmp/matrix_cron_zt.$$"
crontab -l 2>/dev/null | grep -v "zerotier_root_worker.sh" | grep -v "zerotier_status_worker.sh" > "$TMP"
echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh" >> "$TMP"
echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh" >> "$TMP"
crontab "$TMP"; rm -f "$TMP"
ADMIN_HOME="$ADMINWEB/admin_home.sh"
if [ -f "$ADMIN_HOME" ] && ! grep -q "zerotier_manager.sh" "$ADMIN_HOME"; then
    sed -i "/zerotier_setup.sh/a\\        <button class=\"blue\" onclick=\"window.location='/cgi-bin/zerotier_manager.sh'\">ZeroTier Manager</button>" "$ADMIN_HOME"
    chmod +x "$ADMIN_HOME"
fi
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh >/dev/null 2>&1 || true
echo "Matrix Toolkit v71 ZeroTier Live Status installed."
