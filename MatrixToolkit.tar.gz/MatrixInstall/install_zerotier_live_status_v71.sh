#!/bin/sh
SOURCE_DIR="$(dirname "$0")"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
WEB="/usr/local/matrix/web/cgi-bin"
mkdir -p "$ADMINWEB" "$WEB"
for f in zerotier_manager.sh zerotier_root_worker.sh zerotier_status_worker.sh; do
    [ -f "$SOURCE_DIR/cgi-bin_admin/$f" ] && cp -f "$SOURCE_DIR/cgi-bin_admin/$f" "$ADMINWEB/$f" && chmod +x "$ADMINWEB/$f"
done
[ -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" ] && cp -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" "$WEB/zerotier_manager.sh" && chmod +x "$WEB/zerotier_manager.sh"
[ -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" ] && cp -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh" && chmod +x "$WEB/zerotier_fix.sh"
cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
echo repair > /tmp/matrix_zerotier_repair_request
/usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh
cat /tmp/matrix_zerotier_fix.log
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix
cat > /usr/local/bin/matrix-zerotier-status <<'EOF'
#!/bin/sh
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh
cat /tmp/matrix_zerotier_status.cache
EOF
chmod +x /usr/local/bin/matrix-zerotier-status
TMP="/tmp/matrix_cron_zt.$$"
TMP2="/tmp/matrix_cron_zt_new.$$"

# Read existing crontab safely. Some Teltonika/OpenWrt systems return an
# error when no crontab exists yet, so do not let that stop installation.
crontab -l > "$TMP" 2>/dev/null || : > "$TMP"

# Remove old ZeroTier worker lines before adding the current ones.
grep -v "zerotier_root_worker.sh" "$TMP" 2>/dev/null | grep -v "zerotier_status_worker.sh" > "$TMP2" 2>/dev/null || : > "$TMP2"

echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh" >> "$TMP2"
echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh" >> "$TMP2"

crontab "$TMP2"
rm -f "$TMP" "$TMP2"

# Verify cron installation.
if crontab -l 2>/dev/null | grep -q "zerotier_root_worker.sh" && crontab -l 2>/dev/null | grep -q "zerotier_status_worker.sh"; then
    echo "OK: ZeroTier cron workers installed."
else
    echo "WARNING: ZeroTier cron workers could not be verified."
fi

ADMIN_HOME="$ADMINWEB/admin_home.sh"
if [ -f "$ADMIN_HOME" ] && ! grep -q "zerotier_manager.sh" "$ADMIN_HOME"; then
    sed -i "/zerotier_setup.sh/a\\        <button class=\"blue\" onclick=\"window.location='/cgi-bin/zerotier_manager.sh'\">ZeroTier Manager</button>" "$ADMIN_HOME"
    chmod +x "$ADMIN_HOME"
fi
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh >/dev/null 2>&1 || true
# Immediate live status cache refresh v71.2
/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh >/dev/null 2>&1 || true

echo "Matrix Toolkit v71.2 ZeroTier Live Status installed."
