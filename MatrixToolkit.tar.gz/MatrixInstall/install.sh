#!/bin/sh

# Matrix Toolkit installer for Teltonika RUT routers
# Installs files into persistent storage and configures a permanent uhttpd listener on port 8080.

set -u

# Always run from script directory
cd "$(dirname "$0")" || exit 1

MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
ADMIN_DIR="$WEB_DIR/admin"
CGI_DIR="$WEB_DIR/cgi-bin"
BIN_DIR="/usr/local/bin"

configure_uhttpd_matrix() {
    # Remove old/bad Matrix path if it exists from previous testing
    uci set uhttpd.matrix='uhttpd'
    uci delete uhttpd.matrix.listen_http 2>/dev/null
    uci add_list uhttpd.matrix.listen_http='0.0.0.0:8080'
    uci add_list uhttpd.matrix.listen_http='[::]:8080'
    uci set uhttpd.matrix.home="$WEB_DIR"
    uci set uhttpd.matrix.index_page='index.html'
    uci set uhttpd.matrix.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix.script_timeout='600'
    uci set uhttpd.matrix.network_timeout='30'
    uci set uhttpd.matrix.http_keepalive='0'
    uci set uhttpd.matrix.tcp_keepalive='5'
    uci set uhttpd.matrix.no_dirlists='1'
    uci commit uhttpd
}

fix_admin_links() {
    # Make admin buttons use the explicit file path because /admin/ can return Not Found on some uhttpd builds.
    if [ -f "$WEB_DIR/index.html" ]; then
        sed -i "s#window.location='/admin/'#window.location='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
        sed -i 's#href="/admin/"#href="/admin/index.html"#g' "$WEB_DIR/index.html" 2>/dev/null
        sed -i "s#href='/admin/'#href='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
    fi
    if [ -f "$ADMIN_DIR/index.html" ]; then
        sed -i "s#window.location='/admin/'#window.location='/admin/index.html'#g" "$ADMIN_DIR/index.html" 2>/dev/null
        sed -i 's#href="/admin/"#href="/admin/index.html"#g' "$ADMIN_DIR/index.html" 2>/dev/null
        sed -i "s#href='/admin/'#href='/admin/index.html'#g" "$ADMIN_DIR/index.html" 2>/dev/null
    fi
}

echo ""
echo "====================================="
echo "Installing Matrix Toolkit"
echo "====================================="
echo ""

# Create folders in persistent storage
mkdir -p "$MATRIX_DIR" "$WEB_DIR" "$ADMIN_DIR" "$CGI_DIR" "$BIN_DIR"

# Install web files
if [ -d web ]; then
    cp -f web/* "$WEB_DIR/"
else
    echo "ERROR: web folder not found"
    exit 1
fi

if [ -f web_admin/index.html ]; then
    cp -f web_admin/index.html "$ADMIN_DIR/index.html"
else
    echo "WARNING: web_admin/index.html not found"
fi

# Install CGI scripts
if [ -d cgi-bin ]; then
    cp -f cgi-bin/*.sh "$CGI_DIR/" 2>/dev/null
fi

if [ -d cgi-bin_admin ]; then
    for f in cgi-bin_admin/*.sh; do
        [ -f "$f" ] || continue
        case "$(basename "$f")" in
            about.sh)
                # Keep the main about.sh if both folders contain about.sh
                [ -f "$CGI_DIR/about.sh" ] && continue
                ;;
        esac
        cp -f "$f" "$CGI_DIR/"
    done
fi

chmod +x "$CGI_DIR"/*.sh 2>/dev/null

# Install version / settings files
[ -f version.txt ] && cp -f version.txt "$MATRIX_DIR/version.txt"
[ -f clubname.txt ] && cp -f clubname.txt "$MATRIX_DIR/clubname.txt"
[ -f admin_password.txt ] && cp -f admin_password.txt "$MATRIX_DIR/admin_password.txt"

# Fallback version file
if [ ! -f "$MATRIX_DIR/version.txt" ]; then
    cat > "$MATRIX_DIR/version.txt" <<'VERSIONEOF'
Version=Unknown
Build=Unknown
Release=Unknown
Changes=Unknown
GitHub=https://github.com/MatrixFitness/Tool
Author=Unknown
Email=
Company=Matrix Fitness
Message=Matrix Toolkit
VERSIONEOF
fi

fix_admin_links

# Matrix CLI commands
ln -sf "$CGI_DIR/update_github.sh" "$BIN_DIR/matrix-update"
ln -sf "$CGI_DIR/matrix_full_test.sh" "$BIN_DIR/matrix-test"
ln -sf "$CGI_DIR/certification_report.sh" "$BIN_DIR/matrix-report"

cat > "$BIN_DIR/matrix-version" <<'EOF_VERSION'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF_VERSION
chmod +x "$BIN_DIR/matrix-version"

# Permanent uhttpd config for Matrix Toolkit on port 8080
configure_uhttpd_matrix

# Restart, do not kill all uhttpd manually
/etc/init.d/uhttpd restart >/dev/null 2>&1

VERSION="$(cat "$MATRIX_DIR/version.txt" 2>/dev/null)"

 echo ""
echo "====================================="
echo "Matrix Toolkit Installed"
echo ""
echo "Version : $VERSION"
echo "Toolkit : http://192.168.1.1:8080/index.html"
echo "Admin   : http://192.168.1.1:8080/admin/index.html"
echo "====================================="
echo ""
