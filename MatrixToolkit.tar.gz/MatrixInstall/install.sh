#!/bin/sh

echo ""
echo "====================================="
echo "Installing Matrix Toolkit"
echo "====================================="
echo ""

mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/admin
mkdir -p /usr/local/matrix/web/cgi-bin

cp -f web/index.html \
      /usr/local/matrix/web/index.html

cp -f web_admin/index.html \
      /usr/local/matrix/web/admin/index.html

cp -f cgi-bin/*.sh \
      /usr/local/matrix/web/cgi-bin/

cp -f cgi-bin_admin/*.sh \
      /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

cp -f version.txt \
      /usr/local/matrix/version.txt

killall uhttpd 2>/dev/null

uhttpd \
-h /usr/local/matrix/web \
-p 8080 \
-x /cgi-bin \
-i .sh=/bin/sh &

VERSION=$(cat /usr/local/matrix/version.txt)

echo ""
echo "====================================="
echo "Matrix Toolkit Installed"
echo ""
echo "Version : $VERSION"
echo "Toolkit : http://192.168.1.1:8080"
echo "Admin   : http://192.168.1.1:8080/admin/"
echo "====================================="