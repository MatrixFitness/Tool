#!/bin/sh

# Matrix Toolkit installer for Teltonika RUT routers
# 8080 = normal Toolkit
# 8081 = protected Matrix Admin

set -u
cd "$(dirname "$0")" || exit 1

MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
ADMIN_WEB_DIR="$MATRIX_DIR/adminweb"
CGI_DIR="$WEB_DIR/cgi-bin"
ADMIN_CGI_DIR="$ADMIN_WEB_DIR/cgi-bin"
BIN_DIR="/usr/local/bin"

get_matrix_admin_password() {
    PASS="$(uci -q get uhttpd.matrix_admin_web.password 2>/dev/null)"
    [ -n "$PASS" ] || PASS='Matrix2025'
    echo "$PASS"
}

configure_uhttpd_matrix() {
    uci set uhttpd.matrix='uhttpd'
    uci delete uhttpd.matrix.listen_http 2>/dev/null
    uci add_list uhttpd.matrix.listen_http='0.0.0.0:8080'
    uci add_list uhttpd.matrix.listen_http='[::]:8080'
    uci set uhttpd.matrix.home="$WEB_DIR"
    uci set uhttpd.matrix.index_page='index.html'
    uci set uhttpd.matrix.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix.script_timeout='600'
    uci set uhttpd.matrix.network_timeout='30'
    uci set uhttpd.matrix.http_keepalive='0'
    uci set uhttpd.matrix.tcp_keepalive='5'
    uci set uhttpd.matrix.no_dirlists='1'
    uci set uhttpd.matrix.enable_basic_auth='0'
    uci commit uhttpd
}

configure_uhttpd_admin_8081() {
    ADMIN_PASS="$(get_matrix_admin_password)"

    uci set uhttpd.matrix_admin_web='uhttpd'
    uci delete uhttpd.matrix_admin_web.listen_http 2>/dev/null
    uci add_list uhttpd.matrix_admin_web.listen_http='0.0.0.0:8081'
    uci add_list uhttpd.matrix_admin_web.listen_http='[::]:8081'
    uci set uhttpd.matrix_admin_web.home="$ADMIN_WEB_DIR"
    uci set uhttpd.matrix_admin_web.index_page='index.html'
    uci set uhttpd.matrix_admin_web.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix_admin_web.script_timeout='1200'
    uci set uhttpd.matrix_admin_web.network_timeout='120'
    uci set uhttpd.matrix_admin_web.http_keepalive='0'
    uci set uhttpd.matrix_admin_web.tcp_keepalive='5'
    uci set uhttpd.matrix_admin_web.no_dirlists='1'

    # Teltonika uhttpd basic-auth on this dedicated admin listener.
    uci set uhttpd.matrix_admin_web.enable_basic_auth='1'
    uci set uhttpd.matrix_admin_web.realm='Matrix Toolkit Admin'
    uci set uhttpd.matrix_admin_web.username='admin'
    uci set uhttpd.matrix_admin_web.password="$ADMIN_PASS"

    # Remove old prefix-auth sections from the failed 8080 method.
    uci delete uhttpd.matrix_admin 2>/dev/null
    uci delete uhttpd.matrix_admin_update 2>/dev/null
    uci delete uhttpd.matrix_admin_password 2>/dev/null
    uci delete uhttpd.matrix_admin_usb_update 2>/dev/null
    uci delete uhttpd.matrix_admin_zerotier 2>/dev/null
    uci delete uhttpd.matrix_admin_router_backup 2>/dev/null
    uci delete uhttpd.matrix_admin_toolkit_backup 2>/dev/null
    uci delete uhttpd.matrix_admin_health 2>/dev/null

    uci commit uhttpd
}

remove_old_password_files() {
    rm -f "$MATRIX_DIR/admin_password.txt" \
          "$CGI_DIR/get_admin_password.sh" \
          "$CGI_DIR/set_admin_password.sh" \
          "$ADMIN_CGI_DIR/get_admin_password.sh" \
          "$ADMIN_CGI_DIR/set_admin_password.sh" 2>/dev/null
}

create_8080_admin_redirect() {
    mkdir -p "$WEB_DIR/admin"
    cat > "$WEB_DIR/admin/index.html" <<'HTMLEOF'
<!DOCTYPE html>
<html>
<head>
<title>Matrix Admin moved</title>
<meta http-equiv="refresh" content="0;url=//HOST_PLACEHOLDER:8081/index.html">
<script>
(function(){ window.location.href = window.location.protocol + '//' + window.location.hostname + ':8081/index.html'; })();
</script>
</head>
<body style="font-family:Arial;margin:30px;">
<h2>Matrix Admin moved</h2>
<p>Admin is now on the protected port 8081.</p>
<p><a id="adminLink" href="#">Open Matrix Admin</a></p>
<script>
document.getElementById('adminLink').href = window.location.protocol + '//' + window.location.hostname + ':8081/index.html';
</script>
</body>
</html>
HTMLEOF
    sed -i 's#//HOST_PLACEHOLDER:8081#index.html#g' "$WEB_DIR/admin/index.html" 2>/dev/null
}

fix_links() {
    if [ -f "$WEB_DIR/index.html" ]; then
        sed -i "s#window.location='/admin/'#window.location='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
        sed -i 's#href="/admin/"#href="/admin/index.html"#g' "$WEB_DIR/index.html" 2>/dev/null
        sed -i "s#href='/admin/'#href='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
    fi
}

copy_cgi_to_admin() {
    mkdir -p "$ADMIN_CGI_DIR"
    cp -f "$CGI_DIR"/*.sh "$ADMIN_CGI_DIR/" 2>/dev/null
    chmod +x "$ADMIN_CGI_DIR"/*.sh 2>/dev/null
}

echo ""
echo "====================================="
echo "Installing Matrix Toolkit"
echo "====================================="
echo ""

mkdir -p "$MATRIX_DIR" "$WEB_DIR" "$ADMIN_WEB_DIR" "$CGI_DIR" "$ADMIN_CGI_DIR" "$BIN_DIR"

if [ -d web ]; then
    cp -f web/* "$WEB_DIR/"
else
    echo "ERROR: web folder not found"
    exit 1
fi

if [ -f web_admin/index.html ]; then
    cp -f web_admin/index.html "$ADMIN_WEB_DIR/index.html"
else
    echo "WARNING: web_admin/index.html not found"
fi

if [ -d cgi-bin ]; then
    cp -f cgi-bin/*.sh "$CGI_DIR/" 2>/dev/null
fi

if [ -d cgi-bin_admin ]; then
    for f in cgi-bin_admin/*.sh; do
        [ -f "$f" ] || continue
        case "$(basename "$f")" in
            about.sh)
                [ -f "$CGI_DIR/about.sh" ] && continue
                ;;
        esac
        cp -f "$f" "$CGI_DIR/"
    done
fi

chmod +x "$CGI_DIR"/*.sh 2>/dev/null
copy_cgi_to_admin

[ -f version.txt ] && cp -f version.txt "$MATRIX_DIR/version.txt"
[ -f clubname.txt ] && cp -f clubname.txt "$MATRIX_DIR/clubname.txt"

if [ ! -f "$MATRIX_DIR/version.txt" ]; then
    cat > "$MATRIX_DIR/version.txt" <<'VERSIONEOF'
Version=Unknown
Build=Unknown
Release=Unknown
Changes=Unknown
GitHub=https://github.com/MatrixFitness/Tool
Author=Unknown
Email=
Company=Matrix Fitness
Message=Matrix Toolkit
VERSIONEOF
fi

fix_links
create_8080_admin_redirect
remove_old_password_files

ln -sf "$CGI_DIR/update_github.sh" "$BIN_DIR/matrix-update"
ln -sf "$CGI_DIR/matrix_full_test.sh" "$BIN_DIR/matrix-test"
ln -sf "$CGI_DIR/certification_report.sh" "$BIN_DIR/matrix-report"

cat > "$BIN_DIR/matrix-version" <<'EOF_VERSION'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF_VERSION
chmod +x "$BIN_DIR/matrix-version"

configure_uhttpd_matrix
configure_uhttpd_admin_8081

/etc/init.d/uhttpd restart >/dev/null 2>&1

VERSION="$(cat "$MATRIX_DIR/version.txt" 2>/dev/null)"

echo ""
echo "====================================="
echo "Matrix Toolkit Installed"
echo ""
echo "Version : $VERSION"
echo "Toolkit : http://192.168.1.1:8080/index.html"
echo "Admin   : http://192.168.1.1:8081/index.html"
echo "User    : admin"
echo "Pass    : Matrix2025 unless already changed"
echo "====================================="
echo ""
