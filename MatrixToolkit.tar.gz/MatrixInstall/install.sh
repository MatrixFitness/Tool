#!/bin/sh

# Matrix Toolkit installer for Teltonika RUT routers
# 8080 = normal Toolkit
# 8081 = Matrix Admin with CGI session login

set -u

# -----------------------------------------------------
# Find the MatrixInstall source folder automatically.
# This makes the installer work even when the USB is mounted
# as sda1, sdb1, sdc1, /mnt, /media, /tmp, etc.
# -----------------------------------------------------
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd)"
SOURCE_DIR=""

# First try: the folder where this script was started from.
if [ -n "$SCRIPT_DIR" ] && [ -f "$SCRIPT_DIR/install.sh" ] && [ -d "$SCRIPT_DIR/cgi-bin" ]; then
    SOURCE_DIR="$SCRIPT_DIR"
fi

# Second try: common Teltonika/OpenWRT USB mount locations.
if [ -z "$SOURCE_DIR" ]; then
    for d in \
        /usr/local/mnt/sd*/MatrixInstall \
        /mnt/sd*/MatrixInstall \
        /media/sd*/MatrixInstall \
        /tmp/mountd/disk*/MatrixInstall \
        /tmp/run/mountd/sd*/MatrixInstall
    do
        if [ -f "$d/install.sh" ] && [ -d "$d/cgi-bin" ]; then
            SOURCE_DIR="$d"
            break
        fi
    done
fi

# Last fallback: search the filesystem. This is slower, but prevents
# failures when the USB has an unexpected mount path.
if [ -z "$SOURCE_DIR" ]; then
    FOUND="$(find / -type d -name MatrixInstall 2>/dev/null | head -n 1)"
    if [ -n "$FOUND" ] && [ -f "$FOUND/install.sh" ] && [ -d "$FOUND/cgi-bin" ]; then
        SOURCE_DIR="$FOUND"
    fi
fi

if [ -z "$SOURCE_DIR" ]; then
    echo "ERROR: MatrixInstall folder not found."
    echo "Check if the USB stick is inserted and contains the MatrixInstall folder."
    echo "Tip: run this command to search manually:"
    echo "find / -type d -name MatrixInstall 2>/dev/null"
    exit 1
fi

echo "MatrixInstall source found at: $SOURCE_DIR"
cd "$SOURCE_DIR" || exit 1

MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
ADMIN_WEB_DIR="$MATRIX_DIR/adminweb"
CGI_DIR="$WEB_DIR/cgi-bin"
ADMIN_CGI_DIR="$ADMIN_WEB_DIR/cgi-bin"
BIN_DIR="/usr/local/bin"
PASS_FILE="$MATRIX_DIR/admin_password.txt"

configure_uhttpd_matrix() {
    uci set uhttpd.matrix='uhttpd'
    uci delete uhttpd.matrix.listen_http 2>/dev/null
    uci add_list uhttpd.matrix.listen_http='0.0.0.0:8080'
    uci add_list uhttpd.matrix.listen_http='[::]:8080'
    uci set uhttpd.matrix.home="$WEB_DIR"
    uci set uhttpd.matrix.index_page='index.html'
    uci set uhttpd.matrix.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix.script_timeout='600'
    uci set uhttpd.matrix.network_timeout='30'
    uci set uhttpd.matrix.http_keepalive='0'
    uci set uhttpd.matrix.tcp_keepalive='5'
    uci set uhttpd.matrix.no_dirlists='1'
    uci set uhttpd.matrix.enable_basic_auth='0'
    uci commit uhttpd
}

configure_uhttpd_admin_8081() {
    # Dedicated Admin web server. Security is handled by Matrix CGI session login,
    # not Teltonika/uhttpd basic-auth.
    uci set uhttpd.matrix_admin_web='uhttpd'
    uci delete uhttpd.matrix_admin_web.listen_http 2>/dev/null
    uci add_list uhttpd.matrix_admin_web.listen_http='0.0.0.0:8081'
    uci add_list uhttpd.matrix_admin_web.listen_http='[::]:8081'
    uci set uhttpd.matrix_admin_web.home="$ADMIN_WEB_DIR"
    uci set uhttpd.matrix_admin_web.index_page='cgi-bin/admin_login.sh'
    uci set uhttpd.matrix_admin_web.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix_admin_web.script_timeout='1200'
    uci set uhttpd.matrix_admin_web.network_timeout='120'
    uci set uhttpd.matrix_admin_web.http_keepalive='0'
    uci set uhttpd.matrix_admin_web.tcp_keepalive='5'
    uci set uhttpd.matrix_admin_web.no_dirlists='1'
    uci set uhttpd.matrix_admin_web.enable_basic_auth='0'

    # Remove old/failed uhttpd-auth sections so they cannot confuse the setup.
    uci delete uhttpd.matrix_admin 2>/dev/null
    uci delete uhttpd.matrix_admin_update 2>/dev/null
    uci delete uhttpd.matrix_admin_password 2>/dev/null
    uci delete uhttpd.matrix_admin_usb_update 2>/dev/null
    uci delete uhttpd.matrix_admin_zerotier 2>/dev/null
    uci delete uhttpd.matrix_admin_router_backup 2>/dev/null
    uci delete uhttpd.matrix_admin_toolkit_backup 2>/dev/null
    uci delete uhttpd.matrix_admin_health 2>/dev/null

    uci commit uhttpd
}

ensure_admin_password() {
    if [ ! -f "$PASS_FILE" ]; then
        printf "%s" "Matrix2025" > "$PASS_FILE"
    fi
    chmod 644 "$PASS_FILE" 2>/dev/null
}

remove_old_password_scripts() {
    rm -f "$CGI_DIR/get_admin_password.sh" \
          "$CGI_DIR/set_admin_password.sh" \
          "$ADMIN_CGI_DIR/get_admin_password.sh" \
          "$ADMIN_CGI_DIR/set_admin_password.sh" 2>/dev/null
}

create_8080_admin_redirect() {
    mkdir -p "$WEB_DIR/admin"
    cat > "$WEB_DIR/admin/index.html" <<'HTMLEOF'
<!DOCTYPE html>
<html>
<head>
<title>Matrix Admin moved</title>
<script>
(function(){ window.location.href = window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_login.sh'; })();
</script>
</head>
<body style="font-family:Arial;margin:30px;">
<h2>Matrix Admin moved</h2>
<p>Admin is now on port 8081 with Matrix login.</p>
<p><a id="adminLink" href="#">Open Matrix Admin</a></p>
<script>
document.getElementById('adminLink').href = window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_login.sh';
</script>
</body>
</html>
HTMLEOF
}

create_admin_index_redirect() {
    cat > "$ADMIN_WEB_DIR/index.html" <<'HTMLEOF'
<!DOCTYPE html>
<html>
<head>
<title>Matrix Admin</title>
<script>window.location='/cgi-bin/admin_login.sh';</script>
<meta http-equiv="refresh" content="0;url=/cgi-bin/admin_login.sh">
</head>
<body style="font-family:Arial;margin:30px;">
<p><a href="/cgi-bin/admin_login.sh">Open Matrix Admin</a></p>
</body>
</html>
HTMLEOF
}

fix_toolkit_admin_links() {
    if [ -f "$WEB_DIR/index.html" ]; then
        sed -i "s#window.location='/admin/'#window.location='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
        sed -i 's#href="/admin/"#href="/admin/index.html"#g' "$WEB_DIR/index.html" 2>/dev/null
        sed -i "s#href='/admin/'#href='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
    fi
}

copy_cgi_to_admin() {
    mkdir -p "$ADMIN_CGI_DIR"
    cp -f "$CGI_DIR"/*.sh "$ADMIN_CGI_DIR/" 2>/dev/null
    chmod +x "$ADMIN_CGI_DIR"/*.sh 2>/dev/null
}

install_admin_session_files() {
    for f in admin_login.sh admin_logout.sh admin_session_check.sh admin_home.sh admin_change_password.sh; do
        if [ -f "cgi-bin/$f" ]; then
            cp -f "cgi-bin/$f" "$CGI_DIR/$f"
            cp -f "cgi-bin/$f" "$ADMIN_CGI_DIR/$f"
        fi
    done
    chmod +x "$CGI_DIR"/admin_*.sh "$ADMIN_CGI_DIR"/admin_*.sh 2>/dev/null
}

patch_sensitive_admin_scripts() {
    # Add session check to sensitive scripts in the Admin webroot copy only.
    # The normal 8080 toolkit copy remains unchanged.
    CHECK='. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0'
    for f in update_github_start.sh update_github_log.sh update_toolkit.sh zerotier_setup.sh router_backup.sh toolkit_backup.sh matrix_health.sh; do
        FILE="$ADMIN_CGI_DIR/$f"
        [ -f "$FILE" ] || continue
        grep -q "admin_session_check.sh" "$FILE" && continue
        TMP="$FILE.tmp"
        {
            IFS= read -r FIRST || true
            echo "$FIRST"
            echo "$CHECK"
            cat
        } < "$FILE" > "$TMP"
        mv "$TMP" "$FILE"
        chmod +x "$FILE" 2>/dev/null
    done
}


install_root_update_worker() {
    # Required for Admin button update_github_start.sh.
    # CLI command matrix-update can run directly, but the Admin page uses this root cron worker.
    if [ -f matrix_update_worker.sh ]; then
        cp -f matrix_update_worker.sh "$MATRIX_DIR/matrix_update_worker.sh"
    elif [ -f cgi-bin/matrix_update_worker.sh ]; then
        cp -f cgi-bin/matrix_update_worker.sh "$MATRIX_DIR/matrix_update_worker.sh"
    fi

    if [ -f "$MATRIX_DIR/matrix_update_worker.sh" ]; then
        chmod +x "$MATRIX_DIR/matrix_update_worker.sh" 2>/dev/null

        # Install cron entry safely, without duplicates.
        if command -v crontab >/dev/null 2>&1; then
            (crontab -l 2>/dev/null | grep -v "matrix_update_worker.sh"; \
             echo "* * * * * /usr/local/matrix/matrix_update_worker.sh") | crontab -
        else
            mkdir -p /etc/crontabs
            grep -v "matrix_update_worker.sh" /etc/crontabs/root 2>/dev/null > /tmp/matrix_cron_root.$$ || true
            echo "* * * * * /usr/local/matrix/matrix_update_worker.sh" >> /tmp/matrix_cron_root.$$
            cp -f /tmp/matrix_cron_root.$$ /etc/crontabs/root
            rm -f /tmp/matrix_cron_root.$$
        fi

        /etc/init.d/cron enable >/dev/null 2>&1
        /etc/init.d/cron restart >/dev/null 2>&1
    else
        echo "WARNING: matrix_update_worker.sh not found. Admin update button will not work."
    fi
}

verify_matrix_update_ready() {
    echo ""
    echo "Checking matrix-update readiness..."

    FAIL=0

    for f in \
        "$CGI_DIR/update_github.sh" \
        "$CGI_DIR/update_github_start.sh" \
        "$CGI_DIR/update_github_log.sh" \
        "$MATRIX_DIR/matrix_update_worker.sh" \
        "$BIN_DIR/matrix-update"
    do
        if [ ! -e "$f" ]; then
            echo "MISSING: $f"
            FAIL=1
        fi
    done

    if [ -x "$CGI_DIR/update_github.sh" ]; then
        echo "OK: update_github.sh executable"
    else
        echo "MISSING/NOT EXECUTABLE: $CGI_DIR/update_github.sh"
        FAIL=1
    fi

    if [ -L "$BIN_DIR/matrix-update" ] || [ -x "$BIN_DIR/matrix-update" ]; then
        echo "OK: matrix-update command installed"
    else
        echo "MISSING: matrix-update command"
        FAIL=1
    fi

    if grep -q "matrix_update_worker.sh" /etc/crontabs/root 2>/dev/null || crontab -l 2>/dev/null | grep -q "matrix_update_worker.sh"; then
        echo "OK: root update worker cron installed"
    else
        echo "MISSING: root update worker cron"
        FAIL=1
    fi

    if [ "$FAIL" -eq 0 ]; then
        echo "OK: matrix-update is ready."
    else
        echo "WARNING: matrix-update is not fully ready. See missing items above."
    fi
}


install_root_zerotier_worker() {
    # Required for Admin ZeroTier setup button.
    # The web page creates /tmp/matrix_zerotier_request; this root cron worker performs the real setup.
    if [ -f matrix_zerotier_worker.sh ]; then
        cp -f matrix_zerotier_worker.sh "$MATRIX_DIR/matrix_zerotier_worker.sh"
    elif [ -f cgi-bin/matrix_zerotier_worker.sh ]; then
        cp -f cgi-bin/matrix_zerotier_worker.sh "$MATRIX_DIR/matrix_zerotier_worker.sh"
    fi

    if [ -f "$MATRIX_DIR/matrix_zerotier_worker.sh" ]; then
        chmod +x "$MATRIX_DIR/matrix_zerotier_worker.sh" 2>/dev/null

        # Install cron entry safely, without duplicates.
        if command -v crontab >/dev/null 2>&1; then
            (crontab -l 2>/dev/null | grep -v "matrix_zerotier_worker.sh"; \
             echo "* * * * * /usr/local/matrix/matrix_zerotier_worker.sh") | crontab -
        else
            mkdir -p /etc/crontabs
            grep -v "matrix_zerotier_worker.sh" /etc/crontabs/root 2>/dev/null > /tmp/matrix_zt_cron_root.$$ || true
            echo "* * * * * /usr/local/matrix/matrix_zerotier_worker.sh" >> /tmp/matrix_zt_cron_root.$$
            cp -f /tmp/matrix_zt_cron_root.$$ /etc/crontabs/root
            rm -f /tmp/matrix_zt_cron_root.$$
        fi

        /etc/init.d/cron enable >/dev/null 2>&1
        /etc/init.d/cron restart >/dev/null 2>&1
    else
        echo "WARNING: matrix_zerotier_worker.sh not found. Admin ZeroTier button will not work."
    fi
}

verify_zerotier_worker_ready() {
    echo ""
    echo "Checking ZeroTier worker readiness..."

    FAIL=0

    if [ -x "$ADMIN_CGI_DIR/zerotier_setup.sh" ]; then
        echo "OK: Admin ZeroTier web starter installed"
    else
        echo "MISSING/NOT EXECUTABLE: $ADMIN_CGI_DIR/zerotier_setup.sh"
        FAIL=1
    fi

    if [ -x "$MATRIX_DIR/matrix_zerotier_worker.sh" ]; then
        echo "OK: ZeroTier root worker installed"
    else
        echo "MISSING/NOT EXECUTABLE: $MATRIX_DIR/matrix_zerotier_worker.sh"
        FAIL=1
    fi

    if grep -q "matrix_zerotier_worker.sh" /etc/crontabs/root 2>/dev/null || crontab -l 2>/dev/null | grep -q "matrix_zerotier_worker.sh"; then
        echo "OK: ZeroTier root worker cron installed"
    else
        echo "MISSING: ZeroTier root worker cron"
        FAIL=1
    fi

    if [ "$FAIL" -eq 0 ]; then
        echo "OK: ZeroTier Admin button is ready."
    else
        echo "WARNING: ZeroTier Admin button is not fully ready. See missing items above."
    fi
}




install_survey_storage() {
    # Persistent storage for Customer WiFi Survey.
    # This must survive reboot / power loss, so do NOT use /tmp.
    SURVEY_DIR="$MATRIX_DIR/survey"

    echo ""
    echo "Creating persistent WiFi survey storage..."

    mkdir -p "$SURVEY_DIR"

    # Allow CGI/uhttpd scripts to write progress and results.
    chmod 777 "$SURVEY_DIR" 2>/dev/null

    # Create persistent files if they do not exist yet.
    [ -f "$SURVEY_DIR/selected_locations.txt" ] || touch "$SURVEY_DIR/selected_locations.txt"
    [ -f "$SURVEY_DIR/completed_locations.txt" ] || touch "$SURVEY_DIR/completed_locations.txt"
    [ -f "$SURVEY_DIR/locations.txt" ] || touch "$SURVEY_DIR/locations.txt"
    [ -f "$SURVEY_DIR/completed.txt" ] || touch "$SURVEY_DIR/completed.txt"
    [ -f "$SURVEY_DIR/wifi_survey_results.csv" ] || touch "$SURVEY_DIR/wifi_survey_results.csv"
    [ -f "$SURVEY_DIR/survey_state.txt" ] || touch "$SURVEY_DIR/survey_state.txt"

    chmod 666 "$SURVEY_DIR"/*.txt "$SURVEY_DIR"/*.csv 2>/dev/null

    echo "OK: survey storage ready at $SURVEY_DIR"
}

verify_survey_storage_ready() {
    echo ""
    echo "Checking WiFi survey storage readiness..."

    FAIL=0
    SURVEY_DIR="$MATRIX_DIR/survey"

    if [ -d "$SURVEY_DIR" ]; then
        echo "OK: survey folder exists"
    else
        echo "MISSING: $SURVEY_DIR"
        FAIL=1
    fi

    for f in \
        "$SURVEY_DIR/selected_locations.txt" \
        "$SURVEY_DIR/completed_locations.txt" \
        "$SURVEY_DIR/locations.txt" \
        "$SURVEY_DIR/completed.txt" \
        "$SURVEY_DIR/wifi_survey_results.csv" \
        "$SURVEY_DIR/survey_state.txt"
    do
        if [ -e "$f" ]; then
            echo "OK: $(basename "$f")"
        else
            echo "MISSING: $f"
            FAIL=1
        fi
    done

    if [ "$FAIL" -eq 0 ]; then
        echo "OK: WiFi survey can resume after reboot/power loss."
    else
        echo "WARNING: WiFi survey storage is not fully ready."
    fi
}



install_lte_cache_worker() {
    echo ""
    echo "Installing LTE cache worker..."

    if [ -f lte_info_cache.sh ]; then
        cp -f lte_info_cache.sh "$MATRIX_DIR/lte_info_cache.sh"
    elif [ -f cgi-bin/lte_info_cache.sh ]; then
        cp -f cgi-bin/lte_info_cache.sh "$MATRIX_DIR/lte_info_cache.sh"
    fi

    if [ -f "$MATRIX_DIR/lte_info_cache.sh" ]; then
        chmod +x "$MATRIX_DIR/lte_info_cache.sh" 2>/dev/null
        "$MATRIX_DIR/lte_info_cache.sh" >/dev/null 2>&1 || true

        if command -v crontab >/dev/null 2>&1; then
            (crontab -l 2>/dev/null | grep -v "lte_info_cache.sh"; \
             echo "* * * * * /usr/local/matrix/lte_info_cache.sh") | crontab -
        else
            mkdir -p /etc/crontabs
            grep -v "lte_info_cache.sh" /etc/crontabs/root 2>/dev/null > /tmp/matrix_lte_cron_root.$$ || true
            echo "* * * * * /usr/local/matrix/lte_info_cache.sh" >> /tmp/matrix_lte_cron_root.$$
            cp -f /tmp/matrix_lte_cron_root.$$ /etc/crontabs/root
            rm -f /tmp/matrix_lte_cron_root.$$
        fi

        /etc/init.d/cron enable >/dev/null 2>&1
        /etc/init.d/cron restart >/dev/null 2>&1
        echo "OK: LTE cache worker installed and cron enabled"
    else
        echo "WARNING: lte_info_cache.sh not found. LTE pages may show cached data unavailable."
    fi
}

install_post_update_script() {
    if [ -f post_update.sh ]; then
        cp -f post_update.sh "$MATRIX_DIR/post_update.sh"
        chmod +x "$MATRIX_DIR/post_update.sh" 2>/dev/null
        sh "$MATRIX_DIR/post_update.sh" >/dev/null 2>&1 || true
        echo "OK: post_update.sh installed and executed"
    else
        echo "WARNING: post_update.sh not found on USB/GitHub package"
    fi
}



install_wifi_manager_files() {
    echo ""
    echo "Installing WiFi Manager v59.5..."

    mkdir -p "$MATRIX_DIR"

    # If an older test version used /usr/local/matrix/config, migrate it once.
    if [ ! -f "$MATRIX_DIR/matrix_wifi_profiles.conf" ] && [ -f "$MATRIX_DIR/config/matrix_wifi_profiles.conf" ]; then
        cp -f "$MATRIX_DIR/config/matrix_wifi_profiles.conf" "$MATRIX_DIR/matrix_wifi_profiles.conf" 2>/dev/null
        echo "OK: Migrated old WiFi profile location"
    fi

    # Master/default profile file comes from MatrixInstall/matrix_wifi_profiles.conf.
    # It is refreshed during USB install. If missing, create safe built-in defaults.
    if [ -f matrix_wifi_profiles.conf ]; then
        cp -f matrix_wifi_profiles.conf "$MATRIX_DIR/matrix_wifi_profiles.default"
        chmod 644 "$MATRIX_DIR/matrix_wifi_profiles.default" 2>/dev/null
        echo "OK: WiFi master/default profiles installed"
    elif [ ! -f "$MATRIX_DIR/matrix_wifi_profiles.default" ]; then
        cat > "$MATRIX_DIR/matrix_wifi_profiles.default" <<'WIFIEOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
WIFIEOF
        chmod 644 "$MATRIX_DIR/matrix_wifi_profiles.default" 2>/dev/null
        echo "OK: Built-in WiFi master/default profiles created"
    fi

    # Active local config is created only once, so local router edits survive updates.
    if [ ! -f "$MATRIX_DIR/matrix_wifi_profiles.conf" ]; then
        cp -f "$MATRIX_DIR/matrix_wifi_profiles.default" "$MATRIX_DIR/matrix_wifi_profiles.conf" 2>/dev/null
        chmod 644 "$MATRIX_DIR/matrix_wifi_profiles.conf" 2>/dev/null
        echo "OK: Active WiFi profiles created from master/default"
    else
        chmod 644 "$MATRIX_DIR/matrix_wifi_profiles.conf" 2>/dev/null
        echo "OK: Active local WiFi profiles preserved"
    fi

    [ -f "$CGI_DIR/wifi_manager.sh" ] && chmod +x "$CGI_DIR/wifi_manager.sh" 2>/dev/null
    [ -f "$CGI_DIR/wifi_profile.sh" ] && chmod +x "$CGI_DIR/wifi_profile.sh" 2>/dev/null
    [ -f "$CGI_DIR/wifi_profiles_reset.sh" ] && chmod +x "$CGI_DIR/wifi_profiles_reset.sh" 2>/dev/null
}

echo ""
echo "====================================="
echo "Installing Matrix Toolkit"
echo "====================================="
echo ""

mkdir -p "$MATRIX_DIR" "$WEB_DIR" "$ADMIN_WEB_DIR" "$CGI_DIR" "$ADMIN_CGI_DIR" "$BIN_DIR"

if [ -d web ]; then
    cp -f web/* "$WEB_DIR/"
else
    echo "ERROR: web folder not found"
    exit 1
fi

if [ -d web_admin ]; then
    cp -rf web_admin/* "$ADMIN_WEB_DIR/" 2>/dev/null
    [ -f web_admin/index.html ] && cp -f web_admin/index.html "$ADMIN_WEB_DIR/index_source.html" 2>/dev/null
fi

if [ -d cgi-bin ]; then
    cp -f cgi-bin/*.sh "$CGI_DIR/" 2>/dev/null
fi

if [ -d cgi-bin_admin ]; then
    for f in cgi-bin_admin/*.sh; do
        [ -f "$f" ] || continue
        case "$(basename "$f")" in
            about.sh)
                [ -f "$CGI_DIR/about.sh" ] && continue
                ;;
        esac
        cp -f "$f" "$CGI_DIR/"
    done
fi

chmod +x "$CGI_DIR"/*.sh 2>/dev/null
copy_cgi_to_admin
install_admin_session_files
patch_sensitive_admin_scripts

[ -f version.txt ] && cp -f version.txt "$MATRIX_DIR/version.txt"
[ -f clubname.txt ] && cp -f clubname.txt "$MATRIX_DIR/clubname.txt"

if [ ! -f "$MATRIX_DIR/version.txt" ]; then
    cat > "$MATRIX_DIR/version.txt" <<'VERSIONEOF'
Version=Unknown
Build=Unknown
Release=Unknown
Changes=Unknown
GitHub=https://github.com/MatrixFitness/Tool
Author=Unknown
Email=
Company=Matrix Fitness
Message=Matrix Toolkit
VERSIONEOF
fi

install_wifi_manager_files
install_survey_storage
verify_survey_storage_ready
install_post_update_script
install_lte_cache_worker

ensure_admin_password
fix_toolkit_admin_links
create_8080_admin_redirect
create_admin_index_redirect
remove_old_password_scripts

cat > "$BIN_DIR/matrix-update" <<'UPDATECLIEOF'
#!/bin/sh

# Matrix Toolkit Update Request CLI
# This command does not run update_github.sh directly.
# It creates a request file. The root cron worker performs the real update.

REQ="/tmp/matrix_update_request"
LOG="/tmp/matrix_update_github.log"
LOCK="/tmp/matrix_update_worker.lock"

if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "Matrix update already running."
        echo "View log with:"
        echo "cat $LOG"
        exit 0
    fi
    rm -f "$LOCK"
fi

echo "GitHub update requested at: $(date)" > "$LOG"
echo "Waiting for root update worker..." >> "$LOG"
echo "" >> "$LOG"

touch "$REQ"

echo "Matrix update requested."
echo "The root worker will run it within 1 minute."
echo "View log with:"
echo "cat $LOG"

UPDATECLIEOF

chmod +x "$BIN_DIR/matrix-update"

ln -sf "$CGI_DIR/matrix_full_test.sh" "$BIN_DIR/matrix-test"
ln -sf "$CGI_DIR/certification_report.sh" "$BIN_DIR/matrix-report"

cat > "$BIN_DIR/matrix-version" <<'EOF_VERSION'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF_VERSION
chmod +x "$BIN_DIR/matrix-version"

install_root_update_worker
install_root_zerotier_worker
verify_matrix_update_ready
verify_zerotier_worker_ready

configure_uhttpd_matrix
configure_uhttpd_admin_8081

/etc/init.d/uhttpd restart >/dev/null 2>&1

VERSION="$(cat "$MATRIX_DIR/version.txt" 2>/dev/null)"

echo ""
echo "====================================="
echo "Matrix Toolkit Installed"
echo ""
echo "Version : $VERSION"
echo "Toolkit : http://192.168.1.1:8080/index.html"
echo "Admin   : http://192.168.1.1:8081/cgi-bin/admin_login.sh"
echo "User    : admin"
echo "Pass    : Matrix2025 unless already changed"
echo "====================================="
echo ""
