#!/bin/sh

# Always run from script directory
cd "$(dirname "$0")"

echo ""
echo "====================================="
echo "Installing Matrix Toolkit"
echo "====================================="
echo ""

# Create folders
mkdir -p /usr/local/matrix
mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/admin
mkdir -p /usr/local/matrix/web/cgi-bin

# Install web files
cp -f web/index.html \
      /usr/local/matrix/web/index.html

cp -f web_admin/index.html \
      /usr/local/matrix/web/admin/index.html

# Install CGI scripts
cp -f cgi-bin/*.sh \
      /usr/local/matrix/web/cgi-bin/

cp -f cgi-bin_admin/*.sh \
      /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

# Install version
if [ -f version.txt ]
then
    cp -f version.txt \
          /usr/local/matrix/version.txt
fi

# Install club name
if [ -f clubname.txt ]
then
    cp -f clubname.txt \
          /usr/local/matrix/clubname.txt
fi

# Install admin password
if [ -f admin_password.txt ]
then
    cp -f admin_password.txt \
          /usr/local/matrix/admin_password.txt
fi

# Matrix CLI commands
ln -sf /usr/local/matrix/web/cgi-bin/update_github.sh \
      /usr/bin/matrix-update

ln -sf /usr/local/matrix/web/cgi-bin/matrix_full_test.sh \
      /usr/bin/matrix-test

ln -sf /usr/local/matrix/web/cgi-bin/certification_report.sh \
      /usr/bin/matrix-report

cat > /usr/bin/matrix-version << 'EOF'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF

chmod +x /usr/bin/matrix-version

# Restart Matrix webserver
killall uhttpd 2>/dev/null

uhttpd \
-h /usr/local/matrix/web \
-p 8080 \
-x /cgi-bin \
-i .sh=/bin/sh &

VERSION=$(cat /usr/local/matrix/version.txt 2>/dev/null)

echo ""
echo "====================================="
echo "Matrix Toolkit Installed"
echo ""
echo "Version : $VERSION"
echo "Toolkit : http://192.168.1.1:8080"
echo "Admin   : http://192.168.1.1:8080/admin/"
echo "====================================="
echo ""
