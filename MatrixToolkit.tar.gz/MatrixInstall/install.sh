#!/bin/sh

# Always run from script directory
cd "$(dirname "$0")" || exit 1

echo ""
echo "====================================="
echo "Installing Matrix Toolkit"
echo "====================================="
echo ""

# Create folders
mkdir -p /usr/local/matrix
mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/admin
mkdir -p /usr/local/matrix/web/cgi-bin
mkdir -p /usr/local/bin

# Install web files
cp -f web/* /usr/local/matrix/web/
cp -f web_admin/index.html /usr/local/matrix/web/admin/index.html

# Install CGI scripts
cp -f cgi-bin/*.sh /usr/local/matrix/web/cgi-bin/
cp -f cgi-bin_admin/*.sh /usr/local/matrix/web/cgi-bin/
chmod +x /usr/local/matrix/web/cgi-bin/*.sh

# Install version
[ -f version.txt ] && cp -f version.txt /usr/local/matrix/version.txt

# Install clubname
[ -f clubname.txt ] && cp -f clubname.txt /usr/local/matrix/clubname.txt

# Install admin password
[ -f admin_password.txt ] && cp -f admin_password.txt /usr/local/matrix/admin_password.txt

# Matrix CLI commands
ln -sf /usr/local/matrix/web/cgi-bin/update_github.sh /usr/local/bin/matrix-update
ln -sf /usr/local/matrix/web/cgi-bin/matrix_full_test.sh /usr/local/bin/matrix-test
ln -sf /usr/local/matrix/web/cgi-bin/certification_report.sh /usr/local/bin/matrix-report

cat > /usr/local/bin/matrix-version << 'EOF'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF
chmod +x /usr/local/bin/matrix-version

# Permanent Matrix uhttpd instance on port 8080
# Remove old Matrix section if it exists
uci delete uhttpd.matrix 2>/dev/null

# Remove accidental 8080 entries from Teltonika main web UI
uci del_list uhttpd.main.listen_http='0.0.0.0:8080' 2>/dev/null
uci del_list uhttpd.main.listen_http='[::]:8080' 2>/dev/null
uci del_list uhttpd.main.listen_http='8080' 2>/dev/null

uci set uhttpd.matrix='uhttpd'
uci set uhttpd.matrix.listen_http='0.0.0.0:8080'
uci add_list uhttpd.matrix.listen_http='[::]:8080'
uci set uhttpd.matrix.home='/usr/local/matrix/web'
uci set uhttpd.matrix.index_page='index.html'
uci set uhttpd.matrix.cgi_prefix='/cgi-bin'
uci set uhttpd.matrix.script_timeout='600'
uci set uhttpd.matrix.network_timeout='30'
uci set uhttpd.matrix.http_keepalive='0'
uci set uhttpd.matrix.tcp_keepalive='5'
uci set uhttpd.matrix.no_dirlists='1'
uci commit uhttpd

/etc/init.d/uhttpd restart

VERSION=$(cat /usr/local/matrix/version.txt 2>/dev/null)

echo ""
echo "====================================="
echo "Matrix Toolkit Installed"
echo ""
echo "Version : $VERSION"
echo "Toolkit : http://192.168.1.1:8080/index.html"
echo "Admin   : http://192.168.1.1:8080/admin/index.html"
echo "====================================="
echo ""
