#!/bin/sh
# Matrix Toolkit v70.2 ZeroTier Root Worker installer

SOURCE_DIR="$(dirname "$0")"
ADMINWEB="/usr/local/matrix/adminweb/cgi-bin"
WEB="/usr/local/matrix/web/cgi-bin"
mkdir -p "$ADMINWEB" "$WEB"

if [ -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin_admin/zerotier_manager.sh" "$ADMINWEB/zerotier_manager.sh"
    chmod +x "$ADMINWEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin_admin/zerotier_root_worker.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin_admin/zerotier_root_worker.sh" "$ADMINWEB/zerotier_root_worker.sh"
    chmod +x "$ADMINWEB/zerotier_root_worker.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_manager.sh" "$WEB/zerotier_manager.sh"
    chmod +x "$WEB/zerotier_manager.sh"
fi

if [ -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" ]; then
    cp -f "$SOURCE_DIR/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh"
    chmod +x "$WEB/zerotier_fix.sh"
fi

# CLI helper
cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
echo repair > /tmp/matrix_zerotier_repair_request
/usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh
cat /tmp/matrix_zerotier_fix.log
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix

# Cron root worker
TMPCRON="/tmp/matrix_cron_zt.$$"
crontab -l 2>/dev/null | grep -v "zerotier_root_worker.sh" > "$TMPCRON"
echo "* * * * * /usr/local/matrix/adminweb/cgi-bin/zerotier_root_worker.sh" >> "$TMPCRON"
crontab "$TMPCRON"
rm -f "$TMPCRON"

# Ensure admin button exists
ADMIN_HOME="$ADMINWEB/admin_home.sh"
if [ -f "$ADMIN_HOME" ] && ! grep -q "zerotier_manager.sh" "$ADMIN_HOME"; then
    cp -f "$ADMIN_HOME" "$ADMIN_HOME.bak.ztmanager.$(date +%Y%m%d%H%M%S)"
    sed -i "/zerotier_setup.sh/a\\        <button class=\"blue\" onclick=\"window.location='/cgi-bin/zerotier_manager.sh'\">ZeroTier Manager</button>" "$ADMIN_HOME"
    chmod +x "$ADMIN_HOME"
fi

echo "Matrix Toolkit v70.2 ZeroTier Root Worker installed."
