#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION_FILE="/usr/local/matrix/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
MESSAGE=$(get_value Message)
GITHUB=$(get_value GitHub)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="Unknown"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="Unknown"
[ -z "$MESSAGE" ] && MESSAGE="Unknown"
[ -z "$GITHUB" ] && GITHUB="Unknown"

cat << EOF
<html>
<head>
<title>About Matrix Toolkit</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background: #f5f5f5;
    color: #333;
}
.card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    max-width: 800px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.12);
}
table {
    border-collapse: collapse;
    width: 100%;
}
th {
    background: #007bff;
    color: white;
    padding: 8px;
    text-align: left;
}
td {
    border: 1px solid #ddd;
    padding: 8px;
}
button {
    margin-top: 20px;
    width: 220px;
    height: 50px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: 0;
    border-radius: 6px;
    background: #007bff;
    color: white;
}
</style>
</head>

<body>

<div class="card">
<h1>About Matrix Toolkit</h1>

<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Version</td><td>$VERSION</td></tr>
<tr><td>Build</td><td>$BUILD</td></tr>
<tr><td>Release</td><td>$RELEASE</td></tr>
<tr><td>Changes</td><td>$CHANGES</td></tr>
<tr><td>Company</td><td>$COMPANY</td></tr>
<tr><td>Author</td><td>$AUTHOR</td></tr>
<tr><td>Email</td><td>$EMAIL</td></tr>
<tr><td>Message</td><td>$MESSAGE</td></tr>
<tr><td>GitHub</td><td>$GITHUB</td></tr>
</table>

<button onclick="window.location='/admin/'">Back to Admin</button>
<button onclick="window.location='/'">Home</button>

</div>

</body>
</html>
EOF