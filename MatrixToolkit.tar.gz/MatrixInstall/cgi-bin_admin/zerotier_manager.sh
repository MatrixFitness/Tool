#!/bin/sh
REQ="/tmp/matrix_zerotier_repair_request"
LOG="/tmp/matrix_zerotier_fix.log"
STATUS_FILE="/tmp/matrix_zerotier_status.cache"
html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2-; }
getv(){ grep "^$1=" "$STATUS_FILE" 2>/dev/null | head -n1 | cut -d= -f2- | sed 's/&#61;/=/g'; }
ACTION="$(qs action)"
case "$ACTION" in repair|restart|rejoin) echo "$ACTION" > "$REQ"; echo "ZeroTier $ACTION requested at: $(date)" > "$LOG"; echo "Waiting for root worker..." >> "$LOG";; esac
STATUS_WORKER="/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh"
if [ ! -f "$STATUS_FILE" ] || ! grep -q "^CLI=" "$STATUS_FILE" 2>/dev/null; then [ -x "$STATUS_WORKER" ] && "$STATUS_WORKER" >/dev/null 2>&1; sleep 1; fi
[ -f "$STATUS_FILE" ] || { echo "TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')" > "$STATUS_FILE"; echo "HEALTH=WARNING" >> "$STATUS_FILE"; echo "REASON=Live root status cache not available yet. Click Repair Everything or wait for cron." >> "$STATUS_FILE"; }
TIMESTAMP="$(getv TIMESTAMP)"; HOST="$(getv HOST)"; NETWORK_ID="$(getv NETWORK_ID)"; ZT_HOME="$(getv ZT_HOME)"; CLI="$(getv CLI)"; ONE="$(getv ONE)"; PORT_FILE="$(getv PORT_FILE)"; NODE_ID="$(getv NODE_ID)"; ZT_VERSION="$(getv VERSION)"; ONLINE="$(getv ONLINE)"; IFACE="$(getv IFACE)"; IP="$(getv IP)"; REMOTE_URL="$(getv REMOTE_URL)"; NET_STATUS="$(getv NET_STATUS)"; HEALTH="$(getv HEALTH)"; REASON="$(getv REASON)"; INFO="$(getv INFO)"; NETWORK_LINE="$(getv NETWORK_LINE)"; ZT_LOG="$(cat "$LOG" 2>/dev/null)"
[ -z "$HEALTH" ] && HEALTH="WARNING"; HC="warn"; [ "$HEALTH" = "HEALTHY" ] && HC="ok"; [ "$HEALTH" = "FAILED" ] && HC="err"
row(){ N="$1"; S="$2"; D="$3"; C="warn"; [ "$S" = "OK" ] && C="ok"; [ "$S" = "FAIL" ] && C="err"; echo "<tr><td><b>$(html_escape "$N")</b></td><td><span class=\"$C\">$(html_escape "$S")</span></td><td>$(html_escape "$D")</td></tr>"; }
echo "Content-Type: text/html"; echo ""
cat <<EOF
<!DOCTYPE html><html><head><title>ZeroTier Manager</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="30"><style>body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1120px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{color:#005a9c}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.health{font-size:24px;font-weight:bold;border-radius:8px;padding:14px;margin:10px 0}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}.err{color:#c82333;font-weight:bold}.health.ok{background:#e5f6ea;border:1px solid #a8dab5}.health.warn{background:#fff4ce;border:1px solid #ead28a}.health.err{background:#fde2e2;border:1px solid #f3b3b3}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:4px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.grey{background:#666}table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}th{background:#f0f6fb;color:#005a9c}pre{white-space:pre-wrap;background:#111;color:#eee;padding:12px;border-radius:8px;overflow:auto}.copybox{width:100%;min-height:180px;box-sizing:border-box}</style><script>function confirmRepair(){return confirm('Repair ZeroTier now? The root worker will run the repair. Continue?');}function copyDiag(){var t=document.getElementById('diagcopy');t.select();document.execCommand('copy');alert('Diagnostics copied');}</script></head><body><div class="page"><h1>ZeroTier Manager v73</h1><div class="health $HC">ZeroTier Status: $(html_escape "$HEALTH")</div><p><b>Result:</b> $(html_escape "$REASON")</p><p><b>Last live status:</b> $(html_escape "$TIMESTAMP")</p><div class="card"><h2>Live Status</h2><table><tr><th>Check</th><th>Status</th><th>Details</th></tr>
EOF
[ -n "$CLI" ] && row "zerotier-cli" "OK" "$CLI" || row "zerotier-cli" "FAIL" "Missing"
[ -n "$ONE" ] && row "zerotier-one" "OK" "$ONE" || row "zerotier-one" "FAIL" "Missing"
[ -n "$ZT_HOME" ] && row "Persistent Home" "OK" "$ZT_HOME" || row "Persistent Home" "WARN" "Unknown"
[ -n "$PORT_FILE" ] && row "Runtime port file" "OK" "$PORT_FILE" || row "Runtime port file" "WARN" "$ZT_HOME"
[ -n "$NODE_ID" ] && row "Node ID" "OK" "$NODE_ID" || row "Node ID" "WARN" "Unknown"
[ "$ONLINE" = "ONLINE" ] && row "Online" "OK" "$ONLINE" || row "Online" "WARN" "$ONLINE"
[ "$NET_STATUS" = "OK" ] && row "Network joined" "OK" "$NETWORK_LINE" || row "Network joined" "WARN" "$NETWORK_LINE"
[ "$NET_STATUS" = "OK" ] && row "Authorization" "OK" "Authorized" || row "Authorization" "WARN" "$NET_STATUS"
[ -n "$IP" ] && row "ZeroTier IP" "OK" "$IP" || row "ZeroTier IP" "WARN" "No ZeroTier IP"
[ -n "$IFACE" ] && row "Interface" "OK" "$IFACE" || row "Interface" "WARN" "No zt interface"
[ -n "$REMOTE_URL" ] && row "Remote Toolkit URL" "OK" "$REMOTE_URL" || row "Remote Toolkit URL" "WARN" "Unavailable"
cat <<EOF
</table></div><div class="card"><h2>Repair</h2><p><a class="btn green" onclick="return confirmRepair()" href="/cgi-bin/zerotier_manager.sh?action=repair">Repair Everything</a><a class="btn orange" href="/cgi-bin/zerotier_manager.sh?action=restart">Restart ZeroTier</a><a class="btn orange" href="/cgi-bin/zerotier_manager.sh?action=rejoin">Leave + Rejoin Network</a><a class="btn blue" href="/cgi-bin/zerotier_manager.sh?action=refresh&nocache=$(date +%s)">Refresh Status</a></p><p class="warn">If status shows ACCESS_DENIED, authorize Node ID $(html_escape "$NODE_ID") in ZeroTier Central.</p></div><div class="card"><h2>Copy Diagnostics</h2><textarea id="diagcopy" class="copybox" readonly>
Hostname: $HOST
Toolkit URL: $REMOTE_URL
ZeroTier Persistent Home: $ZT_HOME
ZeroTier Network ID: $NETWORK_ID
Node ID: $NODE_ID
ZeroTier Version: $ZT_VERSION
ZeroTier IP: $IP
Interface: $IFACE
Online: $ONLINE
Network Status: $NET_STATUS
Info: $INFO
Network: $NETWORK_LINE
Health: $HEALTH
Reason: $REASON
Last Status: $TIMESTAMP
</textarea><p><button class="btn blue" onclick="copyDiag()">Copy ZeroTier Diagnostics</button></p></div><details><summary><b>Repair Log</b></summary><div class="card"><pre>$(html_escape "$ZT_LOG")</pre></div></details><p><a class="btn grey" href="/cgi-bin/admin_home.sh">Back to Admin</a><a class="btn grey" href="/">Back to Toolkit</a></p></div></body></html>
EOF
