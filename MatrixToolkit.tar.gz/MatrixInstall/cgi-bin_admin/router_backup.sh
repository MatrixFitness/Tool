#!/bin/sh

echo "Content-Type: text/html"
echo ""

mkdir -p /usr/local/mnt/sda1/Backup

FILE="/usr/local/mnt/sda1/Backup/router-config-$(date +%Y%m%d-%H%M%S).tar.gz"

sysupgrade -b "$FILE" >/dev/null 2>&1

echo "<html><body style='font-family:Arial'>"

echo "<h1>Router Config Backup</h1>"

if [ -f "$FILE" ]
then
    echo "<h2 style='color:green'>BACKUP GESLAAGD</h2>"
    echo "<pre>$FILE</pre>"
else
    echo "<h2 style='color:red'>BACKUP MISLUKT</h2>"
fi

echo "<br><a href='/index.html'>Terug naar Admin</a>"

echo "</body></html>"