#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"

VERSION="$(get_value Version)"; BUILD="$(get_value Build)"; RELEASE="$(get_value Release)"
[ -z "$VERSION" ] && VERSION="76.4"
[ -z "$BUILD" ] && BUILD="2026-06-30"
[ -z "$RELEASE" ] && RELEASE="Production LTS"

ZT_IP=""
[ -f /tmp/matrix_zerotier_status.cache ] && ZT_IP="$(grep '^IP=' /tmp/matrix_zerotier_status.cache 2>/dev/null | head -n1 | cut -d= -f2-)"
[ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr show 2>/dev/null | awk '/zt/ {f=1} f && /inet / {split($2,a,"/"); print a[1]; exit}')"
ZT_HEALTH=""
[ -f /tmp/matrix_zerotier_status.cache ] && ZT_HEALTH="$(grep '^HEALTH=' /tmp/matrix_zerotier_status.cache 2>/dev/null | head -n1 | cut -d= -f2-)"
[ -z "$ZT_HEALTH" ] && ZT_HEALTH="UNKNOWN"
INTERNET_STATUS="OFFLINE"; ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && INTERNET_STATUS="ONLINE"

TOOLKIT_URL=""; ADMIN_URL=""
[ -n "$ZT_IP" ] && TOOLKIT_URL="http://$ZT_IP:8080/" && ADMIN_URL="http://$ZT_IP:8081/cgi-bin/admin_login.sh"


UPTIME_SHORT="$(uptime 2>/dev/null | sed 's/^ *//')"
LOAD_AVG="$(uptime 2>/dev/null | sed 's/.*load average: //')"
FREE_MEM="$(free -m 2>/dev/null | awk '/Mem:/ {print $4 " MB"}')"
[ -z "$FREE_MEM" ] && FREE_MEM="Unknown"
FREE_FLASH="$(df -h / 2>/dev/null | awk 'NR==2 {print $4 " free"}')"
[ -z "$FREE_FLASH" ] && FREE_FLASH="Unknown"


CURRENT_TIME="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
cat <<EOF
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Matrix Admin</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--updates:#3949ab;--remote:#6f42c1;--backup:#0077c8;--tools:#f28c28;--status:#0d6efd;--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1320px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.brand h1{margin:0;font-size:28px;line-height:1.1}.brand .sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact-line{margin-top:8px;font-size:13px;opacity:.95}.top-actions{display:flex;gap:10px;flex-wrap:wrap}.top-btn{background:rgba(255,255,255,.16);color:#fff;border:1px solid rgba(255,255,255,.35);text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700;display:inline-block}.top-btn:hover{background:rgba(255,255,255,.26)}
.status-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}.status-card{background:var(--panel);border:1px solid var(--border);border-radius:16px;padding:15px;box-shadow:var(--shadow)}.status-label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}.status-value{margin-top:8px;font-size:20px;font-weight:800;word-break:break-word}.status-ok{color:var(--ok)}.status-warn{color:var(--warn)}.status-fail{color:var(--fail)}
.card-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:16px;align-items:stretch}.card{background:var(--panel);border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);overflow:hidden;display:flex;flex-direction:column;min-height:100%}.card-head{padding:14px 16px;color:#fff;font-weight:800;letter-spacing:.03em;text-transform:uppercase;font-size:14px}.updates .card-head{background:var(--updates)}.remote .card-head{background:var(--remote)}.backup .card-head{background:var(--backup)}.tools .card-head{background:var(--tools)}.system .card-head{background:var(--status)}.card-body{padding:14px;display:flex;flex-direction:column;flex:1}.card-desc{color:var(--muted);font-size:13px;line-height:1.35;margin:0 0 12px}.tile{display:block;text-decoration:none;color:var(--text);background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:12px;margin:9px 0;transition:.12s ease;min-height:58px}.tile:hover{transform:translateY(-1px);box-shadow:0 5px 14px rgba(15,23,42,.08);border-color:#b7c6d8}.tile-title{font-weight:800;font-size:15px}.tile-sub{font-size:12px;color:var(--muted);margin-top:4px;line-height:1.25}.info-list{display:grid;gap:9px;margin-top:2px}.info-row{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:10px}.info-label{font-size:11px;color:var(--muted);text-transform:uppercase;font-weight:800;letter-spacing:.04em}.info-value{font-size:14px;font-weight:800;margin-top:4px;word-break:break-word}.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}
@media(max-width:1240px){.card-grid{grid-template-columns:repeat(3,1fr)}.status-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:860px){.card-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.brand h1{font-size:23px}.top-actions{width:100%}.top-btn{width:100%;text-align:center}.status-grid{grid-template-columns:1fr;gap:10px}.card-grid{grid-template-columns:1fr;gap:12px}.tile{min-height:64px;padding:14px}.tile-title{font-size:16px}.tile-sub{font-size:13px}}
</style></head><body><div class="page">
<section class="hero"><div class="brand"><h1>Matrix Admin</h1><div class="sub">$(html_escape "$HOST") &middot; Secure maintenance dashboard</div><div class="contact-line">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div></div><div class="top-actions"><a class="top-btn" href="/cgi-bin/go_toolkit.sh">Toolkit</a><a class="top-btn" href="/cgi-bin/admin_logout.sh">Logout</a></div></section>
<section class="status-grid"><div class="status-card"><div class="status-label">Router</div><div class="status-value">$(html_escape "$HOST")</div></div><div class="status-card"><div class="status-label">Internet</div><div class="status-value status-$( [ "$INTERNET_STATUS" = "ONLINE" ] && echo ok || echo fail )">$(html_escape "$INTERNET_STATUS")</div></div><div class="status-card"><div class="status-label">ZeroTier</div><div class="status-value status-$( [ "$ZT_HEALTH" = "HEALTHY" ] && echo ok || echo warn )">$(html_escape "$ZT_HEALTH")</div></div><div class="status-card"><div class="status-label">Version</div><div class="status-value">v$(html_escape "$VERSION")</div></div></section>
<section class="card-grid">
<div class="card updates"><div class="card-head">Updates</div><div class="card-body"><p class="card-desc">Toolkit bijwerken en update-status controleren.</p><a class="tile" href="/cgi-bin/update_github_start.sh"><div class="tile-title">GitHub Update</div><div class="tile-sub">Laatste release installeren</div></a><a class="tile" href="/cgi-bin/update_github_log.sh"><div class="tile-title">Update Log</div><div class="tile-sub">Voortgang en foutmeldingen</div></a></div></div>
<div class="card remote"><div class="card-head">Remote Access</div><div class="card-body"><p class="card-desc">ZeroTier installatie, repair en live status.</p><a class="tile" href="/cgi-bin/zerotier_manager.sh"><div class="tile-title">ZeroTier Manager</div><div class="tile-sub">Live status en repair</div></a><a class="tile" href="/cgi-bin/zerotier_setup.sh"><div class="tile-title">ZeroTier Setup</div><div class="tile-sub">Eerste installatie of opnieuw joinen</div></a></div></div>
<div class="card backup"><div class="card-head">Backups</div><div class="card-body"><p class="card-desc">Router- en Toolkit-backups veiligstellen.</p><a class="tile" href="/cgi-bin/router_backup.sh"><div class="tile-title">Router Backup</div><div class="tile-sub">Configuratie veiligstellen</div></a><a class="tile" href="/cgi-bin/toolkit_backup.sh"><div class="tile-title">Toolkit Backup</div><div class="tile-sub">Toolkit bestanden veiligstellen</div></a></div></div>
<div class="card tools"><div class="card-head">Maintenance</div><div class="card-body"><p class="card-desc">Beheer en veilige acties.</p><a class="tile" href="/cgi-bin/install_usb.sh"><div class="tile-title">USB Install</div><div class="tile-sub">Installeren vanaf USB</div></a><a class="tile" href="/cgi-bin/change_admin_password.sh"><div class="tile-title">Admin Password</div><div class="tile-sub">Wachtwoord wijzigen</div></a><a class="tile" href="/cgi-bin/restart_router.sh"><div class="tile-title">Restart Router</div><div class="tile-sub">Alleen gebruiken indien nodig</div></a></div></div>
<div class="card system">
  <div class="card-head">System Health</div>
  <div class="card-body">
    <p class="card-desc">Live statusinformatie voor beheer en support.</p>
    <div class="info-list">
      <div class="info-row"><div class="info-label">Internet</div><div class="info-value">$(html_escape "$INTERNET_STATUS")</div></div>
      <div class="info-row"><div class="info-label">ZeroTier</div><div class="info-value">$(html_escape "$ZT_HEALTH")</div></div>
      <div class="info-row"><div class="info-label">Toolkit Version</div><div class="info-value">v$(html_escape "$VERSION")</div></div>
      <div class="info-row"><div class="info-label">Router Uptime</div><div class="info-value">$(html_escape "$UPTIME_SHORT")</div></div>
      <div class="info-row"><div class="info-label">CPU Load</div><div class="info-value">$(html_escape "$LOAD_AVG")</div></div>
      <div class="info-row"><div class="info-label">Free Memory</div><div class="info-value">$(html_escape "$FREE_MEM")</div></div>
      <div class="info-row"><div class="info-label">Free Flash</div><div class="info-value">$(html_escape "$FREE_FLASH")</div></div>
      <div class="info-row"><div class="info-label">Current Time</div><div class="info-value">$(html_escape "$CURRENT_TIME")</div></div>
    </div>
  </div>
</div>
</section><div class="footer">Matrix Fitness &middot; Admin v$(html_escape "$VERSION")</div></div></body></html>
EOF
