#!/bin/sh
REQ="/tmp/matrix_zerotier_repair_request"
LOCK="/tmp/matrix_zerotier_repair.lock"
LOG="/tmp/matrix_zerotier_fix.log"
ZT_NETWORK_ID="cf719fd5409699a2"
ZT_HOME="/usr/local/matrix/zerotier"
STATUS_WORKER="/usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh"

[ -f "$REQ" ] || exit 0
if [ -f "$LOCK" ]; then
    OLD="$(cat "$LOCK" 2>/dev/null)"
    [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null && exit 0
fi
echo "$$" > "$LOCK"
ACTION="$(cat "$REQ" 2>/dev/null | head -n1)"
rm -f "$REQ"

find_cli() { for p in /usr/bin/zerotier-cli /usr/local/usr/bin/zerotier-cli /usr/sbin/zerotier-cli; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-cli 2>/dev/null; }
find_one() { for p in /usr/bin/zerotier-one /usr/local/usr/bin/zerotier-one /usr/sbin/zerotier-one; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-one 2>/dev/null; }
zt_cli() { C="$(find_cli)"; [ -n "$C" ] && "$C" -D"$ZT_HOME" "$@"; }
zt_iface() { ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}'; }
log() { echo "$1" >> "$LOG"; }

stop_all() {
    /etc/init.d/zerotier stop >/dev/null 2>&1 || true
    /etc/init.d/zerotier disable >/dev/null 2>&1 || true
    killall zerotier-one >/dev/null 2>&1 || true
    sleep 3
}

migrate_id() {
    mkdir -p "$ZT_HOME"
    chmod 700 "$ZT_HOME" 2>/dev/null
    if [ ! -f "$ZT_HOME/identity.secret" ]; then
        if [ -f /tmp/run/zerotier/identity.secret ]; then
            cp -f /tmp/run/zerotier/identity.secret "$ZT_HOME/identity.secret"
            cp -f /tmp/run/zerotier/identity.public "$ZT_HOME/identity.public" 2>/dev/null
            log "Migrated identity from /tmp/run/zerotier"
        elif [ -f /etc/zerotier/identity.secret ]; then
            cp -f /etc/zerotier/identity.secret "$ZT_HOME/identity.secret"
            cp -f /etc/zerotier/identity.public "$ZT_HOME/identity.public" 2>/dev/null
            log "Migrated identity from /etc/zerotier"
        fi
    fi
}

write_service() {
    O="$(find_one)"
    [ -z "$O" ] && O="/usr/local/usr/bin/zerotier-one"
    cat > /etc/init.d/matrix_zerotier <<EOF
#!/bin/sh /etc/rc.common
START=99
STOP=10
start() {
    /etc/init.d/zerotier stop >/dev/null 2>&1
    mkdir -p $ZT_HOME
    chmod 700 $ZT_HOME 2>/dev/null
    if ! pgrep -f "zerotier-one -d $ZT_HOME" >/dev/null 2>&1; then
        killall zerotier-one >/dev/null 2>&1
        $O -d $ZT_HOME >/tmp/zt_start.log 2>&1 &
    fi
}
stop() {
    killall zerotier-one >/dev/null 2>&1
}
EOF
    chmod +x /etc/init.d/matrix_zerotier
    /etc/init.d/matrix_zerotier enable >/dev/null 2>&1
}

start_zt() {
    O="$(find_one)"
    [ -n "$O" ] || { log "ERROR: zerotier-one missing"; return 1; }
    migrate_id
    write_service
    if ! pgrep -f "zerotier-one -d $ZT_HOME" >/dev/null 2>&1 || [ ! -f "$ZT_HOME/zerotier-one.port" ]; then
        log "Normalizing ZeroTier to $ZT_HOME"
        stop_all
        mkdir -p "$ZT_HOME"
        chmod 700 "$ZT_HOME" 2>/dev/null
        "$O" -d "$ZT_HOME" >/tmp/zt_start.log 2>&1 &
        sleep 20
    fi
    if [ ! -f "$ZT_HOME/zerotier-one.port" ]; then
        log "Retry persistent start"
        killall zerotier-one >/dev/null 2>&1
        sleep 3
        "$O" -d "$ZT_HOME" >/tmp/zt_start.log 2>&1 &
        sleep 20
    fi
}

install_pkg() {
    C="$(find_cli)"
    O="$(find_one)"
    if [ -z "$C" ] || [ -z "$O" ]; then
        command -v opkg >/dev/null 2>&1 && {
            opkg update >> "$LOG" 2>&1
            opkg install zerotier >> "$LOG" 2>&1
        }
    fi
}

ensure_fw() {
    if ! uci show firewall 2>/dev/null | grep -q "name='zerotier'"; then
        uci add firewall zone >/dev/null
        uci set firewall.@zone[-1].name='zerotier'
        uci set firewall.@zone[-1].input='ACCEPT'
        uci set firewall.@zone[-1].output='ACCEPT'
        uci set firewall.@zone[-1].forward='ACCEPT'
        uci set firewall.@zone[-1].masq='1'
        uci set firewall.@zone[-1].mtu_fix='1'
        uci add_list firewall.@zone[-1].network='zerotier'
        uci add firewall forwarding >/dev/null
        uci set firewall.@forwarding[-1].src='zerotier'
        uci set firewall.@forwarding[-1].dest='lan'
        uci add firewall forwarding >/dev/null
        uci set firewall.@forwarding[-1].src='lan'
        uci set firewall.@forwarding[-1].dest='zerotier'
        uci commit firewall
    fi
    /etc/init.d/firewall reload >/dev/null 2>&1
}

ensure_net() {
    I="$(zt_iface)"
    [ -z "$I" ] && return
    uci set network.zerotier='interface'
    uci set network.zerotier.proto='none'
    uci set network.zerotier.device="$I"
    uci commit network
    /etc/init.d/network reload >/dev/null 2>&1
}

run_status() {
    log ""
    log "Process:"
    ps | grep zerotier | grep -v grep >> "$LOG" 2>&1
    log ""
    log "ZeroTier info:"
    zt_cli info >> "$LOG" 2>&1
    log ""
    log "ZeroTier networks:"
    zt_cli listnetworks >> "$LOG" 2>&1
    [ -x "$STATUS_WORKER" ] && "$STATUS_WORKER" >/dev/null 2>&1
}

: > "$LOG"
log "Matrix ZeroTier $ACTION started at $(date)"
log "Persistent home: $ZT_HOME"

case "$ACTION" in
    restart)
        start_zt
        zt_cli join "$ZT_NETWORK_ID" >> "$LOG" 2>&1
        sleep 5
        ensure_net
        ensure_fw
        /etc/init.d/uhttpd restart >/dev/null 2>&1
        run_status
        ;;
    rejoin)
        start_zt
        zt_cli leave "$ZT_NETWORK_ID" >> "$LOG" 2>&1
        sleep 3
        zt_cli join "$ZT_NETWORK_ID" >> "$LOG" 2>&1
        sleep 10
        ensure_net
        ensure_fw
        /etc/init.d/uhttpd restart >/dev/null 2>&1
        run_status
        ;;
    repair|*)
        install_pkg
        start_zt
        zt_cli join "$ZT_NETWORK_ID" >> "$LOG" 2>&1
        sleep 10
        ensure_net
        ensure_fw
        /etc/init.d/uhttpd restart >/dev/null 2>&1
        run_status
        ;;
esac

log "Finished at $(date)"
[ -x "$STATUS_WORKER" ] && "$STATUS_WORKER" >/dev/null 2>&1
rm -f "$LOCK"
exit 0
