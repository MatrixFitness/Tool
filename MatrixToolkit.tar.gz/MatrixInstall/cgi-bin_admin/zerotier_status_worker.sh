#!/bin/sh
STATUS_FILE="/tmp/matrix_zerotier_status.cache"
ZT_NETWORK_ID="cf719fd5409699a2"
ZT_HOME="/usr/local/matrix/zerotier"

find_cli() { for p in /usr/bin/zerotier-cli /usr/local/usr/bin/zerotier-cli /usr/sbin/zerotier-cli; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-cli 2>/dev/null; }
find_one() { for p in /usr/bin/zerotier-one /usr/local/usr/bin/zerotier-one /usr/sbin/zerotier-one; do [ -x "$p" ] && { echo "$p"; return; }; done; command -v zerotier-one 2>/dev/null; }
zt_iface() { ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}'; }
zt_ip() { I="$(zt_iface)"; [ -n "$I" ] && ip -4 addr show "$I" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1; }
zt_cli() { C="$(find_cli)"; [ -n "$C" ] && "$C" -D"$ZT_HOME" "$@"; }

CLI="$(find_cli)"; ONE="$(find_one)"; IFACE="$(zt_iface)"; IP="$(zt_ip)"
PORT_FILE=""; [ -f "$ZT_HOME/zerotier-one.port" ] && PORT_FILE="$ZT_HOME/zerotier-one.port"
INFO="$([ -n "$CLI" ] && zt_cli info 2>&1)"
NETWORKS="$([ -n "$CLI" ] && zt_cli listnetworks 2>&1)"
NETWORK_LINE="$(echo "$NETWORKS" | grep "^200 listnetworks $ZT_NETWORK_ID" | tail -n1)"
[ -z "$NETWORK_LINE" ] && NETWORK_LINE="$(echo "$NETWORKS" | grep "$ZT_NETWORK_ID" | tail -n1)"
IP2="$(echo "$NETWORK_LINE" | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\//){split($i,a,"/"); print a[1]; exit}}')"
[ -z "$IP" ] && [ -n "$IP2" ] && IP="$IP2"
NODE="$(echo "$INFO" | awk '/^200 info/{print $3; exit}')"
VER="$(echo "$INFO" | awk '/^200 info/{print $4; exit}')"
ONLINE="$(echo "$INFO" | awk '/^200 info/{print $5; exit}')"
NET_STATUS="UNKNOWN"
echo "$NETWORK_LINE" | grep -q " OK " && NET_STATUS="OK"
echo "$NETWORK_LINE" | grep -q " ACCESS_DENIED " && NET_STATUS="ACCESS_DENIED"
echo "$NETWORK_LINE" | grep -q " REQUESTING_CONFIGURATION " && NET_STATUS="REQUESTING_CONFIGURATION"
HEALTH="WARNING"; REASON="Status unknown. Run Repair Everything if needed."
if [ -z "$CLI" ] || [ -z "$ONE" ]; then HEALTH="FAILED"; REASON="ZeroTier binaries missing."
elif ! pgrep -f zerotier-one >/dev/null 2>&1; then HEALTH="FAILED"; REASON="zerotier-one is not running."
elif echo "$INFO" | grep -q "missing port\|connection failed\|authtoken.secret"; then HEALTH="FAILED"; REASON="ZeroTier CLI cannot connect to persistent home $ZT_HOME."
elif [ "$NET_STATUS" = "OK" ] && [ -n "$IP" ]; then HEALTH="HEALTHY"; REASON="ZeroTier is online, authorized and has an IP."
elif [ "$NET_STATUS" = "OK" ]; then HEALTH="WARNING"; REASON="ZeroTier is authorized but no IP was detected yet."
elif [ "$NET_STATUS" = "ACCESS_DENIED" ]; then HEALTH="WARNING"; REASON="Device is joined but must be authorized in ZeroTier Central."
elif [ "$NET_STATUS" = "REQUESTING_CONFIGURATION" ]; then HEALTH="WARNING"; REASON="Device is waiting for ZeroTier Central configuration/authorization."
elif [ -n "$PORT_FILE" ]; then HEALTH="WARNING"; REASON="Daemon is running but network status is not ready."
fi
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="Unknown"
URL=""; [ -n "$IP" ] && URL="http://$IP:8080/"
cat > "$STATUS_FILE" <<EOF
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
HOST=$HOST
NETWORK_ID=$ZT_NETWORK_ID
ZT_HOME=$ZT_HOME
RUNTIME=$ZT_HOME
CLI=$CLI
ONE=$ONE
PORT_FILE=$PORT_FILE
NODE_ID=$NODE
VERSION=$VER
ONLINE=$ONLINE
IFACE=$IFACE
IP=$IP
REMOTE_URL=$URL
NET_STATUS=$NET_STATUS
HEALTH=$HEALTH
REASON=$REASON
INFO=$(printf '%s' "$INFO" | sed 's/=/&#61;/g')
NETWORK_LINE=$(printf '%s' "$NETWORK_LINE" | sed 's/=/&#61;/g')
EOF
chmod 666 "$STATUS_FILE" 2>/dev/null
