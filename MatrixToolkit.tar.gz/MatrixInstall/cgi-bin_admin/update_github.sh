#!/bin/sh

echo "Content-Type: text/html"
echo ""

rm -rf /tmp/MatrixToolkit
rm -f /tmp/MatrixToolkit.tar.gz

mkdir -p /tmp/MatrixToolkit

wget -O /tmp/MatrixToolkit.tar.gz 
https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz

if [ $? -ne 0 ]; then
echo "<h2>GitHub Update Failed</h2>"
echo "<p>Download failed.</p>"
exit 1
fi

tar -xzf /tmp/MatrixToolkit.tar.gz -C /tmp/MatrixToolkit

if [ $? -ne 0 ]; then
echo "<h2>GitHub Update Failed</h2>"
echo "<p>Archive extraction failed.</p>"
exit 1
fi

cp -f /tmp/MatrixToolkit/MatrixInstall/web/index.html 
/usr/local/matrix/web/index.html

cp -f /tmp/MatrixToolkit/MatrixInstall/web_admin/index.html 
/usr/local/matrix/web/admin/index.html

cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin/*.sh 
/usr/local/matrix/web/cgi-bin/

cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin_admin/*.sh 
/usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

/etc/init.d/uhttpd reload >/dev/null 2>&1

VERSION=$(grep "Matrix Admin v" /usr/local/matrix/web/admin/index.html | head -1)

echo "<html><body>"
echo "<h2>GitHub Update Completed</h2>"
echo "<p>$VERSION installed successfully.</p>"
echo "</body></html>"
