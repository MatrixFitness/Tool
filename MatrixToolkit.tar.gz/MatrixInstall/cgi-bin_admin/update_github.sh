#!/bin/sh

echo "Content-Type: text/html"
echo ""

rm -rf /tmp/MatrixToolkit
rm -f /tmp/MatrixToolkit.tar.gz

mkdir -p /tmp/MatrixToolkit

wget -O /tmp/MatrixToolkit.tar.gz \
https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz

if [ $? -ne 0 ]
then
    echo "<html><body>"
    echo "<h2>GitHub Update Failed</h2>"
    echo "<p>Download failed.</p>"
    echo "</body></html>"
    exit 1
fi

tar -xzf /tmp/MatrixToolkit.tar.gz -C /tmp/MatrixToolkit

if [ $? -ne 0 ]
then
    echo "<html><body>"
    echo "<h2>GitHub Update Failed</h2>"
    echo "<p>Archive extraction failed.</p>"
    echo "</body></html>"
    exit 1
fi

# Install web files
cp -f /tmp/MatrixToolkit/MatrixInstall/web/index.html \
      /usr/local/matrix/web/index.html

cp -f /tmp/MatrixToolkit/MatrixInstall/web_admin/index.html \
      /usr/local/matrix/web/admin/index.html

# Install CGI scripts
cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin/*.sh \
      /usr/local/matrix/web/cgi-bin/

cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin_admin/*.sh \
      /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

# Update version
if [ -f /tmp/MatrixToolkit/MatrixInstall/version.txt ]
then
    cp -f /tmp/MatrixToolkit/MatrixInstall/version.txt \
          /usr/local/matrix/version.txt
fi

# Update admin password
if [ -f /tmp/MatrixToolkit/MatrixInstall/admin_password.txt ]
then
    cp -f /tmp/MatrixToolkit/MatrixInstall/admin_password.txt \
          /usr/local/matrix/admin_password.txt
fi

# DO NOT overwrite clubname.txt

# Refresh Matrix CLI commands
ln -sf /usr/local/matrix/web/cgi-bin/update_github.sh \
      /usr/bin/matrix-update

ln -sf /usr/local/matrix/web/cgi-bin/matrix_full_test.sh \
      /usr/bin/matrix-test

ln -sf /usr/local/matrix/web/cgi-bin/certification_report.sh \
      /usr/bin/matrix-report

cat > /usr/bin/matrix-version << 'EOF'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF

chmod +x /usr/bin/matrix-version

# Reload webserver
/etc/init.d/uhttpd reload >/dev/null 2>&1

VERSION=$(cat /usr/local/matrix/version.txt 2>/dev/null)

echo "<html><body>"
echo "<h2>GitHub Update Completed</h2>"
echo "<p><b>Installed version:</b><br>$VERSION</p>"
echo "<hr>"
echo "<p>Matrix Toolkit updated successfully.</p>"
echo "</body></html>"