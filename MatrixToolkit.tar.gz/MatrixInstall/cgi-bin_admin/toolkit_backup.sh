#!/bin/sh

echo "Content-Type: text/html"
echo ""

BACKUPFILE="/usr/local/mnt/sda1/Backup/toolkit-backup-$(date +%Y%m%d-%H%M%S).tar.gz"

tar -czf "$BACKUPFILE" /usr/local/matrix /usr/local/matrix_admin 2>/dev/null

echo "<html>"
echo "<body style='font-family:Arial'>"

echo "<h1>Toolkit Backup</h1>"

if [ -f "$BACKUPFILE" ]
then
echo "<h2 style='color:green'>BACKUP GESLAAGD</h2>"
echo "<p>Backup opgeslagen als:</p>"
echo "<pre>$BACKUPFILE</pre>"
else
echo "<h2 style='color:red'>BACKUP MISLUKT</h2>"
fi

echo "<br>"
echo "<a href='/index.html'>Terug naar Admin</a>"

echo "</body>"
echo "</html>"
