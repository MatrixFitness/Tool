#!/bin/sh

echo "Content-Type: text/html"
echo ""

mkdir -p /usr/local/matrix/web/admin

# Toolkit pagina

cp -f /usr/local/mnt/sda1/MatrixInstall/web/index.html /usr/local/matrix/web/index.html

# Admin pagina

cp -f /usr/local/mnt/sda1/MatrixInstall/web_admin/index.html /usr/local/matrix/web/admin/index.html

# Normale CGI scripts

cp -f /usr/local/mnt/sda1/MatrixInstall/cgi-bin/*.sh /usr/local/matrix/web/cgi-bin/

# Admin CGI scripts

cp -f /usr/local/mnt/sda1/MatrixInstall/cgi-bin_admin/*.sh /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

# Webserver herladen

/etc/init.d/uhttpd reload >/dev/null 2>&1

echo "<html>"
echo "<head>"
echo "<meta charset='UTF-8'>"
echo "<meta http-equiv='refresh' content='3;url=/admin/' />"
echo "</head>"
echo "<body style='font-family:Arial'>"

echo "<h2>Toolkit succesvol bijgewerkt</h2>"
echo "<p>Toolkit pagina bijgewerkt.</p>"
echo "<p>Admin pagina bijgewerkt.</p>"
echo "<p>Toolkit scripts bijgewerkt.</p>"
echo "<p>Admin scripts bijgewerkt.</p>"
echo "<p>Webserver herladen.</p>"
echo "<br>"
echo "<p>Je wordt automatisch teruggestuurd...</p>"

echo "</body>"
echo "</html>"
