#!/bin/sh
LOG="/tmp/matrix_update_github.log"


# =====================================================
# MATRIX WIFI DEFAULT PROFILES UPDATE
# =====================================================
# Keep the master defaults current, but do not overwrite
# the active router-local matrix_wifi_profiles.conf.
if [ -f "/tmp/MatrixInstall/matrix_wifi_profiles.default" ]; then
    cp -f "/tmp/MatrixInstall/matrix_wifi_profiles.default" "/usr/local/matrix/matrix_wifi_profiles.default" 2>/dev/null
    chmod 666 "/usr/local/matrix/matrix_wifi_profiles.default" 2>/dev/null

    if [ ! -f "/usr/local/matrix/matrix_wifi_profiles.conf" ]; then
        cp -f "/usr/local/matrix/matrix_wifi_profiles.default" "/usr/local/matrix/matrix_wifi_profiles.conf" 2>/dev/null
        chmod 666 "/usr/local/matrix/matrix_wifi_profiles.conf" 2>/dev/null
    fi

    if [ ! -f "/usr/local/matrix/matrix_wifi_profiles.previous" ] && [ -f "/usr/local/matrix/matrix_wifi_profiles.conf" ]; then
        cp -f "/usr/local/matrix/matrix_wifi_profiles.conf" "/usr/local/matrix/matrix_wifi_profiles.previous" 2>/dev/null
        chmod 666 "/usr/local/matrix/matrix_wifi_profiles.previous" 2>/dev/null
    fi

    echo "WiFi default profiles updated." >> "${LOG:-/tmp/matrix_update_github.log}"
fi

