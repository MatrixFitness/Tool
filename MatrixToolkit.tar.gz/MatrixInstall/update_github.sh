#!/bin/sh
# Root copy placeholder. Runtime updater is cgi-bin/update_github.sh.
exec /usr/local/matrix/web/cgi-bin/update_github.sh "$@"

# Matrix WiFi Manager v66 update
fi

# Matrix WiFi Manager v67 update
if [ -f "/tmp/MatrixInstall/install_wifi_manager_v67.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_wifi_manager_v67.sh 2>/dev/null
    /tmp/MatrixInstall/install_wifi_manager_v67.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi
