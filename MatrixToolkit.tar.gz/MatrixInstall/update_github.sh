#!/bin/sh
# Root copy placeholder. Runtime updater is cgi-bin/update_github.sh.
exec /usr/local/matrix/web/cgi-bin/update_github.sh "$@"

# Matrix WiFi Manager v66 update
fi

# Matrix WiFi Manager v67 update
if [ -f "/tmp/MatrixInstall/install_wifi_manager_v67.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_wifi_manager_v67.sh 2>/dev/null
    /tmp/MatrixInstall/install_wifi_manager_v67.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi

# Matrix ZeroTier Repair v68 update
fi

# Matrix ZeroTier Manager v69 update
fi

# Matrix Toolkit v70 components update
if [ -f "/tmp/MatrixInstall/install_matrix_toolkit_v70.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_matrix_toolkit_v70.sh 2>/dev/null
    /tmp/MatrixInstall/install_matrix_toolkit_v70.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi

# Matrix ZeroTier runtime fix v70.1 update
if [ -f "/tmp/MatrixInstall/install_zerotier_runtime_v701.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_zerotier_runtime_v701.sh 2>/dev/null
    /tmp/MatrixInstall/install_zerotier_runtime_v701.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi

# Matrix ZeroTier root worker v70.2 update
if [ -f "/tmp/MatrixInstall/install_zerotier_root_worker_v702.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_zerotier_root_worker_v702.sh 2>/dev/null
    /tmp/MatrixInstall/install_zerotier_root_worker_v702.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi

# Matrix ZeroTier status parser fix v70.3 update
if [ -f "/tmp/MatrixInstall/install_zerotier_status_v703.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_zerotier_status_v703.sh 2>/dev/null
    /tmp/MatrixInstall/install_zerotier_status_v703.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi
