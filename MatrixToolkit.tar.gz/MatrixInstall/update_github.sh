#!/bin/sh
# Root copy placeholder. Runtime updater is cgi-bin/update_github.sh.
exec /usr/local/matrix/web/cgi-bin/update_github.sh "$@"

# Matrix ZeroTier Live Status v71.1 update
if [ -f "/tmp/MatrixInstall/install_zerotier_live_status_v711.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_zerotier_live_status_v711.sh 2>/dev/null
    /tmp/MatrixInstall/install_zerotier_live_status_v711.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi

# Matrix ZeroTier Live Status v71.2 cache autofill update
if [ -f "/tmp/MatrixInstall/install_zerotier_live_status_v712.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_zerotier_live_status_v712.sh 2>/dev/null
    /tmp/MatrixInstall/install_zerotier_live_status_v712.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi

# Matrix ZeroTier Persistent Identity v72 update
if [ -f "/tmp/MatrixInstall/install_zerotier_persistent_v72.sh" ]; then
    chmod +x /tmp/MatrixInstall/install_zerotier_persistent_v72.sh 2>/dev/null
    /tmp/MatrixInstall/install_zerotier_persistent_v72.sh >> "${LOG:-/tmp/matrix_update_github.log}" 2>&1 || true
fi
