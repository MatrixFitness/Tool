#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ROOT UPDATE WORKER
# =====================================================
# This script must run as root from cron.
# The Admin web page and matrix-update CLI only create
# /tmp/matrix_update_request.
# This worker performs the real GitHub update with root rights.
# =====================================================

REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
LOG="/tmp/matrix_update_github.log"
UPDATER="/usr/local/matrix/web/cgi-bin/update_github.sh"

[ -f "$REQ" ] || exit 0

# Prevent two workers at the same time.
if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        exit 0
    fi
    rm -f "$LOCK"
fi

echo "$$" > "$LOCK"
rm -f "$REQ"

{
    echo "Matrix root update worker started at: $(date)"
    echo ""

    if [ ! -x "$UPDATER" ]; then
        echo "ERROR: updater not found or not executable: $UPDATER"
        RC=1
    else
        MATRIX_UPDATE_BACKGROUND=1 sh "$UPDATER" run
        RC=$?
    fi

    echo ""
    echo "Update exit code: $RC"
    echo "Matrix root update worker finished at: $(date)"
} >> "$LOG" 2>&1

if [ -f "/usr/local/matrix/web/cgi-bin/update_github.sh.new" ]; then
    cp -f "/usr/local/matrix/web/cgi-bin/update_github.sh.new" "/usr/local/matrix/web/cgi-bin/update_github.sh"
    chmod +x "/usr/local/matrix/web/cgi-bin/update_github.sh"
    rm -f "/usr/local/matrix/web/cgi-bin/update_github.sh.new"
    echo "Updater script promoted for next update." >> "$LOG"
fi

sync
rm -f "$LOCK"
exit "$RC"
