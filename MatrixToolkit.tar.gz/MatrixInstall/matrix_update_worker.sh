#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ROOT UPDATE WORKER
# =====================================================
# This script must run as root from cron.
# The Admin web page only creates /tmp/matrix_update_request.
# This worker performs the real GitHub update with root rights.
# =====================================================

REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
LOG="/tmp/matrix_update_github.log"
UPDATER="/usr/local/matrix/web/cgi-bin/update_github.sh"

[ -f "$REQ" ] || exit 0

# Prevent two updates at the same time.
if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        exit 0
    fi
fi

echo "$$" > "$LOCK"
rm -f "$REQ"

{
    echo "Matrix root update worker started at: $(date)"
    echo ""

    if [ ! -x "$UPDATER" ]; then
        echo "ERROR: updater not found or not executable: $UPDATER"
        echo ""
        echo "Matrix root update worker finished at: $(date)"
        rm -f "$LOCK"
        exit 1
    fi

    "$UPDATER" run | grep -v "<button"
    RC=$?

    echo ""
    echo "Update exit code: $RC"
    echo "Matrix root update worker finished at: $(date)"
} > "$LOG" 2>&1

sync
rm -f "$LOCK"
exit 0
