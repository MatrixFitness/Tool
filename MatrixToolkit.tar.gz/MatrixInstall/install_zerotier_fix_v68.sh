#!/bin/sh
# Install Matrix ZeroTier Repair v68

SRC="$(dirname "$0")"
WEB="/usr/local/matrix/web/cgi-bin"
MATRIX="/usr/local/matrix"
mkdir -p "$WEB" "$MATRIX"

if [ -f "$SRC/cgi-bin/zerotier_fix.sh" ]; then
    cp -f "$SRC/cgi-bin/zerotier_fix.sh" "$WEB/zerotier_fix.sh"
    chmod +x "$WEB/zerotier_fix.sh"
fi

cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
/usr/local/matrix/web/cgi-bin/zerotier_fix.sh "$@"
EOF
chmod +x /usr/local/bin/matrix-zerotier-fix

echo "Matrix ZeroTier Repair v68 installed."
