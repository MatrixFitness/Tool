#!/bin/sh
# Matrix WiFi Manager v60 Band installer - for MatrixInstall repo

SRC="$(dirname "$0")"
WEB="/usr/local/matrix/web/cgi-bin"

mkdir -p "$WEB" /usr/local/matrix

for f in wifi_manager.sh wifi_profile_edit.sh wifi_profile_save.sh wifi_profile.sh wifi_profiles_restore_previous.sh wifi_profiles_reset.sh; do
    if [ -f "$SRC/cgi-bin/$f" ]; then
        cp -f "$SRC/cgi-bin/$f" "$WEB/$f"
        chmod +x "$WEB/$f"
    elif [ -f "$SRC/$f" ]; then
        cp -f "$SRC/$f" "$WEB/$f"
        chmod +x "$WEB/$f"
    fi
done

if [ -f "$SRC/matrix_wifi_profiles.default" ]; then
    cp -f "$SRC/matrix_wifi_profiles.default" /usr/local/matrix/matrix_wifi_profiles.default
fi

if [ ! -f /usr/local/matrix/matrix_wifi_profiles.conf ]; then
    cp -f /usr/local/matrix/matrix_wifi_profiles.default /usr/local/matrix/matrix_wifi_profiles.conf 2>/dev/null
fi

if [ ! -f /usr/local/matrix/matrix_wifi_profiles.previous ] && [ -f /usr/local/matrix/matrix_wifi_profiles.conf ]; then
    cat /usr/local/matrix/matrix_wifi_profiles.conf > /usr/local/matrix/matrix_wifi_profiles.previous 2>/dev/null
fi

chmod 666 /usr/local/matrix/matrix_wifi_profiles.conf /usr/local/matrix/matrix_wifi_profiles.default /usr/local/matrix/matrix_wifi_profiles.previous 2>/dev/null

echo "Matrix WiFi Manager v60 Band installed."
