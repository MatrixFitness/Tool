#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - POST UPDATE TASKS
# =====================================================
# Safe to run multiple times.
# Creates persistent storage and fixes CGI permissions.
# WiFi Manager v63 installation/migration is handled by install.sh and update_github.sh.
# =====================================================

MATRIX_DIR="/usr/local/matrix"
SURVEY_DIR="$MATRIX_DIR/survey"

echo "Running Matrix post-update tasks..."

mkdir -p "$SURVEY_DIR"
chmod 777 "$SURVEY_DIR" 2>/dev/null

[ -f "$SURVEY_DIR/locations.txt" ] || touch "$SURVEY_DIR/locations.txt"
[ -f "$SURVEY_DIR/completed.txt" ] || touch "$SURVEY_DIR/completed.txt"
[ -f "$SURVEY_DIR/wifi_survey_results.csv" ] || touch "$SURVEY_DIR/wifi_survey_results.csv"
[ -f "$SURVEY_DIR/survey_state.txt" ] || touch "$SURVEY_DIR/survey_state.txt"
[ -f "$SURVEY_DIR/selected_locations.txt" ] || touch "$SURVEY_DIR/selected_locations.txt"
[ -f "$SURVEY_DIR/completed_locations.txt" ] || touch "$SURVEY_DIR/completed_locations.txt"

chmod 666 "$SURVEY_DIR"/*.txt "$SURVEY_DIR"/*.csv 2>/dev/null
chmod +x "$MATRIX_DIR/web/cgi-bin"/*.sh 2>/dev/null
chmod +x "$MATRIX_DIR/adminweb/cgi-bin"/*.sh 2>/dev/null
chmod 666 "$MATRIX_DIR/matrix_wifi_profiles.conf" "$MATRIX_DIR/matrix_wifi_profiles.default" "$MATRIX_DIR/matrix_wifi_profiles.previous" 2>/dev/null

echo "OK: survey storage ready at $SURVEY_DIR"
echo "OK: post-update tasks completed."
exit 0
