#!/bin/sh
# Install Matrix WiFi Manager v63 integrated interface control

WEB="/usr/local/matrix/web/cgi-bin"
mkdir -p "$WEB"

if [ -f "$WEB/wifi_manager.sh" ]; then
    cp -f "$WEB/wifi_manager.sh" "$WEB/wifi_manager.sh.bak.v63.$(date +%Y%m%d%H%M%S)"
fi

cp -f wifi_manager.sh "$WEB/wifi_manager.sh"
chmod +x "$WEB/wifi_manager.sh"

echo "Matrix WiFi Manager v63 installed."
echo "Open: http://<router-ip>:8080/cgi-bin/wifi_manager.sh"
