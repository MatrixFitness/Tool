#!/bin/sh

echo "Content-Type: text/html"
echo ""

if [ -f /usr/local/matrix/wifi_backup.conf ]
then

    OLDSSID=$(grep "ssid='" /usr/local/matrix/wifi_backup.conf | cut -d"'" -f2)
    OLDKEY=$(grep "key='" /usr/local/matrix/wifi_backup.conf | cut -d"'" -f2)
    OLDENC=$(grep "encryption='" /usr/local/matrix/wifi_backup.conf | cut -d"'" -f2)

    uci set wireless.1.ssid="$OLDSSID"
    uci set wireless.1.key="$OLDKEY"
    uci set wireless.1.encryption="$OLDENC"

    uci commit wireless

    wifi reload

    echo "<html><body>"
    echo "<h2>Original WiFi Restored</h2>"
    echo "<p>$OLDSSID</p>"
    echo "</body></html>"

else

    echo "<html><body>"
    echo "<h2>No Backup Found</h2>"
    echo "</body></html>"

fi