#!/bin/sh

echo "Content-Type: text/html"
echo ""

LOCATION="$(echo "$QUERY_STRING" | sed -n 's/.*location=\(.*\)/\1/p' | sed 's/%20/ /g')"

CSV="/usr/local/matrix/wifi_survey.csv"

SSID=$(iwinfo wlan0-3 info | grep ESSID | cut -d'"' -f2)

SIGNAL=$(iwinfo wlan0-3 info | grep Signal | awk '{print $2}')

QUALITY=$(iwinfo wlan0-3 info | grep "Link Quality" | awk '{print $3}')

PINGTEST="FAIL"
ping -c 1 8.8.8.8 >/dev/null 2>&1 && PINGTEST="PASS"

echo "$LOCATION,$SSID,$SIGNAL,$QUALITY,$PINGTEST" >> "$CSV"

echo "<html><body>"
echo "<h2>Measurement Saved</h2>"
echo "<p>$LOCATION</p>"
echo "<p>Signal: $SIGNAL</p>"
echo "<a href='/wifi_survey.html'>Back</a>"
echo "</body></html>"