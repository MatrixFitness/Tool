#!/bin/sh

echo "Content-Type: text/html"
echo ""

SSID=$(uci get wireless.1.ssid 2>/dev/null)

CLIENT_IF=$(ifstatus wan1 | grep '"device"' | head -1 | cut -d'"' -f4)

IPADDR=$(ifstatus wan1 | grep '"address"' | head -1 | cut -d'"' -f4)

IWINFO_OUT=$(iwinfo "$CLIENT_IF" info)

SIGNAL=$(echo "$IWINFO_OUT" | grep "Signal:" | awk '{print $2}')

QUALITY=$(echo "$IWINFO_OUT" | grep "Link Quality:" | awk '{print $6}')

BITRATE=$(echo "$IWINFO_OUT" | grep "Bit Rate:" | awk '{print $3" "$4}')

# Signal rating

SIGNAL_RATING="Unknown"
SIGNAL_COMMENT=""

if [ -n "$SIGNAL" ]
then
if [ "$SIGNAL" -ge "-50" ]
then
SIGNAL_RATING="Excellent"
SIGNAL_COMMENT="Excellent WiFi coverage. This location should provide very reliable connectivity for Matrix and EGYM equipment."
elif [ "$SIGNAL" -ge "-60" ]
then
SIGNAL_RATING="Good"
SIGNAL_COMMENT="Good WiFi coverage. Suitable for normal operation."
elif [ "$SIGNAL" -ge "-70" ]
then
SIGNAL_RATING="Fair"
SIGNAL_COMMENT="Signal is acceptable but could be improved. Consider testing closer to an access point."
else
SIGNAL_RATING="Weak"
SIGNAL_COMMENT="Weak WiFi signal. Connectivity issues may occur. Improving WiFi coverage is recommended."
fi
fi

# Connectivity tests

INTERNET="FAIL"
DNS="FAIL"
MATRIX="FAIL"

ping -c 1 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"

nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"

curl -s --connect-timeout 10 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

# HTML Output

echo "<html>"
echo "<head>"
echo "<title>Customer WiFi Survey Report</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;background:#f5f5f5;}"
echo "table{border-collapse:collapse;width:800px;background:white;}"
echo "th{background:#005a9c;color:white;padding:8px;}"
echo "td{border:1px solid #cccccc;padding:8px;}"
echo "td:first-child{font-weight:bold;background:#f5f5f5;width:250px;}"
echo "button{padding:10px 20px;font-size:14px;margin-right:10px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Survey Report</h2>"

echo "<table>"
echo "<tr><th colspan='2'>WiFi Results</th></tr>"
echo "<tr><td>SSID</td><td>$SSID</td></tr>"
echo "<tr><td>IP Address</td><td>$IPADDR</td></tr>"
echo "<tr><td>Signal Strength</td><td>$SIGNAL dBm</td></tr>"
echo "<tr><td>Signal Rating</td><td>$SIGNAL_RATING</td></tr>"
echo "<tr><td>Link Quality</td><td>$QUALITY</td></tr>"
echo "<tr><td>Bit Rate</td><td>$BITRATE</td></tr>"
echo "</table>"

echo "<br>"

echo "<table>"
echo "<tr><th colspan='2'>Signal Assessment</th></tr>"
echo "<tr><td>Evaluation</td><td>$SIGNAL_COMMENT</td></tr>"
echo "</table>"

echo "<br>"

echo "<table>"
echo "<tr><th colspan='2'>Connectivity Tests</th></tr>"
echo "<tr><td>Internet Access</td><td>$INTERNET</td></tr>"
echo "<tr><td>DNS Resolution</td><td>$DNS</td></tr>"
echo "<tr><td>Matrix Cloud Connectivity</td><td>$MATRIX</td></tr>"
echo "</table>"

echo "<br>"

echo "<button onclick='window.print()'>Save as PDF</button>"
echo "<button onclick="location.href='/wifi_survey.html'">Back</button>"

echo "</body>"
echo "</html>"
