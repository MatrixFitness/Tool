#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

LOCATION=$(echo "$QUERY_STRING" | sed -n 's/.*location=\([^&]*\).*/\1/p' | sed 's/%20/ /g;s/%2F/\//g;s/%26/\&/g')

SSID=$(uci get wireless.1.ssid 2>/dev/null)
CLIENT_IF=$(ifstatus wan1 | grep '"device"' | head -1 | cut -d'"' -f4)
IPADDR=$(ifstatus wan1 | grep '"address"' | head -1 | cut -d'"' -f4)
IWINFO_OUT=$(iwinfo "$CLIENT_IF" info 2>/dev/null)
SIGNAL=$(echo "$IWINFO_OUT" | grep "Signal:" | awk '{print $2}')
QUALITY=$(echo "$IWINFO_OUT" | grep "Link Quality:" | awk '{print $6}')
BITRATE=$(echo "$IWINFO_OUT" | grep "Bit Rate:" | awk '{print $3" "$4}')
DATE=$(date "+%Y-%m-%d %H:%M:%S")

SIGNAL_RATING="Unknown"
SIGNAL_COMMENT=""
if [ -n "$SIGNAL" ]; then
  if [ "$SIGNAL" -ge "-50" ]; then
    SIGNAL_RATING="Excellent"; SIGNAL_COMMENT="Excellent WiFi coverage. This location should provide very reliable connectivity for Matrix and EGYM equipment."
  elif [ "$SIGNAL" -ge "-60" ]; then
    SIGNAL_RATING="Good"; SIGNAL_COMMENT="Good WiFi coverage. Suitable for normal operation."
  elif [ "$SIGNAL" -ge "-70" ]; then
    SIGNAL_RATING="Fair"; SIGNAL_COMMENT="WiFi coverage is acceptable but could be improved."
  else
    SIGNAL_RATING="Weak"; SIGNAL_COMMENT="WiFi coverage is weak. Additional WiFi coverage is recommended."
  fi
fi

INTERNET="FAIL"; DNS="FAIL"; MATRIX="FAIL"
ping -c 1 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"
nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"
curl -s --connect-timeout 10 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

OVERALL="PASS"
[ "$INTERNET" = "FAIL" ] && OVERALL="FAIL"
[ "$DNS" = "FAIL" ] && OVERALL="FAIL"
[ "$MATRIX" = "FAIL" ] && OVERALL="FAIL"

case "$SIGNAL_RATING" in
Excellent) RECOMMENDATION="Excellent WiFi coverage. This location is fully suitable for Matrix and EGYM connected equipment. No improvements are required.";;
Good) RECOMMENDATION="Good WiFi coverage. This location is suitable for normal operation of Matrix and EGYM connected equipment.";;
Fair) RECOMMENDATION="WiFi coverage is acceptable but could be improved. Equipment should function correctly, however improved coverage may increase reliability.";;
Weak) RECOMMENDATION="WiFi coverage is weak. Additional WiFi coverage is recommended before installing connected equipment.";;
*) RECOMMENDATION="No signal rating available.";;
esac

enc(){ echo "$1" | sed 's/ /%20/g;s/&/%26/g;s/\//%2F/g'; }
SAVE_URL="/cgi-bin/save_measurement.sh?location=$(enc "$LOCATION")&ssid=$(enc "$SSID")&ipaddr=$(enc "$IPADDR")&signal=$(enc "$SIGNAL")&rating=$(enc "$SIGNAL_RATING")&quality=$(enc "$QUALITY")&bitrate=$(enc "$BITRATE")&internet=$INTERNET&dns=$DNS&matrix=$MATRIX"

cat <<HTML
<html><head><title>Customer WiFi Survey Report</title>
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5;}table{border-collapse:collapse;width:800px;background:white;margin-bottom:15px;}th{background:#005a9c;color:white;padding:8px;}td{border:1px solid #cccccc;padding:8px;}td:first-child{font-weight:bold;background:#f5f5f5;width:250px;}button{padding:10px 20px;font-size:14px;margin-right:10px;border:0;border-radius:5px;background:#005a9c;color:white;cursor:pointer}.secondary{background:#666}</style>
</head><body>
<h2>Customer WiFi Survey Report</h2>
<table><tr><th colspan='2'>WiFi Results</th></tr><tr><td>Location Tested</td><td>$LOCATION</td></tr><tr><td>SSID</td><td>$SSID</td></tr><tr><td>IP Address</td><td>$IPADDR</td></tr><tr><td>Signal Strength</td><td>$SIGNAL dBm</td></tr><tr><td>Signal Rating</td><td>$SIGNAL_RATING</td></tr><tr><td>Link Quality</td><td>$QUALITY</td></tr><tr><td>Bit Rate</td><td>$BITRATE</td></tr></table>
<table><tr><th colspan='2'>Survey Information</th></tr><tr><td>Survey Date</td><td>$DATE</td></tr><tr><td>Overall Result</td><td>$OVERALL</td></tr></table>
<table><tr><th colspan='2'>Signal Assessment</th></tr><tr><td>Rating</td><td>$SIGNAL_RATING</td></tr><tr><td>Evaluation</td><td>$SIGNAL_COMMENT</td></tr></table>
<table><tr><th colspan='2'>Recommendation</th></tr><tr><td>Assessment</td><td>$RECOMMENDATION</td></tr></table>
<table><tr><th colspan='2'>Connectivity Tests</th></tr><tr><td>Internet Access</td><td>$INTERNET</td></tr><tr><td>DNS Resolution</td><td>$DNS</td></tr><tr><td>Matrix Cloud Connectivity</td><td>$MATRIX</td></tr></table>
<button onclick='window.print()'>Save as PDF</button>
<button onclick="window.location='$SAVE_URL'">Save Measurement</button>
<button class="secondary" onclick="window.location='/cgi-bin/next_location.sh'">Back to Progress</button>
<button class="secondary" onclick="window.location='/cgi-bin/final_report.sh'">Finish Survey</button>
<br><br><hr><small>Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE<br>$COMPANY<br>Created by $AUTHOR<br>$EMAIL<br>$MESSAGE</small>
</body></html>
HTML
