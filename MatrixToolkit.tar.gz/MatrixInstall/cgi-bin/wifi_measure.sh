#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

LOCATION=$(echo "$QUERY_STRING" | sed -n 's/.*location=\([^&]*\).*/\1/p' | sed 's/%20/ /g;s/%2F/\//g;s/%26/\&/g;s/%28/(/g;s/%29/)/g;s/+/ /g')

SSID=$(uci get wireless.1.ssid 2>/dev/null)
CLIENT_IF=$(ifstatus wan1 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)
IPADDR=$(ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)
IWINFO_OUT=$(iwinfo "$CLIENT_IF" info 2>/dev/null)
SIGNAL=$(echo "$IWINFO_OUT" | grep "Signal:" | awk '{print $2}')
QUALITY=$(echo "$IWINFO_OUT" | grep "Link Quality:" | awk '{print $6}')
BITRATE=$(echo "$IWINFO_OUT" | grep "Bit Rate:" | awk '{print $3" "$4}')
BSSID=$(echo "$IWINFO_OUT" | sed -n 's/.*Access Point: *\([0-9A-Fa-f:][0-9A-Fa-f:]*\).*/\1/p' | head -1)
CHANNEL=$(echo "$IWINFO_OUT" | sed -n 's/.*Channel: *\([0-9][0-9]*\).*/\1/p' | head -1)
FREQ=$(echo "$IWINFO_OUT" | sed -n 's/.*Frequency: *\([0-9.][0-9.]*\).*/\1/p' | head -1)
[ -z "$CHANNEL" ] && CHANNEL=$(echo "$IWINFO_OUT" | sed -n 's/.*(Channel *\([0-9][0-9]*\)).*/\1/p' | head -1)

BAND="Unknown"
if echo "$FREQ" | grep -q '^2\.'; then BAND="2.4 GHz"; fi
if echo "$FREQ" | grep -q '^5\.'; then BAND="5 GHz"; fi
if echo "$FREQ" | grep -q '^6\.'; then BAND="6 GHz"; fi
if [ "$BAND" = "Unknown" ] && echo "$CHANNEL" | grep -q '^[0-9][0-9]*$'; then
  if [ "$CHANNEL" -le 14 ]; then BAND="2.4 GHz"; else BAND="5 GHz"; fi
fi
[ -z "$BSSID" ] && BSSID="Unknown"
[ -z "$CHANNEL" ] && CHANNEL="Unknown"

OUI=$(echo "$BSSID" | tr 'a-z' 'A-Z' | cut -d: -f1-3)
AP_VENDOR="Unknown"
case "$OUI" in
  24:5A:4C|44:D9:E7|78:8A:20|F0:9F:C2|AC:8B:A9|DC:9F:DB|18:E8:29|FC:EC:DA) AP_VENDOR="Ubiquiti" ;;
  9C:1C:12|20:4C:03|D8:C7:C8|6C:F3:7F|B0:B8:67|34:3A:20) AP_VENDOR="Aruba / HPE" ;;
  00:1B:54|00:1E:13|00:23:04|F4:CF:E2|70:10:5C|A4:6C:2A|2C:3F:38) AP_VENDOR="Cisco" ;;
  50:C7:BF|D8:0D:17|30:DE:4B|14:CC:20|68:FF:7B|C0:25:E9|E8:48:B8) AP_VENDOR="TP-Link" ;;
  C8:AA:21|2C:5D:93|58:B6:33|84:18:3A) AP_VENDOR="Ruckus" ;;
  00:0C:43|00:18:E7|00:26:5A|40:A5:EF|50:D4:F7) AP_VENDOR="MikroTik" ;;
  00:90:4C|B8:27:EB|E4:5F:01|DC:A6:32) AP_VENDOR="Generic / Broadcom" ;;
  Unknown) AP_VENDOR="Unknown" ;;
esac
DATE=$(date "+%Y-%m-%d %H:%M:%S")

# Normalize the signal value to a clean number.
# Example: "-46", "-46 dBm" or "-46dBm" all become "-46".
SIGNAL_NUM=$(echo "$SIGNAL" | sed 's/[^0-9-]//g')

SIGNAL_RATING="Unknown"
SIGNAL_COMMENT="No signal value was available. Check whether the router is connected as WiFi client."
if echo "$SIGNAL_NUM" | grep -q '^-*[0-9][0-9]*$'; then
  # Important: dBm values are negative. -46 is better than -70.
  if [ "$SIGNAL_NUM" -ge -50 ]; then
    SIGNAL_RATING="Excellent"
    SIGNAL_COMMENT="Excellent WiFi coverage. This location should provide very reliable connectivity for Matrix and EGYM equipment."
  elif [ "$SIGNAL_NUM" -ge -60 ]; then
    SIGNAL_RATING="Good"
    SIGNAL_COMMENT="Good WiFi coverage. Suitable for normal operation."
  elif [ "$SIGNAL_NUM" -ge -70 ]; then
    SIGNAL_RATING="Fair"
    SIGNAL_COMMENT="WiFi coverage is acceptable but could be improved. This location may work but has less margin for roaming or interference."
  else
    SIGNAL_RATING="Weak"
    SIGNAL_COMMENT="WiFi coverage is weak. Additional WiFi coverage or a better AP position is recommended before installing connected equipment."
  fi
fi

INTERNET="FAIL"; DNS="FAIL"; MATRIX="FAIL"
ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"
nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"
curl -s --connect-timeout 10 --max-time 15 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

PING_OUT=$(ping -c 5 -W 2 8.8.8.8 2>&1)
# BusyBox ping example:
# 5 packets transmitted, 5 packets received, 0% packet loss
# round-trip min/avg/max = 5.008/5.109/5.206 ms
PACKET_LOSS=$(echo "$PING_OUT" | sed -n 's/.*received, *\([0-9][0-9]*%\) packet loss.*/\1/p' | head -1)
LATENCY_AVG=$(echo "$PING_OUT" | awk -F'= ' '/round-trip|rtt/ {split($2,a,"/"); print a[2]}' | sed 's/ ms//g' | head -1)
[ -z "$PACKET_LOSS" ] && PACKET_LOSS="Unknown"
[ -z "$LATENCY_AVG" ] && LATENCY_AVG="Unknown"

SPEED_URL="https://speed.cloudflare.com/__down?bytes=5000000"
SPEED_TMP="/tmp/matrix_wifi_speedtest.bin"
SPEED_RESULT=$(curl -L -k -o "$SPEED_TMP" -w "%{speed_download} %{time_total} %{http_code}" --connect-timeout 10 --max-time 30 "$SPEED_URL" 2>/dev/null)
rm -f "$SPEED_TMP" 2>/dev/null
SPEED_BYTES=$(echo "$SPEED_RESULT" | awk '{print $1}')
SPEED_TIME=$(echo "$SPEED_RESULT" | awk '{print $2}')
SPEED_CODE=$(echo "$SPEED_RESULT" | awk '{print $3}')
DOWNLOAD_MBPS="Unknown"
if echo "$SPEED_BYTES" | grep -q '^[0-9]'; then
  DOWNLOAD_MBPS=$(awk "BEGIN {printf \"%.2f\", ($SPEED_BYTES*8)/1000000}")
fi

SPEED_RATING="Unknown"
SPEED_COMMENT="Download throughput could not be measured. Internet may still work but throughput was not available during this test."
if [ "$DOWNLOAD_MBPS" != "Unknown" ]; then
  SPEED_INT=$(echo "$DOWNLOAD_MBPS" | cut -d'.' -f1)
  if [ "$SPEED_INT" -ge 50 ]; then
    SPEED_RATING="Excellent"
    SPEED_COMMENT="Excellent throughput. Suitable for updates, HD streaming, Virtual Active/iFIT and larger deployments."
  elif [ "$SPEED_INT" -ge 20 ]; then
    SPEED_RATING="Good"
    SPEED_COMMENT="Good throughput for normal Matrix Fitness equipment and supported connected solutions and most updates."
  elif [ "$SPEED_INT" -ge 10 ]; then
    SPEED_RATING="Fair"
    SPEED_COMMENT="Usable throughput. Large updates and streaming may take longer."
  elif [ "$SPEED_INT" -ge 5 ]; then
    SPEED_RATING="Poor"
    SPEED_COMMENT="Low throughput. Basic connectivity may work, but update and media performance can be poor."
  else
    SPEED_RATING="Critical"
    SPEED_COMMENT="Critical throughput. This location is not recommended until WiFi or internet capacity is improved."
  fi
fi

QUALITY_RATING="Unknown"
QUALITY_COMMENT="Network quality could not be fully measured."
if [ "$LATENCY_AVG" != "Unknown" ]; then
  LAT_INT=$(echo "$LATENCY_AVG" | cut -d'.' -f1 | sed 's/[^0-9]//g')
  LOSS_INT=$(echo "$PACKET_LOSS" | sed 's/[^0-9]//g')
  [ -z "$LAT_INT" ] && LAT_INT=9999
  [ -z "$LOSS_INT" ] && LOSS_INT=9999
  if [ "$LOSS_INT" -eq 0 ] && [ "$LAT_INT" -lt 20 ]; then
    QUALITY_RATING="Excellent"
    QUALITY_COMMENT="Very responsive connection with no packet loss. This is ideal for Matrix Fitness cloud services and supported internet-connected equipment."
  elif [ "$LOSS_INT" -le 1 ] && [ "$LAT_INT" -lt 50 ]; then
    QUALITY_RATING="Good"
    QUALITY_COMMENT="Stable connection. Latency and packet loss are suitable for Matrix Fitness equipment."
  elif [ "$LOSS_INT" -le 3 ] && [ "$LAT_INT" -lt 100 ]; then
    QUALITY_RATING="Fair"
    QUALITY_COMMENT="Usable but with attention points. Small packet loss or higher latency can cause occasional delay."
  elif [ "$LOSS_INT" -le 5 ] && [ "$LAT_INT" -lt 200 ]; then
    QUALITY_RATING="Poor"
    QUALITY_COMMENT="Unstable connection. Investigate WiFi interference AP load roaming or WAN stability."
  else
    QUALITY_RATING="Critical"
    QUALITY_COMMENT="Critical stability issue. Packet loss or high latency must be fixed before installation."
  fi
fi

OVERALL="PASS"
[ "$INTERNET" = "FAIL" ] && OVERALL="FAIL"
[ "$DNS" = "FAIL" ] && OVERALL="FAIL"
[ "$MATRIX" = "FAIL" ] && OVERALL="FAIL"
[ "$SIGNAL_RATING" = "Weak" ] && OVERALL="ATTENTION"
[ "$SPEED_RATING" = "Poor" ] && OVERALL="ATTENTION"
[ "$SPEED_RATING" = "Critical" ] && OVERALL="FAIL"
[ "$QUALITY_RATING" = "Poor" ] && OVERALL="ATTENTION"
[ "$QUALITY_RATING" = "Critical" ] && OVERALL="FAIL"

case "$OVERALL" in
PASS) RECOMMENDATION="This location is suitable. Signal connectivity and network quality are acceptable for Matrix Fitness equipment and supported connected solutions.";;
ATTENTION) RECOMMENDATION="This location works but has attention points. Improve WiFi coverage or reduce interference if equipment will be used here permanently.";;
FAIL) RECOMMENDATION="This location is not recommended until the failing network items are solved. Check internet DNS Matrix Fitness cloud access signal and packet loss.";;
*) RECOMMENDATION="Review the measured values before installing equipment.";;
esac


rating_class(){
  case "$1" in
    Excellent|PASS) echo "g1";;
    Good) echo "g2";;
    Fair|ATTENTION) echo "y";;
    Poor|Weak) echo "o";;
    Critical|FAIL) echo "r";;
    *) echo "";;
  esac
}
SIG_DOT=$(rating_class "$SIGNAL_RATING")
SPEED_DOT=$(rating_class "$SPEED_RATING")
QUALITY_DOT=$(rating_class "$QUALITY_RATING")
OVERALL_DOT=$(rating_class "$OVERALL")


# Roaming assessment based on measured signal and band.
ROAMING_ASSESSMENT="Unknown"
if echo "$SIGNAL_NUM" | grep -q '^-*[0-9][0-9]*$'; then
  if [ "$SIGNAL_NUM" -ge -60 ]; then
    ROAMING_ASSESSMENT="Good - connected to a suitable access point"
  elif [ "$SIGNAL_NUM" -ge -70 ]; then
    ROAMING_ASSESSMENT="Attention - signal is acceptable but roaming should be checked"
  else
    ROAMING_ASSESSMENT="Poor - device may be connected to a distant access point"
  fi
fi
if [ "$BAND" = "2.4 GHz" ] && [ "$SIGNAL_RATING" = "Excellent" ]; then
  ROAMING_ASSESSMENT="Good - stable 2.4 GHz connection measured"
fi

enc(){ echo "$1" | sed 's/%/%25/g;s/ /%20/g;s/&/%26/g;s/\//%2F/g;s/+/%2B/g;s/#/%23/g'; }
SAVE_URL="/cgi-bin/save_measurement.sh?location=$(enc "$LOCATION")&ssid=$(enc "$SSID")&ipaddr=$(enc "$IPADDR")&signal=$(enc "$SIGNAL_NUM")&rating=$(enc "$SIGNAL_RATING")&quality=$(enc "$QUALITY")&bitrate=$(enc "$BITRATE")&band=$(enc "$BAND")&channel=$(enc "$CHANNEL")&bssid=$(enc "$BSSID")&apvendor=$(enc "$AP_VENDOR")&roaming=$(enc "$ROAMING_ASSESSMENT")&internet=$INTERNET&dns=$DNS&matrix=$MATRIX&latency=$(enc "$LATENCY_AVG")&packetloss=$(enc "$PACKET_LOSS")&download=$(enc "$DOWNLOAD_MBPS")&speedrating=$(enc "$SPEED_RATING")&qualityrating=$(enc "$QUALITY_RATING")&overall=$(enc "$OVERALL")"

cat <<HTML
<html><head><title>Customer WiFi Survey Report</title>
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5;color:#222}.card{background:white;max-width:1050px;padding:22px;border:1px solid #ccc;border-radius:8px}table{border-collapse:collapse;width:100%;background:white;margin-bottom:15px}th{background:#005a9c;color:white;padding:8px;text-align:left}td{border:1px solid #cccccc;padding:8px}td:first-child{font-weight:bold;background:#f5f5f5;width:260px}.ok{color:green;font-weight:bold}.warn{color:#b36b00;font-weight:bold}.bad{color:#b00020;font-weight:bold}.explain{background:#eef6ff;border-left:4px solid #005a9c;padding:12px;margin:12px 0}.legend td:first-child{font-weight:bold}.status-dot,.sw{display:inline-block;width:14px;height:14px;border-radius:50%;margin-right:7px;vertical-align:middle;border:1px solid rgba(0,0,0,.18)}.sw{width:16px;height:16px}.g1{background:#1f8a3b}.g2{background:#5cb85c}.y{background:#f0ad4e}.o{background:#e67e22}.r{background:#c0392b}.badge{display:inline-block;border-radius:999px;padding:4px 9px;font-weight:bold;font-size:12px;color:white}.excellent{background:#1f8a3b}.good{background:#5cb85c}.fair{background:#f0ad4e;color:#222}.poor{background:#e67e22}.critical{background:#c0392b}.unknown{background:#777}button{padding:10px 20px;font-size:14px;margin-right:10px;border:0;border-radius:5px;background:#005a9c;color:white;cursor:pointer}.secondary{background:#666}@media print{button{display:none}}</style>
</head><body><div class="card">
<h2>Customer WiFi Survey Report</h2>
<p><b>Location:</b> $LOCATION &nbsp; | &nbsp; <b>Date:</b> $DATE &nbsp; | &nbsp; <b>Overall:</b> <span class="status-dot $OVERALL_DOT"></span>$OVERALL</p>
<div class="explain"><b>How to read this report:</b><br>Signal strength shows how well the router receives the WiFi at this physical location. The speed test gives a practical download estimate over this WiFi connection. Latency and packet loss show stability. A location can have good signal but still poor speed because of interference router limits or internet capacity.</div>
<table><tr><th colspan='2'>WiFi Signal</th></tr><tr><td>SSID</td><td>$SSID</td></tr><tr><td>IP Address</td><td>$IPADDR</td></tr><tr><td>Signal Strength</td><td>$SIGNAL dBm</td></tr><tr><td>Signal Rating</td><td><span class="status-dot $SIG_DOT"></span>$SIGNAL_RATING</td></tr><tr><td>Link Quality</td><td>$QUALITY</td></tr><tr><td>Bit Rate</td><td>$BITRATE</td></tr><tr><td>Explanation</td><td>$SIGNAL_COMMENT</td></tr></table>
<table><tr><th colspan='2'>Access Point Information</th></tr><tr><td>Frequency Band</td><td>$BAND</td></tr><tr><td>Channel</td><td>$CHANNEL</td></tr><tr><td>BSSID / AP MAC</td><td>$BSSID</td></tr><tr><td>Detected AP Vendor</td><td>$AP_VENDOR</td></tr><tr><td>Roaming Assessment</td><td>$ROAMING_ASSESSMENT</td></tr></table>
<table><tr><th colspan='2'>Speed and Network Quality</th></tr><tr><td>Download Estimate</td><td>$DOWNLOAD_MBPS Mbps</td></tr><tr><td>Speed Rating</td><td><span class="status-dot $SPEED_DOT"></span>$SPEED_RATING</td></tr><tr><td>Latency Average</td><td>$LATENCY_AVG ms</td></tr><tr><td>Packet Loss</td><td>$PACKET_LOSS</td></tr><tr><td>Network Quality</td><td><span class="status-dot $QUALITY_DOT"></span>$QUALITY_RATING</td></tr><tr><td>Speed Explanation</td><td>$SPEED_COMMENT</td></tr><tr><td>Quality Explanation</td><td>$QUALITY_COMMENT</td></tr></table>
<table><tr><th colspan='2'>Connectivity Tests</th></tr><tr><td>Internet Access</td><td>$INTERNET</td></tr><tr><td>DNS Resolution</td><td>$DNS</td></tr><tr><td>Matrix Fitness Cloud Connectivity</td><td>$MATRIX</td></tr></table>
<table class='legend'><tr><th colspan='4'>Reference Values - Signal Strength</th></tr><tr><td><span class='sw g1'></span>Excellent</td><td>-30 to -55 dBm</td><td>Best</td><td>Suitable for Matrix Fitness equipment, streaming and updates.</td></tr><tr><td><span class='sw g2'></span>Good</td><td>-56 to -65 dBm</td><td>Good</td><td>Suitable for normal operation.</td></tr><tr><td><span class='sw y'></span>Fair</td><td>-66 to -72 dBm</td><td>Attention</td><td>Works, but improve if equipment stays here permanently.</td></tr><tr><td><span class='sw o'></span>Poor</td><td>-73 to -80 dBm</td><td>Risk</td><td>Risk of disconnects or slow communication.</td></tr><tr><td><span class='sw r'></span>Critical</td><td>Below -80 dBm</td><td>Not suitable</td><td>Add or reposition access points before installation.</td></tr></table>
<table class='legend'><tr><th colspan='4'>Reference Values - Speed, Latency and Packet Loss</th></tr><tr><td>Download</td><td>&gt;50 Excellent | 20-50 Good | 10-20 Fair | 5-10 Poor | &lt;5 Critical</td><td colspan='2'>Throughput for updates, streaming and Matrix Fitness cloud services.</td></tr><tr><td>Latency</td><td>&lt;20 Excellent | 20-50 Good | 50-100 Fair | 100-200 Poor | &gt;200 Critical</td><td colspan='2'>Lower is better. High latency can cause slow response and timeouts.</td></tr><tr><td>Packet Loss</td><td>0% Excellent | &lt;1% Good | 1-3% Fair | 3-5% Poor | &gt;5% Critical</td><td colspan='2'>Packet loss is often more important than speed. Loss can cause sync and cloud problems.</td></tr></table>
<table><tr><th colspan='2'>Recommendation</th></tr><tr><td>Assessment</td><td>$RECOMMENDATION</td></tr></table>
<button onclick='window.print()'>Save as PDF</button>
<button onclick="window.location='$SAVE_URL'">Save Measurement</button>
<button class="secondary" onclick="window.location='/cgi-bin/next_location.sh'">Back to Progress</button>
<button class="secondary" onclick="window.location='/cgi-bin/final_report.sh'">Finish Survey</button>
<br><br><hr><small>Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE<br>$COMPANY<br>Created by $AUTHOR<br>$EMAIL<br>$MESSAGE</small>
</div></body></html>
HTML
