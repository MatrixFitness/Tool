#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

LOCATION=$(echo "$QUERY_STRING" | sed -n 's/.*location=\([^&]*\).*/\1/p' | sed 's/%20/ /g' | sed 's/+/ /g')
[ -z "$LOCATION" ] && LOCATION="Unknown"

SSID=$(uci get wireless.1.ssid 2>/dev/null)
CLIENT_IF=$(ifstatus wan1 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)
IPADDR=$(ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)

IWINFO_OUT=""
if [ -n "$CLIENT_IF" ]
then
    IWINFO_OUT=$(iwinfo "$CLIENT_IF" info 2>/dev/null)
fi

SIGNAL=$(echo "$IWINFO_OUT" | grep "Signal:" | awk '{print $2}')
QUALITY=$(echo "$IWINFO_OUT" | grep "Link Quality:" | awk '{print $6}')
BITRATE=$(echo "$IWINFO_OUT" | grep "Bit Rate:" | awk '{print $3" "$4}')
DATE=$(date "+%Y-%m-%d %H:%M:%S")

[ -z "$SSID" ] && SSID="Unknown"
[ -z "$IPADDR" ] && IPADDR="No DHCP lease"
[ -z "$SIGNAL" ] && SIGNAL="Unknown"
[ -z "$QUALITY" ] && QUALITY="Unknown"
[ -z "$BITRATE" ] && BITRATE="Unknown"

SIGNAL_RATING="Unknown"
if [ "$SIGNAL" != "Unknown" ]
then
    if [ "$SIGNAL" -ge "-50" ] 2>/dev/null
    then
        SIGNAL_RATING="Excellent"
    elif [ "$SIGNAL" -ge "-60" ] 2>/dev/null
    then
        SIGNAL_RATING="Good"
    elif [ "$SIGNAL" -ge "-70" ] 2>/dev/null
    then
        SIGNAL_RATING="Fair"
    else
        SIGNAL_RATING="Weak"
    fi
fi

INTERNET="FAIL"
DNS="FAIL"
MATRIX="FAIL"

ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"
nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"
curl -s --connect-timeout 10 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

OVERALL="PASS"
[ "$INTERNET" = "FAIL" ] && OVERALL="FAIL"
[ "$DNS" = "FAIL" ] && OVERALL="FAIL"
[ "$MATRIX" = "FAIL" ] && OVERALL="FAIL"
[ "$SIGNAL_RATING" = "Weak" ] && OVERALL="CHECK"
[ "$SIGNAL_RATING" = "Unknown" ] && OVERALL="CHECK"

LOCATION_URL=$(echo "$LOCATION" | sed 's/ /%20/g')
SIGNAL_URL=$(echo "$SIGNAL" | sed 's/ /%20/g')
RATING_URL=$(echo "$SIGNAL_RATING" | sed 's/ /%20/g')
RESULT_CLASS=$(echo "$OVERALL" | tr A-Z a-z)

echo "<html>"
echo "<head>"
echo "<title>WiFi Measurement Preview</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;background:#f5f5f5;}"
echo ".card{background:white;border:1px solid #ccc;border-radius:8px;padding:20px;width:700px;}"
echo "table{border-collapse:collapse;width:100%;background:white;margin-top:10px;}"
echo "th{background:#005a9c;color:white;padding:8px;text-align:left;}"
echo "td{border:1px solid #cccccc;padding:8px;}"
echo "td:first-child{font-weight:bold;background:#f5f5f5;width:220px;}"
echo ".pass{color:green;font-weight:bold;}"
echo ".fail{color:red;font-weight:bold;}"
echo ".check{color:#f39c12;font-weight:bold;}"
echo "button{padding:10px 20px;font-size:14px;margin-right:10px;margin-top:15px;}"
echo ".note{color:#666;font-size:13px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<div class='card'>"
echo "<h2>WiFi Measurement Preview</h2>"
echo "<p class='note'>Quick check before saving. Full details will be shown in the final report.</p>"

echo "<table>"
echo "<tr><th colspan='2'>Measurement</th></tr>"
echo "<tr><td>Location</td><td>$LOCATION</td></tr>"
echo "<tr><td>SSID</td><td>$SSID</td></tr>"
echo "<tr><td>Signal</td><td>$SIGNAL dBm</td></tr>"
echo "<tr><td>Rating</td><td>$SIGNAL_RATING</td></tr>"
echo "<tr><td>Result</td><td class='$RESULT_CLASS'>$OVERALL</td></tr>"
echo "</table>"

echo "<button onclick=\"window.location='/cgi-bin/save_measurement.sh?location=$LOCATION_URL&signal=$SIGNAL_URL&rating=$RATING_URL&internet=$INTERNET&dns=$DNS&matrix=$MATRIX'\">Save Measurement</button>"
echo "<button onclick=\"window.location='/location_survey.html'\">New Location</button>"
echo "<button onclick=\"window.location='/cgi-bin/final_report.sh'\">Finish Survey</button>"
echo "<button onclick=\"window.location='/wifi_survey.html'\">New WiFi Connection</button>"

echo "<br><br><hr>"
echo "<small>"
echo "Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE<br>"
echo "$COMPANY<br>"
echo "Created by $AUTHOR<br>"
echo "$EMAIL<br>"
echo "$MESSAGE"
echo "</small>"

echo "</div>"
echo "</body>"
echo "</html>"
