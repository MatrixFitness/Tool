#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

# Read selected location

LOCATION=$(echo "$QUERY_STRING" | sed -n 's/.*location=\([^&]*\).*/\1/p' | sed 's/%20/ /g')

# Collect WiFi information

SSID=$(uci get wireless.1.ssid 2>/dev/null)

CLIENT_IF=$(ifstatus wan1 | grep '"device"' | head -1 | cut -d'"' -f4)

IPADDR=$(ifstatus wan1 | grep '"address"' | head -1 | cut -d'"' -f4)

IWINFO_OUT=$(iwinfo "$CLIENT_IF" info)

SIGNAL=$(echo "$IWINFO_OUT" | grep "Signal:" | awk '{print $2}')

QUALITY=$(echo "$IWINFO_OUT" | grep "Link Quality:" | awk '{print $6}')

BITRATE=$(echo "$IWINFO_OUT" | grep "Bit Rate:" | awk '{print $3" "$4}')

DATE=$(date "+%Y-%m-%d %H:%M:%S")

# Signal Rating

SIGNAL_RATING="Unknown"
SIGNAL_COMMENT=""

if [ -n "$SIGNAL" ]
then
if [ "$SIGNAL" -ge "-50" ]
then
SIGNAL_RATING="Excellent"
SIGNAL_COMMENT="Excellent WiFi coverage. This location should provide very reliable connectivity for Matrix and EGYM equipment."
elif [ "$SIGNAL" -ge "-60" ]
then
SIGNAL_RATING="Good"
SIGNAL_COMMENT="Good WiFi coverage. Suitable for normal operation."
elif [ "$SIGNAL" -ge "-70" ]
then
SIGNAL_RATING="Fair"
SIGNAL_COMMENT="WiFi coverage is acceptable but could be improved."
else
SIGNAL_RATING="Weak"
SIGNAL_COMMENT="WiFi coverage is weak. Additional WiFi coverage is recommended."
fi
fi

# Connectivity Tests

INTERNET="FAIL"
DNS="FAIL"
MATRIX="FAIL"

ping -c 1 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"
nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"
curl -s --connect-timeout 10 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

# Overall Result

OVERALL="PASS"

[ "$INTERNET" = "FAIL" ] && OVERALL="FAIL"
[ "$DNS" = "FAIL" ] && OVERALL="FAIL"
[ "$MATRIX" = "FAIL" ] && OVERALL="FAIL"

# Recommendation

case "$SIGNAL_RATING" in
Excellent)
RECOMMENDATION="Excellent WiFi coverage. This location is fully suitable for Matrix and EGYM connected equipment. No improvements are required."
;;
Good)
RECOMMENDATION="Good WiFi coverage. This location is suitable for normal operation of Matrix and EGYM connected equipment."
;;
Fair)
RECOMMENDATION="WiFi coverage is acceptable but could be improved. Equipment should function correctly, however improved coverage may increase reliability."
;;
Weak)
RECOMMENDATION="WiFi coverage is weak. Additional WiFi coverage is recommended before installing connected equipment."
;;
esac

# HTML

echo "<html>"
echo "<head>"
echo "<title>Customer WiFi Survey Report</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;background:#f5f5f5;}"
echo "table{border-collapse:collapse;width:800px;background:white;margin-bottom:15px;}"
echo "th{background:#005a9c;color:white;padding:8px;}"
echo "td{border:1px solid #cccccc;padding:8px;}"
echo "td:first-child{font-weight:bold;background:#f5f5f5;width:250px;}"
echo "button{padding:10px 20px;font-size:14px;margin-right:10px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Survey Report</h2>"

echo "<table>"
echo "<tr><th colspan='2'>WiFi Results</th></tr>"
echo "<tr><td>Location Tested</td><td>$LOCATION</td></tr>"
echo "<tr><td>SSID</td><td>$SSID</td></tr>"
echo "<tr><td>IP Address</td><td>$IPADDR</td></tr>"
echo "<tr><td>Signal Strength</td><td>$SIGNAL dBm</td></tr>"
echo "<tr><td>Signal Rating</td><td>$SIGNAL_RATING</td></tr>"
echo "<tr><td>Link Quality</td><td>$QUALITY</td></tr>"
echo "<tr><td>Bit Rate</td><td>$BITRATE</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Survey Information</th></tr>"
echo "<tr><td>Survey Date</td><td>$DATE</td></tr>"
echo "<tr><td>Overall Result</td><td>$OVERALL</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Signal Assessment</th></tr>"
echo "<tr><td>Rating</td><td>$SIGNAL_RATING</td></tr>"
echo "<tr><td>Evaluation</td><td>$SIGNAL_COMMENT</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>WiFi Signal Reference</th></tr>"
echo "<tr><td>-50 dBm or better</td><td>Excellent</td></tr>"
echo "<tr><td>-51 to -60 dBm</td><td>Good</td></tr>"
echo "<tr><td>-61 to -70 dBm</td><td>Fair</td></tr>"
echo "<tr><td>Below -70 dBm</td><td>Weak</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Recommendation</th></tr>"
echo "<tr><td>Assessment</td><td>$RECOMMENDATION</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Connectivity Tests</th></tr>"
echo "<tr><td>Internet Access</td><td>$INTERNET</td></tr>"
echo "<tr><td>DNS Resolution</td><td>$DNS</td></tr>"
echo "<tr><td>Matrix Cloud Connectivity</td><td>$MATRIX</td></tr>"
echo "</table>"

echo "<br>"

echo "<button onclick='window.print()'>Save as PDF</button>"
echo "<button onclick=\"window.location='/cgi-bin/save_measurement.sh?location=$LOCATION&signal=$SIGNAL&rating=$SIGNAL_RATING&internet=$INTERNET&dns=$DNS&matrix=$MATRIX'\">Save Measurement</button>"
echo "<button onclick=\"window.location='/location_survey.html'\">Next Location</button>"
echo "<button onclick=\"window.location='/cgi-bin/final_report.sh'\">Finish Survey</button>"

echo "<br><br><hr>"
echo "<small>"
echo "Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE<br>"
echo "$COMPANY<br>"
echo "Created by $AUTHOR<br>"
echo "$MESSAGE"
echo "</small>"

echo "</body>"
echo "</html>"

