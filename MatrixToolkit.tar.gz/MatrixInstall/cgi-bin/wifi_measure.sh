#!/bin/sh

echo "Content-Type: text/html"
echo ""

SSID=$(uci get wireless.1.ssid 2>/dev/null)

IPADDR=$(ifstatus wan1 | grep '"address"' | head -1 | cut -d'"' -f4)

SIGNAL=$(iwinfo | grep -A10 "ESSID: "$SSID"" | grep "Signal:" | awk '{print $2}')

QUALITY=$(iwinfo | grep -A10 "ESSID: "$SSID"" | grep "Link Quality:" | awk '{print $3}')

BITRATE=$(iwinfo | grep -A10 "ESSID: "$SSID"" | grep "Bit Rate:" | awk '{print $3" "$4}')

INTERNET="FAIL"
DNS="FAIL"
MATRIX="FAIL"

ping -c 1 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"

nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"

curl -s --connect-timeout 10 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

echo "<html>"
echo "<head>"
echo "<title>Customer WiFi Survey Report</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;}"
echo "table{border-collapse:collapse;width:700px;}"
echo "th{background:#005a9c;color:white;padding:8px;}"
echo "td{border:1px solid #ccc;padding:8px;}"
echo "td:first-child{font-weight:bold;background:#f5f5f5;width:250px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Survey Report</h2>"

echo "<table>"
echo "<tr><th colspan='2'>WiFi Results</th></tr>"
echo "<tr><td>SSID</td><td>$SSID</td></tr>"
echo "<tr><td>IP Address</td><td>$IPADDR</td></tr>"
echo "<tr><td>Signal Strength</td><td>$SIGNAL dBm</td></tr>"
echo "<tr><td>Link Quality</td><td>$QUALITY</td></tr>"
echo "<tr><td>Bit Rate</td><td>$BITRATE</td></tr>"
echo "</table>"

echo "<br>"

echo "<table>"
echo "<tr><th colspan='2'>Connectivity Tests</th></tr>"
echo "<tr><td>Internet</td><td>$INTERNET</td></tr>"
echo "<tr><td>DNS</td><td>$DNS</td></tr>"
echo "<tr><td>Matrix Cloud</td><td>$MATRIX</td></tr>"
echo "</table>"

echo "<br>"
echo "<button onclick='window.print()'>Save as PDF</button>"
echo " "
echo "<button onclick="location.href='/wifi_survey.html'">Back</button>"

echo "</body>"
echo "</html>"
