#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

get_value() {
    KEY="$1"
    grep "^$KEY=" /usr/local/matrix/version.txt 2>/dev/null | cut -d'=' -f2-
}

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"

VERSION="$(get_value Version)"
[ -z "$VERSION" ] && VERSION="74.5"

UPTIME="$(uptime 2>/dev/null)"
LOAD="$(printf '%s' "$UPTIME" | sed 's/.*load average: //')"

WAN_IP="$(ip -4 addr show 2>/dev/null | awk '/inet / && $2 !~ /^127/ && $0 !~ /br-lan/ && $0 !~ /zt/ {split($2,a,"/"); print a[1]; exit}')"
LAN_IP="$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
ZT_IP="$(ip -4 addr show 2>/dev/null | awk '/zt/ {f=1} f && /inet / {split($2,a,"/"); print a[1]; exit}')"

RAW_IFCONFIG="$(ifconfig 2>/dev/null)"
IFACES="$(printf '%s\n' "$RAW_IFCONFIG" | awk '/^[a-zA-Z0-9_.-]+[[:space:]]+Link/{print $1}')"
IFACE_COUNT="$(printf '%s\n' "$IFACES" | grep -c .)"

INTERFACE_ROWS="/tmp/matrix_report_rows.$$"
: > "$INTERFACE_ROWS"

OK_COUNT=0
WARN_COUNT=0

for IFACE in $IFACES; do
    BLOCK="$(printf '%s\n' "$RAW_IFCONFIG" | awk -v i="$IFACE" '
        $1==i {p=1}
        p && NR>1 && /^[a-zA-Z0-9_.-]+[[:space:]]+Link/ && $1!=i {p=0}
        p {print}
    ')"

    MAC="$(printf '%s\n' "$BLOCK" | awk '/HWaddr/{print $NF; exit}')"
    IPV4="$(printf '%s\n' "$BLOCK" | sed -n 's/.*inet addr:\([^ ]*\).*/\1/p' | head -n1)"
    [ -z "$IPV4" ] && IPV4="$(ip -4 addr show "$IFACE" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
    MTU="$(printf '%s\n' "$BLOCK" | sed -n 's/.*MTU:\([0-9]*\).*/\1/p' | head -n1)"

    RX_PACKETS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX packets:\([0-9]*\).*/\1/p' | head -n1)"
    TX_PACKETS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX packets:\([0-9]*\).*/\1/p' | head -n1)"
    RX_BYTES="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX bytes:[0-9]* (\([^)]*\)).*/\1/p' | head -n1)"
    TX_BYTES="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX bytes:[0-9]* (\([^)]*\)).*/\1/p' | head -n1)"

    RX_ERRORS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX packets:[0-9]* errors:\([0-9]*\).*/\1/p' | head -n1)"
    RX_DROPPED="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX packets:[0-9]* errors:[0-9]* dropped:\([0-9]*\).*/\1/p' | head -n1)"
    TX_ERRORS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX packets:[0-9]* errors:\([0-9]*\).*/\1/p' | head -n1)"
    TX_DROPPED="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX packets:[0-9]* errors:[0-9]* dropped:\([0-9]*\).*/\1/p' | head -n1)"

    [ -z "$RX_ERRORS" ] && RX_ERRORS="0"
    [ -z "$RX_DROPPED" ] && RX_DROPPED="0"
    [ -z "$TX_ERRORS" ] && TX_ERRORS="0"
    [ -z "$TX_DROPPED" ] && TX_DROPPED="0"
    [ -z "$RX_PACKETS" ] && RX_PACKETS="-"
    [ -z "$TX_PACKETS" ] && TX_PACKETS="-"
    [ -z "$RX_BYTES" ] && RX_BYTES="-"
    [ -z "$TX_BYTES" ] && TX_BYTES="-"
    [ -z "$MTU" ] && MTU="-"
    [ -z "$MAC" ] && MAC="-"
    [ -z "$IPV4" ] && IPV4="-"

    CLASS="ok"
    STATUS="OK"
    ISSUE=""
    if [ "$RX_ERRORS" != "0" ] || [ "$TX_ERRORS" != "0" ] || [ "$RX_DROPPED" != "0" ] || [ "$TX_DROPPED" != "0" ]; then
        CLASS="warn"
        STATUS="CHECK"
        ISSUE="Errors/drops detected"
        WARN_COUNT=$((WARN_COUNT+1))
    else
        OK_COUNT=$((OK_COUNT+1))
    fi

    TYPE="Interface"
    echo "$IFACE" | grep -q "^br-lan" && TYPE="LAN Bridge"
    echo "$IFACE" | grep -q "^eth" && TYPE="Ethernet"
    echo "$IFACE" | grep -q "^wlan" && TYPE="WiFi"
    echo "$IFACE" | grep -q "^wwan\|^qmimux" && TYPE="LTE/WAN"
    echo "$IFACE" | grep -q "^zt" && TYPE="ZeroTier"
    echo "$IFACE" | grep -q "^lo" && TYPE="Loopback"

    cat >> "$INTERFACE_ROWS" <<EOF
<div class="iface-card">
  <div class="iface-head">
    <div>
      <div class="iface-name">$(html_escape "$IFACE")</div>
      <div class="iface-type">$(html_escape "$TYPE")</div>
    </div>
    <div class="badge $CLASS">$(html_escape "$STATUS")</div>
  </div>
  <div class="iface-grid">
    <div><span>IPv4</span><b>$(html_escape "$IPV4")</b></div>
    <div><span>MAC</span><b>$(html_escape "$MAC")</b></div>
    <div><span>MTU</span><b>$(html_escape "$MTU")</b></div>
    <div><span>RX</span><b>$(html_escape "$RX_BYTES")</b><small>$(html_escape "$RX_PACKETS") packets</small></div>
    <div><span>TX</span><b>$(html_escape "$TX_BYTES")</b><small>$(html_escape "$TX_PACKETS") packets</small></div>
    <div><span>Drops / Errors</span><b>RX $(html_escape "$RX_DROPPED") / $(html_escape "$RX_ERRORS")</b><small>TX $(html_escape "$TX_DROPPED") / $(html_escape "$TX_ERRORS")</small></div>
  </div>
  $( [ -n "$ISSUE" ] && echo "<div class='issue'>$(html_escape "$ISSUE")</div>" )
</div>
EOF
done

ROWS="$(cat "$INTERFACE_ROWS" 2>/dev/null)"
rm -f "$INTERFACE_ROWS"

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Report Test</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--blue:#005a9c;--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1280px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:white;border-radius:18px;padding:20px 22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px;font-size:14px}
.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:white;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}
.summary{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:18px 0}
.sum-card{background:var(--panel);border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow);padding:15px}
.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}.value{margin-top:8px;font-size:19px;font-weight:800;word-break:break-word}
.ok{color:var(--ok)}.warn{color:var(--warn)}.fail{color:var(--fail)}
.section{background:var(--panel);border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:16px;margin:16px 0}
.section h2{margin:0 0 12px;color:#0d3b66;font-size:20px}
.ifaces{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
.iface-card{border:1px solid var(--border);border-radius:16px;background:#f8fafc;padding:14px}
.iface-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;margin-bottom:12px}
.iface-name{font-size:18px;font-weight:800}.iface-type{font-size:13px;color:var(--muted);margin-top:3px}
.badge{border-radius:999px;padding:5px 9px;font-size:12px;font-weight:800;color:white;background:var(--ok)}.badge.warn{background:var(--warn)}.badge.fail{background:var(--fail)}
.iface-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.iface-grid div{background:white;border:1px solid var(--border);border-radius:12px;padding:10px;min-height:62px}
.iface-grid span{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;font-weight:700}
.iface-grid b{display:block;margin-top:5px;font-size:14px;word-break:break-word}
.iface-grid small{display:block;color:var(--muted);font-size:11px;margin-top:3px}
.issue{margin-top:10px;background:#fff4ce;border:1px solid #ead28a;color:#7a3b00;border-radius:10px;padding:9px;font-size:13px;font-weight:700}
pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px}
@media(max-width:1000px){.summary{grid-template-columns:repeat(2,1fr)}.ifaces{grid-template-columns:1fr}.iface-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.summary{grid-template-columns:1fr}.iface-grid{grid-template-columns:1fr}.btn{width:100%;text-align:center}}
</style>
</head>
<body>
<div class="page">
  <div class="hero">
    <div>
      <h1>Report Test</h1>
      <div class="sub">Router interface report voor $(html_escape "$HOST")</div>
    </div>
    <div>
      <a class="btn" href="/">Back to Toolkit</a>
    </div>
  </div>

  <div class="summary">
    <div class="sum-card"><div class="label">Router</div><div class="value">$(html_escape "$HOST")</div></div>
    <div class="sum-card"><div class="label">LAN IP</div><div class="value">$(html_escape "$LAN_IP")</div></div>
    <div class="sum-card"><div class="label">WAN IP</div><div class="value">$(html_escape "$WAN_IP")</div></div>
    <div class="sum-card"><div class="label">ZeroTier IP</div><div class="value">$(html_escape "$ZT_IP")</div></div>
    <div class="sum-card"><div class="label">Interfaces</div><div class="value">$(html_escape "$IFACE_COUNT")</div></div>
  </div>

  <div class="section">
    <h2>Interface Overview</h2>
    <div class="ifaces">
      $ROWS
    </div>
  </div>

  <div class="section">
    <h2>System Load</h2>
    <div class="summary" style="margin:0">
      <div class="sum-card"><div class="label">Load Average</div><div class="value">$(html_escape "$LOAD")</div></div>
      <div class="sum-card"><div class="label">Interfaces OK</div><div class="value ok">$(html_escape "$OK_COUNT")</div></div>
      <div class="sum-card"><div class="label">Interfaces Check</div><div class="value warn">$(html_escape "$WARN_COUNT")</div></div>
      <div class="sum-card"><div class="label">Toolkit</div><div class="value">v$(html_escape "$VERSION")</div></div>
    </div>
  </div>

  <details class="section">
    <summary><b>Advanced Raw Interface Output</b></summary>
    <pre>$(html_escape "$RAW_IFCONFIG")</pre>
  </details>
</div>
</body>
</html>
EOF
