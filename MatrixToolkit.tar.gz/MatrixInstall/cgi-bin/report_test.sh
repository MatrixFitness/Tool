#!/bin/sh
# Matrix Interface Report v76.3
# Clean interface report. Raw ifconfig only under Advanced Diagnostics.

printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"
VERSION="$(get_value Version)"
[ -z "$VERSION" ] && VERSION="76.3"
NOW="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
UPTIME="$(uptime 2>/dev/null)"
LOAD="$(printf '%s' "$UPTIME" | sed 's/.*load average: //')"

RAW="$(ifconfig 2>/dev/null)"
LAN_IP="$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
WAN_IF="$(ip route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
WAN_IP=""
[ -n "$WAN_IF" ] && WAN_IP="$(ip -4 addr show "$WAN_IF" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
ZT_IF="$(ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}')"
ZT_IP=""
[ -n "$ZT_IF" ] && ZT_IP="$(ip -4 addr show "$ZT_IF" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"

TMP_ROWS="/tmp/matrix_report_rows.$$"
TMP_SUMMARY="/tmp/matrix_report_summary.$$"
: > "$TMP_ROWS"
: > "$TMP_SUMMARY"
trap 'rm -f "$TMP_ROWS" "$TMP_SUMMARY"' EXIT

OK_COUNT=0
WARN_COUNT=0
FAIL_COUNT=0
IFACE_COUNT=0
TOTAL_DROPS=0
TOTAL_ERRORS=0

iface_type(){
    case "$1" in
        br-lan*) echo "LAN Bridge" ;;
        eth*) echo "Ethernet" ;;
        wlan*) echo "WiFi" ;;
        qmimux*|wwan*) echo "LTE / Mobile" ;;
        zt*) echo "ZeroTier" ;;
        lo) echo "Loopback" ;;
        *) echo "Interface" ;;
    esac
}

status_class(){
    case "$1" in
        OK) echo "ok" ;;
        CHECK) echo "warn" ;;
        FAIL) echo "fail" ;;
        *) echo "warn" ;;
    esac
}

for IFACE in $(printf '%s\n' "$RAW" | awk '/^[A-Za-z0-9_.-]+[[:space:]]+Link/{print $1}'); do
    IFACE_COUNT=$((IFACE_COUNT+1))
    BLOCK="$(printf '%s\n' "$RAW" | awk -v iface="$IFACE" '
      $1==iface {p=1; print; next}
      /^[A-Za-z0-9_.-]+[[:space:]]+Link/ && p==1 {p=0}
      p==1 {print}
    ')"
    TYPE="$(iface_type "$IFACE")"
    MAC="$(printf '%s\n' "$BLOCK" | awk '/HWaddr/{print $NF; exit}')"
    [ -z "$MAC" ] && MAC="-"
    IPV4="$(printf '%s\n' "$BLOCK" | sed -n 's/.*inet addr:\([^ ]*\).*/\1/p' | head -n1)"
    [ -z "$IPV4" ] && IPV4="$(ip -4 addr show "$IFACE" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
    [ -z "$IPV4" ] && IPV4="-"
    MTU="$(printf '%s\n' "$BLOCK" | sed -n 's/.*MTU:\([0-9]*\).*/\1/p' | head -n1)"
    [ -z "$MTU" ] && MTU="-"
    RX_PACKETS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX packets:\([0-9]*\).*/\1/p' | head -n1)"
    TX_PACKETS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX packets:\([0-9]*\).*/\1/p' | head -n1)"
    RX_BYTES="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX bytes:[0-9]* (\([^)]*\)).*/\1/p' | head -n1)"
    TX_BYTES="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX bytes:[0-9]* (\([^)]*\)).*/\1/p' | head -n1)"
    RX_ERRORS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX packets:[0-9]* errors:\([0-9]*\).*/\1/p' | head -n1)"
    RX_DROPPED="$(printf '%s\n' "$BLOCK" | sed -n 's/.*RX packets:[0-9]* errors:[0-9]* dropped:\([0-9]*\).*/\1/p' | head -n1)"
    TX_ERRORS="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX packets:[0-9]* errors:\([0-9]*\).*/\1/p' | head -n1)"
    TX_DROPPED="$(printf '%s\n' "$BLOCK" | sed -n 's/.*TX packets:[0-9]* errors:[0-9]* dropped:\([0-9]*\).*/\1/p' | head -n1)"
    [ -z "$RX_PACKETS" ] && RX_PACKETS="-"
    [ -z "$TX_PACKETS" ] && TX_PACKETS="-"
    [ -z "$RX_BYTES" ] && RX_BYTES="-"
    [ -z "$TX_BYTES" ] && TX_BYTES="-"
    [ -z "$RX_ERRORS" ] && RX_ERRORS=0
    [ -z "$RX_DROPPED" ] && RX_DROPPED=0
    [ -z "$TX_ERRORS" ] && TX_ERRORS=0
    [ -z "$TX_DROPPED" ] && TX_DROPPED=0
    ERR_TOTAL=$((RX_ERRORS + TX_ERRORS))
    DROP_TOTAL=$((RX_DROPPED + TX_DROPPED))
    TOTAL_ERRORS=$((TOTAL_ERRORS + ERR_TOTAL))
    TOTAL_DROPS=$((TOTAL_DROPS + DROP_TOTAL))
    STATUS="OK"
    NOTE="No interface errors detected."
    if [ "$ERR_TOTAL" -gt 0 ]; then
        STATUS="FAIL"; NOTE="Interface errors detected. Check cable, switch port or link quality."; FAIL_COUNT=$((FAIL_COUNT+1))
    elif [ "$DROP_TOTAL" -gt 0 ]; then
        STATUS="CHECK"; NOTE="Dropped packets detected. This can be normal on busy WiFi/WAN, but should be checked if devices have issues."; WARN_COUNT=$((WARN_COUNT+1))
    else
        OK_COUNT=$((OK_COUNT+1))
    fi
    CLASS="$(status_class "$STATUS")"
    cat >> "$TMP_ROWS" <<ROW
<div class="iface-card $CLASS"><div class="iface-head"><div><h3>$(html_escape "$IFACE")</h3><p>$(html_escape "$TYPE")</p></div><div class="badge $CLASS">$(html_escape "$STATUS")</div></div><div class="metric-grid"><div class="metric"><div class="metric-label">IPv4</div><div class="metric-value">$(html_escape "$IPV4")</div><div class="metric-extra">IP address</div></div><div class="metric"><div class="metric-label">MAC</div><div class="metric-value">$(html_escape "$MAC")</div><div class="metric-extra">Hardware address</div></div><div class="metric"><div class="metric-label">MTU</div><div class="metric-value">$(html_escape "$MTU")</div><div class="metric-extra">Packet size</div></div><div class="metric"><div class="metric-label">RX / TX Traffic</div><div class="metric-value">$(html_escape "$RX_BYTES") / $(html_escape "$TX_BYTES")</div><div class="metric-extra">Received / sent</div></div><div class="metric"><div class="metric-label">RX / TX Packets</div><div class="metric-value">$(html_escape "$RX_PACKETS") / $(html_escape "$TX_PACKETS")</div><div class="metric-extra">Packet counters</div></div><div class="metric"><div class="metric-label">Drops / Errors</div><div class="metric-value">$(html_escape "$DROP_TOTAL") / $(html_escape "$ERR_TOTAL")</div><div class="metric-extra">Dropped / errors</div></div></div><details><summary>Explanation</summary><div class="explain">$(html_escape "$NOTE")</div></details></div>
ROW
    cat >> "$TMP_SUMMARY" <<ROW
<tr><td>$(html_escape "$IFACE")</td><td>$(html_escape "$TYPE")</td><td>$(html_escape "$IPV4")</td><td>$(html_escape "$DROP_TOTAL")</td><td>$(html_escape "$ERR_TOTAL")</td><td>$(html_escape "$STATUS")</td></tr>
ROW
done

OVERALL="OK"; OVERALL_CLASS="ok"; OVERALL_TEXT="All interfaces look healthy."
if [ "$WARN_COUNT" -gt 0 ]; then OVERALL="CHECK"; OVERALL_CLASS="warn"; OVERALL_TEXT="Some interfaces show dropped packets. Check if customers report connectivity issues."; fi
if [ "$FAIL_COUNT" -gt 0 ]; then OVERALL="ATTENTION"; OVERALL_CLASS="fail"; OVERALL_TEXT="One or more interfaces show errors. Check cabling, switch ports or link quality."; fi

cat <<EOF_HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Matrix Interface Report</title><meta name="viewport" content="width=device-width, initial-scale=1"><style>
:root{--bg:#eef2f6;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1280px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:white;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:white;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}.cert,.sum-card,.iface-card,.section{background:white;border:1px solid var(--border);box-shadow:var(--shadow)}.cert{border-radius:20px;padding:20px;margin:18px 0;display:grid;grid-template-columns:240px 1fr;gap:18px;align-items:center}.score-ring{border-radius:18px;background:#f8fafc;border:1px solid var(--border);padding:18px;text-align:center}.score{font-size:36px;font-weight:900}.score.ok{color:var(--ok)}.score.warn{color:var(--warn)}.score.fail{color:var(--fail)}.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}.sum-card{border-radius:16px;padding:15px}.value{margin-top:8px;font-size:18px;font-weight:800;word-break:break-word}.ifaces{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.iface-card{border-radius:18px;padding:15px;border-top:6px solid var(--ok)}.iface-card.warn{border-top-color:var(--warn)}.iface-card.fail{border-top-color:var(--fail)}.iface-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.iface-head h3{margin:0;font-size:18px}.iface-head p{margin:5px 0 0;color:var(--muted);font-size:13px}.badge{border-radius:999px;padding:6px 10px;color:white;font-size:12px;font-weight:800;background:var(--ok);white-space:nowrap}.badge.warn{background:var(--warn)}.badge.fail{background:var(--fail)}.metric-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:11px}.metric-label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800}.metric-value{font-size:16px;font-weight:900;margin-top:5px;word-break:break-word}.metric-extra{font-size:12px;color:var(--muted);margin-top:3px}details{margin-top:12px}summary{cursor:pointer;color:#0d3b66;font-weight:800}.explain{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:12px;margin-top:9px;line-height:1.45;color:#344054}.section{border-radius:18px;padding:16px;margin:16px 0}.bigtable{width:100%;border-collapse:collapse}.bigtable td,.bigtable th{border:1px solid var(--border);padding:9px;text-align:left}.bigtable th{background:#f0f6fb}pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px}@media(max-width:1000px){.cert{grid-template-columns:1fr}.summary{grid-template-columns:repeat(2,1fr)}.ifaces{grid-template-columns:1fr}}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.summary{grid-template-columns:1fr}.metric-grid{grid-template-columns:1fr}.btn{width:100%;text-align:center}.iface-head{display:block}.badge{display:inline-block;margin-top:10px}}
</style></head><body><div class="page"><div class="hero"><div><h1>Matrix Interface Report</h1><div class="sub">Router interface health report for $(html_escape "$HOST")</div></div><a class="btn" href="/">Back to Toolkit</a></div><div class="cert"><div class="score-ring"><div class="score $OVERALL_CLASS">$(html_escape "$OVERALL")</div><div class="label">Interface Status</div></div><div><p><b>Result:</b> $(html_escape "$OVERALL_TEXT")</p><p><b>Router:</b> $(html_escape "$HOST") &nbsp; <b>Report time:</b> $(html_escape "$NOW")</p></div></div><div class="summary"><div class="sum-card"><div class="label">Interfaces</div><div class="value">$(html_escape "$IFACE_COUNT")</div></div><div class="sum-card"><div class="label">WAN</div><div class="value">$(html_escape "$WAN_IF") $(html_escape "$WAN_IP")</div></div><div class="sum-card"><div class="label">LAN IP</div><div class="value">$(html_escape "$LAN_IP")</div></div><div class="sum-card"><div class="label">ZeroTier IP</div><div class="value">$(html_escape "$ZT_IP")</div></div></div><div class="summary"><div class="sum-card"><div class="label">OK Interfaces</div><div class="value">$(html_escape "$OK_COUNT")</div></div><div class="sum-card"><div class="label">Check Interfaces</div><div class="value">$(html_escape "$WARN_COUNT")</div></div><div class="sum-card"><div class="label">Failed Interfaces</div><div class="value">$(html_escape "$FAIL_COUNT")</div></div><div class="sum-card"><div class="label">Drops / Errors</div><div class="value">$(html_escape "$TOTAL_DROPS") / $(html_escape "$TOTAL_ERRORS")</div></div></div><div class="ifaces">$(cat "$TMP_ROWS")</div><div class="section"><h2>Interface Summary</h2><table class="bigtable"><tr><th>Interface</th><th>Type</th><th>IPv4</th><th>Drops</th><th>Errors</th><th>Status</th></tr>$(cat "$TMP_SUMMARY")</table></div><details class="section"><summary><b>Advanced Raw ifconfig Output</b></summary><pre>$(html_escape "$RAW")</pre></details></div></body></html>
EOF_HTML
