#!/bin/sh
if [ -x /usr/local/matrix/adminweb/cgi-bin/zerotier_manager.sh ]; then
    /usr/local/matrix/adminweb/cgi-bin/zerotier_manager.sh
else
    echo "Status: 302 Found"
    echo "Location: http://$HTTP_HOST:8081/cgi-bin/zerotier_manager.sh"
    echo ""
fi
