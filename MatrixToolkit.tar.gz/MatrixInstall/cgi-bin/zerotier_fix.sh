#!/bin/sh
# Matrix Toolkit - ZeroTier Repair / Fix v68
# Can run as CGI or CLI.
# Checks and repairs ZeroTier install, daemon, join, firewall and autostart.

ZT_NETWORK_ID="cf719fd5409699a2"
LOG="/tmp/matrix_zerotier_fix.log"

is_cgi(){
    [ -n "$GATEWAY_INTERFACE" ] || [ -n "$QUERY_STRING" ]
}

html_escape(){
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

say(){
    MSG="$1"
    echo "$MSG" >> "$LOG"
    if is_cgi; then
        echo "<tr><td>$(html_escape "$STEP")</td><td>$(html_escape "$MSG")</td></tr>"
    else
        echo "$STEP: $MSG"
    fi
}

find_zt_cli(){
    for p in /usr/bin/zerotier-cli /usr/local/usr/bin/zerotier-cli /usr/sbin/zerotier-cli; do
        [ -x "$p" ] && { echo "$p"; return; }
    done
    command -v zerotier-cli 2>/dev/null
}

find_zt_one(){
    for p in /usr/bin/zerotier-one /usr/local/usr/bin/zerotier-one /usr/sbin/zerotier-one; do
        [ -x "$p" ] && { echo "$p"; return; }
    done
    command -v zerotier-one 2>/dev/null
}

zt_ip(){
    IFACE="$(ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}')"
    [ -n "$IFACE" ] || return
    ip -4 addr show "$IFACE" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1
}

zt_iface(){
    ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}'
}

write_cli_helper(){
    cat > /usr/local/bin/matrix-zerotier-fix <<'EOF'
#!/bin/sh
/usr/local/matrix/web/cgi-bin/zerotier_fix.sh "$@"
EOF
    chmod +x /usr/local/bin/matrix-zerotier-fix 2>/dev/null
}

write_autostart(){
    ZT_ONE="$1"
    [ -n "$ZT_ONE" ] || return 1

    cat > /etc/init.d/matrix_zerotier <<EOF
#!/bin/sh /etc/rc.common
START=99
STOP=10

start() {
    if ! pgrep -f zerotier-one >/dev/null 2>&1; then
        $ZT_ONE -d >/dev/null 2>&1
    fi
}

stop() {
    killall zerotier-one >/dev/null 2>&1
}
EOF
    chmod +x /etc/init.d/matrix_zerotier
    /etc/init.d/matrix_zerotier enable >/dev/null 2>&1
    return 0
}

ensure_firewall(){
    # Create/ensure a permissive ZeroTier firewall zone.
    if uci show firewall 2>/dev/null | grep -q "name='zerotier'"; then
        return 0
    fi

    uci add firewall zone >/dev/null
    uci set firewall.@zone[-1].name='zerotier'
    uci set firewall.@zone[-1].input='ACCEPT'
    uci set firewall.@zone[-1].output='ACCEPT'
    uci set firewall.@zone[-1].forward='ACCEPT'
    uci set firewall.@zone[-1].masq='1'
    uci set firewall.@zone[-1].mtu_fix='1'
    uci add_list firewall.@zone[-1].network='zerotier'

    uci add firewall forwarding >/dev/null
    uci set firewall.@forwarding[-1].src='zerotier'
    uci set firewall.@forwarding[-1].dest='lan'

    uci add firewall forwarding >/dev/null
    uci set firewall.@forwarding[-1].src='lan'
    uci set firewall.@forwarding[-1].dest='zerotier'

    uci commit firewall
    /etc/init.d/firewall reload >/dev/null 2>&1
    return 0
}

ensure_network_interface(){
    IFACE="$(zt_iface)"
    [ -n "$IFACE" ] || return 1

    if ! uci -q get network.zerotier >/dev/null 2>&1; then
        uci set network.zerotier='interface'
        uci set network.zerotier.proto='none'
        uci set network.zerotier.device="$IFACE"
        uci commit network
        /etc/init.d/network reload >/dev/null 2>&1
    else
        uci set network.zerotier.device="$IFACE"
        uci commit network
    fi
    return 0
}

run_fix(){
    : > "$LOG"
    echo "Matrix ZeroTier Repair started at $(date)" >> "$LOG"

    STEP="ZeroTier package"
    ZT_CLI="$(find_zt_cli)"
    ZT_ONE="$(find_zt_one)"

    if [ -z "$ZT_CLI" ] || [ -z "$ZT_ONE" ]; then
        if command -v opkg >/dev/null 2>&1; then
            say "ZeroTier not fully found. Trying opkg install zerotier..."
            opkg update >> "$LOG" 2>&1
            opkg install zerotier >> "$LOG" 2>&1
            ZT_CLI="$(find_zt_cli)"
            ZT_ONE="$(find_zt_one)"
        else
            say "ZeroTier not found and opkg is not available."
        fi
    else
        say "ZeroTier binaries found."
    fi

    STEP="CLI paths"
    say "zerotier-cli=${ZT_CLI:-missing}, zerotier-one=${ZT_ONE:-missing}"

    STEP="Daemon"
    if pgrep -f zerotier-one >/dev/null 2>&1; then
        say "zerotier-one is already running."
    else
        if [ -n "$ZT_ONE" ]; then
            "$ZT_ONE" -d >/dev/null 2>&1
            sleep 3
            if pgrep -f zerotier-one >/dev/null 2>&1; then
                say "zerotier-one started."
            else
                say "zerotier-one could not be started."
            fi
        else
            say "Cannot start daemon because zerotier-one is missing."
        fi
    fi

    STEP="Autostart"
    if [ -n "$ZT_ONE" ] && write_autostart "$ZT_ONE"; then
        say "Autostart service installed/enabled: /etc/init.d/matrix_zerotier"
    else
        say "Autostart could not be installed."
    fi

    STEP="CLI helper"
    write_cli_helper
    say "CLI helper installed: matrix-zerotier-fix"

    STEP="ZeroTier status"
    if [ -n "$ZT_CLI" ]; then
        STATUS="$($ZT_CLI status 2>&1)"
        say "$STATUS"
    else
        say "zerotier-cli missing."
    fi

    STEP="Join network"
    if [ -n "$ZT_CLI" ]; then
        if "$ZT_CLI" listnetworks 2>/dev/null | grep -q "$ZT_NETWORK_ID"; then
            say "Already joined network $ZT_NETWORK_ID."
        else
            JOIN="$($ZT_CLI join "$ZT_NETWORK_ID" 2>&1)"
            sleep 2
            say "$JOIN"
        fi
    else
        say "Cannot join because zerotier-cli is missing."
    fi

    STEP="Network state"
    if [ -n "$ZT_CLI" ]; then
        NETWORKS="$($ZT_CLI listnetworks 2>&1)"
        echo "$NETWORKS" >> "$LOG"
        LINE="$(echo "$NETWORKS" | grep "$ZT_NETWORK_ID" | head -n1)"
        if echo "$LINE" | grep -q "OK"; then
            say "Network joined and authorized: $LINE"
        elif echo "$LINE" | grep -q "ACCESS_DENIED"; then
            say "Joined but not authorized in ZeroTier Central yet: $LINE"
        elif [ -n "$LINE" ]; then
            say "$LINE"
        else
            say "Network not visible in listnetworks."
        fi
    fi

    STEP="ZeroTier IP"
    IP="$(zt_ip)"
    if [ -n "$IP" ]; then
        say "ZeroTier IP: $IP"
    else
        say "No ZeroTier IP yet. If ACCESS_DENIED is shown, authorize this device in ZeroTier Central first."
    fi

    STEP="Network interface"
    IFACE="$(zt_iface)"
    if [ -n "$IFACE" ]; then
        if ensure_network_interface; then
            say "OpenWrt network interface checked: zerotier device=$IFACE"
        else
            say "Could not create OpenWrt zerotier network interface."
        fi
    else
        say "No zt interface found yet."
    fi

    STEP="Firewall"
    if ensure_firewall; then
        say "Firewall zone checked/created for zerotier."
    else
        say "Firewall check failed."
    fi

    STEP="Final result"
    IP="$(zt_ip)"
    if [ -n "$IP" ]; then
        say "ZeroTier repair completed. Remote URL could be: http://$IP:8080/"
    else
        say "Repair completed, but no ZeroTier IP yet. Usually this means the device still needs authorization in ZeroTier Central."
    fi
}

if is_cgi; then
    echo "Content-Type: text/html"
    echo ""
    cat <<'EOF'
<!DOCTYPE html>
<html>
<head>
<title>ZeroTier Repair</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1100px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{color:#005a9c}
table{width:100%;border-collapse:collapse;background:white}
th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}
th{background:#f0f6fb;color:#005a9c}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}
.blue{background:#007bff}.grey{background:#666}
</style>
</head>
<body>
<div class="page">
<h1>ZeroTier Repair / Fix</h1>
<table>
<tr><th>Step</th><th>Result</th></tr>
EOF
    run_fix
    cat <<EOF
</table>
<p>
<a class="btn blue" href="/cgi-bin/zerotier_fix.sh?nocache=$(date +%s)">Run Again</a>
<a class="btn grey" href="/">Back to Toolkit</a>
</p>
</div>
</body>
</html>
EOF
else
    run_fix
    echo
    echo "Log: $LOG"
fi
