#!/bin/sh

echo "Content-Type: text/plain"
echo ""

CLUBNAME=$(echo "$QUERY_STRING" | sed 's/^club=//' | sed 's/%20/ /g')

echo "$CLUBNAME" > /usr/local/matrix/clubname.txt

echo "OK"