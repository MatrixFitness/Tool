#!/bin/sh

echo "Content-Type: text/html"
echo ""

SURVEY_DIR="/usr/local/matrix/survey"
LOCATIONS_FILE="$SURVEY_DIR/locations.txt"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"
CSV="$SURVEY_DIR/wifi_survey_results.csv"

mkdir -p "$SURVEY_DIR"
[ -f "$COMPLETED_FILE" ] || : > "$COMPLETED_FILE"

html_header(){
cat <<HTML
<html>
<head>
<title>Next WiFi Survey Location</title>
<style>
body{font-family:Arial;margin:30px;background:#f5f5f5;}
.card{background:white;max-width:850px;padding:22px;border-radius:8px;border:1px solid #ccc;}
.ok{color:green;font-weight:bold;}.todo{color:#005a9c;font-weight:bold;}
button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:#005a9c;color:white;cursor:pointer;}
button.secondary{background:#666;}
table{border-collapse:collapse;width:100%;background:white;margin-top:12px;}td,th{border:1px solid #ccc;padding:8px;text-align:left;}th{background:#005a9c;color:white;}
.note{background:#fff8d6;border:1px solid #e0c85a;padding:12px;border-radius:6px;margin:15px 0;}
</style>
</head><body><div class="card">
HTML
}

html_footer(){
cat <<HTML
</div></body></html>
HTML
}

html_header

echo "<h1>WiFi Survey Progress</h1>"

if [ ! -s "$LOCATIONS_FILE" ]; then
  echo "<p>No active survey found.</p>"
  echo "<button onclick=\"window.location='/location_survey.html'\">Start Survey</button>"
  html_footer
  exit 0
fi

NEXT=""
while IFS= read -r LOC; do
  [ -z "$LOC" ] && continue
  if ! grep -Fxq "$LOC" "$COMPLETED_FILE" 2>/dev/null; then
    NEXT="$LOC"
    break
  fi
done < "$LOCATIONS_FILE"

echo "<table><tr><th>Location</th><th>Status</th></tr>"
while IFS= read -r LOC; do
  [ -z "$LOC" ] && continue
  if grep -Fxq "$LOC" "$COMPLETED_FILE" 2>/dev/null; then
    echo "<tr><td>$LOC</td><td class='ok'>Done</td></tr>"
  else
    echo "<tr><td>$LOC</td><td class='todo'>To do</td></tr>"
  fi
done < "$LOCATIONS_FILE"
echo "</table>"

if [ -z "$NEXT" ]; then
  echo "<h2>All selected locations are completed.</h2>"
  echo "<button onclick=\"window.location='/cgi-bin/final_report.sh'\">Open Final Report</button>"
  echo "<button class='secondary' onclick=\"window.location='/location_survey.html'\">New Survey</button>"
else
  ENC=$(echo "$NEXT" | sed 's/ /%20/g;s/&/%26/g;s/\//%2F/g')
  echo "<div class='note'><b>Next location:</b><br><h2>$NEXT</h2>"
  echo "Move the router to this location. If needed, power it off, move it, power it on again, reconnect, and then continue.</div>"
  echo "<button onclick=\"window.location='/cgi-bin/wifi_measure.sh?location=$ENC'\">Run Measurement for $NEXT</button>"
  echo "<button class='secondary' onclick=\"window.location='/location_survey.html'\">Back</button>"
fi

html_footer
