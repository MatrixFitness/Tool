#!/bin/sh
echo "Content-Type: text/html"
echo ""

ZT_NETWORK="cf719fd5409699a2"
ZT_HOME="/etc/zerotier"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"
ZT_ONE="/usr/local/usr/bin/zerotier-one"

MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
CGI_DIR="$WEB_DIR/cgi-bin"
ADMIN_INDEX="$WEB_DIR/admin/index.html"

LOG="/tmp/matrix_health.log"
EXTRACT="/tmp/MatrixInstall"

fix_log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG"
}

echo "Matrix Health Check Started" > "$LOG"
fix_log "Starting checks"

if ! ps | grep -v grep | grep -q "zerotier-one"; then
    fix_log "ZeroTier not running, starting"
    "$ZT_ONE" -d "$ZT_HOME" >/dev/null 2>&1 &
    sleep 10
else
    fix_log "ZeroTier process OK"
fi

if [ -x "$ZT_CLI" ]; then
    if ! "$ZT_CLI" -D"$ZT_HOME" listnetworks 2>/dev/null | grep -q "$ZT_NETWORK"; then
        fix_log "Joining ZeroTier network"
        "$ZT_CLI" -D"$ZT_HOME" join "$ZT_NETWORK" >/dev/null 2>&1
        sleep 5
    fi
fi

ZT_IP=$(ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)
[ -n "$ZT_IP" ] && fix_log "ZeroTier IP OK: $ZT_IP" || fix_log "WARNING: No ZeroTier IP"

if ! netstat -tlnp 2>/dev/null | grep -q ":8080"; then
    fix_log "uhttpd 8080 not listening, restarting"
    /etc/init.d/uhttpd restart >/dev/null 2>&1
    sleep 5
else
    fix_log "uhttpd 8080 OK"
fi

if ! uci show firewall 2>/dev/null | grep -q "Allow-Matrix-Toolkit-ZeroTier"; then
    fix_log "Adding firewall rule for port 8080"
    uci add firewall rule >/dev/null
    uci set firewall.@rule[-1].name='Allow-Matrix-Toolkit-ZeroTier'
    uci set firewall.@rule[-1].src='*'
    uci set firewall.@rule[-1].proto='tcp'
    uci set firewall.@rule[-1].dest_port='8080'
    uci set firewall.@rule[-1].target='ACCEPT'
    uci commit firewall
    /etc/init.d/firewall restart >/dev/null 2>&1
else
    fix_log "Firewall rule OK"
fi

for f in version_footer.sh update_github.sh update_github_start.sh update_github_log.sh zerotier_setup.sh matrix_health.sh; do
    if [ -f "$CGI_DIR/$f" ]; then
        chmod +x "$CGI_DIR/$f"
        fix_log "$f OK"
    else
        fix_log "WARNING: $f missing"
    fi
done

if [ -f "$ADMIN_INDEX" ]; then
    sed -i 's#update_github.sh#update_github_start.sh#g' "$ADMIN_INDEX"
    fix_log "Admin update button checked"
fi

LOCAL_VERSION=$(grep "^Version=" "$MATRIX_DIR/version.txt" 2>/dev/null | cut -d= -f2)
GITHUB_VERSION=""

if [ -f "$EXTRACT/version.txt" ]; then
    GITHUB_VERSION=$(grep "^Version=" "$EXTRACT/version.txt" 2>/dev/null | cut -d= -f2)
fi

if [ -n "$GITHUB_VERSION" ] && [ -n "$LOCAL_VERSION" ]; then
    if [ "$GITHUB_VERSION" != "$LOCAL_VERSION" ]; then
        fix_log "WARNING: Version mismatch. Local=$LOCAL_VERSION Archive=$GITHUB_VERSION"
    else
        fix_log "Version OK: $LOCAL_VERSION"
    fi
else
    fix_log "Version: ${LOCAL_VERSION:-Unknown}"
fi

fix_log "Health check finished"

cat << HTML
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Health Check</title>
<meta http-equiv="refresh" content="10">
<style>
body { font-family: Arial; margin:20px; background:#f5f5f5; }
.card { background:white; padding:20px; border-radius:8px; max-width:900px; }
pre { background:#111; color:#eee; padding:15px; border-radius:6px; white-space:pre-wrap; }
button { width:220px; height:50px; font-size:16px; font-weight:bold; margin-right:10px; }
</style>
</head>
<body>
<div class="card">
<h2>Matrix Health Check</h2>
<p><b>Version:</b> ${LOCAL_VERSION:-Unknown}</p>
<p><b>ZeroTier IP:</b> ${ZT_IP:-Not connected}</p>
<pre>
$(cat "$LOG")
</pre>
<button onclick="window.location='/admin/index.html'">Return to Admin</button>
<button onclick="window.location='/index.html'">Home</button>
</div>
</body>
</html>
HTML
