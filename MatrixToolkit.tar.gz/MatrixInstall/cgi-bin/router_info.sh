#!/bin/sh
exec /usr/local/matrix/web/cgi-bin/routerinfo.sh "$@"
