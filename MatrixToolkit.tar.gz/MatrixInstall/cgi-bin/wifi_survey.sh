#!/bin/sh
printf "Content-Type: text/html\n\n"
cat <<'HTMLEOF'
<!DOCTYPE html>
<html>
<head>
<title>Customer WiFi Survey</title>
<meta http-equiv="refresh" content="0;url=/wifi_survey.html">
<script>window.location='/wifi_survey.html';</script>
</head>
<body style="font-family:Arial;margin:30px;">
<p><a href="/wifi_survey.html">Open Customer WiFi Survey</a></p>
</body>
</html>
HTMLEOF
