<html>
<head>
<title>Customer WiFi Survey</title>

<style>
body {
    font-family: Arial;
    margin: 30px;
    background: #f5f5f5;
}

input {
    width: 400px;
    height: 40px;
    margin-bottom: 10px;
    padding-left: 10px;
}

button {
    width: 250px;
    height: 50px;
    margin-bottom: 10px;
    font-size: 16px;
}

.result {
    background: white;
    padding: 15px;
    border-radius: 8px;
    margin-top: 20px;
}
</style>

<script>

function connectWifi() {

    var ssid = document.getElementById("ssid").value;
    var password = document.getElementById("password").value;

    window.location =
        "/cgi-bin/wifi_connect.sh?ssid=" +
        encodeURIComponent(ssid) +
        "&password=" +
        encodeURIComponent(password);
}

function saveMeasurement() {

    var location =
        document.getElementById("location").value;

    window.location =
        "/cgi-bin/wifi_measure.sh?location=" +
        encodeURIComponent(location);
}

function restoreWifi() {

    window.location =
        "/cgi-bin/wifi_restore.sh";
}

</script>

</head>

<body>

<h1>Customer WiFi Survey</h1>

<h3>Connect Customer WiFi</h3>

<input id="ssid" placeholder="SSID"><br>
<input id="password" type="password" placeholder="Password"><br>

<button onclick="connectWifi()">
Connect Customer WiFi
</button>

<hr>

<h3>Location Survey</h3>

<input id="location" placeholder="Reception / Cardio / Stretch"><br>

<button onclick="saveMeasurement()">
Save Measurement
</button>

<hr>

<button onclick="restoreWifi()">
Restore Original WiFi
</button>

</body>
</html>