#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
[ -z "$VERSION" ] && VERSION="77.6"
[ -z "$BUILD" ] && BUILD="2026-06-30"
[ -z "$RELEASE" ] && RELEASE="Production LTS"

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Customer WiFi Survey</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--blue:#005a9c}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1200px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}
.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}
.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px}
.card h2{margin:0 0 8px;color:#0d3b66}.desc{color:var(--muted);font-size:13px;line-height:1.4;margin:0 0 14px}
label{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);font-weight:800;margin:12px 0 6px}
input,select{width:100%;height:44px;border:1px solid var(--border);border-radius:12px;padding:0 12px;font-size:15px;background:#fff}
.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer;margin-top:14px;width:100%}
.btn.secondary{background:#667085}.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}
@media(max-width:800px){.grid{grid-template-columns:1fr}.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn{width:100%;text-align:center}}
</style>
<script>
function connectWifi(){
  var ssid=document.getElementById("ssid").value;
  var password=document.getElementById("password").value;
  window.location="/cgi-bin/wifi_connect.sh?ssid="+encodeURIComponent(ssid)+"&password="+encodeURIComponent(password);
}
function saveMeasurement(){
  var location=document.getElementById("location").value;
  window.location="/cgi-bin/wifi_measure.sh?location="+encodeURIComponent(location);
}
function restoreWifi(){
  window.location="/cgi-bin/wifi_restore.sh";
}
</script>
</head>
<body>
<div class="page">
  <section class="hero">
    <div>
      <h1>Customer WiFi Survey</h1>
      <div class="sub">Connect customer WiFi and save location measurements</div>
      <div class="contact">Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE</div>
      <div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
    </div>
    <a class="top-btn" href="/">Back to Toolkit</a>
  </section>

  <div class="grid">
    <div class="card">
      <h2>Connect Customer WiFi</h2>
      <p class="desc">Connect the router temporarily to the customer WiFi for survey and testing.</p>
      <label for="ssid">SSID</label>
      <input id="ssid" placeholder="Matrix">
      <label for="password">Password</label>
      <input id="password" type="password" placeholder="WiFi password">
      <button class="btn" onclick="connectWifi()">Connect Customer WiFi</button>
    </div>

    <div class="card">
      <h2>Location Survey</h2>
      <p class="desc">Save a WiFi measurement for a location inside the club.</p>
      <label for="location">Location</label>
      <input id="location" placeholder="Reception / Cardio / Stretch">
      <button class="btn" onclick="saveMeasurement()">Save Measurement</button>
      <button class="btn secondary" onclick="restoreWifi()">Restore Original WiFi</button>
    </div>
  </div>

  <div class="footer">Matrix Fitness &middot; WiFi Survey</div>
</div>
</body>
</html>
EOF
