#!/bin/sh
# Matrix WiFi Survey v77.2
# Styled WiFi scan/report page with Back to Toolkit button.

printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

get_value(){
    grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-
}

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"

VERSION="$(get_value Version)"
[ -z "$VERSION" ] && VERSION="77.2"
NOW="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"

TMP="/tmp/matrix_wifi_survey.$$"
ROWS="/tmp/matrix_wifi_rows.$$"
SUMMARY="/tmp/matrix_wifi_summary.$$"
: > "$ROWS"
: > "$SUMMARY"
trap 'rm -f "$TMP" "$ROWS" "$SUMMARY"' EXIT

# Collect WiFi scan output. Prefer iwinfo because it is common on Teltonika/OpenWrt.
RAW=""
RADIOS="$(iwinfo 2>/dev/null | awk '/ESSID|Access Point|Mode: Master|Mode: Client/{print $1}' | sort -u)"
[ -z "$RADIOS" ] && RADIOS="$(iw dev 2>/dev/null | awk '/Interface/{print $2}')"

for R in $RADIOS; do
    OUT="$(iwinfo "$R" scan 2>/dev/null)"
    if [ -n "$OUT" ]; then
        RAW="$RAW
===== $R =====
$OUT
"
    fi
done

# Fallback: show interface info when scan is unavailable.
if [ -z "$RAW" ]; then
    RAW="$(iwinfo 2>/dev/null)"
fi
[ -z "$RAW" ] && RAW="No WiFi scan data available. iwinfo may be unavailable or the radio may not support scanning while active."

printf '%s\n' "$RAW" > "$TMP"

TOTAL=0
EXCELLENT=0
GOOD=0
FAIR=0
POOR=0
UNKNOWN=0

quality_from_signal(){
    SIG="$1"
    [ -z "$SIG" ] && { echo "UNKNOWN"; return; }
    # Signal is negative dBm.
    if [ "$SIG" -ge -55 ]; then echo "EXCELLENT"
    elif [ "$SIG" -ge -65 ]; then echo "GOOD"
    elif [ "$SIG" -ge -75 ]; then echo "FAIR"
    else echo "POOR"; fi
}

class_for(){
    case "$1" in
        EXCELLENT|GOOD) echo "ok" ;;
        FAIR|UNKNOWN) echo "warn" ;;
        POOR) echo "fail" ;;
        *) echo "warn" ;;
    esac
}

recommendation_for(){
    case "$1" in
        EXCELLENT) echo "Excellent signal. No action needed." ;;
        GOOD) echo "Good signal. Suitable for most Matrix and EGYM use." ;;
        FAIR) echo "Usable, but check placement and interference if devices disconnect." ;;
        POOR) echo "Weak signal. Move AP/router closer, reduce interference or add an access point." ;;
        *) echo "Could not determine signal quality from scan output." ;;
    esac
}

# Parse iwinfo blocks. BusyBox awk can be limited, so keep simple.
awk '
BEGIN{cell=""}
/^Cell [0-9]+/{
  if(cell!=""){print cell}
  cell=$0
  next
}
{
  if(cell!=""){cell=cell "\n" $0}
}
END{if(cell!=""){print cell}}
' "$TMP" | while IFS= read -r CELL_BLOCK; do
    # This loop receives one line at a time because shell pipes lose multiline blocks.
    # Parsing multiline in pure ash is hard; so we use awk below to generate pipe-separated rows.
    :
done

# Generate parsed rows using awk directly.
awk '
BEGIN{
  ssid=""; bssid=""; channel=""; signal=""; quality=""; enc="";
}
/^Cell [0-9]+/{
  if(ssid!="" || bssid!=""){
    print ssid "|" bssid "|" channel "|" signal "|" quality "|" enc
  }
  ssid=""; bssid=""; channel=""; signal=""; quality=""; enc="";
  for(i=1;i<=NF;i++){
    if($i=="Address:"){bssid=$(i+1)}
  }
  next
}
/ESSID:/{
  line=$0
  sub(/^.*ESSID: "/,"",line)
  sub(/"$/,"",line)
  ssid=line
}
/Channel:/{
  line=$0
  sub(/^.*Channel:/,"",line)
  sub(/[[:space:]].*$/,"",line)
  channel=line
}
/Signal:/{
  line=$0
  sub(/^.*Signal:[[:space:]]*/,"",line)
  sub(/[[:space:]]dBm.*$/,"",line)
  signal=line
}
/Quality:/{
  line=$0
  sub(/^.*Quality:[[:space:]]*/,"",line)
  quality=line
}
/Encryption:/{
  line=$0
  sub(/^.*Encryption:[[:space:]]*/,"",line)
  enc=line
}
END{
  if(ssid!="" || bssid!=""){
    print ssid "|" bssid "|" channel "|" signal "|" quality "|" enc
  }
}
' "$TMP" > /tmp/matrix_wifi_parsed.$$

if [ ! -s /tmp/matrix_wifi_parsed.$$ ]; then
    echo "No parsed scan results found. Raw output is available under Advanced." > "$ROWS"
else
    while IFS='|' read -r SSID BSSID CHANNEL SIGNAL QUALITY ENC; do
        [ -z "$SSID" ] && SSID="Hidden / Unknown"
        [ -z "$BSSID" ] && BSSID="-"
        [ -z "$CHANNEL" ] && CHANNEL="-"
        [ -z "$SIGNAL" ] && SIGNAL=""
        [ -z "$QUALITY" ] && QUALITY="-"
        [ -z "$ENC" ] && ENC="-"

        TOTAL=$((TOTAL+1))
        GRADE="$(quality_from_signal "$SIGNAL")"
        CLASS="$(class_for "$GRADE")"
        REC="$(recommendation_for "$GRADE")"

        case "$GRADE" in
            EXCELLENT) EXCELLENT=$((EXCELLENT+1)) ;;
            GOOD) GOOD=$((GOOD+1)) ;;
            FAIR) FAIR=$((FAIR+1)) ;;
            POOR) POOR=$((POOR+1)) ;;
            *) UNKNOWN=$((UNKNOWN+1)) ;;
        esac

        SIG_DISPLAY="-"
        [ -n "$SIGNAL" ] && SIG_DISPLAY="${SIGNAL} dBm"

        cat >> "$ROWS" <<EOF
<div class="wifi-card $CLASS">
  <div class="wifi-head">
    <div>
      <h3>$(html_escape "$SSID")</h3>
      <p>BSSID: $(html_escape "$BSSID")</p>
    </div>
    <div class="badge $CLASS">$(html_escape "$GRADE")</div>
  </div>
  <div class="metric-grid">
    <div class="metric"><div class="metric-label">Signal</div><div class="metric-value">$(html_escape "$SIG_DISPLAY")</div><div class="metric-extra">RSSI strength</div></div>
    <div class="metric"><div class="metric-label">Channel</div><div class="metric-value">$(html_escape "$CHANNEL")</div><div class="metric-extra">WiFi channel</div></div>
    <div class="metric"><div class="metric-label">Quality</div><div class="metric-value">$(html_escape "$QUALITY")</div><div class="metric-extra">Radio quality</div></div>
    <div class="metric"><div class="metric-label">Encryption</div><div class="metric-value">$(html_escape "$ENC")</div><div class="metric-extra">Security mode</div></div>
  </div>
  <details>
    <summary>Explanation and recommendation</summary>
    <div class="explain">$(html_escape "$REC")</div>
  </details>
</div>
EOF

        cat >> "$SUMMARY" <<EOF
<tr><td>$(html_escape "$SSID")</td><td>$(html_escape "$BSSID")</td><td>$(html_escape "$CHANNEL")</td><td>$(html_escape "$SIG_DISPLAY")</td><td>$(html_escape "$GRADE")</td></tr>
EOF
    done < /tmp/matrix_wifi_parsed.$$
fi
rm -f /tmp/matrix_wifi_parsed.$$

OVERALL="OK"
OVERALL_CLASS="ok"
OVERALL_TEXT="WiFi scan completed."
if [ "$POOR" -gt 0 ]; then
    OVERALL="ATTENTION"
    OVERALL_CLASS="fail"
    OVERALL_TEXT="One or more WiFi networks have weak signal. Check AP placement or interference."
elif [ "$FAIR" -gt 0 ] || [ "$UNKNOWN" -gt 0 ]; then
    OVERALL="CHECK"
    OVERALL_CLASS="warn"
    OVERALL_TEXT="Some WiFi results should be checked if devices report connection issues."
fi

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix WiFi Survey</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1280px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:#fff;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}
.cert{background:#fff;border:1px solid var(--border);border-radius:20px;box-shadow:var(--shadow);padding:20px;margin:18px 0;display:grid;grid-template-columns:240px 1fr;gap:18px;align-items:center}
.score-ring{border-radius:18px;background:#f8fafc;border:1px solid var(--border);padding:18px;text-align:center}.score{font-size:36px;font-weight:900}.score.ok{color:var(--ok)}.score.warn{color:var(--warn)}.score.fail{color:var(--fail)}
.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}
.summary{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:18px 0}.sum-card{background:#fff;border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow);padding:15px}.value{margin-top:8px;font-size:18px;font-weight:800;word-break:break-word}
.wifi-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.wifi-card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:15px;border-top:6px solid var(--ok)}.wifi-card.warn{border-top-color:var(--warn)}.wifi-card.fail{border-top-color:var(--fail)}
.wifi-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.wifi-head h3{margin:0;font-size:18px}.wifi-head p{margin:5px 0 0;color:var(--muted);font-size:13px;word-break:break-word}
.badge{border-radius:999px;padding:6px 10px;color:#fff;font-size:12px;font-weight:800;background:var(--ok);white-space:nowrap}.badge.warn{background:var(--warn)}.badge.fail{background:var(--fail)}
.metric-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:11px}.metric-label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800}.metric-value{font-size:17px;font-weight:900;margin-top:5px;word-break:break-word}.metric-extra{font-size:12px;color:var(--muted);margin-top:3px}
details{margin-top:12px}summary{cursor:pointer;color:#0d3b66;font-weight:800}.explain{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:12px;margin-top:9px;line-height:1.45;color:#344054}
.section{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:16px;margin:16px 0}.bigtable{width:100%;border-collapse:collapse}.bigtable td,.bigtable th{border:1px solid var(--border);padding:9px;text-align:left}.bigtable th{background:#f0f6fb}
pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px}
@media(max-width:1000px){.cert{grid-template-columns:1fr}.summary{grid-template-columns:repeat(2,1fr)}.wifi-grid{grid-template-columns:1fr}}
@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.summary{grid-template-columns:1fr}.metric-grid{grid-template-columns:1fr}.btn{width:100%;text-align:center}.wifi-head{display:block}.badge{display:inline-block;margin-top:10px}}
</style>
</head>
<body>
<div class="page">
  <div class="hero">
    <div><h1>Matrix WiFi Survey</h1><div class="sub">WiFi scan report for $(html_escape "$HOST")</div></div>
    <a class="btn" href="/">Back to Toolkit</a>
  </div>

  <div class="cert">
    <div class="score-ring"><div class="score $OVERALL_CLASS">$(html_escape "$OVERALL")</div><div class="label">WiFi Survey Status</div></div>
    <div><p><b>Result:</b> $(html_escape "$OVERALL_TEXT")</p><p><b>Router:</b> $(html_escape "$HOST") &nbsp; <b>Scan time:</b> $(html_escape "$NOW")</p></div>
  </div>

  <div class="summary">
    <div class="sum-card"><div class="label">Networks</div><div class="value">$(html_escape "$TOTAL")</div></div>
    <div class="sum-card"><div class="label">Excellent</div><div class="value">$(html_escape "$EXCELLENT")</div></div>
    <div class="sum-card"><div class="label">Good</div><div class="value">$(html_escape "$GOOD")</div></div>
    <div class="sum-card"><div class="label">Fair</div><div class="value">$(html_escape "$FAIR")</div></div>
    <div class="sum-card"><div class="label">Poor</div><div class="value">$(html_escape "$POOR")</div></div>
  </div>

  <div class="wifi-grid">
$(cat "$ROWS")
  </div>

  <div class="section">
    <h2>WiFi Summary</h2>
    <table class="bigtable">
      <tr><th>SSID</th><th>BSSID</th><th>Channel</th><th>Signal</th><th>Result</th></tr>
      $(cat "$SUMMARY")
    </table>
  </div>

  <details class="section">
    <summary><b>Advanced Raw WiFi Scan Output</b></summary>
    <pre>$(html_escape "$RAW")</pre>
  </details>
</div>
</body>
</html>
EOF
