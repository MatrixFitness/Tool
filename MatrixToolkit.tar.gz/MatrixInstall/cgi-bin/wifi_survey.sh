
matrix_page_header() {
    TITLE="$1"
    SUB="$2"
    VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
    BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
    RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
    [ -z "$VERSION" ] && VERSION="77.4"
    [ -z "$BUILD" ] && BUILD="2026-06-30"
    [ -z "$RELEASE" ] && RELEASE="Production LTS"

    cat <<EOF
<div class="matrix-hero">
  <div>
    <h1>$(html_escape "$TITLE")</h1>
    <div class="matrix-sub">$(html_escape "$SUB")</div>
    <div class="matrix-contact">Matrix Toolkit v$(html_escape "$VERSION") | Build $(html_escape "$BUILD") | $(html_escape "$RELEASE")</div>
    <div class="matrix-contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
  </div>
  <div class="matrix-actions">
    <a href="/" class="matrix-top-btn">Back to Toolkit</a>
  </div>
</div>
EOF
}

matrix_style_block() {
cat <<'EOF'
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333;--blue:#005a9c}
body{background:var(--bg)!important;font-family:Arial,Helvetica,sans-serif!important;color:var(--text)!important;margin:0}
.matrix-page{max-width:1200px;margin:0 auto;padding:18px}
.matrix-hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:18px}
.matrix-hero h1{margin:0;font-size:28px;line-height:1.1}
.matrix-sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}
.matrix-contact{margin-top:7px;font-size:13px;opacity:.95}
.matrix-actions{display:flex;gap:10px;flex-wrap:wrap}
.matrix-top-btn,.matrix-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}
.matrix-card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin:14px 0}
.matrix-status{display:inline-block;border-radius:999px;background:var(--ok);color:#fff;padding:7px 12px;font-weight:800;font-size:13px;margin-bottom:12px}
.matrix-status.warn{background:var(--warn)}.matrix-status.fail{background:var(--fail)}
.matrix-table{width:100%;border-collapse:collapse;background:#fff;margin-top:10px}
.matrix-table td,.matrix-table th{border:1px solid var(--border);padding:10px;text-align:left}
.matrix-table th{background:#f0f6fb}
.matrix-button-row{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
.matrix-action-btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700;border:0}
.matrix-action-btn.secondary{background:#667085}
.matrix-footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}
@media(max-width:640px){.matrix-page{padding:10px}.matrix-hero{border-radius:14px;padding:16px}.matrix-hero h1{font-size:23px}.matrix-actions,.matrix-top-btn,.matrix-action-btn{width:100%;text-align:center}.matrix-button-row{display:block}.matrix-button-row a,.matrix-button-row input,.matrix-button-row button{width:100%;margin:6px 0;text-align:center}}
</style>
EOF
}

#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
cat <<'HTML'
<html>
<head>
<meta charset="UTF-8">
<title>Customer WiFi Survey</title>

<style>
body {
    font-family: Arial;
    margin: 30px;
    background: #f5f5f5;
}

input {
    width: 400px;
    height: 40px;
    margin-bottom: 10px;
    padding-left: 10px;
}

button {
    width: 250px;
    height: 50px;
    margin-bottom: 10px;
    font-size: 16px;
}

.result {
    background: white;
    padding: 15px;
    border-radius: 8px;
    margin-top: 20px;
}
</style>

<script>

function connectWifi() {

    var ssid = document.getElementById("ssid").value;
    var password = document.getElementById("password").value;

    window.location =
        "/cgi-bin/wifi_connect.sh?ssid=" +
        encodeURIComponent(ssid) +
        "&password=" +
        encodeURIComponent(password);
}

function saveMeasurement() {

    var location =
        document.getElementById("location").value;

    window.location =
        "/cgi-bin/wifi_measure.sh?location=" +
        encodeURIComponent(location);
}

function restoreWifi() {

    window.location =
        "/cgi-bin/wifi_restore.sh";
}

</script>


<style>
body{background:#eef2f6!important;font-family:Arial,Helvetica,sans-serif!important;color:#1f2933!important}
.matrix-survey-wrap{max-width:1200px;margin:14px auto;background:#fff;border:1px solid #d9e2ec;border-radius:18px;box-shadow:0 8px 22px rgba(15,23,42,.08);padding:16px}
.matrix-survey-title{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:20px 22px;margin:14px auto;max-width:1200px;font-family:Arial,Helvetica,sans-serif;box-shadow:0 8px 22px rgba(15,23,42,.08)}
.matrix-survey-title h1{margin:0;font-size:28px}
.matrix-survey-title div{opacity:.9;margin-top:6px;font-size:14px}
input,select,button{border-radius:10px!important}
table{border-collapse:collapse}
</style>

</head>

<body>

<div class="matrix-survey-title">
  <h1>Matrix WiFi Survey</h1>
  <div>Customer WiFi scan and survey tool</div>
</div>

<div style="max-width:1200px;margin:14px auto 0;padding:0 12px;">
  <a href="/" style="display:inline-block;background:#005a9c;color:#fff;text-decoration:none;border-radius:12px;padding:11px 14px;font-family:Arial,Helvetica,sans-serif;font-weight:700;">Back to Toolkit</a>
</div>


<h1>Customer WiFi Survey</h1>

<h3>Connect Customer WiFi</h3>

<input id="ssid" placeholder="SSID"><br>
<input id="password" type="password" placeholder="Password"><br>

<button onclick="connectWifi()">
Connect Customer WiFi
</button>

<hr>

<h3>Location Survey</h3>

<input id="location" placeholder="Reception / Cardio / Stretch"><br>

<button onclick="saveMeasurement()">
Save Measurement
</button>

<hr>

<button onclick="restoreWifi()">
Restore Original WiFi
</button>

</body>
</html>
HTML
