#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
[ -z "$VERSION" ] && VERSION="85"
[ -z "$BUILD" ] && BUILD="2026-07-02"
[ -z "$RELEASE" ] && RELEASE="Professional Edition"

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Customer WiFi Wizard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--blue:#005a9c;--ok:#1f8a3b}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1200px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}
.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}
.grid{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;margin-top:18px}
.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px}
.card h2{margin:0 0 8px;color:#0d3b66}.desc{color:var(--muted);font-size:13px;line-height:1.4;margin:0 0 14px}
.network{display:flex;justify-content:space-between;gap:12px;align-items:center;border:1px solid var(--border);background:#f8fafc;border-radius:13px;padding:12px;margin:8px 0;cursor:pointer}
.network:hover,.network.selected{border-color:#005a9c;background:#eef6ff}.muted{color:var(--muted);font-size:12px;margin-top:4px}.pill{background:#e7f6ec;color:#146c2e;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:800;white-space:nowrap}
label{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);font-weight:800;margin:12px 0 6px}
input{width:100%;height:44px;border:1px solid var(--border);border-radius:12px;padding:0 12px;font-size:15px;background:#fff}
.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer;margin-top:14px;width:100%}.btn.green{background:var(--ok)}.btn.grey{background:#667085}
.selected-box{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:12px;margin-top:10px}
.note{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:12px;margin-top:14px;color:var(--muted);font-size:13px;line-height:1.45}
.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}
@media(max-width:800px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn{width:100%;text-align:center}.grid{grid-template-columns:1fr}}
</style>
<script>
function loadNetworks(){
  var box=document.getElementById("networks");
  box.innerHTML="<div class='note'>Scanning customer WiFi networks...</div>";
  fetch("/cgi-bin/wifi_scan_customer.sh?ts="+Date.now()).then(r=>r.text()).then(t=>{
    box.innerHTML=t || "<div class='note'>No WiFi networks found. Try Refresh Scan.</div>";
  }).catch(e=>{box.innerHTML="<div class='note'>Scan failed. Try Refresh Scan.</div>";});
}
function selectNetwork(el){
  document.querySelectorAll(".network").forEach(n=>n.classList.remove("selected"));
  el.classList.add("selected");
  document.getElementById("ssid").value=el.dataset.ssid || "";
  document.getElementById("selectedSsid").innerText=el.dataset.ssid || "-";
  document.getElementById("selectedDetails").innerText=(el.dataset.band||"")+" · Channel "+(el.dataset.channel||"")+" · "+(el.dataset.signal||"")+" · "+(el.dataset.security||"");
  document.getElementById("password").focus();
}
function connectWifi(){
  var ssid=document.getElementById("ssid").value;
  var manual=document.getElementById("manualSsid");
  if((!ssid || ssid=="") && manual){ssid=manual.value;}
  var password=document.getElementById("password").value;
  if(!ssid){alert("Select a customer WiFi network or enter SSID manually.");return;}
  window.location="/cgi-bin/wifi_connect.sh?ssid="+encodeURIComponent(ssid)+"&password="+encodeURIComponent(password);
}
window.onload=loadNetworks;
</script>
</head>
<body>
<div class="page">
  <section class="hero">
    <div>
      <h1>Customer WiFi Wizard</h1>
      <div class="sub">Step 1: scan, select the customer SSID, enter password and connect</div>
      <div class="contact">Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE</div>
      <div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
    </div>
    <a class="top-btn" href="/">Back to Toolkit</a>
  </section>

  <div class="grid">
    <div class="card">
      <h2>Available Customer WiFi Networks</h2>
      <p class="desc">Select the correct customer SSID from the scan. This prevents typing mistakes.</p>
      <button class="btn grey" onclick="loadNetworks()">Refresh Scan</button>
      <div id="networks" style="margin-top:12px"></div>
    </div>

    <div class="card">
      <h2>Connect Selected WiFi</h2>
      <p class="desc">After selecting the SSID, only enter the password.</p>
      <div class="selected-box">
        <label>Selected SSID</label>
        <div id="selectedSsid" style="font-size:22px;font-weight:900">-</div>
        <div id="selectedDetails" class="muted">No network selected</div>
      </div>
      <input id="ssid" type="hidden">
      <label for="password">Password</label>
      <input id="password" type="password" placeholder="Customer WiFi password">
      <button class="btn green" onclick="connectWifi()">Connect Customer WiFi</button>
      <div class="note"><b>Workflow:</b> scan first, select SSID, enter password, then continue to the location survey from the connection page.</div>
    </div>
  </div>

  <div class="footer">Matrix Fitness &middot; Customer WiFi Wizard</div>
</div>
</body>
</html>
EOF
