#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
cat <<'HTML'
<html>
<head>
<meta charset="UTF-8">
<title>Customer WiFi Survey</title>

<style>
body {
    font-family: Arial;
    margin: 30px;
    background: #f5f5f5;
}

input {
    width: 400px;
    height: 40px;
    margin-bottom: 10px;
    padding-left: 10px;
}

button {
    width: 250px;
    height: 50px;
    margin-bottom: 10px;
    font-size: 16px;
}

.result {
    background: white;
    padding: 15px;
    border-radius: 8px;
    margin-top: 20px;
}
</style>

<script>

function connectWifi() {

    var ssid = document.getElementById("ssid").value;
    var password = document.getElementById("password").value;

    window.location =
        "/cgi-bin/wifi_connect.sh?ssid=" +
        encodeURIComponent(ssid) +
        "&password=" +
        encodeURIComponent(password);
}

function saveMeasurement() {

    var location =
        document.getElementById("location").value;

    window.location =
        "/cgi-bin/wifi_measure.sh?location=" +
        encodeURIComponent(location);
}

function restoreWifi() {

    window.location =
        "/cgi-bin/wifi_restore.sh";
}

</script>


<style>
body{background:#eef2f6!important;font-family:Arial,Helvetica,sans-serif!important;color:#1f2933!important}
.matrix-survey-wrap{max-width:1200px;margin:14px auto;background:#fff;border:1px solid #d9e2ec;border-radius:18px;box-shadow:0 8px 22px rgba(15,23,42,.08);padding:16px}
.matrix-survey-title{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:20px 22px;margin:14px auto;max-width:1200px;font-family:Arial,Helvetica,sans-serif;box-shadow:0 8px 22px rgba(15,23,42,.08)}
.matrix-survey-title h1{margin:0;font-size:28px}
.matrix-survey-title div{opacity:.9;margin-top:6px;font-size:14px}
input,select,button{border-radius:10px!important}
table{border-collapse:collapse}
</style>

</head>

<body>

<div class="matrix-survey-title">
  <h1>Matrix WiFi Survey</h1>
  <div>Customer WiFi scan and survey tool</div>
</div>

<div style="max-width:1200px;margin:14px auto 0;padding:0 12px;">
  <a href="/" style="display:inline-block;background:#005a9c;color:#fff;text-decoration:none;border-radius:12px;padding:11px 14px;font-family:Arial,Helvetica,sans-serif;font-weight:700;">Back to Toolkit</a>
</div>


<h1>Customer WiFi Survey</h1>

<h3>Connect Customer WiFi</h3>

<input id="ssid" placeholder="SSID"><br>
<input id="password" type="password" placeholder="Password"><br>

<button onclick="connectWifi()">
Connect Customer WiFi
</button>

<hr>

<h3>Location Survey</h3>

<input id="location" placeholder="Reception / Cardio / Stretch"><br>

<button onclick="saveMeasurement()">
Save Measurement
</button>

<hr>

<button onclick="restoreWifi()">
Restore Original WiFi
</button>

</body>
</html>
HTML
