#!/bin/sh
CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() { printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

write_builtin_defaults() {
    cat > "$1" <<'EOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
EOF
}

echo "Content-Type: text/html"
echo ""
mkdir -p /usr/local/matrix
[ -f "$DEFAULTS" ] || write_builtin_defaults "$DEFAULTS"

if [ -f "$DEFAULTS" ]; then
    [ -f "$CONFIG" ] && cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    [ -f "$CONFIG" ] && cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
    cp -f "$DEFAULTS" "$CONFIG"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    MSG="Factory/default profiles restored."
    CLASS="ok"
    echo "$(date '+%Y-%m-%d %H:%M:%S') Profiles restored from factory defaults" >> "$LOG"
else
    MSG="Default/master profile file could not be created."
    CLASS="err"
fi

E_MSG="$(html_escape "$MSG")"
cat <<EOF
<html><head><title>Restore Factory WiFi Profiles</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="3;url=/cgi-bin/wifi_manager.sh"><style>body{font-family:Arial;margin:20px;background:#f5f5f5}.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}h1{color:#005a9c}.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}</style></head><body><div class="box"><h1>Restore Factory Defaults</h1><p class="$CLASS">$E_MSG</p><p>You will return to WiFi Manager automatically.</p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></div></body></html>
EOF
