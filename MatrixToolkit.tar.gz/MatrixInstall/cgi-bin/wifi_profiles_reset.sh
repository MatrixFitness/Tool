#!/bin/sh

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
OLD_CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
url_decode(){ sed -e 's/+/ /g' -e 's/%0[Dd]//g' -e 's/%0[Aa]/ /g' -e 's/%3[Dd]/=/g' -e 's/%7[Bb]/{/g' -e 's/%7[Dd]/}/g' -e 's/%20/ /g' -e 's/%21/!/g' -e 's/%23/#/g' -e 's/%24/$/g' -e 's/%25/%/g' -e 's/%26/\&/g' -e 's/%28/(/g' -e 's/%29/)/g' -e 's/%2[Aa]/*/g' -e 's/%2[Bb]/+/g' -e 's/%2[Cc]/,/g' -e 's/%2[Dd]/-/g' -e 's/%2[Ee]/./g' -e 's/%2[Ff]/\//g' -e 's/%3[Aa]/:/g' -e 's/%3[Bb]/;/g' -e 's/%3[Ff]/?/g' -e 's/%40/@/g' -e 's/%5[Bb]/[/g' -e 's/%5[Dd]/]/g' -e 's/%5[Ee]/^/g' -e 's/%5[Ff]/_/g' -e 's/%7[Cc]/|/g' -e 's/%7[Ee]/~/g'; }
qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode; }

write_defaults(){ cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default
PROFILE1_MODE=DUAL
PROFILE1_2G_SSID={HOSTNAME}_2G
PROFILE1_2G_PASSWORD=matrixfitness
PROFILE1_5G_SSID={HOSTNAME}_5G
PROFILE1_5G_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM
PROFILE2_MODE=SINGLE
PROFILE2_BAND=2G
PROFILE2_SSID=egym
PROFILE2_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2

PROFILE3_NAME=Customer Both
PROFILE3_MODE=DUAL
PROFILE3_2G_SSID=ClubWifi
PROFILE3_2G_PASSWORD=Welkom123
PROFILE3_5G_SSID=ClubWifi
PROFILE3_5G_PASSWORD=Welkom123
DEFEOF
}
ensure_config(){ mkdir -p /usr/local/matrix 2>/dev/null; if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null; fi; if [ ! -f "$CONFIG" ]; then if [ -f "$DEFAULTS" ]; then cat "$DEFAULTS" > "$CONFIG" 2>/dev/null; else write_defaults "$CONFIG"; fi; fi; [ -f "$DEFAULTS" ] || write_defaults "$DEFAULTS"; [ -f "$PREVIOUS" ] || cat "$CONFIG" > "$PREVIOUS" 2>/dev/null; chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null; }
profile_count(){ grep -o "^PROFILE[0-9][0-9]*_" "$CONFIG" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1; }
pv(){ IDX="$1"; KEY="$2"; grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-; }
backup_current(){ cat "$CONFIG" > "$PREVIOUS" 2>/dev/null; cat "$CONFIG" > "/tmp/matrix_wifi_profiles.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null; }
resolve_ssid(){ RAW="$1"; HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="Matrix"; printf '%s' "$RAW" | sed "s/{HOSTNAME}/$HOST/g"; }
upper(){ printf '%s' "$1" | tr 'a-z' 'A-Z'; }
mode_norm(){ M="$(upper "$1")"; case "$M" in DUAL|BOTH) echo DUAL;; *) echo SINGLE;; esac; }
band_norm(){ B="$(upper "$1")"; case "$B" in 2G|2.4G|2.4GHZ) echo 2G;; 5G|5GHZ) echo 5G;; BOTH|DUAL|ALL) echo BOTH;; *) echo 5G;; esac; }
band_label(){ case "$(band_norm "$1")" in 2G) echo "2.4 GHz";; 5G) echo "5 GHz";; BOTH) echo "2.4 + 5 GHz";; esac; }
write_config_stream(){ TMP="$1"; cat "$TMP" > "$CONFIG"; chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null; }

migrate_profiles(){
    COUNT="$(profile_count)"; [ -z "$COUNT" ] && return 0
    NEED=0; i=1
    while [ "$i" -le "$COUNT" ]; do [ -z "$(pv "$i" MODE)" ] && NEED=1; i=$((i+1)); done
    [ "$NEED" -eq 0 ] && return 0
    TMP="/tmp/matrix_wifi_profiles_migrate.$$"; : > "$TMP"
    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(pv "$i" NAME)"; OLDSSID="$(pv "$i" SSID)"; OLDPASS="$(pv "$i" PASSWORD)"; OLDBAND="$(band_norm "$(pv "$i" BAND)")"
        [ -z "$NAME" ] && NAME="Profile $i"
        LC="$(printf '%s %s' "$NAME" "$OLDSSID" | tr 'A-Z' 'a-z')"
        case "$LC" in
            *egym*) MODE="SINGLE"; OLDBAND="2G";;
            *matrix*|*hostname*) MODE="DUAL";;
            *) MODE="SINGLE"; [ -z "$(pv "$i" BAND)" ] && OLDBAND="5G";;
        esac
        if [ "$MODE" = "DUAL" ]; then
            [ -z "$OLDPASS" ] && OLDPASS="matrixfitness"
            echo "PROFILE${i}_NAME=$NAME" >> "$TMP"; echo "PROFILE${i}_MODE=DUAL" >> "$TMP"; echo "PROFILE${i}_2G_SSID={HOSTNAME}_2G" >> "$TMP"; echo "PROFILE${i}_2G_PASSWORD=$OLDPASS" >> "$TMP"; echo "PROFILE${i}_5G_SSID={HOSTNAME}_5G" >> "$TMP"; echo "PROFILE${i}_5G_PASSWORD=$OLDPASS" >> "$TMP"; echo "" >> "$TMP"
        else
            [ -z "$OLDSSID" ] && OLDSSID="NewSSID"; [ -z "$OLDPASS" ] && OLDPASS="password"
            echo "PROFILE${i}_NAME=$NAME" >> "$TMP"; echo "PROFILE${i}_MODE=SINGLE" >> "$TMP"; echo "PROFILE${i}_BAND=$OLDBAND" >> "$TMP"; echo "PROFILE${i}_SSID=$OLDSSID" >> "$TMP"; echo "PROFILE${i}_PASSWORD=$OLDPASS" >> "$TMP"; echo "" >> "$TMP"
        fi
        i=$((i+1))
    done
    backup_current; write_config_stream "$TMP"; rm -f "$TMP" 2>/dev/null; echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi profiles migrated to v62 dual format" >> "$LOG"
}
init_profiles(){ ensure_config; migrate_profiles; }

page_header(){ TITLE="$1"; cat <<EOF
Content-Type: text/html

<!DOCTYPE html><html><head><title>$TITLE</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1120px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:middle}th{background:#f0f6fb;color:#005a9c}input[type=text],input[type=password],select{width:100%;height:40px;border:1px solid #ccc;border-radius:6px;padding:0 8px;box-sizing:border-box;font-size:14px;background:white}.field{margin:12px 0}.field label{display:block;font-size:12px;color:#666;font-weight:bold;margin-bottom:4px}.twocol{display:grid;grid-template-columns:1fr 1fr;gap:16px}.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid,.twocol{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>function confirmApply(n){return confirm('Apply WiFi profile: '+n+'\\n\\nWiFi will reload. Continue?');}function confirmDelete(n){return confirm('Delete profile: '+n+' ?');}function confirmPrevious(){return confirm('Restore previous profile configuration?');}function confirmFactory(){return confirm('Restore factory/default profiles?');}function togglePw(id){var x=document.getElementById(id);x.type=x.type==='password'?'text':'password';}</script>
</head><body><div class="page">
EOF
}
page_footer(){ echo '</div></body></html>'; }

ensure_config
write_defaults "$DEFAULTS"; backup_current; cat "$DEFAULTS" > "$CONFIG"; chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null; echo "$(date '+%Y-%m-%d %H:%M:%S') Profiles restored from factory defaults" >> "$LOG"
echo "Content-Type: text/html"; echo ""; echo "<html><head><meta http-equiv=\"refresh\" content=\"2;url=/cgi-bin/wifi_manager.sh\"></head><body style=\"font-family:Arial;margin:20px;\"><h1>Restore Factory Defaults</h1><p>Factory profiles restored.</p><p><a href=\"/cgi-bin/wifi_manager.sh\">Back</a></p></body></html>"
