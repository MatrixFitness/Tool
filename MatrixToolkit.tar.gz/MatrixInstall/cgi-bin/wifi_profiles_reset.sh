#!/bin/sh
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"
ensure_wifi_files
write_system_defaults "$SYSTEM_DEFAULTS"
cp -f "$SYSTEM_DEFAULTS" "$SYSTEM_PROFILES"
chmod 666 "$SYSTEM_DEFAULTS" "$SYSTEM_PROFILES" 2>/dev/null
echo "$(date '+%Y-%m-%d %H:%M:%S') Restored system WiFi profiles to defaults" >> "$LOG"
echo "Content-Type: text/html"
echo ""
echo "<html><head><meta http-equiv=\"refresh\" content=\"1;url=/cgi-bin/wifi_manager.sh\"></head><body>Factory profiles restored.</body></html>"
