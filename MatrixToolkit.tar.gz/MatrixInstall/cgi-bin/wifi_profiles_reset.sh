#!/bin/sh
. /usr/local/matrix/web/cgi-bin/wifi_lib.sh
ensure_config
write_defaults "$DEFAULTS"
backup_current
cat "$DEFAULTS" > "$CONFIG"
chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
echo "$(date '+%Y-%m-%d %H:%M:%S') Profiles restored from factory defaults v64" >> "$LOG"
echo "Content-Type: text/html"; echo ""; echo "<html><head><meta http-equiv=\"refresh\" content=\"2;url=/cgi-bin/wifi_manager.sh\"></head><body style=\"font-family:Arial;margin:20px;\"><h1>Restore Factory Profiles</h1><p>Factory profiles restored.</p><p><a href=\"/cgi-bin/wifi_manager.sh\">Back</a></p></body></html>"
