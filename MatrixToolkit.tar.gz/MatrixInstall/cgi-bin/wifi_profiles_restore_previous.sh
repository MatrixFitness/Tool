#!/bin/sh
# Matrix Toolkit v60 - Restore previous WiFi profiles
CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
LOG="/tmp/matrix_wifi_manager.log"
html_escape() { printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
echo "Content-Type: text/html"; echo ""
mkdir -p /usr/local/matrix
if [ -f "$PREVIOUS" ]; then
    TMP="/tmp/matrix_wifi_profiles_restore.$$"
    [ -f "$CONFIG" ] && cp -f "$CONFIG" "$TMP" 2>/dev/null
    cp -f "$PREVIOUS" "$CONFIG"
    [ -f "$TMP" ] && cp -f "$TMP" "$PREVIOUS" 2>/dev/null
    rm -f "$TMP" 2>/dev/null
    chmod 666 "$CONFIG" "$PREVIOUS" 2>/dev/null
    MSG="Previous profiles restored. You can use Restore Previous again to toggle back."; CLASS="ok"
    echo "$(date '+%Y-%m-%d %H:%M:%S') Profiles restored from previous" >> "$LOG"
else
    MSG="No previous profile configuration found."; CLASS="err"
fi
E_MSG="$(html_escape "$MSG")"
cat <<EOF
<html><head><title>Restore Previous</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="3;url=/cgi-bin/wifi_manager.sh"><style>body{font-family:Arial;margin:20px;background:#f5f5f5}.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}h1{color:#005a9c}.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}</style></head><body><div class="box"><h1>Restore Previous</h1><p class="$CLASS">$E_MSG</p><p>You will return to WiFi Manager automatically.</p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></div></body></html>
EOF
