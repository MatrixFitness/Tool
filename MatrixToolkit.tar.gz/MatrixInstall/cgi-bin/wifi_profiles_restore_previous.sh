#!/bin/sh
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"
ensure_wifi_files
if [ -f "/usr/local/matrix/matrix_wifi_user_profiles.previous" ]; then
    cp -f "/usr/local/matrix/matrix_wifi_user_profiles.previous" "$USER_PROFILES"
    chmod 666 "$USER_PROFILES" 2>/dev/null
    MSG="Previous user profiles restored."
else
    MSG="No previous user profile backup found."
fi
echo "$(date '+%Y-%m-%d %H:%M:%S') $MSG" >> "$LOG"
echo "Content-Type: text/html"; echo ""
echo "<html><head><meta http-equiv=\"refresh\" content=\"2;url=/cgi-bin/wifi_manager.sh\"></head><body style=\"font-family:Arial;margin:20px;\"><h1>Restore Previous</h1><p>$MSG</p><p><a href=\"/cgi-bin/wifi_manager.sh\">Back</a></p></body></html>"
