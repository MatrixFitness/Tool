#!/bin/sh
. /usr/local/matrix/web/cgi-bin/wifi_lib.sh
ensure_config
if [ -f "$PREVIOUS" ]; then TMP="/tmp/matrix_wifi_profiles_restore.$$"; cat "$CONFIG" > "$TMP" 2>/dev/null; cat "$PREVIOUS" > "$CONFIG"; cat "$TMP" > "$PREVIOUS" 2>/dev/null; rm -f "$TMP" 2>/dev/null; chmod 666 "$CONFIG" "$PREVIOUS" 2>/dev/null; MSG="Previous profiles restored."; else MSG="No previous profile configuration found."; fi
echo "$(date '+%Y-%m-%d %H:%M:%S') $MSG" >> "$LOG"
echo "Content-Type: text/html"; echo ""; echo "<html><head><meta http-equiv=\"refresh\" content=\"2;url=/cgi-bin/wifi_manager.sh\"></head><body style=\"font-family:Arial;margin:20px;\"><h1>Restore Previous</h1><p>$MSG</p><p><a href=\"/cgi-bin/wifi_manager.sh\">Back</a></p></body></html>"
