#!/bin/sh

echo "Content-Type: text/html"
echo ""

echo "<html>"
echo "<head>
<meta charset="UTF-8">"
echo "<title>Matrix Connectiviteit</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;}"
echo "table{border-collapse:collapse;width:100%;}"
echo "th,td{border:1px solid #ccc;padding:8px;text-align:left;}"
echo "th{background:#f2f2f2;}"
echo ".pass{color:green;font-weight:bold;}"
echo ".fail{color:red;font-weight:bold;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h1>Matrix Connectiviteit</h1>"

FAIL=0

echo "<table>"
echo "<tr><th>Service</th><th>Status</th></tr>"

check_host() {
if nslookup "$1" >/dev/null 2>&1
then
echo "<tr><td>$1</td><td class='pass'>PASS</td></tr>"
else
echo "<tr><td>$1</td><td class='fail'>FAIL</td></tr>"
FAIL=1
fi
}

check_host "dapi.jfit.co"
check_host "orion.jfit.co"
check_host "mwtn.jfit.co"
check_host "pt-client.jfit.co"
check_host "facilitycalendar.jfit.co"
check_host "frontend-config.jfit.co"
check_host "config.jhtassets.com"
check_host "images.jhtassets.com"
check_host "location-ip.jfit.co"
check_host "am4.matrixfitness.com"
check_host "am4-api.jfit.co"

echo "</table>"
echo "<hr>"

if [ "$FAIL" -eq 0 ]
then
echo "<h2 style='color:green'>STATUS: GOEDGEKEURD</h2>"
echo "<p>Alle kritische Matrix services zijn bereikbaar.</p>"
else
echo "<h2 style='color:red'>STATUS: AFGEKEURD</h2>"
echo "<p>Niet alle kritische Matrix services zijn bereikbaar.</p>"
fi

echo "<br>"
echo "<a href='/index.html'>Terug naar Matrix Toolkit</a>"

echo "</body>"
echo "</html>"
