#!/bin/sh

printf "Content-Type: text/html\n\n"

VERSION_FILE="/usr/local/matrix/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | head -n1 | cut -d= -f2-
}

get_block() {
    KEY="$1"
    awk -v key="$KEY" '
        $0 == key "<<END" {show=1; next}
        $0 == "END" && show==1 {exit}
        show==1 {print}
    ' "$VERSION_FILE" 2>/dev/null
}

html_escape() {
    sed \
        -e 's/&/\&amp;/g' \
        -e 's/</\&lt;/g' \
        -e 's/>/\&gt;/g' \
        -e 's/"/\&quot;/g'
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_block Changes)
[ -z "$CHANGES" ] && CHANGES=$(get_value Changes)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
GITHUB=$(get_value GitHub)

[ -z "$VERSION" ] && VERSION="0.0"
[ -z "$BUILD" ] && BUILD="0000-00-00"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="None"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="unknown@matrixfitness.nl"

VERSION_HTML=$(printf '%s' "$VERSION" | html_escape)
BUILD_HTML=$(printf '%s' "$BUILD" | html_escape)
RELEASE_HTML=$(printf '%s' "$RELEASE" | html_escape)
CHANGES_HTML=$(printf '%s' "$CHANGES" | html_escape)
COMPANY_HTML=$(printf '%s' "$COMPANY" | html_escape)
AUTHOR_HTML=$(printf '%s' "$AUTHOR" | html_escape)
EMAIL_HTML=$(printf '%s' "$EMAIL" | html_escape)
GITHUB_HTML=$(printf '%s' "$GITHUB" | html_escape)

# Reliable ZeroTier IP lookup. Prefer the known ZeroTier IP range first, then any zt interface.
ZT_IP=$(ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)
[ -z "$ZT_IP" ] && ZT_IP=$(ip -4 addr show 2>/dev/null | awk '/scope global/ && /zt/ {print $2}' | cut -d/ -f1 | head -1)

cat <<HTML_EOF
<div style="font-size:13px; line-height:1.5; color:#555;">
<b>Matrix Toolkit v$VERSION_HTML</b><br>
Build $BUILD_HTML<br>
Release $RELEASE_HTML<br>
<div style="white-space: pre-line; margin-top:4px;">Changes $CHANGES_HTML</div>

<br>

$COMPANY_HTML<br>
Created by $AUTHOR_HTML<br>
$EMAIL_HTML
HTML_EOF

if [ -n "$ZT_IP" ]; then
    ZT_IP_HTML=$(printf '%s' "$ZT_IP" | html_escape)
cat <<HTML_EOF

<br><br>
<b>ZeroTier Remote Access</b><br>
Toolkit:
<a href="http://$ZT_IP_HTML:8080" target="_blank">http://$ZT_IP_HTML:8080</a><br>

Admin:
<a href="http://$ZT_IP_HTML:8081/cgi-bin/admin_login.sh" target="_blank">http://$ZT_IP_HTML:8081/cgi-bin/admin_login.sh</a>
HTML_EOF
else
cat <<HTML_EOF

<br><br>
<b>ZeroTier Remote Access</b><br>
Not connected
HTML_EOF
fi

if [ -n "$GITHUB" ]; then
cat <<HTML_EOF

<br><br>
Repository:<br>
<a href="$GITHUB_HTML" target="_blank">$GITHUB_HTML</a>
HTML_EOF
fi

cat <<HTML_EOF
</div>
HTML_EOF
