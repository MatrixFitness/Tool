#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION_FILE="/usr/local/matrix/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

html_escape() {
    sed \
        -e 's/&/\&amp;/g' \
        -e 's/</\&lt;/g' \
        -e 's/>/\&gt;/g' \
        -e 's/"/\&quot;/g'
}

PAGE_NAME="Matrix Toolkit"
case "$QUERY_STRING" in
    *name=Matrix%20Admin*) PAGE_NAME="Matrix Admin" ;;
    *name=Matrix%20Toolkit*) PAGE_NAME="Matrix Toolkit" ;;
esac

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
MESSAGE=$(get_value Message)

[ -z "$VERSION" ] && VERSION="0.0"
[ -z "$BUILD" ] && BUILD="0000-00-00"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="None"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="unknown@matrixfitness.nl"
[ -z "$MESSAGE" ] && MESSAGE="Message"

PAGE_NAME=$(printf '%s' "$PAGE_NAME" | html_escape)
VERSION=$(printf '%s' "$VERSION" | html_escape)
BUILD=$(printf '%s' "$BUILD" | html_escape)
RELEASE=$(printf '%s' "$RELEASE" | html_escape)
CHANGES=$(printf '%s' "$CHANGES" | html_escape)
COMPANY=$(printf '%s' "$COMPANY" | html_escape)
AUTHOR=$(printf '%s' "$AUTHOR" | html_escape)
EMAIL=$(printf '%s' "$EMAIL" | html_escape)
MESSAGE=$(printf '%s' "$MESSAGE" | html_escape)

MESSAGE=$(echo "$MESSAGE" | sed 's/&amp;&amp;&amp;/<br>/g')

cat << EOF
${PAGE_NAME} v${VERSION}<br>
Build ${BUILD}<br>
Release ${RELEASE}<br>
Changes ${CHANGES}

<br><br>

${COMPANY}<br>
Created by ${AUTHOR}<br>
${EMAIL}<br>
${MESSAGE}
EOF
