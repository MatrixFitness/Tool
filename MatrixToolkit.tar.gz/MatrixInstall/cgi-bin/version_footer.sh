#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION_FILE="/usr/local/matrix/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
MESSAGE=$(get_value Message)
GITHUB=$(get_value GitHub)

[ -z "$VERSION" ] && VERSION="0.0"
[ -z "$BUILD" ] && BUILD="0000-00-00"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="None"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="unknown@matrixfitness.nl"
[ -z "$MESSAGE" ] && MESSAGE="Message"

# Convert line breaks from version.txt
MESSAGE=$(echo "$MESSAGE" | sed 's/&&&/<br><br>/g')

# Get ZeroTier IP automatically
ZT_IP=$(ip -4 addr show 2>/dev/null | \
    awk '/scope global zt/ {print $2}' | \
    cut -d/ -f1 | head -1)

cat << EOF
Matrix Toolkit v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL

<br><br>

$MESSAGE
EOF

if [ -n "$ZT_IP" ]; then
cat << EOF

<br><br>
<b>ZeroTier Remote Access</b><br>
Toolkit:
<a href="http://$ZT_IP:8080" target="_blank">
http://$ZT_IP:8080
</a><br>

Admin:
<a href="http://$ZT_IP:8080/admin/index.html" target="_blank">
http://$ZT_IP:8080/admin/index.html
</a>
EOF
else
cat << EOF

<br><br>
<b>ZeroTier Remote Access</b><br>
Not connected
EOF
fi

if [ -n "$GITHUB" ]; then
cat << EOF

<br><br>
Repository:<br>
<a href="$GITHUB" target="_blank">$GITHUB</a>
EOF
fi