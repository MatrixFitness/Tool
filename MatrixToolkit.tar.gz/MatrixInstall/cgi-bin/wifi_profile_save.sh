#!/bin/sh
# Matrix Toolkit - Save one WiFi profile CLEAN FINAL

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
OLD_CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    sed \
        -e 's/+/ /g' \
        -e 's/%0[Dd]//g' \
        -e 's/%0[Aa]/ /g' \
        -e 's/%3[Dd]/=/g' \
        -e 's/%7[Bb]/{/g' \
        -e 's/%7[Dd]/}/g' \
        -e 's/%20/ /g' \
        -e 's/%21/!/g' \
        -e 's/%23/#/g' \
        -e 's/%24/$/g' \
        -e 's/%25/%/g' \
        -e 's/%26/\&/g' \
        -e 's/%28/(/g' \
        -e 's/%29/)/g' \
        -e 's/%2[Aa]/*/g' \
        -e 's/%2[Bb]/+/g' \
        -e 's/%2[Cc]/,/g' \
        -e 's/%2[Dd]/-/g' \
        -e 's/%2[Ee]/./g' \
        -e 's/%2[Ff]/\//g' \
        -e 's/%3[Aa]/:/g' \
        -e 's/%3[Bb]/;/g' \
        -e 's/%3[Ff]/?/g' \
        -e 's/%40/@/g' \
        -e 's/%5[Bb]/[/g' \
        -e 's/%5[Dd]/]/g' \
        -e 's/%5[Ee]/^/g' \
        -e 's/%5[Ff]/_/g' \
        -e 's/%7[Cc]/|/g' \
        -e 's/%7[Ee]/~/g'
}

qs() {
    FIELD="$1"
    printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode
}

write_defaults() {
    cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
DEFEOF
}

ensure_config() {
    mkdir -p /usr/local/matrix

    if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then
        cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null
    fi

    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then
            cp -f "$DEFAULTS" "$CONFIG" 2>/dev/null
        else
            write_defaults "$CONFIG"
        fi
    fi

    if [ ! -f "$DEFAULTS" ]; then
        cp -f "$CONFIG" "$DEFAULTS" 2>/dev/null || write_defaults "$DEFAULTS"
    fi

    if [ ! -f "$PREVIOUS" ]; then
        cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    fi

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_count() {
    grep -o "^PROFILE[0-9][0-9]*_" "$CONFIG" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1
}

profile_value() {
    IDX="$1"
    KEY="$2"
    grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" | head -n1 | cut -d= -f2-
}

backup_current() {
    cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
}

page_header() {
    TITLE="$1"
    cat <<EOF
Content-Type: text/html

<!DOCTYPE html>
<html>
<head>
<title>$TITLE</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1040px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}
h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}
.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}
.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}
.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
table{width:100%;border-collapse:collapse;background:white}
th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:middle}
th{background:#f0f6fb;color:#005a9c}
input[type=text],input[type=password]{width:100%;height:40px;border:1px solid #ccc;border-radius:6px;padding:0 8px;box-sizing:border-box;font-size:14px}
.field{margin:12px 0}.field label{display:block;font-size:12px;color:#666;font-weight:bold;margin-bottom:4px}
.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function confirmApply(name,ssid){return confirm('Apply WiFi profile: '+name+'\\nSSID: '+ssid+'\\n\\nThis will reload 5 GHz WiFi. Continue?');}
function confirmDelete(name){return confirm('Delete profile: '+name+' ?');}
function confirmPrevious(){return confirm('Restore previous profile configuration?');}
function confirmFactory(){return confirm('Restore factory/default profiles?');}
function togglePw(id){var x=document.getElementById(id);x.type=x.type==='password'?'text':'password';}
</script>
</head>
<body><div class="page">
EOF
}

page_footer() {
    echo '</div></body></html>'
}

save_profile() {
    IDX="$1"
    NEW_NAME="$2"
    NEW_SSID="$3"
    NEW_PASS="$4"

    TMP="/tmp/matrix_wifi_profiles_save.$$"
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0
    [ "$IDX" -gt "$COUNT" ] 2>/dev/null && COUNT="$IDX"

    backup_current
    : > "$TMP"

    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(profile_value "$i" NAME)"
        SSID="$(profile_value "$i" SSID)"
        PASS="$(profile_value "$i" PASSWORD)"

        if [ "$i" = "$IDX" ]; then
            NAME="$NEW_NAME"
            SSID="$NEW_SSID"
            PASS="$NEW_PASS"
        fi

        if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
            {
                echo "PROFILE${i}_NAME=$NAME"
                echo "PROFILE${i}_SSID=$SSID"
                echo "PROFILE${i}_PASSWORD=$PASS"
                echo ""
            } >> "$TMP"
        fi
        i=$((i+1))
    done

    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

add_profile() {
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0
    NEW=$((COUNT+1))
    backup_current
    {
        echo ""
        echo "PROFILE${NEW}_NAME=New Profile"
        echo "PROFILE${NEW}_SSID=NewSSID"
        echo "PROFILE${NEW}_PASSWORD=password"
    } >> "$CONFIG"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    echo "$NEW"
}

delete_profile() {
    IDX="$1"
    TMP="/tmp/matrix_wifi_profiles_delete.$$"
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0
    NEW=1
    backup_current
    : > "$TMP"

    i=1
    while [ "$i" -le "$COUNT" ]; do
        if [ "$i" != "$IDX" ]; then
            NAME="$(profile_value "$i" NAME)"
            SSID="$(profile_value "$i" SSID)"
            PASS="$(profile_value "$i" PASSWORD)"
            if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
                {
                    echo "PROFILE${NEW}_NAME=$NAME"
                    echo "PROFILE${NEW}_SSID=$SSID"
                    echo "PROFILE${NEW}_PASSWORD=$PASS"
                    echo ""
                } >> "$TMP"
                NEW=$((NEW+1))
            fi
        fi
        i=$((i+1))
    done

    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

ensure_config

ACTION="$(qs action)"
IDX="$(qs profile)"

MSG="No action performed."
CLASS="err"
REDIRECT="/cgi-bin/wifi_manager.sh?nocache=$(date +%s)"

case "$ACTION" in
    save)
        NAME="$(qs name)"
        SSID="$(qs ssid)"
        PASS="$(qs password)"
        if [ -z "$IDX" ] || [ -z "$NAME" ] || [ -z "$SSID" ] || [ -z "$PASS" ]; then
            MSG="Profile not saved. Name, SSID and password are required."
            CLASS="err"
        else
            save_profile "$IDX" "$NAME" "$SSID" "$PASS"
            MSG="Profile $IDX saved."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX saved name=$NAME ssid=$SSID" >> "$LOG"
        fi
        ;;
    add)
        NEW="$(add_profile)"
        MSG="New profile added."
        CLASS="ok"
        REDIRECT="/cgi-bin/wifi_profile_edit.sh?p=$NEW"
        echo "$(date '+%Y-%m-%d %H:%M:%S') New profile $NEW added" >> "$LOG"
        ;;
    delete)
        if [ -n "$IDX" ]; then
            delete_profile "$IDX"
            MSG="Profile $IDX deleted."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX deleted" >> "$LOG"
        fi
        ;;
esac

E_MSG="$(html_escape "$MSG")"

page_header "WiFi Profile Save"
cat <<EOF
<h1>WiFi Profile Save</h1>
<div class="card">
<p class="$CLASS">$E_MSG</p>
<p>You will return automatically.</p>
<a class="btn blue" href="$REDIRECT">Continue</a>
</div>
<meta http-equiv="refresh" content="1;url=$REDIRECT">
EOF
page_footer
