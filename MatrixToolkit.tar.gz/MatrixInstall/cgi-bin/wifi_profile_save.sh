#!/bin/sh
# Matrix Toolkit v60 - Save WiFi profile
# Uses GET fields to avoid BusyBox/uHTTPd POST issues.

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    sed \
        -e 's/+/ /g' \
        -e 's/%0[Dd]//g' \
        -e 's/%0[Aa]/ /g' \
        -e 's/%3[Dd]/=/g' \
        -e 's/%7[Bb]/{/g' \
        -e 's/%7[Dd]/}/g' \
        -e 's/%20/ /g' \
        -e 's/%21/!/g' \
        -e 's/%23/#/g' \
        -e 's/%24/$/g' \
        -e 's/%25/%/g' \
        -e 's/%26/\&/g' \
        -e 's/%28/(/g' \
        -e 's/%29/)/g' \
        -e 's/%2[Aa]/*/g' \
        -e 's/%2[Bb]/+/g' \
        -e 's/%2[Cc]/,/g' \
        -e 's/%2[Dd]/-/g' \
        -e 's/%2[Ee]/./g' \
        -e 's/%2[Ff]/\//g' \
        -e 's/%3[Aa]/:/g' \
        -e 's/%3[Bb]/;/g' \
        -e 's/%3[Ff]/?/g' \
        -e 's/%40/@/g' \
        -e 's/%5[Bb]/[/g' \
        -e 's/%5[Dd]/]/g' \
        -e 's/%5[Ee]/^/g' \
        -e 's/%5[Ff]/_/g' \
        -e 's/%7[Cc]/|/g' \
        -e 's/%7[Ee]/~/g'
}

get_qs_field() {
    FIELD="$1"
    printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode
}

write_builtin_defaults() {
    cat > "$1" <<'EOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
EOF
}

ensure_config() {
    mkdir -p /usr/local/matrix

    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then
            cp -f "$DEFAULTS" "$CONFIG" 2>/dev/null
        else
            write_builtin_defaults "$CONFIG"
        fi
    fi

    if [ ! -f "$DEFAULTS" ]; then
        cp -f "$CONFIG" "$DEFAULTS" 2>/dev/null || write_builtin_defaults "$DEFAULTS"
    fi

    if [ ! -f "$PREVIOUS" ]; then
        cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    fi

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_count() {
    awk -F= '
        /^PROFILE[0-9]+_NAME=/ { n=$1; gsub(/^PROFILE/,"",n); gsub(/_NAME$/,"",n); if (n>max) max=n }
        /^PROFILE[0-9]+_SSID=/ { n=$1; gsub(/^PROFILE/,"",n); gsub(/_SSID$/,"",n); if (n>max) max=n }
        /^PROFILE[0-9]+_PASSWORD=/ { n=$1; gsub(/^PROFILE/,"",n); gsub(/_PASSWORD$/,"",n); if (n>max) max=n }
        END { if (max=="") max=0; print max }
    ' "$CONFIG"
}

get_profile_value() {
    IDX="$1"
    KEY="$2"
    grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" | head -n1 | cut -d= -f2-
}

rebuild_save_profile() {
    IDX="$1"
    NEW_NAME="$2"
    NEW_SSID="$3"
    NEW_PASS="$4"

    TMP="/tmp/matrix_wifi_profiles_save.$$"
    COUNT="$(profile_count)"
    [ "$IDX" -gt "$COUNT" ] 2>/dev/null && COUNT="$IDX"

    cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null

    : > "$TMP"
    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(get_profile_value "$i" NAME)"
        SSID="$(get_profile_value "$i" SSID)"
        PASS="$(get_profile_value "$i" PASSWORD)"

        if [ "$i" = "$IDX" ]; then
            NAME="$NEW_NAME"
            SSID="$NEW_SSID"
            PASS="$NEW_PASS"
        fi

        if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
            {
                echo "PROFILE${i}_NAME=$NAME"
                echo "PROFILE${i}_SSID=$SSID"
                echo "PROFILE${i}_PASSWORD=$PASS"
                echo ""
            } >> "$TMP"
        fi
        i=$((i+1))
    done

    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

delete_profile() {
    IDX="$1"
    TMP="/tmp/matrix_wifi_profiles_delete.$$"
    COUNT="$(profile_count)"
    NEW=1

    cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null

    : > "$TMP"
    i=1
    while [ "$i" -le "$COUNT" ]; do
        if [ "$i" != "$IDX" ]; then
            NAME="$(get_profile_value "$i" NAME)"
            SSID="$(get_profile_value "$i" SSID)"
            PASS="$(get_profile_value "$i" PASSWORD)"
            if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
                {
                    echo "PROFILE${NEW}_NAME=$NAME"
                    echo "PROFILE${NEW}_SSID=$SSID"
                    echo "PROFILE${NEW}_PASSWORD=$PASS"
                    echo ""
                } >> "$TMP"
                NEW=$((NEW+1))
            fi
        fi
        i=$((i+1))
    done

    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

ensure_config

ACTION="$(get_qs_field action)"
IDX="$(get_qs_field profile)"
MSG="No action performed."
CLASS="err"

case "$ACTION" in
    save)
        NAME="$(get_qs_field name)"
        SSID="$(get_qs_field ssid)"
        PASS="$(get_qs_field password)"

        if [ -z "$IDX" ] || [ -z "$NAME" ] || [ -z "$SSID" ] || [ -z "$PASS" ]; then
            MSG="Profile not saved. Name, SSID and password are required."
            CLASS="err"
        else
            rebuild_save_profile "$IDX" "$NAME" "$SSID" "$PASS"
            MSG="Profile $IDX saved."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX saved name=$NAME ssid=$SSID" >> "$LOG"
        fi
        ;;
    delete)
        if [ -n "$IDX" ]; then
            delete_profile "$IDX"
            MSG="Profile $IDX deleted."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX deleted" >> "$LOG"
        fi
        ;;
    add)
        COUNT="$(profile_count)"
        NEW=$((COUNT+1))
        rebuild_save_profile "$NEW" "New Profile" "NewSSID" "password"
        MSG="New profile added."
        CLASS="ok"
        echo "$(date '+%Y-%m-%d %H:%M:%S') New profile added" >> "$LOG"
        ;;
esac

E_MSG="$(html_escape "$MSG")"

echo "Content-Type: text/html"
echo ""
cat <<EOF
<html>
<head>
<title>WiFi Profile Save</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="2;url=/cgi-bin/wifi_manager.sh">
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5}
.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}
h1{color:#005a9c}
.ok{color:#1f8a3b;font-weight:bold}
.err{color:#c82333;font-weight:bold}
.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}
</style>
</head>
<body>
<div class="box">
<h1>WiFi Profile Save</h1>
<p class="$CLASS">$E_MSG</p>
<p>You will return to WiFi Manager automatically.</p>
<a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a>
</div>
</body>
</html>
EOF
