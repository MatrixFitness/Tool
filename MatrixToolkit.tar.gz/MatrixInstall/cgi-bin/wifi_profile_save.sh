#!/bin/sh
# Matrix Toolkit - WiFi Profile Save DIRECT FIX
# Very simple save logic:
# - Save directly replaces PROFILEX_NAME / SSID / PASSWORD lines with sed
# - If profile does not exist, append it
# - Add appends only
# - Delete removes matching lines only

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    sed \
        -e 's/+/ /g' \
        -e 's/%0[Dd]//g' \
        -e 's/%0[Aa]/ /g' \
        -e 's/%3[Dd]/=/g' \
        -e 's/%7[Bb]/{/g' \
        -e 's/%7[Dd]/}/g' \
        -e 's/%20/ /g' \
        -e 's/%21/!/g' \
        -e 's/%23/#/g' \
        -e 's/%24/$/g' \
        -e 's/%25/%/g' \
        -e 's/%26/\&/g' \
        -e 's/%28/(/g' \
        -e 's/%29/)/g' \
        -e 's/%2[Aa]/*/g' \
        -e 's/%2[Bb]/+/g' \
        -e 's/%2[Cc]/,/g' \
        -e 's/%2[Dd]/-/g' \
        -e 's/%2[Ee]/./g' \
        -e 's/%2[Ff]/\//g' \
        -e 's/%3[Aa]/:/g' \
        -e 's/%3[Bb]/;/g' \
        -e 's/%3[Ff]/?/g' \
        -e 's/%40/@/g' \
        -e 's/%5[Bb]/[/g' \
        -e 's/%5[Dd]/]/g' \
        -e 's/%5[Ee]/^/g' \
        -e 's/%5[Ff]/_/g' \
        -e 's/%7[Cc]/|/g' \
        -e 's/%7[Ee]/~/g'
}

qs() {
    FIELD="$1"
    printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode
}

write_defaults() {
    cat > "$1" <<'EOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
EOF
}

ensure_config() {
    mkdir -p /usr/local/matrix

    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then
            cp -f "$DEFAULTS" "$CONFIG" 2>/dev/null
        else
            write_defaults "$CONFIG"
        fi
    fi

    if [ ! -f "$DEFAULTS" ]; then
        cp -f "$CONFIG" "$DEFAULTS" 2>/dev/null || write_defaults "$DEFAULTS"
    fi

    if [ ! -f "$PREVIOUS" ]; then
        cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    fi

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_count() {
    grep -o "^PROFILE[0-9][0-9]*_" "$CONFIG" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1
}

backup_current() {
    cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
}

safe_value() {
    # remove newlines and | because sed uses | as separator
    printf '%s' "$1" | tr '\r\n|' '   '
}

replace_or_append() {
    IDX="$1"
    KEY="$2"
    VALUE="$(safe_value "$3")"
    LINE="PROFILE${IDX}_${KEY}=${VALUE}"

    if grep -q "^PROFILE${IDX}_${KEY}=" "$CONFIG"; then
        # BusyBox sed -i safe enough here because separator is |
        sed -i "s|^PROFILE${IDX}_${KEY}=.*|$LINE|" "$CONFIG"
    else
        echo "$LINE" >> "$CONFIG"
    fi
}

save_profile() {
    IDX="$1"
    NAME="$2"
    SSID="$3"
    PASS="$4"

    backup_current

    replace_or_append "$IDX" "NAME" "$NAME"
    replace_or_append "$IDX" "SSID" "$SSID"
    replace_or_append "$IDX" "PASSWORD" "$PASS"

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

add_profile() {
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0
    NEW=$((COUNT+1))

    backup_current

    {
        echo ""
        echo "PROFILE${NEW}_NAME=New Profile"
        echo "PROFILE${NEW}_SSID=NewSSID"
        echo "PROFILE${NEW}_PASSWORD=password"
    } >> "$CONFIG"

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    echo "$NEW"
}

delete_profile() {
    IDX="$1"
    backup_current

    sed -i "/^PROFILE${IDX}_NAME=/d" "$CONFIG"
    sed -i "/^PROFILE${IDX}_SSID=/d" "$CONFIG"
    sed -i "/^PROFILE${IDX}_PASSWORD=/d" "$CONFIG"

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

page() {
    TITLE="$1"
    MSG="$2"
    CLASS="$3"
    REDIRECT="$4"

    E_MSG="$(html_escape "$MSG")"

    echo "Content-Type: text/html"
    echo ""
    cat <<EOF
<!DOCTYPE html>
<html>
<head>
<title>$TITLE</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="refresh" content="1;url=$REDIRECT">
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5}
.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}
h1{color:#005a9c}
.ok{color:#1f8a3b;font-weight:bold}
.err{color:#c82333;font-weight:bold}
.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}
</style>
</head>
<body>
<div class="box">
<h1>$TITLE</h1>
<p class="$CLASS">$E_MSG</p>
<p>You will return automatically.</p>
<a class="btn" href="$REDIRECT">Continue</a>
</div>
</body>
</html>
EOF
}

ensure_config

ACTION="$(qs action)"
IDX="$(qs profile)"

MSG="No action performed."
CLASS="err"
REDIRECT="/cgi-bin/wifi_manager.sh?nocache=$(date +%s)"

case "$ACTION" in
    save)
        NAME="$(qs name)"
        SSID="$(qs ssid)"
        PASS="$(qs password)"

        echo "$(date '+%Y-%m-%d %H:%M:%S') DEBUG query=$QUERY_STRING parsed profile=$IDX name=$NAME ssid=$SSID" >> "$LOG"

        if [ -z "$IDX" ] || [ -z "$NAME" ] || [ -z "$SSID" ] || [ -z "$PASS" ]; then
            MSG="Profile not saved. Name, SSID and password are required."
            CLASS="err"
        else
            save_profile "$IDX" "$NAME" "$SSID" "$PASS"
            MSG="Profile $IDX saved."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX saved name=$NAME ssid=$SSID" >> "$LOG"
        fi
        ;;
    add)
        NEW="$(add_profile)"
        MSG="New profile added."
        CLASS="ok"
        REDIRECT="/cgi-bin/wifi_profile_edit.sh?p=$NEW"
        echo "$(date '+%Y-%m-%d %H:%M:%S') New profile $NEW added" >> "$LOG"
        ;;
    delete)
        if [ -n "$IDX" ]; then
            delete_profile "$IDX"
            MSG="Profile $IDX deleted."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX deleted" >> "$LOG"
        fi
        ;;
esac

page "WiFi Profile Save" "$MSG" "$CLASS" "$REDIRECT"
