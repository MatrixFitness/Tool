#!/bin/sh
# Matrix Toolkit - WiFi Profile Save STREAM FIX
# Reason:
# CGI user may write to /usr/local/matrix/matrix_wifi_profiles.conf when file is chmod 666,
# but cannot use sed -i or cp over the file because that needs directory write permissions.
# This script writes via: cat /tmp/newfile > "$CONFIG"

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    sed \
        -e 's/+/ /g' \
        -e 's/%0[Dd]//g' \
        -e 's/%0[Aa]/ /g' \
        -e 's/%3[Dd]/=/g' \
        -e 's/%7[Bb]/{/g' \
        -e 's/%7[Dd]/}/g' \
        -e 's/%20/ /g' \
        -e 's/%21/!/g' \
        -e 's/%23/#/g' \
        -e 's/%24/$/g' \
        -e 's/%25/%/g' \
        -e 's/%26/\&/g' \
        -e 's/%28/(/g' \
        -e 's/%29/)/g' \
        -e 's/%2[Aa]/*/g' \
        -e 's/%2[Bb]/+/g' \
        -e 's/%2[Cc]/,/g' \
        -e 's/%2[Dd]/-/g' \
        -e 's/%2[Ee]/./g' \
        -e 's/%2[Ff]/\//g' \
        -e 's/%3[Aa]/:/g' \
        -e 's/%3[Bb]/;/g' \
        -e 's/%3[Ff]/?/g' \
        -e 's/%40/@/g' \
        -e 's/%5[Bb]/[/g' \
        -e 's/%5[Dd]/]/g' \
        -e 's/%5[Ee]/^/g' \
        -e 's/%5[Ff]/_/g' \
        -e 's/%7[Cc]/|/g' \
        -e 's/%7[Ee]/~/g'
}

qs() {
    FIELD="$1"
    printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode
}

write_defaults_to() {
    OUT="$1"
    cat > "$OUT" <<'EOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
EOF
}

ensure_config() {
    mkdir -p /usr/local/matrix 2>/dev/null

    if [ ! -f "$CONFIG" ]; then
        write_defaults_to "$CONFIG"
    fi

    if [ ! -f "$DEFAULTS" ]; then
        write_defaults_to "$DEFAULTS"
    fi

    if [ ! -f "$PREVIOUS" ]; then
        cat "$CONFIG" > "$PREVIOUS" 2>/dev/null
    fi

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_count() {
    grep -o "^PROFILE[0-9][0-9]*_" "$CONFIG" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1
}

backup_current() {
    cat "$CONFIG" > "$PREVIOUS" 2>/dev/null
    cat "$CONFIG" > "/tmp/matrix_wifi_profiles.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
}

save_profile_stream() {
    IDX="$1"
    NEW_NAME="$2"
    NEW_SSID="$3"
    NEW_PASS="$4"

    TMP="/tmp/matrix_wifi_profiles_stream.$$"
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0
    [ "$IDX" -gt "$COUNT" ] 2>/dev/null && COUNT="$IDX"

    backup_current
    : > "$TMP"

    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(grep "^PROFILE${i}_NAME=" "$CONFIG" | head -n1 | cut -d= -f2-)"
        SSID="$(grep "^PROFILE${i}_SSID=" "$CONFIG" | head -n1 | cut -d= -f2-)"
        PASS="$(grep "^PROFILE${i}_PASSWORD=" "$CONFIG" | head -n1 | cut -d= -f2-)"

        if [ "$i" = "$IDX" ]; then
            NAME="$NEW_NAME"
            SSID="$NEW_SSID"
            PASS="$NEW_PASS"
        fi

        if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
            {
                echo "PROFILE${i}_NAME=$NAME"
                echo "PROFILE${i}_SSID=$SSID"
                echo "PROFILE${i}_PASSWORD=$PASS"
                echo ""
            } >> "$TMP"
        fi

        i=$((i+1))
    done

    # Critical part: do not cp/mv/sed -i into CONFIG.
    # This only opens the already writable file and truncates it.
    cat "$TMP" > "$CONFIG"
    rm -f "$TMP" 2>/dev/null
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

add_profile_stream() {
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0
    NEW=$((COUNT+1))

    backup_current

    {
        echo ""
        echo "PROFILE${NEW}_NAME=New Profile"
        echo "PROFILE${NEW}_SSID=NewSSID"
        echo "PROFILE${NEW}_PASSWORD=password"
    } >> "$CONFIG"

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    echo "$NEW"
}

delete_profile_stream() {
    IDX="$1"
    TMP="/tmp/matrix_wifi_profiles_delete.$$"
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0
    NEW=1

    backup_current
    : > "$TMP"

    i=1
    while [ "$i" -le "$COUNT" ]; do
        if [ "$i" != "$IDX" ]; then
            NAME="$(grep "^PROFILE${i}_NAME=" "$CONFIG" | head -n1 | cut -d= -f2-)"
            SSID="$(grep "^PROFILE${i}_SSID=" "$CONFIG" | head -n1 | cut -d= -f2-)"
            PASS="$(grep "^PROFILE${i}_PASSWORD=" "$CONFIG" | head -n1 | cut -d= -f2-)"

            if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
                {
                    echo "PROFILE${NEW}_NAME=$NAME"
                    echo "PROFILE${NEW}_SSID=$SSID"
                    echo "PROFILE${NEW}_PASSWORD=$PASS"
                    echo ""
                } >> "$TMP"
                NEW=$((NEW+1))
            fi
        fi

        i=$((i+1))
    done

    cat "$TMP" > "$CONFIG"
    rm -f "$TMP" 2>/dev/null
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

page() {
    TITLE="$1"
    MSG="$2"
    CLASS="$3"
    REDIRECT="$4"
    E_MSG="$(html_escape "$MSG")"

    echo "Content-Type: text/html"
    echo ""
    cat <<EOF
<!DOCTYPE html>
<html>
<head>
<title>$TITLE</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="refresh" content="1;url=$REDIRECT">
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5}
.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}
h1{color:#005a9c}
.ok{color:#1f8a3b;font-weight:bold}
.err{color:#c82333;font-weight:bold}
.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}
</style>
</head>
<body>
<div class="box">
<h1>$TITLE</h1>
<p class="$CLASS">$E_MSG</p>
<p>You will return automatically.</p>
<a class="btn" href="$REDIRECT">Continue</a>
</div>
</body>
</html>
EOF
}

ensure_config

ACTION="$(qs action)"
IDX="$(qs profile)"
MSG="No action performed."
CLASS="err"
REDIRECT="/cgi-bin/wifi_manager.sh?nocache=$(date +%s)"

case "$ACTION" in
    save)
        NAME="$(qs name)"
        SSID="$(qs ssid)"
        PASS="$(qs password)"

        echo "$(date '+%Y-%m-%d %H:%M:%S') DEBUG stream query=$QUERY_STRING parsed profile=$IDX name=$NAME ssid=$SSID" >> "$LOG"

        if [ -z "$IDX" ] || [ -z "$NAME" ] || [ -z "$SSID" ] || [ -z "$PASS" ]; then
            MSG="Profile not saved. Name, SSID and password are required."
            CLASS="err"
        else
            save_profile_stream "$IDX" "$NAME" "$SSID" "$PASS"
            MSG="Profile $IDX saved."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX stream-saved name=$NAME ssid=$SSID" >> "$LOG"
        fi
        ;;
    add)
        NEW="$(add_profile_stream)"
        MSG="New profile added."
        CLASS="ok"
        REDIRECT="/cgi-bin/wifi_profile_edit.sh?p=$NEW"
        echo "$(date '+%Y-%m-%d %H:%M:%S') New profile $NEW added" >> "$LOG"
        ;;
    delete)
        if [ -n "$IDX" ]; then
            delete_profile_stream "$IDX"
            MSG="Profile $IDX deleted."
            CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX deleted" >> "$LOG"
        fi
        ;;
esac

page "WiFi Profile Save" "$MSG" "$CLASS" "$REDIRECT"
