#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

echo "Content-Type: text/html; charset=UTF-8"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""

LOG="/tmp/matrix_update_github.log"
REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"

STATUS="Not running"
REFRESH=""

if [ -f "$LOCK" ]; then
    STATUS="Running"
    REFRESH="<meta http-equiv=\"refresh\" content=\"5;url=/cgi-bin/update_github_log.sh?ts=$(date +%s)\">"
elif [ -f "$REQ" ]; then
    STATUS="Waiting for root worker"
    REFRESH="<meta http-equiv=\"refresh\" content=\"5;url=/cgi-bin/update_github_log.sh?ts=$(date +%s)\">"
elif [ -f "$LOG" ]; then
    STATUS="Finished"
fi

STATUS_CLASS="warn"
[ "$STATUS" = "Finished" ] && STATUS_CLASS="ok"
[ "$STATUS" = "Running" ] && STATUS_CLASS="ok"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>GitHub Update Log</title>
$REFRESH
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--blue:#005a9c}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1200px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}
.top-actions,.actions{display:flex;gap:10px;flex-wrap:wrap}.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer}.btn.light{background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35)}.btn.green{background:var(--ok)}.btn.grey{background:#667085}
.card{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:18px}
.status{display:inline-block;border-radius:999px;padding:7px 12px;font-weight:900;font-size:13px;color:#fff}.status.ok{background:var(--ok)}.status.warn{background:var(--warn)}
.logbox{background:#111827;color:#e5e7eb;padding:15px;border-radius:14px;white-space:pre-wrap;overflow:auto;font-family:Consolas,monospace;font-size:13px;line-height:1.35;margin-top:14px;max-height:70vh}
.note{color:var(--muted);font-size:13px;line-height:1.45}.top-log-actions{background:#f8fafc;border:1px solid var(--border);border-radius:14px;padding:12px;margin:14px 0}
@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-actions,.actions{display:block}.btn{width:100%;text-align:center;margin:6px 0}.logbox{font-size:12px;max-height:none}}
</style>
</head>
<body>
<div class="page">
  <section class="hero">
    <div>
      <h1>GitHub Update Log</h1>
      <div class="sub">Update output and navigation</div>
      <div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
    </div>
    <div class="top-actions">
      <a class="btn light" href="/cgi-bin/admin_home.sh">Return to Admin</a>
      <a class="btn light" href="/cgi-bin/update_github_start.sh?ts=$(date +%s)">Start New Update</a>
    </div>
  </section>

  <section class="card">
    <p><b>Status:</b> <span class="status $STATUS_CLASS">$STATUS</span></p>
    <p class="note">Showing update output. Navigation buttons are provided above and below.</p>
    <p class="note">Previous log is saved at <b>/tmp/matrix_update_github.previous.log</b> when available.</p>

    <div class="top-log-actions">
      <div class="actions">
        <a class="btn" href="/cgi-bin/admin_home.sh">Return to Admin</a>
        <a class="btn green" href="/cgi-bin/update_github_start.sh?ts=$(date +%s)">Start New Update</a>
        <a class="btn grey" href="/">Back to Toolkit</a>
      </div>
    </div>

    <div class="logbox">
HTML

if [ -f "$LOG" ]; then
    sed \
        -e '/Return to Home/d' \
        -e '/Return to Admin/d' \
        -e '/Start New Update/d' \
        -e '/Toolkit Info/d' \
        -e '/<button /d' \
        "$LOG"
else
    echo "No update log available."
fi

cat <<HTML
    </div>

    <div class="top-log-actions">
      <div class="actions">
        <a class="btn" href="/cgi-bin/admin_home.sh">Return to Admin</a>
        <a class="btn green" href="/cgi-bin/update_github_start.sh?ts=$(date +%s)">Start New Update</a>
        <a class="btn grey" href="/">Back to Toolkit</a>
      </div>
    </div>
  </section>
</div>
</body>
</html>
HTML

exit 0
