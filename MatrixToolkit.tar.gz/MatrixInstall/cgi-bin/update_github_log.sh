cat > /usr/local/matrix/web/cgi-bin/update_github_log.sh <<'EOF'
#!/bin/sh
echo "Content-Type: text/html"
echo ""

LOG="/tmp/matrix_update_github.log"

cat << HTML
<html>
<head>
<title>GitHub Update Log</title>
<meta http-equiv="refresh" content="5">
</head>
<body style="font-family:Arial;margin:20px;">
<h2>GitHub Update Log</h2>
<pre>
HTML

cat "$LOG" 2>/dev/null

cat << HTML
</pre>
<br>
<button onclick="window.location='/admin/index.html'">Return to Admin</button>
<button onclick="window.location='/index.html'">Home</button>
</body>
</html>
HTML
EOF

chmod +x /usr/local/matrix/web/cgi-bin/update_github_log.sh