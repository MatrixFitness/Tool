#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

echo "Content-Type: text/html"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""

LOG="/tmp/matrix_update_github.log"
REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"

STATUS="Not running"
REFRESH=""

if [ -f "$LOCK" ]; then
STATUS="Running"
REFRESH='<meta http-equiv="refresh" content="5;url=/cgi-bin/update_github_log.sh?ts='$(date +%s)'">'
elif [ -f "$REQ" ]; then
STATUS="Waiting for root worker"
REFRESH='<meta http-equiv="refresh" content="5;url=/cgi-bin/update_github_log.sh?ts='$(date +%s)'">'
elif [ -f "$LOG" ]; then
STATUS="Finished"
fi

cat <<HTML

<html>
<head>
<title>GitHub Update Log</title>
$REFRESH
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">

<style>
body{
    font-family:Arial,Helvetica,sans-serif;
    margin:20px;
    background:#f5f5f5;
}
.card{
    background:white;
    padding:20px;
    border-radius:8px;
    max-width:1000px;
    box-shadow:0 1px 4px rgba(0,0,0,.12);
}
pre{
    background:#111;
    color:#eee;
    padding:15px;
    border-radius:6px;
    white-space:pre-wrap;
    overflow:auto;
}
button{
    margin-top:20px;
    width:220px;
    height:50px;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
    border:0;
    border-radius:6px;
    background:#007bff;
    color:white;
    margin-right:10px;
}
</style>

</head>

<body>

<div class="card">

<h2>GitHub Update Log</h2>

<p><b>Status:</b> $STATUS</p>

<pre>
HTML

if [ -f "$LOG" ]; then
    cat "$LOG"
else
    echo "No update log available."
fi

cat <<HTML
</pre>

<button onclick="window.location='/cgi-bin/admin_home.sh'">
Return to Admin
</button>

</div>

</body>
</html>
HTML
