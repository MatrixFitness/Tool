#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

echo "Content-Type: text/html; charset=UTF-8"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""

LOG="/tmp/matrix_update_github.log"
REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
VERSION_FILE="/usr/local/matrix/version.txt"

STATUS="Not running"
REFRESH=""
if [ -f "$LOCK" ]; then
    STATUS="Running"
    REFRESH="<meta http-equiv=\"refresh\" content=\"5;url=/cgi-bin/update_github_log.sh?ts=$(date +%s)\">"
elif [ -f "$REQ" ]; then
    STATUS="Waiting for root worker"
    REFRESH="<meta http-equiv=\"refresh\" content=\"5;url=/cgi-bin/update_github_log.sh?ts=$(date +%s)\">"
elif [ -f "$LOG" ]; then
    STATUS="Finished"
fi

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-; }
log_value(){ grep "^$1:" "$LOG" 2>/dev/null | tail -n1 | cut -d: -f2- | sed 's/^ *//'; }
log_time_after(){ grep "$1" "$LOG" 2>/dev/null | tail -n1 | sed "s/.*$1//;s/^: *//"; }

VERSION="$(log_value Version)"; [ -z "$VERSION" ] && VERSION="$(get_value Version)"
BUILD="$(log_value Build)"; [ -z "$BUILD" ] && BUILD="$(get_value Build)"
RELEASE="$(log_value Release)"; [ -z "$RELEASE" ] && RELEASE="$(get_value Release)"
CHANGES="$(log_value Changes)"; [ -z "$CHANGES" ] && CHANGES="$(get_value Changes)"
ZT_STATUS="$(log_value ZeroTier)"
ZT_IP="$(log_value "ZeroTier IP")"
CLI_STATUS="$(log_value "CLI Command")"
FOOTER_STATUS="$(log_value Footer)"

REQ_TIME="$(grep '^GitHub update requested at:' "$LOG" 2>/dev/null | tail -n1 | sed 's/^GitHub update requested at: *//')"
START_TIME="$(grep '^Matrix root update worker started at:' "$LOG" 2>/dev/null | tail -n1 | sed 's/^Matrix root update worker started at: *//')"
FINISH_TIME="$(grep '^Matrix root update worker finished at:' "$LOG" 2>/dev/null | tail -n1 | sed 's/^Matrix root update worker finished at: *//')"
EXIT_CODE="$(grep '^Update exit code:' "$LOG" 2>/dev/null | tail -n1 | sed 's/^Update exit code: *//')"
[ -z "$EXIT_CODE" ] && EXIT_CODE="-"

STATUS_CLASS="warn"
RESULT_TEXT="$STATUS"
if [ "$STATUS" = "Finished" ]; then
    if [ "$EXIT_CODE" = "0" ] || grep -q "Matrix Toolkit updated successfully" "$LOG" 2>/dev/null; then
        STATUS_CLASS="ok"
        RESULT_TEXT="Update Successful"
    else
        STATUS_CLASS="fail"
        RESULT_TEXT="Update Finished With Warnings"
    fi
elif [ "$STATUS" = "Running" ]; then
    STATUS_CLASS="ok"
    RESULT_TEXT="Update Running"
fi

RAW_LOG="No update log available."
[ -f "$LOG" ] && RAW_LOG="$(cat "$LOG")"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Update Center</title>
$REFRESH
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333;--blue:#005a9c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1200px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px}.contact{margin-top:7px;font-size:13px;opacity:.95}
.actions{display:flex;gap:10px;flex-wrap:wrap}.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer}.btn.light{background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35)}.btn.green{background:var(--ok)}.btn.grey{background:#667085}
.card{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:18px}.status{display:inline-block;border-radius:999px;padding:7px 12px;font-weight:900;font-size:13px;color:#fff}.status.ok{background:var(--ok)}.status.warn{background:var(--warn)}.status.fail{background:var(--fail)}
.summary-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:13px}.label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800;letter-spacing:.04em}.value{font-size:18px;font-weight:900;margin-top:6px;word-break:break-word}.big{font-size:30px}.oktxt{color:var(--ok)}.warntxt{color:var(--warn)}.failtxt{color:var(--fail)}
.timeline{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.step{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:13px}.step b{color:#0d3b66}.step div{font-size:13px;color:var(--muted);margin-top:5px;line-height:1.35}
.checks{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.check{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:10px;font-weight:800}.check:before{content:"✓ ";color:var(--ok)}
pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px;line-height:1.35}details summary{cursor:pointer;font-weight:900;color:#0d3b66;padding:12px;background:#f0f6fb;border-radius:12px}
@media(max-width:800px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.actions{display:block}.btn{width:100%;text-align:center;margin:6px 0}.summary-grid,.timeline,.checks{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="page">
  <section class="hero">
    <div>
      <h1>Matrix Update Center</h1>
      <div class="sub">Professional update summary and advanced log</div>
      <div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
    </div>
    <div class="actions">
      <a class="btn light" href="/cgi-bin/admin_home.sh">Return to Admin</a>
      <a class="btn light" href="/cgi-bin/update_github_start.sh?ts=$(date +%s)">Start New Update</a>
      <a class="btn light" href="/">Back to Toolkit</a>
    </div>
  </section>

  <section class="card">
    <span class="status $STATUS_CLASS">$(html_escape "$RESULT_TEXT")</span>
    <h2>Matrix Toolkit Update</h2>
    <div class="summary-grid">
      <div class="metric"><div class="label">Version</div><div class="value big">v$(html_escape "$VERSION")</div></div>
      <div class="metric"><div class="label">Build</div><div class="value">$(html_escape "$BUILD")</div></div>
      <div class="metric"><div class="label">Release</div><div class="value">$(html_escape "$RELEASE")</div></div>
      <div class="metric"><div class="label">Exit Code</div><div class="value $([ "$EXIT_CODE" = "0" ] && echo oktxt || echo warntxt)">$(html_escape "$EXIT_CODE")</div></div>
    </div>
  </section>

  <section class="card">
    <h2>What's New</h2>
    <p>$(html_escape "$CHANGES")</p>
  </section>

  <section class="card">
    <h2>Toolkit Integrity</h2>
    <div class="checks">
      <div class="check">Version</div>
      <div class="check">CGI Scripts</div>
      <div class="check">Permissions</div>
      <div class="check">Workers</div>
      <div class="check">ZeroTier</div>
      <div class="check">WiFi Manager</div>
      <div class="check">Survey</div>
      <div class="check">Admin Pages</div>
      <div class="check">Reports</div>
    </div>
  </section>

  <section class="card">
    <h2>Services</h2>
    <div class="summary-grid">
      <div class="metric"><div class="label">ZeroTier</div><div class="value">$(html_escape "$ZT_STATUS")</div></div>
      <div class="metric"><div class="label">ZeroTier IP</div><div class="value">$(html_escape "$ZT_IP")</div></div>
      <div class="metric"><div class="label">CLI</div><div class="value">$(html_escape "$CLI_STATUS")</div></div>
      <div class="metric"><div class="label">Footer</div><div class="value">$(html_escape "$FOOTER_STATUS")</div></div>
    </div>
  </section>

  <section class="card">
    <h2>Update Timeline</h2>
    <div class="timeline">
      <div class="step"><b>Update Requested</b><div>$(html_escape "$REQ_TIME")</div></div>
      <div class="step"><b>Worker Started</b><div>$(html_escape "$START_TIME")</div></div>
      <div class="step"><b>Finished</b><div>$(html_escape "$FINISH_TIME")</div></div>
    </div>
  </section>

  <section class="card">
    <details>
      <summary>Show Advanced Technical Log</summary>
      <pre>$(html_escape "$RAW_LOG")</pre>
    </details>
  </section>
</div>
</body>
</html>
HTML
exit 0
