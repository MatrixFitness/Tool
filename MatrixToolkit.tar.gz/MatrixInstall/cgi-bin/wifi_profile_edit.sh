#!/bin/sh
# Matrix WiFi Profile Edit v65.4
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"
ensure_wifi_files
TYPE="$(qs type)"; IDX="$(qs p)"
[ "$TYPE" = "user" ] || TYPE="user"
[ -z "$IDX" ] && IDX=1
FILE="$USER_PROFILES"
NAME="$(profile_value_file "$FILE" "$IDX" NAME)"; [ -z "$NAME" ] && NAME="New User Profile"
R0A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R0_ACTION)")"; R0S="$(profile_value_file "$FILE" "$IDX" R0_SSID)"; R0P="$(profile_value_file "$FILE" "$IDX" R0_PASSWORD)"
R1A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R1_ACTION)")"; R1S="$(profile_value_file "$FILE" "$IDX" R1_SSID)"; R1P="$(profile_value_file "$FILE" "$IDX" R1_PASSWORD)"
[ -z "$R0P" ] && R0P="password"; [ -z "$R1P" ] && R1P="password"
sel(){ [ "$1" = "$2" ] && echo selected; }
echo "Content-Type: text/html"; echo ""
cat <<EOF
<!DOCTYPE html><html><head><title>Edit WiFi Profile</title><meta name="viewport" content="width=device-width, initial-scale=1"><style>
body{font-family:Arial;margin:20px;background:#f5f5f5}.page{max-width:900px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}h1,h2{color:#005a9c}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0}.field{margin:12px 0}.field label{display:block;font-size:12px;color:#666;font-weight:bold;margin-bottom:4px}input,select{width:100%;height:40px;border:1px solid #ccc;border-radius:6px;padding:0 8px;box-sizing:border-box}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}.blue{background:#007bff}.grey{background:#666}</style>
<script>function togglePw(id){var x=document.getElementById(id);x.type=x.type==='password'?'text':'password';}</script></head><body><div class="page">
<h1>Edit User WiFi Profile</h1><form method="get" action="/cgi-bin/wifi_profile_save.sh"><input type="hidden" name="action" value="save"><input type="hidden" name="type" value="user"><input type="hidden" name="profile" value="$IDX">
<div class="card"><h2>Profile</h2><div class="field"><label>Name</label><input type="text" name="name" value="$(html_escape "$NAME")"></div></div>
<div class="card"><h2>Radio 0 / 2.4 GHz</h2><div class="field"><label>Action</label><select name="r0_action"><option value="KEEP" $(sel "$R0A" KEEP)>Keep current</option><option value="SET" $(sel "$R0A" SET)>Set SSID</option><option value="DISABLE" $(sel "$R0A" DISABLE)>Disable</option></select></div><div class="field"><label>SSID</label><input type="text" name="r0_ssid" value="$(html_escape "$R0S")"></div><div class="field"><label>Password</label><input id="r0p" type="password" name="r0_password" value="$(html_escape "$R0P")"></div></div>
<div class="card"><h2>Radio 1 / 5 GHz</h2><div class="field"><label>Action</label><select name="r1_action"><option value="KEEP" $(sel "$R1A" KEEP)>Keep current</option><option value="SET" $(sel "$R1A" SET)>Set SSID</option><option value="DISABLE" $(sel "$R1A" DISABLE)>Disable</option></select></div><div class="field"><label>SSID</label><input type="text" name="r1_ssid" value="$(html_escape "$R1S")"></div><div class="field"><label>Password</label><input id="r1p" type="password" name="r1_password" value="$(html_escape "$R1P")"></div></div>
<p><button class="btn grey" type="button" onclick="togglePw('r0p');togglePw('r1p')">Show / Hide Passwords</button><button class="btn blue" type="submit">Save Profile</button><a class="btn grey" href="/cgi-bin/wifi_manager.sh">Cancel</a></p></form></div></body></html>
EOF
