#!/bin/sh

if [ "$MATRIX_UPDATE_BACKGROUND" != "1" ]; then
    echo "Content-Type: text/html"
    echo ""
fi

# =====================================================
# MATRIX TOOLKIT - GITHUB UPDATE v3.5 FULL FIXED
# =====================================================
# Works from CLI, Admin page and background updater.
# Does not restart uhttpd during active CGI request.
# Copies version.txt reliably.
# Uses protected Admin webserver on port 8081 with Matrix CGI session login.
# admin_password.txt is stored outside the webroot and is not downloadable.
# =====================================================

SELF="/usr/local/matrix/web/cgi-bin/update_github.sh"
URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz"

RUNID=$$
TMPBASE="/tmp/matrix_update_$RUNID"
TMPDIR="$TMPBASE/extract"
ARCHIVE="$TMPBASE/MatrixToolkit.tar.gz"
LOG="$TMPBASE/update.log"
ZT_CHECK="$TMPBASE/matrix_zt_check.txt"

MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
ADMIN_WEB_DIR="$MATRIX_DIR/adminweb"
CGI_DIR="$WEB_DIR/cgi-bin"
ADMIN_CGI_DIR="$ADMIN_WEB_DIR/cgi-bin"
BIN_DIR="/usr/local/bin"
PASS_FILE="$MATRIX_DIR/admin_password.txt"

html_error() {
cat << HTMLEOF
<html>
<head><title>Matrix Update Failed</title></head>
<body style="font-family:Arial;margin:20px;">
<h2>GitHub Update Failed</h2>
<p>$1</p>
<pre>
HTMLEOF
[ -f "$LOG" ] && cat "$LOG"
cat << HTMLEOF
</pre>
<button onclick="window.location='/index.html'">Home</button>
</body>
</html>
HTMLEOF
exit 1
}

get_value() {
    grep "^$1=" "$MATRIX_DIR/version.txt" 2>/dev/null | cut -d= -f2-
}

configure_uhttpd_matrix() {
    uci set uhttpd.matrix='uhttpd'
    uci delete uhttpd.matrix.listen_http 2>/dev/null
    uci add_list uhttpd.matrix.listen_http='0.0.0.0:8080'
    uci add_list uhttpd.matrix.listen_http='[::]:8080'
    uci set uhttpd.matrix.home="$WEB_DIR"
    uci set uhttpd.matrix.index_page='index.html'
    uci set uhttpd.matrix.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix.script_timeout='1200'
    uci set uhttpd.matrix.network_timeout='120'
    uci set uhttpd.matrix.http_keepalive='0'
    uci set uhttpd.matrix.tcp_keepalive='5'
    uci set uhttpd.matrix.no_dirlists='1'
    uci set uhttpd.matrix.enable_basic_auth='0'
    uci commit uhttpd
}

get_matrix_admin_password() {
    PASS="$(uci -q get uhttpd.matrix_admin_web.password 2>/dev/null)"
    [ -n "$PASS" ] || PASS='Matrix2025'
    echo "$PASS"
}

configure_uhttpd_admin_8081() {
    # Dedicated Admin web server. Security is handled by Matrix CGI session login,
    # not Teltonika/uhttpd basic-auth.
    uci set uhttpd.matrix_admin_web='uhttpd'
    uci delete uhttpd.matrix_admin_web.listen_http 2>/dev/null
    uci add_list uhttpd.matrix_admin_web.listen_http='0.0.0.0:8081'
    uci add_list uhttpd.matrix_admin_web.listen_http='[::]:8081'
    uci set uhttpd.matrix_admin_web.home="$ADMIN_WEB_DIR"
    uci set uhttpd.matrix_admin_web.index_page='cgi-bin/admin_login.sh'
    uci set uhttpd.matrix_admin_web.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix_admin_web.script_timeout='1200'
    uci set uhttpd.matrix_admin_web.network_timeout='120'
    uci set uhttpd.matrix_admin_web.http_keepalive='0'
    uci set uhttpd.matrix_admin_web.tcp_keepalive='5'
    uci set uhttpd.matrix_admin_web.no_dirlists='1'
    uci set uhttpd.matrix_admin_web.enable_basic_auth='0'

    # Remove old/failed uhttpd-auth sections so they cannot confuse the setup.
    uci delete uhttpd.matrix_admin 2>/dev/null
    uci delete uhttpd.matrix_admin_update 2>/dev/null
    uci delete uhttpd.matrix_admin_password 2>/dev/null
    uci delete uhttpd.matrix_admin_usb_update 2>/dev/null
    uci delete uhttpd.matrix_admin_zerotier 2>/dev/null
    uci delete uhttpd.matrix_admin_router_backup 2>/dev/null
    uci delete uhttpd.matrix_admin_toolkit_backup 2>/dev/null
    uci delete uhttpd.matrix_admin_health 2>/dev/null

    uci commit uhttpd
}

ensure_admin_password() {
    if [ ! -f "$PASS_FILE" ]; then
        printf "%s" "Matrix2025" > "$PASS_FILE"
    fi
    chmod 644 "$PASS_FILE" 2>/dev/null
}

create_admin_index_redirect() {
    cat > "$ADMIN_WEB_DIR/index.html" <<'ADMININDEXEOF'
<!DOCTYPE html>
<html>
<head>
<title>Matrix Admin</title>
<script>window.location='/cgi-bin/admin_login.sh';</script>
<meta http-equiv="refresh" content="0;url=/cgi-bin/admin_login.sh">
</head>
<body style="font-family:Arial;margin:30px;">
<p><a href="/cgi-bin/admin_home.sh">Open Matrix Admin</a></p>
</body>
</html>
ADMININDEXEOF
}

remove_old_password_files() {
    rm -f "$CGI_DIR/get_admin_password.sh" \
          "$CGI_DIR/set_admin_password.sh" \
          "$ADMIN_CGI_DIR/get_admin_password.sh" \
          "$ADMIN_CGI_DIR/set_admin_password.sh" 2>/dev/null
}

fix_admin_links() {
    for f in "$WEB_DIR/index.html" "$ADMIN_WEB_DIR/index_source.html"; do
        [ -f "$f" ] || continue
        sed -i "s#window.location='/admin/'#window.location='/admin/index.html'#g" "$f" 2>/dev/null
        sed -i 's#href="/admin/"#href="/admin/index.html"#g' "$f" 2>/dev/null
        sed -i "s#href='/admin/'#href='/admin/index.html'#g" "$f" 2>/dev/null
        sed -i 's#update_github.sh#update_github_start.sh#g' "$f" 2>/dev/null
    done
}

install_admin_session_files() {
    for f in admin_login.sh admin_logout.sh admin_session_check.sh admin_home.sh admin_change_password.sh; do
        if [ -f "$CGI_DIR/$f" ]; then
            cp -f "$CGI_DIR/$f" "$ADMIN_CGI_DIR/$f" >> "$LOG" 2>&1
        fi
    done
    chmod +x "$CGI_DIR"/admin_*.sh "$ADMIN_CGI_DIR"/admin_*.sh 2>/dev/null
}

patch_sensitive_admin_scripts() {
    CHECK='. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0'
    for f in update_github_start.sh update_github_log.sh update_toolkit.sh zerotier_setup.sh router_backup.sh toolkit_backup.sh matrix_health.sh; do
        FILE="$ADMIN_CGI_DIR/$f"
        [ -f "$FILE" ] || continue
        grep -q "admin_session_check.sh" "$FILE" && continue
        TMP="$FILE.tmp"
        {
            IFS= read -r FIRST || true
            echo "$FIRST"
            echo "$CHECK"
            cat
        } < "$FILE" > "$TMP"
        mv "$TMP" "$FILE"
        chmod +x "$FILE" 2>/dev/null
    done
}

repair_permissions() {
    mkdir -p "$MATRIX_DIR" "$WEB_DIR" "$ADMIN_WEB_DIR" "$CGI_DIR" "$ADMIN_CGI_DIR" "$BIN_DIR"

    chmod 755 "$MATRIX_DIR" "$WEB_DIR" "$ADMIN_WEB_DIR" "$CGI_DIR" "$ADMIN_CGI_DIR" 2>/dev/null

    find "$WEB_DIR" -type d -exec chmod 755 {} \; 2>/dev/null
    find "$ADMIN_WEB_DIR" -type d -exec chmod 755 {} \; 2>/dev/null
    find "$WEB_DIR" -type f -name "*.html" -exec chmod 644 {} \; 2>/dev/null
    find "$ADMIN_WEB_DIR" -type f -name "*.html" -exec chmod 644 {} \; 2>/dev/null
    find "$WEB_DIR" -type f -name "*.css" -exec chmod 644 {} \; 2>/dev/null
    find "$WEB_DIR" -type f -name "*.js" -exec chmod 644 {} \; 2>/dev/null
    find "$WEB_DIR" -type f -name "*.txt" -exec chmod 644 {} \; 2>/dev/null

    chmod +x "$CGI_DIR"/*.sh 2>/dev/null
    chmod 644 "$MATRIX_DIR/version.txt" 2>/dev/null
    chmod 644 "$MATRIX_DIR/clubname.txt" 2>/dev/null

    chmod 755 /etc/zerotier 2>/dev/null
    chmod 644 /etc/zerotier/authtoken.secret 2>/dev/null
    chmod 644 /etc/zerotier/zerotier-one.port 2>/dev/null
}

ensure_version_file() {
    if [ ! -f "$MATRIX_DIR/version.txt" ]; then
cat > "$MATRIX_DIR/version.txt" <<'VERSIONEOF'
Version=Unknown
Build=Unknown
Release=Unknown
Changes=Unknown
GitHub=https://github.com/MatrixFitness/Tool
Author=Unknown
Email=unknown@matrixfitness.nl
Company=Matrix Fitness
Message=Matrix Toolkit
VERSIONEOF
    fi
}

copy_files() {
    SRC="$1"

    echo "Copying web files..." >> "$LOG"
    [ -d "$SRC/web" ] || html_error "Web folder not found in archive."
    cp -f "$SRC/web/"* "$WEB_DIR/" >> "$LOG" 2>&1

    echo "Copying admin index..." >> "$LOG"
    if [ -f "$SRC/web_admin/index.html" ]; then
        cp -f "$SRC/web_admin/index.html" "$ADMIN_WEB_DIR/index_source.html" >> "$LOG" 2>&1
    else
        echo "WARNING: web_admin/index.html not found" >> "$LOG"
    fi

    echo "Copying CGI scripts..." >> "$LOG"
    if [ -d "$SRC/cgi-bin" ]; then
        for f in "$SRC/cgi-bin/"*.sh; do
            [ -f "$f" ] || continue
            BASE="$(basename "$f")"
            case "$BASE" in
                update_github.sh)
                    # Do not overwrite the updater while it is running.
                    # BusyBox/ash can continue reading from the overwritten file and execute the wrong block.
                    cp -f "$f" "$CGI_DIR/update_github.sh.new" >> "$LOG" 2>&1
                    echo "Skipped live replacement of update_github.sh; saved archive copy as update_github.sh.new" >> "$LOG"
                    ;;
                *)
                    cp -f "$f" "$CGI_DIR/" >> "$LOG" 2>&1
                    ;;
            esac
        done
    fi

    echo "Copying admin CGI scripts..." >> "$LOG"
    if [ -d "$SRC/cgi-bin_admin" ]; then
        for f in "$SRC/cgi-bin_admin/"*.sh; do
            [ -f "$f" ] || continue
            case "$(basename "$f")" in
                about.sh)
                    echo "Skipped duplicate cgi-bin_admin/about.sh" >> "$LOG"
                    ;;
                *)
                    cp -f "$f" "$CGI_DIR/" >> "$LOG" 2>&1
                    ;;
            esac
        done
    fi

    echo "Copying CGI scripts to Admin 8081 webroot..." >> "$LOG"
    mkdir -p "$ADMIN_CGI_DIR"
    cp -f "$CGI_DIR"/*.sh "$ADMIN_CGI_DIR/" >> "$LOG" 2>&1
    chmod +x "$ADMIN_CGI_DIR"/*.sh 2>/dev/null
    install_admin_session_files
    patch_sensitive_admin_scripts

    echo "Creating 8080 admin redirect..." >> "$LOG"
    mkdir -p "$WEB_DIR/admin"
    cat > "$WEB_DIR/admin/index.html" <<'REDIRECTEOF'
<!DOCTYPE html>
<html>
<head>
<title>Matrix Admin moved</title>
<script>
(function(){ window.location.href = window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_login.sh'; })();
</script>
</head>
<body style="font-family:Arial;margin:30px;">
<h2>Matrix Admin moved</h2>
<p>Admin is now on port 8081 with Matrix login.</p>
<p><a id="adminLink" href="#">Open Matrix Admin</a></p>
<script>
document.getElementById('adminLink').href = window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_login.sh';
</script>
</body>
</html>
REDIRECTEOF

    echo "Copying version and settings files..." >> "$LOG"
    if [ -f "$SRC/version.txt" ]; then
        cp -f "$SRC/version.txt" "$MATRIX_DIR/version.txt" >> "$LOG" 2>&1
        echo "version.txt copied" >> "$LOG"
    else
        echo "WARNING: version.txt missing in archive" >> "$LOG"
    fi

    [ -f "$SRC/clubname.txt" ] && cp -f "$SRC/clubname.txt" "$MATRIX_DIR/clubname.txt" >> "$LOG" 2>&1

    remove_old_password_files
}


install_wifi_manager_files() {
    SRC="$1"

    echo "Installing WiFi Manager v61 band module..." >> "$LOG"
    mkdir -p "$MATRIX_DIR" "$CGI_DIR" "$ADMIN_CGI_DIR" >> "$LOG" 2>&1

    if [ -f "$SRC/matrix_wifi_profiles.default" ]; then
        cp -f "$SRC/matrix_wifi_profiles.default" "$MATRIX_DIR/matrix_wifi_profiles.default" >> "$LOG" 2>&1
        chmod 666 "$MATRIX_DIR/matrix_wifi_profiles.default" 2>/dev/null
        echo "WiFi default profiles installed" >> "$LOG"
    elif [ -f "$SRC/matrix_wifi_profiles.conf" ]; then
        cp -f "$SRC/matrix_wifi_profiles.conf" "$MATRIX_DIR/matrix_wifi_profiles.default" >> "$LOG" 2>&1
        chmod 666 "$MATRIX_DIR/matrix_wifi_profiles.default" 2>/dev/null
        echo "Old WiFi profile file installed as default" >> "$LOG"
    else
        cat > "$MATRIX_DIR/matrix_wifi_profiles.default" <<'WIFIEOF'
PROFILE1_NAME=Matrix Default 5G
PROFILE1_BAND=5G
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM 2G
PROFILE2_BAND=2G
PROFILE2_SSID=egym
PROFILE2_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2

PROFILE3_NAME=Customer Both
PROFILE3_BAND=BOTH
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
WIFIEOF
        echo "WiFi default profiles created from built-in v61 defaults" >> "$LOG"
    fi

    if [ ! -f "$MATRIX_DIR/matrix_wifi_profiles.conf" ] && [ -f "$MATRIX_DIR/config/matrix_wifi_profiles.conf" ]; then
        cp -f "$MATRIX_DIR/config/matrix_wifi_profiles.conf" "$MATRIX_DIR/matrix_wifi_profiles.conf" >> "$LOG" 2>&1
        echo "Migrated old WiFi profile config to root location" >> "$LOG"
    fi

    if [ ! -f "$MATRIX_DIR/matrix_wifi_profiles.conf" ]; then
        cp -f "$MATRIX_DIR/matrix_wifi_profiles.default" "$MATRIX_DIR/matrix_wifi_profiles.conf" >> "$LOG" 2>&1
        echo "Active WiFi profiles created from v61 defaults" >> "$LOG"
    else
        echo "Active local WiFi profiles preserved" >> "$LOG"
    fi

    TMP_WIFI="/tmp/matrix_wifi_profiles_migrate.$$"
    : > "$TMP_WIFI"
    MAX_PROFILE="$(grep -o '^PROFILE[0-9][0-9]*_' "$MATRIX_DIR/matrix_wifi_profiles.conf" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1)"
    [ -z "$MAX_PROFILE" ] && MAX_PROFILE=0
    i=1
    while [ "$i" -le "$MAX_PROFILE" ]; do
        NAME="$(grep "^PROFILE${i}_NAME=" "$MATRIX_DIR/matrix_wifi_profiles.conf" | head -n1 | cut -d= -f2-)"
        BAND="$(grep "^PROFILE${i}_BAND=" "$MATRIX_DIR/matrix_wifi_profiles.conf" | head -n1 | cut -d= -f2-)"
        SSID="$(grep "^PROFILE${i}_SSID=" "$MATRIX_DIR/matrix_wifi_profiles.conf" | head -n1 | cut -d= -f2-)"
        PASS="$(grep "^PROFILE${i}_PASSWORD=" "$MATRIX_DIR/matrix_wifi_profiles.conf" | head -n1 | cut -d= -f2-)"
        if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
            if [ -z "$BAND" ]; then
                if [ "$i" -eq 2 ]; then BAND="2G"; else BAND="5G"; fi
            fi
            echo "PROFILE${i}_NAME=$NAME" >> "$TMP_WIFI"
            echo "PROFILE${i}_BAND=$BAND" >> "$TMP_WIFI"
            echo "PROFILE${i}_SSID=$SSID" >> "$TMP_WIFI"
            echo "PROFILE${i}_PASSWORD=$PASS" >> "$TMP_WIFI"
            echo "" >> "$TMP_WIFI"
        fi
        i=$((i+1))
    done
    if [ -s "$TMP_WIFI" ]; then
        cat "$MATRIX_DIR/matrix_wifi_profiles.conf" > "$MATRIX_DIR/matrix_wifi_profiles.previous" 2>/dev/null
        cat "$TMP_WIFI" > "$MATRIX_DIR/matrix_wifi_profiles.conf"
        echo "WiFi profiles migrated to v61 band format" >> "$LOG"
    fi
    rm -f "$TMP_WIFI" 2>/dev/null

    if [ ! -f "$MATRIX_DIR/matrix_wifi_profiles.previous" ]; then
        cat "$MATRIX_DIR/matrix_wifi_profiles.conf" > "$MATRIX_DIR/matrix_wifi_profiles.previous" 2>/dev/null
    fi

    chmod 666 "$MATRIX_DIR/matrix_wifi_profiles.conf" \
              "$MATRIX_DIR/matrix_wifi_profiles.default" \
              "$MATRIX_DIR/matrix_wifi_profiles.previous" 2>/dev/null

    chmod +x "$CGI_DIR"/wifi_*.sh 2>/dev/null
    if [ -d "$ADMIN_CGI_DIR" ]; then
        cp -f "$CGI_DIR"/wifi_*.sh "$ADMIN_CGI_DIR"/ >> "$LOG" 2>&1
        chmod +x "$ADMIN_CGI_DIR"/wifi_*.sh 2>/dev/null
    fi
}

create_cli_shortcuts() {
    echo "Creating/repairing CLI shortcuts..." >> "$LOG"

    # This must also run during web/background updates.
    # CLI shortcuts are installed only in /usr/local/bin because /usr/bin
    # can be read-only on Teltonika/OpenWRT firmware.
    mkdir -p /usr/local/bin 2>> "$LOG"

    chmod +x "$CGI_DIR/update_github.sh" 2>> "$LOG"
    [ -f "$CGI_DIR/matrix_full_test.sh" ] && chmod +x "$CGI_DIR/matrix_full_test.sh" 2>> "$LOG"
    [ -f "$CGI_DIR/certification_report.sh" ] && chmod +x "$CGI_DIR/certification_report.sh" 2>> "$LOG"

    for D in /usr/local/bin; do
        [ -d "$D" ] || continue

        cat > "$D/matrix-update" <<'UPDATECLIEOF'
#!/bin/sh

# Matrix Toolkit Update Request CLI
# This command does not run update_github.sh directly.
# It creates a request file. The root cron worker performs the real update.

REQ="/tmp/matrix_update_request"
LOG="/tmp/matrix_update_github.log"
LOCK="/tmp/matrix_update_worker.lock"

if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo "Matrix update already running."
        echo "View log with:"
        echo "cat $LOG"
        exit 0
    fi
    rm -f "$LOCK"
fi

echo "GitHub update requested at: $(date)" > "$LOG"
echo "Waiting for root update worker..." >> "$LOG"
echo "" >> "$LOG"

touch "$REQ"

echo "Matrix update requested."
echo "The root worker will run it within 1 minute."
echo "View log with:"
echo "cat $LOG"

UPDATECLIEOF
        [ -f "$CGI_DIR/matrix_full_test.sh" ] && ln -sf "$CGI_DIR/matrix_full_test.sh" "$D/matrix-test" 2>> "$LOG"
        [ -f "$CGI_DIR/certification_report.sh" ] && ln -sf "$CGI_DIR/certification_report.sh" "$D/matrix-report" 2>> "$LOG"

        cat > "$D/matrix-version" <<'VERSIONCLIEOF'
#!/bin/sh
cat /usr/local/matrix/version.txt
VERSIONCLIEOF

        cat > "$D/matrix-zerotier" <<'ZTCLIEOF'
#!/bin/sh
ZT_CLI="/usr/local/usr/bin/zerotier-cli"
ZT_HOME="/etc/zerotier"

if [ -x "$ZT_CLI" ]; then
    echo "ZeroTier Info:"
    "$ZT_CLI" -D"$ZT_HOME" info 2>/dev/null || true
    echo
    echo "ZeroTier Networks:"
    "$ZT_CLI" -D"$ZT_HOME" listnetworks 2>/dev/null || true
else
    echo "ZeroTier CLI not found: $ZT_CLI"
fi

echo
echo "ZeroTier IP:"
ip addr 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1
ZTCLIEOF

        cat > "$D/matrix-help" <<'HELPCLIEOF'
#!/bin/sh
cat <<EOF
Matrix Toolkit CLI commands:

matrix-update      Update Matrix Toolkit from GitHub
matrix-version     Show installed Matrix Toolkit version.txt
matrix-zerotier    Show ZeroTier status and IP
matrix-test        Run Matrix Full Test when available
matrix-report      Run certification report when available
EOF
HELPCLIEOF

        chmod +x "$D/matrix-update" "$D/matrix-version" "$D/matrix-zerotier" "$D/matrix-help" 2>> "$LOG"
        [ -e "$D/matrix-test" ] && chmod +x "$D/matrix-test" 2>> "$LOG"
        [ -e "$D/matrix-report" ] && chmod +x "$D/matrix-report" 2>> "$LOG"
    done

    if command -v matrix-update >/dev/null 2>&1; then
        echo "matrix-update command OK: $(command -v matrix-update)" >> "$LOG"
    else
        echo "WARNING: matrix-update command not found in PATH after repair" >> "$LOG"
    fi
}



install_lte_cache_worker() {
    SRC="$1"

    echo "Installing LTE cache worker..." >> "$LOG"

    if [ -f "$SRC/lte_info_cache.sh" ]; then
        cp -f "$SRC/lte_info_cache.sh" "$MATRIX_DIR/lte_info_cache.sh" >> "$LOG" 2>&1
    elif [ -f "$SRC/cgi-bin/lte_info_cache.sh" ]; then
        cp -f "$SRC/cgi-bin/lte_info_cache.sh" "$MATRIX_DIR/lte_info_cache.sh" >> "$LOG" 2>&1
    fi

    if [ -f "$MATRIX_DIR/lte_info_cache.sh" ]; then
        chmod +x "$MATRIX_DIR/lte_info_cache.sh" >> "$LOG" 2>&1
        "$MATRIX_DIR/lte_info_cache.sh" >> "$LOG" 2>&1 || echo "WARNING: LTE cache worker returned an error" >> "$LOG"

        (crontab -l 2>/dev/null | grep -v "lte_info_cache.sh"; \
         echo "* * * * * /usr/local/matrix/lte_info_cache.sh") | crontab -

        /etc/init.d/cron enable >/dev/null 2>&1
        /etc/init.d/cron restart >/dev/null 2>&1

        echo "LTE cache worker installed and cron enabled" >> "$LOG"
    else
        echo "WARNING: lte_info_cache.sh missing in archive" >> "$LOG"
    fi
}

install_and_run_post_update() {
    SRC="$1"

    echo "Running post-update tasks..." >> "$LOG"

    if [ -f "$SRC/post_update.sh" ]; then
        cp -f "$SRC/post_update.sh" "$MATRIX_DIR/post_update.sh" >> "$LOG" 2>&1
        chmod +x "$MATRIX_DIR/post_update.sh" >> "$LOG" 2>&1
        sh "$MATRIX_DIR/post_update.sh" >> "$LOG" 2>&1 || echo "WARNING: post_update.sh returned an error" >> "$LOG"
    else
        echo "WARNING: post_update.sh missing in archive; running built-in fallback" >> "$LOG"
        SURVEY_DIR="$MATRIX_DIR/survey"
        mkdir -p "$SURVEY_DIR" >> "$LOG" 2>&1
        chmod 777 "$SURVEY_DIR" >> "$LOG" 2>&1
        [ -f "$SURVEY_DIR/locations.txt" ] || touch "$SURVEY_DIR/locations.txt"
        [ -f "$SURVEY_DIR/completed.txt" ] || touch "$SURVEY_DIR/completed.txt"
        [ -f "$SURVEY_DIR/wifi_survey_results.csv" ] || touch "$SURVEY_DIR/wifi_survey_results.csv"
        [ -f "$SURVEY_DIR/survey_state.txt" ] || touch "$SURVEY_DIR/survey_state.txt"
        [ -f "$SURVEY_DIR/selected_locations.txt" ] || touch "$SURVEY_DIR/selected_locations.txt"
        [ -f "$SURVEY_DIR/completed_locations.txt" ] || touch "$SURVEY_DIR/completed_locations.txt"
        chmod 666 "$SURVEY_DIR"/*.txt "$SURVEY_DIR"/*.csv 2>/dev/null
    fi
}

mkdir -p "$TMPDIR" "$BIN_DIR" "$MATRIX_DIR" "$WEB_DIR" "$ADMIN_WEB_DIR" "$CGI_DIR" "$ADMIN_CGI_DIR"

echo "Downloading Matrix Toolkit..." > "$LOG"
wget --no-check-certificate -O "$ARCHIVE" "$URL" >> "$LOG" 2>&1 || html_error "Download failed."

[ -s "$ARCHIVE" ] || html_error "Download failed. File is empty."

echo "" >> "$LOG"
echo "Checking archive..." >> "$LOG"
tar -tzf "$ARCHIVE" >/dev/null 2>> "$LOG" || html_error "Downloaded file is not a valid tar.gz archive."

echo "Extracting archive..." >> "$LOG"
tar -xzf "$ARCHIVE" -C "$TMPDIR" >> "$LOG" 2>&1 || html_error "Archive extraction failed."

SRC="$TMPDIR/MatrixInstall"
[ -d "$SRC" ] || html_error "MatrixInstall folder not found in archive."

# Self-update disabled: never overwrite update_github.sh while it is running.
# The archive copy is saved as update_github.sh.new by copy_files().

copy_files "$SRC"
install_wifi_manager_files "$SRC"
if [ -f "$SRC/matrix_update_worker.sh" ]; then
    cp -f "$SRC/matrix_update_worker.sh" "$MATRIX_DIR/matrix_update_worker.sh" >> "$LOG" 2>&1
    chmod +x "$MATRIX_DIR/matrix_update_worker.sh" >> "$LOG" 2>&1

    (crontab -l 2>/dev/null | grep -v "matrix_update_worker.sh"; \
     echo "* * * * * /usr/local/matrix/matrix_update_worker.sh") | crontab -

    /etc/init.d/cron enable >/dev/null 2>&1
    /etc/init.d/cron restart >/dev/null 2>&1

    echo "Root update worker installed and cron enabled" >> "$LOG"
else
    echo "WARNING: matrix_update_worker.sh missing in archive" >> "$LOG"
fi
ensure_version_file
ensure_admin_password
create_admin_index_redirect
repair_permissions
fix_admin_links
remove_old_password_files
create_cli_shortcuts
install_and_run_post_update "$SRC"
install_lte_cache_worker "$SRC"

sync
sleep 2

echo "Configuring Matrix webserver on port 8080 and Admin login on 8081..." >> "$LOG"
configure_uhttpd_matrix >> "$LOG" 2>&1
configure_uhttpd_admin_8081 >> "$LOG" 2>&1

if [ "$MATRIX_UPDATE_BACKGROUND" = "1" ]; then
    /etc/init.d/uhttpd restart >> "$LOG" 2>&1
    echo "uhttpd restarted by background worker to apply admin security." >> "$LOG"
else
    echo "uhttpd restart skipped during direct update to prevent Bad Gateway." >> "$LOG"
fi

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
GITHUB=$(get_value GitHub)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
COMPANY=$(get_value Company)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="Unknown"
[ -z "$GITHUB" ] && GITHUB="Unknown"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="Unknown"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"

ZT_IP=$(ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)

FOOTER_STATUS="Not checked"
if [ -f "$CGI_DIR/version_footer.sh" ]; then
    if grep -q "ZeroTier Remote Access" "$CGI_DIR/version_footer.sh"; then
        FOOTER_STATUS="OK - dynamic ZeroTier footer installed"
    else
        FOOTER_STATUS="WARNING - version_footer.sh installed but ZeroTier block missing"
    fi
else
    FOOTER_STATUS="ERROR - version_footer.sh missing"
fi

ZT_STATUS="Not checked"
if /usr/local/usr/bin/zerotier-cli listnetworks > "$ZT_CHECK" 2>/dev/null; then
    if grep -q "OK PRIVATE" "$ZT_CHECK"; then
        ZT_STATUS="OK - connected"
    else
        ZT_STATUS="WARNING - ZeroTier not OK or not authorized"
    fi
else
    if [ -n "$ZT_IP" ]; then
        ZT_STATUS="WARNING - CLI check failed, but ZeroTier IP exists"
    else
        ZT_STATUS="WARNING - ZeroTier CLI check failed"
    fi
fi

CLI_STATUS="WARNING - matrix-update not found in PATH"
if command -v matrix-update >/dev/null 2>&1; then
    CLI_STATUS="OK - $(command -v matrix-update)"
elif [ -x /usr/local/bin/matrix-update ]; then
    CLI_STATUS="OK - /usr/local/bin/matrix-update"
fi

rm -rf "$TMPBASE"

cat << HTMLEOF
<html>
<head>
<title>Matrix Toolkit Update</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.card { background: white; padding: 20px; border-radius: 8px; max-width: 850px; box-shadow: 0 1px 4px rgba(0,0,0,0.12); }
table { border-collapse: collapse; width: 100%; }
td { border: 1px solid #ddd; padding: 8px; vertical-align: top; }
th { background: #007bff; color: white; padding: 8px; text-align: left; }
.pass { color: green; font-weight: bold; }
.warn { color: #b26a00; font-weight: bold; }
button { margin-top: 20px; width: 220px; height: 50px; font-size: 16px; font-weight: bold; cursor: pointer; border: 0; border-radius: 6px; background: #007bff; color: white; margin-right: 10px; }
</style>
</head>
<body>
<div class="card">
<h2>GitHub Update Completed</h2>
<table>
<tr><th>Item</th><th>Value</th></tr>
<tr><td>Version</td><td>$VERSION</td></tr>
<tr><td>Build</td><td>$BUILD</td></tr>
<tr><td>Release</td><td>$RELEASE</td></tr>
<tr><td>Changes</td><td>$CHANGES</td></tr>
<tr><td>Company</td><td>$COMPANY</td></tr>
<tr><td>Author</td><td>$AUTHOR</td></tr>
<tr><td>Email</td><td>$EMAIL</td></tr>
<tr><td>GitHub</td><td>$GITHUB</td></tr>
<tr><td>Footer</td><td>$FOOTER_STATUS</td></tr>
<tr><td>ZeroTier</td><td>$ZT_STATUS</td></tr>
<tr><td>ZeroTier IP</td><td>${ZT_IP:-Not connected}</td></tr>
<tr><td>CLI Command</td><td>$CLI_STATUS</td></tr>
<tr><td>uhttpd Restart</td><td>Applied by background worker when available</td></tr>
</table>
<p class="pass">Matrix Toolkit updated successfully.</p>
<p class="warn">Refresh the browser with Ctrl + F5 if old information is still visible.</p>
</div>
</body>
</html>
HTMLEOF
