#!/bin/sh

SELF="/usr/local/matrix/web/cgi-bin/update_github.sh"
URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz"

RUNID=$$
TMPBASE="/tmp/matrix_update_$RUNID"
TMPDIR="$TMPBASE/MatrixToolkit"
ARCHIVE="$TMPBASE/MatrixToolkit.tar.gz"
LOG="$TMPBASE/update.log"

html_error() {
    echo "<html><head><title>Matrix Update Failed</title></head>"
    echo "<body style='font-family:Arial;margin:20px;'>"
    echo "<h2>GitHub Update Failed</h2>"
    echo "<p>$1</p>"

    if [ -f "$LOG" ]; then
        echo "<hr><b>Details:</b><pre>"
        cat "$LOG"
        echo "</pre>"
    fi

    echo "<br><button onclick=\"window.location='/admin/'\">Return to Admin</button>"
    echo "</body></html>"
    exit 1
}

mkdir -p "$TMPDIR"
mkdir -p /usr/local/bin
mkdir -p /usr/local/matrix
mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/admin
mkdir -p /usr/local/matrix/web/cgi-bin

echo "Downloading Matrix Toolkit..." > "$LOG"

wget --no-check-certificate -O "$ARCHIVE" "$URL" >> "$LOG" 2>&1

if [ $? -ne 0 ]; then
    html_error "Download failed."
fi

if [ ! -s "$ARCHIVE" ]; then
    html_error "Download failed. File is empty."
fi

echo "" >> "$LOG"
echo "Checking archive..." >> "$LOG"

tar -tzf "$ARCHIVE" >/dev/null 2>> "$LOG"

if [ $? -ne 0 ]; then
    html_error "Downloaded file is not a valid tar.gz archive."
fi

echo "Extracting archive..." >> "$LOG"

tar -xzf "$ARCHIVE" -C "$TMPDIR" >> "$LOG" 2>&1

if [ $? -ne 0 ]; then
    html_error "Archive extraction failed."
fi

if [ ! -d "$TMPDIR/MatrixInstall" ]; then
    html_error "MatrixInstall folder not found in archive."
fi

# Self-update first, then restart once
if [ "$1" != "run" ] && [ -f "$TMPDIR/MatrixInstall/cgi-bin/update_github.sh" ]; then
    echo "Self updating update_github.sh..." >> "$LOG"
    cp -f "$TMPDIR/MatrixInstall/cgi-bin/update_github.sh" "$SELF" >> "$LOG" 2>&1
    chmod +x "$SELF" >> "$LOG" 2>&1
    exec "$SELF" run
fi

echo "Copying web files..." >> "$LOG"

if [ -d "$TMPDIR/MatrixInstall/web" ]; then
    cp -f "$TMPDIR/MatrixInstall/web/"* /usr/local/matrix/web/ >> "$LOG" 2>&1
else
    html_error "Web folder not found in archive."
fi

if [ -f "$TMPDIR/MatrixInstall/web_admin/index.html" ]; then
    cp -f "$TMPDIR/MatrixInstall/web_admin/index.html" /usr/local/matrix/web/admin/index.html >> "$LOG" 2>&1
fi

echo "Copying CGI scripts..." >> "$LOG"

if [ -d "$TMPDIR/MatrixInstall/cgi-bin" ]; then
    for f in "$TMPDIR/MatrixInstall/cgi-bin/"*.sh
    do
        [ -f "$f" ] || continue
        cp -f "$f" /usr/local/matrix/web/cgi-bin/ >> "$LOG" 2>&1
    done
fi

echo "Copying admin CGI scripts, skipping duplicate about.sh..." >> "$LOG"

if [ -d "$TMPDIR/MatrixInstall/cgi-bin_admin" ]; then
    for f in "$TMPDIR/MatrixInstall/cgi-bin_admin/"*.sh
    do
        [ -f "$f" ] || continue

        case "$(basename "$f")" in
            about.sh)
                echo "Skipped duplicate cgi-bin_admin/about.sh" >> "$LOG"
                ;;
            *)
                cp -f "$f" /usr/local/matrix/web/cgi-bin/ >> "$LOG" 2>&1
                ;;
        esac
    done
fi

chmod +x /usr/local/matrix/web/cgi-bin/*.sh >> "$LOG" 2>&1

echo "Copying version.txt..." >> "$LOG"

if [ -f "$TMPDIR/MatrixInstall/version.txt" ]; then
    cp -f "$TMPDIR/MatrixInstall/version.txt" /usr/local/matrix/version.txt >> "$LOG" 2>&1
fi

if [ ! -f /usr/local/matrix/version.txt ]; then
    cat > /usr/local/matrix/version.txt << EOF
Version=Unknown
Build=Unknown
Release=Unknown
Changes=Unknown
GitHub=https://github.com/MatrixFitness/Tool

Author=Unknown
Email=
Company=Matrix Fitness
Message=Matrix Toolkit
EOF
fi

get_value() {
    grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
GITHUB=$(get_value GitHub)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
COMPANY=$(get_value Company)
MESSAGE=$(get_value Message)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="Unknown"
[ -z "$GITHUB" ] && GITHUB="Unknown"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="Unknown"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$MESSAGE" ] && MESSAGE=""

cat > /tmp/main_footer.html << EOF
<div class="footer">
Matrix Toolkit v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE

<br><br>

Repository:<br>
$GITHUB
</div>
EOF

cat > /tmp/admin_footer.html << EOF
<div class="footer">
Backup locatie:<br>
/usr/local/mnt/sda1/Backup

<br><br>

Matrix Admin v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE

<br><br>

Repository:<br>
$GITHUB
</div>
EOF

echo "Updating footers..." >> "$LOG"

if [ -f /usr/local/matrix/web/index.html ]; then
    sed -i "/<div class=\"footer\">/,/<\/div>/{
        /<div class=\"footer\">/r /tmp/main_footer.html
        d
    }" /usr/local/matrix/web/index.html
fi

if [ -f /usr/local/matrix/web/admin/index.html ]; then
    sed -i "/<div class=\"footer\">/,/<\/div>/{
        /<div class=\"footer\">/r /tmp/admin_footer.html
        d
    }" /usr/local/matrix/web/admin/index.html
fi

if [ -f "$TMPDIR/MatrixInstall/admin_password.txt" ]; then
    cp -f "$TMPDIR/MatrixInstall/admin_password.txt" /usr/local/matrix/admin_password.txt >> "$LOG" 2>&1
fi

echo "Creating CLI shortcuts..." >> "$LOG"

ln -sf /usr/local/matrix/web/cgi-bin/update_github.sh /usr/local/bin/matrix-update
ln -sf /usr/local/matrix/web/cgi-bin/matrix_full_test.sh /usr/local/bin/matrix-test
ln -sf /usr/local/matrix/web/cgi-bin/certification_report.sh /usr/local/bin/matrix-report

cat > /usr/local/bin/matrix-version << 'EOF'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF

chmod +x /usr/local/bin/matrix-version

echo "Reloading webserver..." >> "$LOG"
/etc/init.d/uhttpd reload >> "$LOG" 2>&1

rm -rf "$TMPBASE"

echo "Content-Type: text/html"
echo ""

cat << EOF
<html>
<head>
<title>Matrix Toolkit Update</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background: #f5f5f5;
}
.card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    max-width: 800px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.12);
}
table {
    border-collapse: collapse;
    width: 100%;
}
td {
    border: 1px solid #ddd;
    padding: 8px;
}
th {
    background: #007bff;
    color: white;
    padding: 8px;
    text-align: left;
}
.pass {
    color: green;
    font-weight: bold;
}
.warn {
    color: orange;
    font-weight: bold;
}
button {
    margin-top: 20px;
    width: 220px;
    height: 50px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: 0;
    border-radius: 6px;
    background: #007bff;
    color: white;
}
</style>
</head>
<body>

<div class="card">
<h2>GitHub Update Completed</h2>

<table>
<tr><th>Item</th><th>Value</th></tr>
<tr><td>Version</td><td>$VERSION</td></tr>
<tr><td>Build</td><td>$BUILD</td></tr>
<tr><td>Release</td><td>$RELEASE</td></tr>
<tr><td>Changes</td><td>$CHANGES</td></tr>
<tr><td>Company</td><td>$COMPANY</td></tr>
<tr><td>Author</td><td>$AUTHOR</td></tr>
<tr><td>Email</td><td>$EMAIL</td></tr>
<tr><td>GitHub</td><td>$GITHUB</td></tr>
</table>

<p class="pass">Matrix Toolkit updated successfully.</p>

<button onclick="window.location='/'">Return to Home</button>
<button onclick="window.location='/admin/'">Return to Admin</button>
</div>

</body>
</html>
EOF