#!/bin/sh

# Matrix Toolkit GitHub updater for Teltonika RUT routers
# Downloads MatrixToolkit.tar.gz, copies files into persistent storage,
# and keeps uhttpd permanently configured on port 8080.

SELF="/usr/local/matrix/web/cgi-bin/update_github.sh"
URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz"

RUNID=$$
TMPBASE="/tmp/matrix_update_$RUNID"
TMPDIR="$TMPBASE/extract"
ARCHIVE="$TMPBASE/MatrixToolkit.tar.gz"
LOG="$TMPBASE/update.log"

MATRIX_DIR="/usr/local/matrix"
WEB_DIR="$MATRIX_DIR/web"
ADMIN_DIR="$WEB_DIR/admin"
CGI_DIR="$WEB_DIR/cgi-bin"
BIN_DIR="/usr/local/bin"

html_header() {
    echo "Content-Type: text/html"
    echo ""
}

html_error() {
    html_header
    echo "<html><head><title>Matrix Update Failed</title></head>"
    echo "<body style='font-family:Arial;margin:20px;'>"
    echo "<h2>GitHub Update Failed</h2>"
    echo "<p>$1</p>"

    if [ -f "$LOG" ]; then
        echo "<hr><b>Details:</b><pre>"
        cat "$LOG"
        echo "</pre>"
    fi

    echo "<br><button onclick=\"window.location='/admin/index.html'\">Return to Admin</button>"
    echo "</body></html>"
    exit 1
}

configure_uhttpd_matrix() {
    uci set uhttpd.matrix='uhttpd'
    uci delete uhttpd.matrix.listen_http 2>/dev/null
    uci add_list uhttpd.matrix.listen_http='0.0.0.0:8080'
    uci add_list uhttpd.matrix.listen_http='[::]:8080'
    uci set uhttpd.matrix.home="$WEB_DIR"
    uci set uhttpd.matrix.index_page='index.html'
    uci set uhttpd.matrix.cgi_prefix='/cgi-bin'
    uci set uhttpd.matrix.script_timeout='600'
    uci set uhttpd.matrix.network_timeout='30'
    uci set uhttpd.matrix.http_keepalive='0'
    uci set uhttpd.matrix.tcp_keepalive='5'
    uci set uhttpd.matrix.no_dirlists='1'
    uci commit uhttpd
}

fix_admin_links() {
    if [ -f "$WEB_DIR/index.html" ]; then
        sed -i "s#window.location='/admin/'#window.location='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
        sed -i 's#href="/admin/"#href="/admin/index.html"#g' "$WEB_DIR/index.html" 2>/dev/null
        sed -i "s#href='/admin/'#href='/admin/index.html'#g" "$WEB_DIR/index.html" 2>/dev/null
    fi
    if [ -f "$ADMIN_DIR/index.html" ]; then
        sed -i "s#window.location='/admin/'#window.location='/admin/index.html'#g" "$ADMIN_DIR/index.html" 2>/dev/null
        sed -i 's#href="/admin/"#href="/admin/index.html"#g' "$ADMIN_DIR/index.html" 2>/dev/null
        sed -i "s#href='/admin/'#href='/admin/index.html'#g" "$ADMIN_DIR/index.html" 2>/dev/null
    fi
}

mkdir -p "$TMPDIR" "$BIN_DIR" "$MATRIX_DIR" "$WEB_DIR" "$ADMIN_DIR" "$CGI_DIR"

echo "Downloading Matrix Toolkit..." > "$LOG"
wget --no-check-certificate -O "$ARCHIVE" "$URL" >> "$LOG" 2>&1 || html_error "Download failed."

[ -s "$ARCHIVE" ] || html_error "Download failed. File is empty."

echo "" >> "$LOG"
echo "Checking archive..." >> "$LOG"
tar -tzf "$ARCHIVE" >/dev/null 2>> "$LOG" || html_error "Downloaded file is not a valid tar.gz archive."

echo "Extracting archive..." >> "$LOG"
tar -xzf "$ARCHIVE" -C "$TMPDIR" >> "$LOG" 2>&1 || html_error "Archive extraction failed."

SRC="$TMPDIR/MatrixInstall"
[ -d "$SRC" ] || html_error "MatrixInstall folder not found in archive."

# Self-update first, then run once again with the fresh updater
if [ "$1" != "run" ] && [ -f "$SRC/cgi-bin/update_github.sh" ]; then
    echo "Self updating update_github.sh..." >> "$LOG"
    cp -f "$SRC/cgi-bin/update_github.sh" "$SELF" >> "$LOG" 2>&1
    chmod +x "$SELF" >> "$LOG" 2>&1
    exec "$SELF" run
fi

echo "Copying web files..." >> "$LOG"
[ -d "$SRC/web" ] || html_error "Web folder not found in archive."
cp -f "$SRC/web/"* "$WEB_DIR/" >> "$LOG" 2>&1

if [ -f "$SRC/web_admin/index.html" ]; then
    cp -f "$SRC/web_admin/index.html" "$ADMIN_DIR/index.html" >> "$LOG" 2>&1
else
    echo "WARNING: web_admin/index.html not found" >> "$LOG"
fi

echo "Copying CGI scripts..." >> "$LOG"
if [ -d "$SRC/cgi-bin" ]; then
    for f in "$SRC/cgi-bin/"*.sh; do
        [ -f "$f" ] || continue
        cp -f "$f" "$CGI_DIR/" >> "$LOG" 2>&1
    done
fi

echo "Copying admin CGI scripts, skipping duplicate about.sh..." >> "$LOG"
if [ -d "$SRC/cgi-bin_admin" ]; then
    for f in "$SRC/cgi-bin_admin/"*.sh; do
        [ -f "$f" ] || continue
        case "$(basename "$f")" in
            about.sh)
                echo "Skipped duplicate cgi-bin_admin/about.sh" >> "$LOG"
                ;;
            *)
                cp -f "$f" "$CGI_DIR/" >> "$LOG" 2>&1
                ;;
        esac
    done
fi

chmod +x "$CGI_DIR"/*.sh >> "$LOG" 2>&1

echo "Copying version and settings files..." >> "$LOG"
[ -f "$SRC/version.txt" ] && cp -f "$SRC/version.txt" "$MATRIX_DIR/version.txt" >> "$LOG" 2>&1
[ -f "$SRC/clubname.txt" ] && cp -f "$SRC/clubname.txt" "$MATRIX_DIR/clubname.txt" >> "$LOG" 2>&1
[ -f "$SRC/admin_password.txt" ] && cp -f "$SRC/admin_password.txt" "$MATRIX_DIR/admin_password.txt" >> "$LOG" 2>&1

if [ ! -f "$MATRIX_DIR/version.txt" ]; then
    cat > "$MATRIX_DIR/version.txt" <<'VERSIONEOF'
Version=Unknown
Build=Unknown
Release=Unknown
Changes=Unknown
GitHub=https://github.com/MatrixFitness/Tool
Author=Unknown
Email=
Company=Matrix Fitness
Message=Matrix Toolkit
VERSIONEOF
fi

get_value() {
    grep "^$1=" "$MATRIX_DIR/version.txt" 2>/dev/null | cut -d= -f2-
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
GITHUB=$(get_value GitHub)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
COMPANY=$(get_value Company)
MESSAGE=$(get_value Message)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="Unknown"
[ -z "$GITHUB" ] && GITHUB="Unknown"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="Unknown"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$MESSAGE" ] && MESSAGE=""

cat > /tmp/main_footer.html << FOOTEREOF
<div class="footer">
Matrix Toolkit v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE

<br><br>

Repository:<br>
$GITHUB
</div>
FOOTEREOF

cat > /tmp/admin_footer.html << FOOTEREOF
<div class="footer">
Backup locatie:<br>
/usr/local/mnt/sda1/Backup

<br><br>

Matrix Admin v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE

<br><br>

Repository:<br>
$GITHUB
</div>
FOOTEREOF

echo "Updating footers..." >> "$LOG"
if [ -f "$WEB_DIR/index.html" ]; then
    sed -i "/<div class=\"footer\">/,/<\/div>/{
        /<div class=\"footer\">/r /tmp/main_footer.html
        d
    }" "$WEB_DIR/index.html" 2>> "$LOG"
fi

if [ -f "$ADMIN_DIR/index.html" ]; then
    sed -i "/<div class=\"footer\">/,/<\/div>/{
        /<div class=\"footer\">/r /tmp/admin_footer.html
        d
    }" "$ADMIN_DIR/index.html" 2>> "$LOG"
fi

fix_admin_links

echo "Creating CLI shortcuts..." >> "$LOG"
ln -sf "$CGI_DIR/update_github.sh" "$BIN_DIR/matrix-update"
ln -sf "$CGI_DIR/matrix_full_test.sh" "$BIN_DIR/matrix-test"
ln -sf "$CGI_DIR/certification_report.sh" "$BIN_DIR/matrix-report"

cat > "$BIN_DIR/matrix-version" <<'EOF_VERSION'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF_VERSION
chmod +x "$BIN_DIR/matrix-version"

echo "Configuring Matrix webserver on port 8080..." >> "$LOG"
configure_uhttpd_matrix >> "$LOG" 2>&1
/etc/init.d/uhttpd restart >> "$LOG" 2>&1

rm -rf "$TMPBASE"

html_header
cat << HTMLEOF
<html>
<head>
<title>Matrix Toolkit Update</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.card { background: white; padding: 20px; border-radius: 8px; max-width: 800px; box-shadow: 0 1px 4px rgba(0,0,0,0.12); }
table { border-collapse: collapse; width: 100%; }
td { border: 1px solid #ddd; padding: 8px; }
th { background: #007bff; color: white; padding: 8px; text-align: left; }
.pass { color: green; font-weight: bold; }
button { margin-top: 20px; width: 220px; height: 50px; font-size: 16px; font-weight: bold; cursor: pointer; border: 0; border-radius: 6px; background: #007bff; color: white; }
</style>
</head>
<body>
<div class="card">
<h2>GitHub Update Completed</h2>
<table>
<tr><th>Item</th><th>Value</th></tr>
<tr><td>Version</td><td>$VERSION</td></tr>
<tr><td>Build</td><td>$BUILD</td></tr>
<tr><td>Release</td><td>$RELEASE</td></tr>
<tr><td>Changes</td><td>$CHANGES</td></tr>
<tr><td>Company</td><td>$COMPANY</td></tr>
<tr><td>Author</td><td>$AUTHOR</td></tr>
<tr><td>Email</td><td>$EMAIL</td></tr>
<tr><td>GitHub</td><td>$GITHUB</td></tr>
</table>
<p class="pass">Matrix Toolkit updated successfully.</p>
<button onclick="window.location='/index.html'">Return to Home</button>
<button onclick="window.location='/admin/index.html'">Return to Admin</button>
</div>
</body>
</html>
HTMLEOF
