#!/bin/sh

[ "$MATRIX_UPDATE_BACKGROUND" != "1" ] && {
echo "Content-Type: text/html"
echo ""
}

URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz"
TMP="/tmp/MatrixToolkit.tar.gz"
WORK="/tmp/MatrixToolkit_update"

echo "Downloading Matrix Toolkit..."

rm -f "$TMP"
rm -rf "$WORK"
mkdir -p "$WORK"

wget -O "$TMP" "$URL" || {
echo "ERROR: download failed"
exit 1
}

tar -xzf "$TMP" -C "$WORK" || {
echo "ERROR: extract failed"
exit 1
}

SRC="$(find "$WORK" -type f -name version.txt | head -1 | xargs dirname)"

if [ -z "$SRC" ] || [ ! -d "$SRC" ]; then
echo "ERROR: source folder not found"
exit 1
fi

echo "Installing from: $SRC"

cp -a "$SRC"/* /usr/local/matrix/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh 2>/dev/null
chmod +x /usr/local/matrix/adminweb/cgi-bin/*.sh 2>/dev/null
chmod +x /usr/local/matrix/matrix_update_worker.sh 2>/dev/null

echo ""
echo "Matrix Toolkit updated successfully."

exit 0
