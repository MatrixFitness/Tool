#!/bin/sh

echo "Content-Type: text/html"
echo ""

rm -rf /tmp/MatrixToolkit
rm -f /tmp/MatrixToolkit.tar.gz

mkdir -p /tmp/MatrixToolkit
mkdir -p /usr/local/bin

wget -O /tmp/MatrixToolkit.tar.gz \
"https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz"

if [ $? -ne 0 ]
then
    echo "<html><body>"
    echo "<h2>GitHub Update Failed</h2>"
    echo "<p>Download failed.</p>"
    echo "</body></html>"
    exit 1
fi

tar -xzf /tmp/MatrixToolkit.tar.gz -C /tmp/MatrixToolkit

if [ $? -ne 0 ]
then
    echo "<html><body>"
    echo "<h2>GitHub Update Failed</h2>"
    echo "<p>Archive extraction failed.</p>"
    echo "</body></html>"
    exit 1
fi

cp -f /tmp/MatrixToolkit/MatrixInstall/web/* \
      /usr/local/matrix/web/

cp -f /tmp/MatrixToolkit/MatrixInstall/web_admin/index.html \
      /usr/local/matrix/web/admin/index.html

cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin/*.sh \
      /usr/local/matrix/web/cgi-bin/

cp -f /tmp/MatrixToolkit/MatrixInstall/cgi-bin_admin/*.sh \
      /usr/local/matrix/web/cgi-bin/

chmod +x /usr/local/matrix/web/cgi-bin/*.sh

if [ -f /tmp/MatrixToolkit/MatrixInstall/version.txt ]
then
    cp -f /tmp/MatrixToolkit/MatrixInstall/version.txt \
          /usr/local/matrix/version.txt
fi

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
CHANGES=$(grep '^Changes=' /usr/local/matrix/version.txt | cut -d'=' -f2-)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

cat > /tmp/main_footer.html << EOF
<div class="footer">
Matrix Toolkit v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE
</div>
EOF

cat > /tmp/admin_footer.html << EOF
<div class="footer">
Backup locatie:<br>
/usr/local/mnt/sda1/Backup

<br><br>

Matrix Admin v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE
</div>
EOF

sed -i "/<div class=\"footer\">/,/<\/div>/{
    /<div class=\"footer\">/r /tmp/main_footer.html
    d
}" /usr/local/matrix/web/index.html

sed -i "/<div class=\"footer\">/,/<\/div>/{
    /<div class=\"footer\">/r /tmp/admin_footer.html
    d
}" /usr/local/matrix/web/admin/index.html

if [ -f /tmp/MatrixToolkit/MatrixInstall/admin_password.txt ]
then
    cp -f /tmp/MatrixToolkit/MatrixInstall/admin_password.txt \
          /usr/local/matrix/admin_password.txt
fi

ln -sf /usr/local/matrix/web/cgi-bin/update_github.sh \
      /usr/local/bin/matrix-update

ln -sf /usr/local/matrix/web/cgi-bin/matrix_full_test.sh \
      /usr/local/bin/matrix-test

ln -sf /usr/local/matrix/web/cgi-bin/certification_report.sh \
      /usr/local/bin/matrix-report

cat > /usr/local/bin/matrix-version << 'EOF'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF

chmod +x /usr/local/bin/matrix-version

/etc/init.d/uhttpd reload >/dev/null 2>&1

echo "<html>"
echo "<head>"
echo "<title>Matrix Toolkit Update</title>"
echo "</head>"
echo "<body style='font-family:Arial;margin:20px;'>"

echo "<h2>GitHub Update Completed</h2>"

echo "<p>"
echo "<b>Version:</b> $VERSION<br>"
echo "<b>Build:</b> $BUILD<br>"
echo "<b>Release:</b> $RELEASE<br>"
echo "<b>Changes:</b> $CHANGES<br>"
echo "<b>Company:</b> $COMPANY<br>"
echo "<b>Author:</b> $AUTHOR<br>"
echo "<b>Email:</b> $EMAIL<br>"
echo "<b>Notes:</b> $MESSAGE"
echo "</p>"

echo "<hr>"
echo "<p>Matrix Toolkit updated successfully.</p>"

echo "<br><br>"
echo "<button onclick=\"window.location='/'\">Return to Home</button>"

echo "</body>"
echo "</html>"