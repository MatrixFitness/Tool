#!/bin/sh

echo "Content-Type: text/html"
echo ""

SELF="/usr/local/matrix/web/cgi-bin/update_github.sh"
URL="https://raw.githubusercontent.com/MatrixFitness/Tool/main/MatrixToolkit.tar.gz"
TMPDIR="/tmp/MatrixToolkit"
ARCHIVE="/tmp/MatrixToolkit.tar.gz"
LOG="/tmp/matrix_update_error.log"

html_error() {
    echo "<html>"
    echo "<head><title>Matrix Toolkit Update Failed</title></head>"
    echo "<body style='font-family:Arial;margin:20px;'>"
    echo "<h2>GitHub Update Failed</h2>"
    echo "<p>$1</p>"

    if [ -f "$LOG" ]; then
        echo "<hr>"
        echo "<b>Details:</b>"
        echo "<pre>"
        cat "$LOG"
        echo "</pre>"
    fi

    echo "<br>"
    echo "<button onclick=\"window.location='/'\">Return to Home</button>"
    echo "</body></html>"
    exit 1
}

rm -rf "$TMPDIR"
rm -f "$ARCHIVE"
rm -f "$LOG"

mkdir -p "$TMPDIR"
mkdir -p /usr/local/bin
mkdir -p /usr/local/matrix/web
mkdir -p /usr/local/matrix/web/admin
mkdir -p /usr/local/matrix/web/cgi-bin

echo "Downloading Matrix Toolkit..." > "$LOG"

wget --no-check-certificate -O "$ARCHIVE" "$URL" >> "$LOG" 2>&1

if [ $? -ne 0 ]; then
    html_error "Download failed."
fi

if [ ! -s "$ARCHIVE" ]; then
    html_error "Download failed. File is empty."
fi

echo "" >> "$LOG"
echo "Extracting archive..." >> "$LOG"

tar -xzf "$ARCHIVE" -C "$TMPDIR" >> "$LOG" 2>&1

if [ $? -ne 0 ]; then
    html_error "Archive extraction failed."
fi

if [ ! -d "$TMPDIR/MatrixInstall" ]; then
    html_error "MatrixInstall folder not found in archive."
fi

# Self-update first, then restart once
if [ "$1" != "run" ] && [ -f "$TMPDIR/MatrixInstall/cgi-bin/update_github.sh" ]; then
    cp -f "$TMPDIR/MatrixInstall/cgi-bin/update_github.sh" "$SELF" >> "$LOG" 2>&1
    chmod +x "$SELF" >> "$LOG" 2>&1
    exec "$SELF" run
fi

if [ -d "$TMPDIR/MatrixInstall/web" ]; then
    cp -f "$TMPDIR/MatrixInstall/web/"* /usr/local/matrix/web/ >> "$LOG" 2>&1
else
    html_error "Web folder not found in archive."
fi

if [ -f "$TMPDIR/MatrixInstall/web_admin/index.html" ]; then
    cp -f "$TMPDIR/MatrixInstall/web_admin/index.html" /usr/local/matrix/web/admin/index.html >> "$LOG" 2>&1
fi

if [ -d "$TMPDIR/MatrixInstall/cgi-bin" ]; then
    cp -f "$TMPDIR/MatrixInstall/cgi-bin/"*.sh /usr/local/matrix/web/cgi-bin/ >> "$LOG" 2>&1
fi

if [ -d "$TMPDIR/MatrixInstall/cgi-bin_admin" ]; then
    cp -f "$TMPDIR/MatrixInstall/cgi-bin_admin/"*.sh /usr/local/matrix/web/cgi-bin/ >> "$LOG" 2>&1
fi

chmod +x /usr/local/matrix/web/cgi-bin/*.sh >> "$LOG" 2>&1

if [ -f "$TMPDIR/MatrixInstall/version.txt" ]; then
    cp -f "$TMPDIR/MatrixInstall/version.txt" /usr/local/matrix/version.txt >> "$LOG" 2>&1
fi

if [ ! -f /usr/local/matrix/version.txt ]; then
    cat > /usr/local/matrix/version.txt << EOF
Version=Unknown
Build=Unknown
Release=Unknown
Changes=Unknown
Company=Matrix Fitness
Author=Rob Bosman
Email=
Message=Matrix Toolkit
GitHub=https://github.com/MatrixFitness/Tool
EOF
fi

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
CHANGES=$(grep '^Changes=' /usr/local/matrix/version.txt | cut -d'=' -f2-)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)
GITHUB=$(grep '^GitHub=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

cat > /tmp/main_footer.html << EOF
<div class="footer">
Matrix Toolkit v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE

<br><br>

Repository:<br>
$GITHUB
</div>
EOF

cat > /tmp/admin_footer.html << EOF
<div class="footer">
Backup locatie:<br>
/usr/local/mnt/sda1/Backup

<br><br>

Matrix Admin v$VERSION<br>
Build $BUILD<br>
Release $RELEASE<br>
Changes $CHANGES

<br><br>

$COMPANY<br>
Created by $AUTHOR<br>
$EMAIL<br>
$MESSAGE

<br><br>

Repository:<br>
$GITHUB
</div>
EOF

if [ -f /usr/local/matrix/web/index.html ]; then
    sed -i "/<div class=\"footer\">/,/<\/div>/{
        /<div class=\"footer\">/r /tmp/main_footer.html
        d
    }" /usr/local/matrix/web/index.html
fi

if [ -f /usr/local/matrix/web/admin/index.html ]; then
    sed -i "/<div class=\"footer\">/,/<\/div>/{
        /<div class=\"footer\">/r /tmp/admin_footer.html
        d
    }" /usr/local/matrix/web/admin/index.html
fi

if [ -f "$TMPDIR/MatrixInstall/admin_password.txt" ]; then
    cp -f "$TMPDIR/MatrixInstall/admin_password.txt" /usr/local/matrix/admin_password.txt >> "$LOG" 2>&1
fi

ln -sf /usr/local/matrix/web/cgi-bin/update_github.sh /usr/local/bin/matrix-update
ln -sf /usr/local/matrix/web/cgi-bin/matrix_full_test.sh /usr/local/bin/matrix-test
ln -sf /usr/local/matrix/web/cgi-bin/certification_report.sh /usr/local/bin/matrix-report

cat > /usr/local/bin/matrix-version << 'EOF'
#!/bin/sh
cat /usr/local/matrix/version.txt
EOF

chmod +x /usr/local/bin/matrix-version

/etc/init.d/uhttpd reload >> "$LOG" 2>&1

echo "<html>"
echo "<head>"
echo "<title>Matrix Toolkit Update</title>"
echo "</head>"
echo "<body style='font-family:Arial;margin:20px;'>"

echo "<h2>GitHub Update Completed</h2>"

echo "<p>"
echo "<b>Version:</b> $VERSION<br>"
echo "<b>Build:</b> $BUILD<br>"
echo "<b>Release:</b> $RELEASE<br>"
echo "<b>Changes:</b> $CHANGES<br>"
echo "<b>Company:</b> $COMPANY<br>"
echo "<b>Author:</b> $AUTHOR<br>"
echo "<b>Email:</b> $EMAIL<br>"
echo "<b>Notes:</b> $MESSAGE<br>"
echo "<b>GitHub:</b> $GITHUB"
echo "</p>"

echo "<hr>"
echo "<p>Matrix Toolkit updated successfully.</p>"

echo "<br><br>"
echo "<button onclick=\"window.location='/'\">Return to Home</button>"

echo "</body>"
echo "</html>"