#!/bin/sh

SESSION_DIR="/tmp/matrix_admin_sessions"
COOKIE_NAME="MatrixAdminSession"

SID="$(echo "$HTTP_COOKIE" | tr ';' '\n' | sed 's/^ *//' | grep "^${COOKIE_NAME}=" | head -1 | cut -d= -f2-)"
case "$SID" in
    ''|*[!A-Za-z0-9_-]*) ;;
    *) rm -f "$SESSION_DIR/$SID" 2>/dev/null ;;
esac

echo "Set-Cookie: MatrixAdminSession=deleted; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"
echo "Content-Type: text/html"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo ""
cat <<HTML
<html><head><title>Logged out</title><meta http-equiv="refresh" content="0;url=/cgi-bin/admin_login.sh"><script>window.location='/cgi-bin/admin_login.sh';</script></head><body>Logged out. <a href="/cgi-bin/admin_login.sh">Login again</a></body></html>
HTML
