#!/bin/sh

echo "Content-Type: text/html"
echo ""

DATE=$(date "+%Y-%m-%d %H:%M:%S")

LOCATION=$(echo "$QUERY_STRING" | sed -n 's/.*location=\([^&]*\).*/\1/p' | sed 's/%20/ /g')
SIGNAL=$(echo "$QUERY_STRING" | sed -n 's/.*signal=\([^&]*\).*/\1/p')
RATING=$(echo "$QUERY_STRING" | sed -n 's/.*rating=\([^&]*\).*/\1/p')
INTERNET=$(echo "$QUERY_STRING" | sed -n 's/.*internet=\([^&]*\).*/\1/p')
DNS=$(echo "$QUERY_STRING" | sed -n 's/.*dns=\([^&]*\).*/\1/p')
MATRIX=$(echo "$QUERY_STRING" | sed -n 's/.*matrix=\([^&]*\).*/\1/p')

CSV="/tmp/wifi_survey_results.csv"

if [ ! -f "$CSV" ]
then
    echo "Date,Location,Signal,Rating,Internet,DNS,Matrix" > "$CSV"
fi

echo "$DATE,$LOCATION,$SIGNAL,$RATING,$INTERNET,$DNS,$MATRIX" >> "$CSV"

echo "<html>"
echo "<body style='font-family:Arial'>"
echo "<h2>Measurement Saved</h2>"
echo "<p>Location: $LOCATION</p>"
echo "<p>Signal: $SIGNAL dBm</p>"
echo "<br>"
echo "<button onclick=\"window.location='/location_survey.html'\">Next Location</button>"
echo "<button onclick=\"window.location='/cgi-bin/final_report.sh'\">Finish Survey</button>"
echo "</body>"
echo "</html>"