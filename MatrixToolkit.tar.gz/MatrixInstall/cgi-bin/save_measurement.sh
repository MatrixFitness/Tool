#!/bin/sh

printf "Content-Type: text/html\n\n"

SURVEY_DIR="/usr/local/matrix/survey"
CSV="$SURVEY_DIR/wifi_survey_results.csv"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"
LOGO="/matrix_logo.png"

mkdir -p "$SURVEY_DIR" 2>/dev/null
chmod 777 "$SURVEY_DIR" 2>/dev/null
[ -f "$CSV" ] || echo "Date,Location,SSID,IP Address,Signal,Rating,Link Quality,Bit Rate,Band,Channel,BSSID,AP Vendor,Roaming Assessment,Internet,DNS,Matrix,Latency,Packet Loss,Download Mbps,Speed Rating,Network Quality,Overall" > "$CSV"
[ -f "$COMPLETED_FILE" ] || : > "$COMPLETED_FILE"

DATE=$(date "+%Y-%m-%d %H:%M:%S")

get_param(){
  echo "$QUERY_STRING" | sed -n "s/.*$1=\([^&]*\).*/\1/p" | sed 's/%20/ /g;s/%2F/\//g;s/%2D/-/g;s/%28/(/g;s/%29/)/g;s/%26/\&/g;s/%2B/+/g;s/%25/%/g;s/+/ /g'
}

html_escape(){
  printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

badge_class(){
  case "$1" in
    Excellent|PASS) echo "excellent";;
    Good) echo "good";;
    Fair|ATTENTION) echo "fair";;
    Poor|Weak) echo "poor";;
    Critical|FAIL) echo "critical";;
    *) echo "unknown";;
  esac
}

dot_class(){
  case "$1" in
    Excellent|PASS) echo "dot-excellent";;
    Good) echo "dot-good";;
    Fair|ATTENTION) echo "dot-fair";;
    Poor|Weak) echo "dot-poor";;
    Critical|FAIL) echo "dot-critical";;
    *) echo "dot-unknown";;
  esac
}

LOCATION=$(get_param location)
SSID=$(get_param ssid)
IPADDR=$(get_param ipaddr)
SIGNAL=$(get_param signal)
RATING=$(get_param rating)
QUALITY=$(get_param quality)
BITRATE=$(get_param bitrate)
BAND=$(get_param band)
CHANNEL=$(get_param channel)
BSSID=$(get_param bssid)
APVENDOR=$(get_param apvendor)
ROAMING=$(get_param roaming)
INTERNET=$(get_param internet)
DNS=$(get_param dns)
MATRIX=$(get_param matrix)
LATENCY=$(get_param latency)
PACKETLOSS=$(get_param packetloss)
DOWNLOAD=$(get_param download)
SPEEDRATING=$(get_param speedrating)
QUALITYRATING=$(get_param qualityrating)
OVERALL=$(get_param overall)

[ -z "$LOCATION" ] && LOCATION="Unknown"
[ -z "$SSID" ] && SSID="Unknown"
[ -z "$BAND" ] && BAND="Unknown"
[ -z "$CHANNEL" ] && CHANNEL="Unknown"
[ -z "$BSSID" ] && BSSID="Unknown"
[ -z "$APVENDOR" ] && APVENDOR="Unknown"
[ -z "$ROAMING" ] && ROAMING="Unknown"
[ -z "$OVERALL" ] && OVERALL="PASS"

# Prevent duplicate save for the same location during resume/retry.
if ! grep -Fxq "$LOCATION" "$COMPLETED_FILE" 2>/dev/null; then
  echo "$DATE,$LOCATION,$SSID,$IPADDR,$SIGNAL,$RATING,$QUALITY,$BITRATE,$BAND,$CHANNEL,$BSSID,$APVENDOR,$ROAMING,$INTERNET,$DNS,$MATRIX,$LATENCY,$PACKETLOSS,$DOWNLOAD,$SPEEDRATING,$QUALITYRATING,$OVERALL" >> "$CSV"
  echo "$LOCATION" >> "$COMPLETED_FILE"
fi

RC=$(badge_class "$RATING")
SC=$(badge_class "$SPEEDRATING")
QC=$(badge_class "$QUALITYRATING")
OC=$(badge_class "$OVERALL")
RD=$(dot_class "$RATING")
SD=$(dot_class "$SPEEDRATING")
QD=$(dot_class "$QUALITYRATING")
OD=$(dot_class "$OVERALL")

cat <<HTML
<html>
<head>
<title>Measurement Saved</title>

cat <<HTML
<html>
<head>
<title>Measurement Saved</title>
<style>
:root{--blue:#005a9c;--green:#1f8a3b;--bg:#f5f5f5;}
body{font-family:Arial,Helvetica,sans-serif;margin:0;background:var(--bg);color:#222;}
.page{max-width:720px;margin:24px auto;background:#fff;border:1px solid #ccc;border-radius:10px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.08);}
h1{margin:0;color:var(--blue);font-size:26px}.success{background:#eefaf0;border-left:6px solid var(--green);padding:14px;border-radius:6px;margin:18px 0;line-height:1.5}.details{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:14px;margin:14px 0;line-height:1.7}.actions{margin-top:18px}button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:var(--blue);color:white;cursor:pointer}.secondary{background:#666}.small{color:#555;font-size:13px}
</style>
</head>
<body>
<div class="page">
<h1>Measurement Saved</h1>
<div class="success"><b>$LOCATION</b> has been saved to the survey.</div>
<div class="details">
<b>Result:</b> $OVERALL<br>
<b>Signal:</b> $SIGNAL dBm ($RATING)<br>
<b>Download:</b> $DOWNLOAD Mbps ($SPEEDRATING)<br>
<b>Latency / Packet Loss:</b> $LATENCY ms / $PACKETLOSS<br>
<b>WiFi:</b> $SSID | $BAND | Channel $CHANNEL
</div>
<p class="small">You may now move the router to the next location. The final report is created only when you click <b>Finish Survey</b>.</p>
<div class="actions">
<button onclick="window.location='/cgi-bin/next_location.sh'">Next Location</button>
<button class="secondary" onclick="window.location='/cgi-bin/final_report.sh'">Finish Survey</button>
<button class="secondary" onclick="window.location='/location_survey.html'">Survey Home</button>
</div>
</div>
</body>
</html>
HTML
