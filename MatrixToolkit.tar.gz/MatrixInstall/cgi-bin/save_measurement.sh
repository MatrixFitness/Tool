#!/bin/sh

echo "Content-Type: text/html"
echo ""

SURVEY_DIR="/usr/local/matrix/survey"
CSV="$SURVEY_DIR/wifi_survey_results.csv"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"

mkdir -p "$SURVEY_DIR"
[ -f "$CSV" ] || echo "Date,Location,SSID,IP Address,Signal,Rating,Link Quality,Bit Rate,Internet,DNS,Matrix" > "$CSV"
[ -f "$COMPLETED_FILE" ] || : > "$COMPLETED_FILE"

DATE=$(date "+%Y-%m-%d %H:%M:%S")

get_param(){
  echo "$QUERY_STRING" | sed -n "s/.*$1=\([^&]*\).*/\1/p" | sed 's/%20/ /g;s/%2F/\//g;s/%2D/-/g;s/%28/(/g;s/%29/)/g;s/%26/\&/g'
}

LOCATION=$(get_param location)
SSID=$(get_param ssid)
IPADDR=$(get_param ipaddr)
SIGNAL=$(get_param signal)
RATING=$(get_param rating)
QUALITY=$(get_param quality)
BITRATE=$(get_param bitrate)
INTERNET=$(get_param internet)
DNS=$(get_param dns)
MATRIX=$(get_param matrix)

# Prevent duplicate save for the same location during resume/retry.
if ! grep -Fxq "$LOCATION" "$COMPLETED_FILE" 2>/dev/null; then
  echo "$DATE,$LOCATION,$SSID,$IPADDR,$SIGNAL,$RATING,$QUALITY,$BITRATE,$INTERNET,$DNS,$MATRIX" >> "$CSV"
  echo "$LOCATION" >> "$COMPLETED_FILE"
fi

cat <<HTML
<html><head><title>Measurement Saved</title>
<style>body{font-family:Arial;margin:30px;background:#f5f5f5}.card{background:white;max-width:700px;padding:22px;border:1px solid #ccc;border-radius:8px}button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:#005a9c;color:white;cursor:pointer}.secondary{background:#666}</style>
</head><body><div class="card">
<h2>Measurement Saved</h2>
<p><b>Location:</b> $LOCATION</p>
<p><b>Signal:</b> $SIGNAL dBm</p>
<p>This location is now marked as done. You may power off the router and move it to the next location.</p>
<button onclick="window.location='/cgi-bin/next_location.sh'">Next Location</button>
<button class="secondary" onclick="window.location='/cgi-bin/final_report.sh'">Finish Survey</button>
</div></body></html>
HTML
