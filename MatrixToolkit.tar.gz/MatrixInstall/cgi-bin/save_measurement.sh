#!/bin/sh

printf "Content-Type: text/html\n\n"

SURVEY_DIR="/usr/local/matrix/survey"
CSV="$SURVEY_DIR/wifi_survey_results.csv"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"
LOGO="/matrix_logo.png"

mkdir -p "$SURVEY_DIR" 2>/dev/null
chmod 777 "$SURVEY_DIR" 2>/dev/null
[ -f "$CSV" ] || echo "Date,Location,SSID,IP Address,Signal,Rating,Link Quality,Bit Rate,Band,Channel,BSSID,AP Vendor,Roaming Assessment,Internet,DNS,Matrix,Latency,Packet Loss,Download Mbps,Speed Rating,Network Quality,Overall" > "$CSV"
[ -f "$COMPLETED_FILE" ] || : > "$COMPLETED_FILE"

DATE=$(date "+%Y-%m-%d %H:%M:%S")

get_param(){
  echo "$QUERY_STRING" | sed -n "s/.*$1=\([^&]*\).*/\1/p" | sed 's/%20/ /g;s/%2F/\//g;s/%2D/-/g;s/%28/(/g;s/%29/)/g;s/%26/\&/g;s/%2B/+/g;s/%25/%/g;s/+/ /g'
}

html_escape(){
  printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

badge_class(){
  case "$1" in
    Excellent|PASS) echo "excellent";;
    Good) echo "good";;
    Fair|ATTENTION) echo "fair";;
    Poor|Weak) echo "poor";;
    Critical|FAIL) echo "critical";;
    *) echo "unknown";;
  esac
}

dot_class(){
  case "$1" in
    Excellent|PASS) echo "dot-excellent";;
    Good) echo "dot-good";;
    Fair|ATTENTION) echo "dot-fair";;
    Poor|Weak) echo "dot-poor";;
    Critical|FAIL) echo "dot-critical";;
    *) echo "dot-unknown";;
  esac
}

LOCATION=$(get_param location)
SSID=$(get_param ssid)
IPADDR=$(get_param ipaddr)
SIGNAL=$(get_param signal)
RATING=$(get_param rating)
QUALITY=$(get_param quality)
BITRATE=$(get_param bitrate)
BAND=$(get_param band)
CHANNEL=$(get_param channel)
BSSID=$(get_param bssid)
APVENDOR=$(get_param apvendor)
ROAMING=$(get_param roaming)
INTERNET=$(get_param internet)
DNS=$(get_param dns)
MATRIX=$(get_param matrix)
LATENCY=$(get_param latency)
PACKETLOSS=$(get_param packetloss)
DOWNLOAD=$(get_param download)
SPEEDRATING=$(get_param speedrating)
QUALITYRATING=$(get_param qualityrating)
OVERALL=$(get_param overall)

[ -z "$LOCATION" ] && LOCATION="Unknown"
[ -z "$SSID" ] && SSID="Unknown"
[ -z "$BAND" ] && BAND="Unknown"
[ -z "$CHANNEL" ] && CHANNEL="Unknown"
[ -z "$BSSID" ] && BSSID="Unknown"
[ -z "$APVENDOR" ] && APVENDOR="Unknown"
[ -z "$ROAMING" ] && ROAMING="Unknown"
[ -z "$OVERALL" ] && OVERALL="PASS"

# Prevent duplicate save for the same location during resume/retry.
if ! grep -Fxq "$LOCATION" "$COMPLETED_FILE" 2>/dev/null; then
  echo "$DATE,$LOCATION,$SSID,$IPADDR,$SIGNAL,$RATING,$QUALITY,$BITRATE,$BAND,$CHANNEL,$BSSID,$APVENDOR,$ROAMING,$INTERNET,$DNS,$MATRIX,$LATENCY,$PACKETLOSS,$DOWNLOAD,$SPEEDRATING,$QUALITYRATING,$OVERALL" >> "$CSV"
  echo "$LOCATION" >> "$COMPLETED_FILE"
fi

RC=$(badge_class "$RATING")
SC=$(badge_class "$SPEEDRATING")
QC=$(badge_class "$QUALITYRATING")
OC=$(badge_class "$OVERALL")
RD=$(dot_class "$RATING")
SD=$(dot_class "$SPEEDRATING")
QD=$(dot_class "$QUALITYRATING")
OD=$(dot_class "$OVERALL")

cat <<HTML
<html>
<head>
<title>Measurement Saved</title>
<style>
:root{--blue:#005a9c;--green:#1f8a3b;--lightgreen:#5cb85c;--yellow:#f0ad4e;--orange:#e67e22;--red:#c0392b;--bg:#f5f5f5;}
body{font-family:Arial,Helvetica,sans-serif;margin:0;background:var(--bg);color:#222;}
.page{max-width:980px;margin:24px auto;background:#fff;border:1px solid #ccc;border-radius:12px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.08);}
.header{display:flex;align-items:center;gap:18px;border-bottom:2px solid #e5eef7;padding-bottom:16px;margin-bottom:20px;}
.logo{height:58px;max-width:220px;object-fit:contain;}
h1{margin:0;color:var(--blue);font-size:28px;}h2{color:var(--blue);margin-top:24px}.sub{color:#555;margin-top:4px}.success{background:#eefaf0;border-left:6px solid var(--green);padding:14px;border-radius:6px;margin:16px 0;}
.summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin:18px 0;}.metric{border:1px solid #ddd;border-radius:10px;background:#fafafa;padding:15px}.metric-title{font-size:13px;color:#555}.metric-value{font-size:24px;font-weight:bold;margin-top:6px}.metric-rating{margin-top:8px}.badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:bold;font-size:12px;min-width:72px;text-align:center}.excellent{background:#1f8a3b;color:white}.good{background:#5cb85c;color:white}.fair{background:#f0ad4e;color:#222}.poor{background:#e67e22;color:white}.critical{background:#c0392b;color:white}.unknown{background:#777;color:white}.status-dot{width:14px;height:14px;display:inline-block;border-radius:50%;vertical-align:middle;margin-right:7px;border:1px solid rgba(0,0,0,.18)}.dot-excellent{background:#1f8a3b}.dot-good{background:#5cb85c}.dot-fair{background:#f0ad4e}.dot-poor{background:#e67e22}.dot-critical{background:#c0392b}.dot-unknown{background:#777}table{border-collapse:collapse;width:100%;font-size:14px;margin:12px 0 22px 0}th{background:var(--blue);color:#fff;text-align:left;padding:9px}td{border:1px solid #ccc;padding:9px;vertical-align:top}tr:nth-child(even) td{background:#fbfbfb}.note{background:#eef6ff;border-left:5px solid var(--blue);padding:14px;border-radius:5px;line-height:1.5;margin:16px 0}.actions{margin-top:20px}button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:var(--blue);color:white;cursor:pointer}.secondary{background:#666}@media print{body{background:white}.page{box-shadow:none;border:0;margin:0;max-width:none}button{display:none}}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <img class="logo" src="$LOGO" alt="Matrix Fitness">
    <div>
      <h1>Measurement Saved</h1>
      <div class="sub">Location completed and stored in the WiFi survey</div>
    </div>
  </div>

  <div class="success">
    <b><span class="status-dot $OD"></span>$(html_escape "$OVERALL")</b><br>
    This survey location has been successfully completed.
  </div>

  <h2>Location</h2>
  <table>
    <tr><th>Location</th><th>Survey time</th><th>Result</th></tr>
    <tr><td><b>$(html_escape "$LOCATION")</b></td><td>$(html_escape "$DATE")</td><td><span class="badge $OC">$(html_escape "$OVERALL")</span></td></tr>
  </table>

  <h2>Measurement Overview</h2>
  <div class="summary">
    <div class="metric"><div class="metric-title">Signal Strength</div><div class="metric-value"><span class="status-dot $RD"></span>$(html_escape "$SIGNAL") dBm</div><div class="metric-rating"><span class="badge $RC">$(html_escape "$RATING")</span></div></div>
    <div class="metric"><div class="metric-title">Download Speed</div><div class="metric-value"><span class="status-dot $SD"></span>$(html_escape "$DOWNLOAD") Mbps</div><div class="metric-rating"><span class="badge $SC">$(html_escape "$SPEEDRATING")</span></div></div>
    <div class="metric"><div class="metric-title">Latency</div><div class="metric-value"><span class="status-dot $QD"></span>$(html_escape "$LATENCY") ms</div><div class="metric-rating"><span class="badge $QC">$(html_escape "$QUALITYRATING")</span></div></div>
    <div class="metric"><div class="metric-title">Packet Loss</div><div class="metric-value"><span class="status-dot $QD"></span>$(html_escape "$PACKETLOSS")</div><div class="metric-rating"><span class="badge $QC">Network Quality</span></div></div>
  </div>

  <h2>Connected WiFi Details</h2>
  <table>
    <tr><th>Item</th><th>Value</th></tr>
    <tr><td><b>SSID</b></td><td>$(html_escape "$SSID")</td></tr>
    <tr><td><b>Band / Channel</b></td><td>$(html_escape "$BAND") / $(html_escape "$CHANNEL")</td></tr>
    <tr><td><b>BSSID / AP MAC</b></td><td>$(html_escape "$BSSID")</td></tr>
    <tr><td><b>Access Point Vendor</b></td><td>$(html_escape "$APVENDOR")</td></tr>
    <tr><td><b>Roaming Assessment</b></td><td>$(html_escape "$ROAMING")</td></tr>
    <tr><td><b>Internet / DNS / Matrix Fitness Cloud</b></td><td>$(html_escape "$INTERNET") / $(html_escape "$DNS") / $(html_escape "$MATRIX")</td></tr>
  </table>

  <div class="note">
    If required, the router may now be powered off and moved to the next survey location.<br>
    The survey progress is stored on the router and will automatically continue where it left off after reconnecting to WiFi.
  </div>

  <div class="actions">
    <button onclick="window.location='/cgi-bin/next_location.sh'">Next Location</button>
    <button class="secondary" onclick="window.location='/cgi-bin/final_report.sh'">Finish Survey</button>
    <button class="secondary" onclick="window.location='/location_survey.html'">Survey Home</button>
  </div>
</div>
</body>
</html>
HTML
