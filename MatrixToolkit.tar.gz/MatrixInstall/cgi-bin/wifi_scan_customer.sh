#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

QS="$(printf '%s' "$QUERY_STRING")"
SHOW_ALL="0"
echo "$QS" | grep -q 'all=1' && SHOW_ALL="1"
SEARCH="$(printf '%s' "$QS" | tr '&' '\n' | awk -F= '$1=="q"{print substr($0,3); exit}' | sed 's/+/ /g;s/%20/ /g')"
SEARCH_LC="$(printf '%s' "$SEARCH" | tr 'A-Z' 'a-z')"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

TMP="/tmp/matrix_customer_wifi_scan.$$"
BEST="/tmp/matrix_customer_wifi_best.$$"
IFACES="/tmp/matrix_customer_wifi_ifaces.$$"
: > "$TMP"
: > "$IFACES"

iw dev 2>/dev/null | awk '/Interface /{print $2}' >> "$IFACES"
for I in wlan0 wlan1 wlan0-1 wlan1-1 wlan0-2 wlan1-2 radio0 radio1 phy0 phy1; do
    echo "$I" >> "$IFACES"
done
sort -u "$IFACES" > "$IFACES.sorted"
mv "$IFACES.sorted" "$IFACES"

radio_from_iface() {
    DEV="$1"
    case "$DEV" in
        *wlan1*|radio1|phy1) echo "radio1" ;;
        *wlan0*|radio0|phy0) echo "radio0" ;;
        *)
            PHY="$(iw dev "$DEV" info 2>/dev/null | awk '/wiphy/ {print $2; exit}')"
            [ "$PHY" = "1" ] && echo "radio1" || echo "radio0"
            ;;
    esac
}

parse_iwinfo_scan() {
    awk '
    BEGIN{ssid=""; bssid=""; sig=""; chan=""; enc=""}
    /Cell [0-9]+ - Address:/{
      if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}
      ssid=""; bssid=$5; sig=""; chan=""; enc=""
    }
    /ESSID:/{
      line=$0; sub(/^.*ESSID: "/,"",line); sub(/"$/,"",line); ssid=line
    }
    /Signal:/{
      for(i=1;i<=NF;i++) if($i=="Signal:"){sig=$(i+1)}
    }
    /Channel:/{
      for(i=1;i<=NF;i++) if($i=="Channel:"){chan=$(i+1)}
    }
    /Encryption:/{
      line=$0; sub(/^.*Encryption: /,"",line); enc=line
    }
    END{if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}}
    '
}

parse_iw_scan() {
    awk '
    BEGIN{ssid=""; bssid=""; sig=""; chan=""; enc=""}
    /^BSS /{
      if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}
      ssid=""; bssid=$2; sub(/\(.*/,"",bssid); sig=""; chan=""; enc="Unknown"
    }
    /^[ \t]*SSID:/{
      line=$0; sub(/^[ \t]*SSID: /,"",line); ssid=line
    }
    /^[ \t]*signal:/{
      sig=$2
    }
    /^[ \t]*DS Parameter set:/{
      chan=$5
    }
    /^[ \t]*primary channel:/{
      chan=$3
    }
    /^[ \t]*RSN:/{
      enc="WPA2/WPA3"
    }
    /^[ \t]*WPA:/{
      if(enc=="Unknown"){enc="WPA/WPA2"}
    }
    END{if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}}
    '
}

while read DEV; do
    [ -n "$DEV" ] || continue
    RADIO="$(radio_from_iface "$DEV")"
    OUT="$(iwinfo "$DEV" scan 2>/dev/null)"
    if echo "$OUT" | grep -q 'ESSID:'; then
        echo "$OUT" | parse_iwinfo_scan | awk -F'|' -v r="$RADIO" 'BEGIN{OFS="|"}{print $1,$2,$3,$4,$5,r}' >> "$TMP"
    fi
done < "$IFACES"

if [ ! -s "$TMP" ]; then
    while read DEV; do
        [ -n "$DEV" ] || continue
        RADIO="$(radio_from_iface "$DEV")"
        OUT="$(iw dev "$DEV" scan 2>/dev/null)"
        if echo "$OUT" | grep -q 'SSID:'; then
            echo "$OUT" | parse_iw_scan | awk -F'|' -v r="$RADIO" 'BEGIN{OFS="|"}{print $1,$2,$3,$4,$5,r}' >> "$TMP"
        fi
    done < "$IFACES"
fi

if [ ! -s "$TMP" ]; then
    cat <<EOF
<div class="note">
<b>No WiFi networks found.</b><br>
The router did not return scan results.<br>
Try <b>Refresh Scan</b> or use the manual SSID fallback.
</div>
EOF
    rm -f "$TMP" "$BEST" "$IFACES"
    exit 0
fi

awk -F'|' '
function sigint(v){ gsub(/ dBm/,"",v); gsub(/\.00/,"",v); gsub(/[^0-9-]/,"",v); if(v=="") return -999; return v+0 }
length($1)>0 {
    ssid=$1; bssid=$2; sig=sigint($3); chan=$4; enc=$5; radio=$6
    count[ssid]++
    if(!(ssid in bestsig) || sig>bestsig[ssid]){
        bestsig[ssid]=sig; bestbssid[ssid]=bssid; bestchan[ssid]=chan; bestenc[ssid]=enc; bestradio[ssid]=radio
    }
}
END{
    for(ssid in bestsig){
        print ssid "|" bestbssid[ssid] "|" bestsig[ssid] "|" bestchan[ssid] "|" bestenc[ssid] "|" count[ssid] "|" bestradio[ssid]
    }
}' "$TMP" | sort -t'|' -k3,3nr > "$BEST"

TOTAL="$(wc -l < "$BEST" | tr -d ' ')"

cat <<EOF
<div class="note">
<b>$TOTAL unique SSIDs found.</b><br>
Duplicates are grouped. The scan now remembers the exact radio where the SSID was found.
</div>
EOF

VISIBLE=0
while IFS='|' read SSID BSSID SIGNAL CHANNEL ENC AP_COUNT RADIO; do
    [ -z "$SSID" ] && continue
    SSID_LC="$(printf '%s' "$SSID" | tr 'A-Z' 'a-z')"
    if [ -n "$SEARCH_LC" ]; then
        echo "$SSID_LC" | grep -q "$SEARCH_LC" || continue
    fi
    if [ "$SHOW_ALL" != "1" ] && [ "$SIGNAL" -lt -88 ]; then
        continue
    fi

    BAND="Unknown"
    case "$RADIO" in
        radio1) BAND="5 GHz" ;;
        radio0) BAND="2.4 GHz" ;;
    esac
    case "$CHANNEL" in
        [1-9]|1[0-4]) BAND="2.4 GHz" ;;
        ''|Unknown) ;;
        *) BAND="5 GHz" ;;
    esac

    RATING="Unknown"
    if [ "$SIGNAL" -ge -55 ]; then RATING="Excellent"
    elif [ "$SIGNAL" -ge -65 ]; then RATING="Good"
    elif [ "$SIGNAL" -ge -75 ]; then RATING="Fair"
    else RATING="Poor"
    fi

    E_SSID="$(html_escape "$SSID")"
    E_BSSID="$(html_escape "$BSSID")"
    E_SIGNAL="$(html_escape "$SIGNAL")"
    E_CHANNEL="$(html_escape "$CHANNEL")"
    E_BAND="$(html_escape "$BAND")"
    E_ENC="$(html_escape "$ENC")"
    E_RATING="$(html_escape "$RATING")"
    E_COUNT="$(html_escape "$AP_COUNT")"
    E_RADIO="$(html_escape "$RADIO")"

    printf '<div class="network" onclick="selectNetwork(this)" data-ssid="%s" data-bssid="%s" data-band="%s" data-channel="%s" data-signal="%s" data-security="%s" data-radio="%s">\n' "$E_SSID" "$E_BSSID" "$E_BAND" "$E_CHANNEL" "$E_SIGNAL" "$E_ENC" "$E_RADIO"
    printf '  <div><b>%s</b><div class="muted">Best AP: %s dBm · %s · %s · Channel %s · %s · %s AP(s)</div><div class="muted">BSSID %s</div></div>\n' "$E_SSID" "$E_SIGNAL" "$E_RADIO" "$E_BAND" "$E_CHANNEL" "$E_RATING" "$E_COUNT" "$E_BSSID"
    printf '  <div class="pill">%s</div>\n' "$E_ENC"
    printf '</div>\n'
    VISIBLE=$((VISIBLE+1))
done < "$BEST"

if [ "$VISIBLE" -eq 0 ]; then
    cat <<EOF
<div class="note">
No matching SSID is visible with the current filter.<br>
Use <b>Show All</b> or enter the SSID manually.
</div>
EOF
fi

rm -f "$TMP" "$BEST" "$IFACES"
exit 0
