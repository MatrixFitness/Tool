#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

# Prefer iwinfo scan on both radios.
TMP="/tmp/matrix_customer_wifi_scan.$$"
: > "$TMP"

for DEV in radio0 radio1 wlan0 wlan1; do
    iwinfo "$DEV" scan 2>/dev/null | awk '
    BEGIN{ssid=""; bssid=""; sig=""; chan=""; enc=""}
    /Cell [0-9]+ - Address:/{
      if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}
      ssid=""; bssid=$5; sig=""; chan=""; enc=""
    }
    /ESSID:/{
      line=$0; sub(/^.*ESSID: "/,"",line); sub(/"$/,"",line); ssid=line
    }
    /Signal:/{
      for(i=1;i<=NF;i++) if($i=="Signal:"){sig=$(i+1)}
    }
    /Channel:/{
      for(i=1;i<=NF;i++) if($i=="Channel:"){chan=$(i+1)}
    }
    /Encryption:/{
      line=$0; sub(/^.*Encryption: /,"",line); enc=line
    }
    END{if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}}
    ' >> "$TMP"
done

# Remove empty SSIDs and duplicates, keep strongest seen first-ish.
awk -F'|' 'length($1)>0 && !seen[$1]++ {print}' "$TMP" | while IFS='|' read SSID BSSID SIGNAL CHANNEL ENC; do
    [ -z "$SSID" ] && continue
    BAND="Unknown"
    case "$CHANNEL" in
        [1-9]|1[0-4]) BAND="2.4 GHz" ;;
        ''|Unknown) BAND="Unknown" ;;
        *) BAND="5 GHz" ;;
    esac
    RATING="Unknown"
    SIG_NUM="$(echo "$SIGNAL" | sed 's/[^0-9-]//g')"
    if [ -n "$SIG_NUM" ]; then
        if [ "$SIG_NUM" -ge -55 ]; then RATING="Excellent"
        elif [ "$SIG_NUM" -ge -65 ]; then RATING="Good"
        elif [ "$SIG_NUM" -ge -75 ]; then RATING="Fair"
        else RATING="Poor"
        fi
    fi

    E_SSID="$(html_escape "$SSID")"
    E_BSSID="$(html_escape "$BSSID")"
    E_SIGNAL="$(html_escape "$SIGNAL")"
    E_CHANNEL="$(html_escape "$CHANNEL")"
    E_BAND="$(html_escape "$BAND")"
    E_ENC="$(html_escape "$ENC")"
    E_RATING="$(html_escape "$RATING")"

    printf '<div class="network" onclick="selectNetwork(this)" data-ssid="%s" data-bssid="%s" data-band="%s" data-channel="%s" data-signal="%s" data-security="%s">\n' "$E_SSID" "$E_BSSID" "$E_BAND" "$E_CHANNEL" "$E_SIGNAL" "$E_ENC"
    printf '  <div><b>%s</b><div class="muted">%s · Channel %s · %s · %s</div></div>\n' "$E_SSID" "$E_BAND" "$E_CHANNEL" "$E_SIGNAL" "$E_RATING"
    printf '  <div class="pill">%s</div>\n' "$E_ENC"
    printf '</div>\n'
done

rm -f "$TMP"
