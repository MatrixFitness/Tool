#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

TMP="/tmp/matrix_customer_wifi_scan.$$"
IFACES="/tmp/matrix_customer_wifi_ifaces.$$"
: > "$TMP"
: > "$IFACES"

# Build a broad list of real WiFi interfaces. Teltonika/OpenWRT names vary.
iw dev 2>/dev/null | awk '/Interface /{print $2}' >> "$IFACES"
for I in wlan0 wlan1 wlan0-1 wlan1-1 wlan0-2 wlan1-2 radio0 radio1 phy0 phy1; do
    echo "$I" >> "$IFACES"
done
sort -u "$IFACES" > "$IFACES.sorted"
mv "$IFACES.sorted" "$IFACES"

parse_iwinfo_scan() {
    awk '
    BEGIN{ssid=""; bssid=""; sig=""; chan=""; enc=""}
    /Cell [0-9]+ - Address:/{
      if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}
      ssid=""; bssid=$5; sig=""; chan=""; enc=""
    }
    /ESSID:/{
      line=$0; sub(/^.*ESSID: "/,"",line); sub(/"$/,"",line); ssid=line
    }
    /Signal:/{
      for(i=1;i<=NF;i++) if($i=="Signal:"){sig=$(i+1)}
    }
    /Channel:/{
      for(i=1;i<=NF;i++) if($i=="Channel:"){chan=$(i+1)}
    }
    /Encryption:/{
      line=$0; sub(/^.*Encryption: /,"",line); enc=line
    }
    END{if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}}
    '
}

parse_iw_scan() {
    awk '
    BEGIN{ssid=""; bssid=""; sig=""; chan=""; enc=""}
    /^BSS /{
      if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}
      ssid=""; bssid=$2; sub(/\(.*/,"",bssid); sig=""; chan=""; enc="Unknown"
    }
    /^[ \t]*SSID:/{
      line=$0; sub(/^[ \t]*SSID: /,"",line); ssid=line
    }
    /^[ \t]*signal:/{
      sig=$2
    }
    /^[ \t]*DS Parameter set:/{
      chan=$5
    }
    /^[ \t]*primary channel:/{
      chan=$3
    }
    /^[ \t]*RSN:/{
      enc="WPA2/WPA3"
    }
    /^[ \t]*WPA:/{
      if(enc=="Unknown"){enc="WPA/WPA2"}
    }
    END{if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}}
    '
}

# Method 1: iwinfo scan on all detected interfaces.
while read DEV; do
    [ -n "$DEV" ] || continue
    OUT="$(iwinfo "$DEV" scan 2>/dev/null)"
    if echo "$OUT" | grep -q 'ESSID:'; then
        echo "$OUT" | parse_iwinfo_scan >> "$TMP"
    fi
done < "$IFACES"

# Method 2: iw dev <iface> scan fallback.
if [ ! -s "$TMP" ]; then
    while read DEV; do
        [ -n "$DEV" ] || continue
        OUT="$(iw dev "$DEV" scan 2>/dev/null)"
        if echo "$OUT" | grep -q 'SSID:'; then
            echo "$OUT" | parse_iw_scan >> "$TMP"
        fi
    done < "$IFACES"
fi

# Method 3: if scan is blocked because STA is active, temporarily scan known radios with iwinfo.
# No WiFi settings are changed here; this is only another read attempt.
if [ ! -s "$TMP" ]; then
    for DEV in $(cat "$IFACES"); do
        OUT="$(timeout 8 iwinfo "$DEV" scan 2>/dev/null)"
        if echo "$OUT" | grep -q 'ESSID:'; then
            echo "$OUT" | parse_iwinfo_scan >> "$TMP"
        fi
    done
fi

COUNT="$(awk -F'|' 'length($1)>0 {print $1}' "$TMP" | wc -l)"

if [ "$COUNT" -eq 0 ]; then
    cat <<EOF
<div class="note">
<b>No WiFi networks found.</b><br>
The router did not return scan results.<br><br>
Possible reasons:<br>
- WiFi radio is busy as AP/client<br>
- Driver does not allow scan on this interface<br>
- No WiFi networks in range<br><br>
Try:<br>
1. Press <b>Refresh Scan</b><br>
2. Open <b>WiFi Manager</b> and check if WiFi is enabled<br>
3. If needed, use manual SSID entry below
</div>
EOF
    rm -f "$TMP" "$IFACES"
    exit 0
fi

# Deduplicate by SSID+BSSID and show strongest-ish first.
awk -F'|' 'length($1)>0 && !seen[$1 "|" $2]++ {print}' "$TMP" | sort -t'|' -k3,3nr | while IFS='|' read SSID BSSID SIGNAL CHANNEL ENC; do
    [ -z "$SSID" ] && continue
    BAND="Unknown"
    case "$CHANNEL" in
        [1-9]|1[0-4]) BAND="2.4 GHz" ;;
        ''|Unknown) BAND="Unknown" ;;
        *) BAND="5 GHz" ;;
    esac

    RATING="Unknown"
    SIG_NUM="$(echo "$SIGNAL" | sed 's/[^0-9-]//g')"
    if [ -n "$SIG_NUM" ]; then
        if [ "$SIG_NUM" -ge -55 ]; then RATING="Excellent"
        elif [ "$SIG_NUM" -ge -65 ]; then RATING="Good"
        elif [ "$SIG_NUM" -ge -75 ]; then RATING="Fair"
        else RATING="Poor"
        fi
    fi

    E_SSID="$(html_escape "$SSID")"
    E_BSSID="$(html_escape "$BSSID")"
    E_SIGNAL="$(html_escape "$SIGNAL")"
    E_CHANNEL="$(html_escape "$CHANNEL")"
    E_BAND="$(html_escape "$BAND")"
    E_ENC="$(html_escape "$ENC")"
    E_RATING="$(html_escape "$RATING")"

    printf '<div class="network" onclick="selectNetwork(this)" data-ssid="%s" data-bssid="%s" data-band="%s" data-channel="%s" data-signal="%s" data-security="%s">\n' "$E_SSID" "$E_BSSID" "$E_BAND" "$E_CHANNEL" "$E_SIGNAL" "$E_ENC"
    printf '  <div><b>%s</b><div class="muted">%s · Channel %s · %s dBm · %s · BSSID %s</div></div>\n' "$E_SSID" "$E_BAND" "$E_CHANNEL" "$E_SIGNAL" "$E_RATING" "$E_BSSID"
    printf '  <div class="pill">%s</div>\n' "$E_ENC"
    printf '</div>\n'
done

rm -f "$TMP" "$IFACES"
exit 0
