#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

TMP="/tmp/matrix_customer_wifi_scan.$$"
BEST="/tmp/matrix_customer_wifi_best.$$"
IFACES="/tmp/matrix_customer_wifi_ifaces.$$"
: > "$TMP"
: > "$IFACES"

iw dev 2>/dev/null | awk '/Interface /{print $2}' >> "$IFACES"
for I in wlan0 wlan1 wlan0-1 wlan1-1 wlan0-2 wlan1-2 radio0 radio1 phy0 phy1; do
    echo "$I" >> "$IFACES"
done
sort -u "$IFACES" > "$IFACES.sorted"
mv "$IFACES.sorted" "$IFACES"

parse_iwinfo_scan() {
    awk '
    BEGIN{ssid=""; bssid=""; sig=""; chan=""; enc=""}
    /Cell [0-9]+ - Address:/{
      if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}
      ssid=""; bssid=$5; sig=""; chan=""; enc=""
    }
    /ESSID:/{
      line=$0; sub(/^.*ESSID: "/,"",line); sub(/"$/,"",line); ssid=line
    }
    /Signal:/{
      for(i=1;i<=NF;i++) if($i=="Signal:"){sig=$(i+1)}
    }
    /Channel:/{
      for(i=1;i<=NF;i++) if($i=="Channel:"){chan=$(i+1)}
    }
    /Encryption:/{
      line=$0; sub(/^.*Encryption: /,"",line); enc=line
    }
    END{if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}}
    '
}

parse_iw_scan() {
    awk '
    BEGIN{ssid=""; bssid=""; sig=""; chan=""; enc=""}
    /^BSS /{
      if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}
      ssid=""; bssid=$2; sub(/\(.*/,"",bssid); sig=""; chan=""; enc="Unknown"
    }
    /^[ \t]*SSID:/{
      line=$0; sub(/^[ \t]*SSID: /,"",line); ssid=line
    }
    /^[ \t]*signal:/{
      sig=$2
    }
    /^[ \t]*DS Parameter set:/{
      chan=$5
    }
    /^[ \t]*primary channel:/{
      chan=$3
    }
    /^[ \t]*RSN:/{
      enc="WPA2/WPA3"
    }
    /^[ \t]*WPA:/{
      if(enc=="Unknown"){enc="WPA/WPA2"}
    }
    END{if(ssid!=""){print ssid "|" bssid "|" sig "|" chan "|" enc}}
    '
}

while read DEV; do
    [ -n "$DEV" ] || continue
    OUT="$(iwinfo "$DEV" scan 2>/dev/null)"
    if echo "$OUT" | grep -q 'ESSID:'; then
        echo "$OUT" | parse_iwinfo_scan >> "$TMP"
    fi
done < "$IFACES"

if [ ! -s "$TMP" ]; then
    while read DEV; do
        [ -n "$DEV" ] || continue
        OUT="$(iw dev "$DEV" scan 2>/dev/null)"
        if echo "$OUT" | grep -q 'SSID:'; then
            echo "$OUT" | parse_iw_scan >> "$TMP"
        fi
    done < "$IFACES"
fi

if [ ! -s "$TMP" ]; then
    cat <<EOF
<div class="note">
<b>No WiFi networks found.</b><br>
The router did not return scan results.<br><br>
Try <b>Refresh Scan</b> or use the manual SSID fallback.
</div>
EOF
    rm -f "$TMP" "$BEST" "$IFACES"
    exit 0
fi

# Clean, group by SSID, keep strongest AP per SSID.
# Field output: SSID|BEST_BSSID|BEST_SIGNAL_INT|CHANNEL|ENC|COUNT
awk -F'|' '
function sigint(v){ gsub(/ dBm/,"",v); gsub(/\.00/,"",v); gsub(/[^0-9-]/,"",v); if(v=="") return -999; return v+0 }
length($1)>0 {
    ssid=$1
    bssid=$2
    sig=sigint($3)
    chan=$4
    enc=$5
    count[ssid]++
    if(!(ssid in bestsig) || sig>bestsig[ssid]){
        bestsig[ssid]=sig
        bestbssid[ssid]=bssid
        bestchan[ssid]=chan
        bestenc[ssid]=enc
    }
}
END{
    for(ssid in bestsig){
        print ssid "|" bestbssid[ssid] "|" bestsig[ssid] "|" bestchan[ssid] "|" bestenc[ssid] "|" count[ssid]
    }
}' "$TMP" | sort -t'|' -k3,3nr > "$BEST"

TOTAL="$(wc -l < "$BEST" | tr -d ' ')"

cat <<EOF
<div class="note">
<b>$TOTAL unique SSIDs found.</b><br>
Duplicates are grouped. Only the strongest access point per SSID is shown.
</div>
EOF

while IFS='|' read SSID BSSID SIGNAL CHANNEL ENC AP_COUNT; do
    [ -z "$SSID" ] && continue

    # Hide extremely weak networks by default to keep list usable.
    if [ "$SIGNAL" -lt -85 ]; then
        continue
    fi

    BAND="Unknown"
    case "$CHANNEL" in
        [1-9]|1[0-4]) BAND="2.4 GHz" ;;
        ''|Unknown) BAND="Unknown" ;;
        *) BAND="5 GHz" ;;
    esac

    RATING="Unknown"
    if [ "$SIGNAL" -ge -55 ]; then RATING="Excellent"
    elif [ "$SIGNAL" -ge -65 ]; then RATING="Good"
    elif [ "$SIGNAL" -ge -75 ]; then RATING="Fair"
    else RATING="Poor"
    fi

    E_SSID="$(html_escape "$SSID")"
    E_BSSID="$(html_escape "$BSSID")"
    E_SIGNAL="$(html_escape "$SIGNAL")"
    E_CHANNEL="$(html_escape "$CHANNEL")"
    E_BAND="$(html_escape "$BAND")"
    E_ENC="$(html_escape "$ENC")"
    E_RATING="$(html_escape "$RATING")"
    E_COUNT="$(html_escape "$AP_COUNT")"

    printf '<div class="network" onclick="selectNetwork(this)" data-ssid="%s" data-bssid="%s" data-band="%s" data-channel="%s" data-signal="%s" data-security="%s">\n' "$E_SSID" "$E_BSSID" "$E_BAND" "$E_CHANNEL" "$E_SIGNAL" "$E_ENC"
    printf '  <div><b>%s</b><div class="muted">Best AP: %s dBm · %s · Channel %s · %s · %s AP(s)</div><div class="muted">BSSID %s</div></div>\n' "$E_SSID" "$E_SIGNAL" "$E_BAND" "$E_CHANNEL" "$E_RATING" "$E_COUNT" "$E_BSSID"
    printf '  <div class="pill">%s</div>\n' "$E_ENC"
    printf '</div>\n'
done < "$BEST"

rm -f "$TMP" "$BEST" "$IFACES"
exit 0
