#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - MATRIX FULL TEST
# Professional network capacity, connectivity and service check
# =====================================================

echo "Content-Type: text/html"
echo ""

HOSTS="
dapi.jfit.co
orion.jfit.co
mwtn.jfit.co
pt-client.jfit.co
facilitycalendar.jfit.co
frontend-config.jfit.co
config.jhtassets.com
images.jhtassets.com
location-ip.jfit.co
am4.matrixfitness.com
am4-api.jfit.co
console-event-service.jfit.co
console-event-service-prod.jfit.co
console-settings-store.jfit.co
youtube.jfit.co
myfitnesspal.jfit.co
www-weather-console.jfit.co
"

# -----------------------------
# Helpers
# -----------------------------
get_param() {
    echo "$QUERY_STRING" | tr '&' '\n' | grep "^$1=" | head -1 | cut -d'=' -f2-
}

urldecode() {
    echo "$1" | sed 's/+/ /g;s/%20/ /g;s/%2F/\//g;s/%3A/:/g;s/%2D/-/g;s/%5F/_/g;s/%40/@/g;s/%26/\&/g'
}

html_escape() {
    sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'
}

num() {
    case "$1" in
        ''|*[!0-9]*) echo 0 ;;
        *) echo "$1" ;;
    esac
}

fmt_tenths() {
    V="$1"
    [ -z "$V" ] && V=0
    WHOLE=$((V / 10))
    DEC=$((V % 10))
    if [ "$DEC" -eq 0 ]; then
        echo "$WHOLE"
    else
        echo "$WHOLE.$DEC"
    fi
}

status_badge() {
    STATUS="$1"
    case "$STATUS" in
        PASS|HEALTHY|EXCELLENT) echo "<span class='badge good'>$STATUS</span>" ;;
        WARNING|FAIR) echo "<span class='badge warn'>$STATUS</span>" ;;
        FAIL|POOR|ISSUES) echo "<span class='badge bad'>$STATUS</span>" ;;
        *) echo "<span class='badge neutral'>$STATUS</span>" ;;
    esac
}

bar() {
    LABEL="$1"
    VALUE_T="$2"
    REQUIRED_T="$3"
    VALUE_TXT="$(fmt_tenths "$VALUE_T")"
    REQUIRED_TXT="$(fmt_tenths "$REQUIRED_T")"

    [ "$REQUIRED_T" -le 0 ] && REQUIRED_T=1
    PERCENT=$((VALUE_T * 100 / REQUIRED_T))
    [ "$PERCENT" -gt 140 ] && PERCENT=140

    WIDTH="$PERCENT"
    [ "$WIDTH" -gt 100 ] && WIDTH=100

    CLASS="good"
    TEXT="PASS"
    if [ "$PERCENT" -lt 80 ]; then CLASS="bad"; TEXT="FAIL"; fi
    if [ "$PERCENT" -ge 80 ] && [ "$PERCENT" -lt 100 ]; then CLASS="warn"; TEXT="WARNING"; fi

    echo "<div class='metric-row'>"
    echo "  <div><b>$LABEL</b><br><span>$VALUE_TXT Mbps measured / $REQUIRED_TXT Mbps recommended</span></div>"
    echo "  <div>$(status_badge "$TEXT")</div>"
    echo "</div>"
    echo "<div class='bar'><div class='bar-fill $CLASS' style='width:${WIDTH}%;'>${PERCENT}%</div></div>"
}

extract_download_mbps() {
    echo "$1" | grep -i "Average download speed\|Download:" | tail -1 | sed 's/.*Average download speed is //I;s/.*Download:[[:space:]]*//I;s/[[:space:]]*Mbit\/s.*//I;s/[[:space:]]*Mbps.*//I;s/mbps.*//I;s/Mbps.*//I' | awk '{print int($1)}'
}

extract_upload_mbps() {
    echo "$1" | grep -i "Average upload speed\|Upload:" | tail -1 | sed 's/.*Average upload speed is //I;s/.*Upload:[[:space:]]*//I;s/[[:space:]]*Mbit\/s.*//I;s/[[:space:]]*Mbps.*//I;s/mbps.*//I;s/Mbps.*//I' | awk '{print int($1)}'
}

# -----------------------------
# Input values
# -----------------------------
CLUB_RAW="$(get_param club)"
CLUB="$(urldecode "$CLUB_RAW" | html_escape)"
CARDIO=$(num "$(get_param cardio)")
TOUCH=$(num "$(get_param touch)")
EGYM=$(num "$(get_param egym)")
WIFI_USERS=$(num "$(get_param wifi)")
PCS=$(num "$(get_param pcs)")
TVS=$(num "$(get_param tvs)")

# Values in tenths of Mbps so we can use 0.5 Mbps in POSIX shell.
# 5 = 0.5 Mbps, 30 = 3.0 Mbps, etc.
CARDIO_UNIT_T=5
TOUCH_UNIT_T=30
EGYM_UNIT_T=5
WIFI_UNIT_T=20
PCS_UNIT_T=20
TV_UNIT_T=80
RESERVE_T=250
CONCURRENCY=70
MIN_DOWNLOAD_T=250
MIN_UPLOAD_T=100

CARDIO_T=$((CARDIO * CARDIO_UNIT_T))
TOUCH_T=$((TOUCH * TOUCH_UNIT_T))
EGYM_T=$((EGYM * EGYM_UNIT_T))
WIFI_T=$((WIFI_USERS * WIFI_UNIT_T))
PCS_T=$((PCS * PCS_UNIT_T))
TV_T=$((TVS * TV_UNIT_T))
RAW_DOWNLOAD_T=$((CARDIO_T + TOUCH_T + EGYM_T + WIFI_T + PCS_T + TV_T))
CONCURRENT_T=$((RAW_DOWNLOAD_T * CONCURRENCY / 100))
REQUIRED_DOWNLOAD_T=$((CONCURRENT_T + RESERVE_T))
[ "$REQUIRED_DOWNLOAD_T" -lt "$MIN_DOWNLOAD_T" ] && REQUIRED_DOWNLOAD_T="$MIN_DOWNLOAD_T"
REQUIRED_UPLOAD_T=$((REQUIRED_DOWNLOAD_T / 5))
[ "$REQUIRED_UPLOAD_T" -lt "$MIN_UPLOAD_T" ] && REQUIRED_UPLOAD_T="$MIN_UPLOAD_T"

# -----------------------------
# CSS / HTML header
# -----------------------------
print_head() {
cat <<'EOFHTML'
<html>
<head>
<title>Matrix Full Test</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
:root {
    --blue:#0b5cab;
    --blue2:#073b73;
    --bg:#eef2f6;
    --card:#ffffff;
    --text:#1f2937;
    --muted:#6b7280;
    --line:#d8dee8;
    --green:#198754;
    --orange:#fd7e14;
    --red:#dc3545;
}
* { box-sizing:border-box; }
body { font-family:Arial, Helvetica, sans-serif; margin:0; background:var(--bg); color:var(--text); }
.header { background:linear-gradient(135deg,var(--blue2),var(--blue)); color:white; padding:26px 30px; }
.header h1 { margin:0; font-size:30px; }
.header p { margin:8px 0 0 0; opacity:.9; }
.wrap { max-width:1180px; margin:24px auto; padding:0 18px; }
.card { background:var(--card); border-radius:14px; padding:20px; box-shadow:0 4px 14px rgba(20,34,64,.10); margin-bottom:20px; border:1px solid rgba(0,0,0,.04); }
.card h2 { margin:0 0 14px 0; font-size:21px; color:#102a43; }
.card h3 { margin:18px 0 8px 0; font-size:17px; }
.grid { display:grid; grid-template-columns:repeat(6,1fr); gap:14px; }
.grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
@media (max-width:900px) { .grid { grid-template-columns:repeat(2,1fr); } .grid-2 { grid-template-columns:1fr; } }
.stat { background:#f8fafc; border:1px solid var(--line); border-radius:12px; padding:14px; }
.stat .label { color:var(--muted); font-size:13px; }
.stat .value { font-size:30px; font-weight:bold; margin-top:4px; }
label { display:block; font-weight:bold; margin:14px 0 6px; }
input, select { width:100%; max-width:420px; height:42px; font-size:16px; padding:8px 10px; border:1px solid #cbd5e1; border-radius:8px; background:white; }
.form-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px 24px; }
@media (max-width:760px) { .form-grid { grid-template-columns:1fr; } }
button, .btn { display:inline-block; min-width:180px; height:46px; line-height:46px; text-align:center; font-size:15px; font-weight:bold; cursor:pointer; border:0; border-radius:8px; margin:6px 8px 6px 0; background:var(--blue); color:white; text-decoration:none; }
.btn.secondary { background:#475569; }
.btn.orange { background:var(--orange); }
table { border-collapse:collapse; width:100%; background:white; }
th { background:#eaf2fb; color:#0f335c; text-align:left; padding:10px; border-bottom:1px solid var(--line); }
td { border-bottom:1px solid var(--line); padding:10px; vertical-align:top; }
.small { font-size:13px; color:var(--muted); line-height:1.45; }
.badge { display:inline-block; padding:5px 10px; border-radius:999px; font-size:12px; font-weight:bold; color:white; }
.badge.good { background:var(--green); }
.badge.warn { background:var(--orange); }
.badge.bad { background:var(--red); }
.badge.neutral { background:#64748b; }
pre { background:#0f172a; color:#e5e7eb; padding:16px; border-radius:10px; overflow:auto; font-size:13px; }
.metric-row { display:flex; justify-content:space-between; align-items:center; gap:14px; margin-bottom:8px; }
.metric-row span { color:var(--muted); font-size:13px; }
.bar { width:100%; height:30px; background:#dce3ee; border-radius:999px; overflow:hidden; margin-bottom:16px; }
.bar-fill { height:30px; color:white; text-align:center; line-height:30px; font-weight:bold; }
.bar-fill.good { background:var(--green); }
.bar-fill.warn { background:var(--orange); }
.bar-fill.bad { background:var(--red); }
.note { background:#f8fafc; border-left:4px solid var(--blue); padding:12px 14px; border-radius:8px; color:#334155; }
.footer-actions { margin:24px 0; }
.score { font-size:42px; font-weight:bold; margin:6px 0; }
.score.good { color:var(--green); }
.score.warn { color:var(--orange); }
.score.bad { color:var(--red); }
</style>
<script>
function goAdmin(){ window.location = window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_home.sh'; }
function goHome(){ window.location = '/index.html'; }
</script>
</head>
<body>
EOFHTML
}

print_head

# -----------------------------
# Form page
# -----------------------------
if [ -z "$QUERY_STRING" ]; then
cat <<'EOFHTML'
<div class="header">
    <h1>Matrix Full Test</h1>
    <p>Professionele netwerkcheck voor Matrix / EGYM installaties</p>
</div>
<div class="wrap">
    <div class="card">
        <h2>Clubgegevens en belasting</h2>
        <p class="note">Vul de aantallen in. De tool berekent op basis van vaste waardes hoeveel internetcapaciteit minimaal aanbevolen is. Daarna worden verbinding, DNS, Matrix hosts en lokale services getest.</p>
        <form method="get">
            <label>Clubnaam</label>
            <input name="club" placeholder="Bijv. Basic-Fit Rotterdam Alexandrium">

            <div class="form-grid">
                <div><label>Aantal cardio machines / LED consoles</label><input name="cardio" type="number" min="0" value="0"></div>
                <div><label>Aantal Touch consoles</label><input name="touch" type="number" min="0" value="0"></div>
                <div><label>Aantal EGYM toestellen</label><input name="egym" type="number" min="0" value="0"></div>
                <div><label>Gemiddeld aantal klanten op WiFi</label><input name="wifi" type="number" min="0" value="0"></div>
                <div><label>Aantal PC's / kassa / balie systemen</label><input name="pcs" type="number" min="0" value="0"></div>
                <div><label>Aantal TV / IPTV schermen</label><input name="tvs" type="number" min="0" value="0"></div>
            </div>

            <button type="submit">Start Full Test</button>
            <a class="btn secondary" href="/index.html">Terug naar Toolkit</a>
        </form>
    </div>

    <div class="card">
        <h2>Gebruikte rekenwaardes</h2>
        <table>
            <tr><th>Onderdeel</th><th>Waarde</th><th>Toelichting</th></tr>
            <tr><td>Cardio / LED</td><td>0.5 Mbps per machine</td><td>Cloudcommunicatie, status, basisdata</td></tr>
            <tr><td>Touch console</td><td>3 Mbps per console</td><td>Apps, media, updates en interactieve content</td></tr>
            <tr><td>EGYM toestel</td><td>0.5 Mbps per toestel</td><td>Synchronisatie en clouddata</td></tr>
            <tr><td>WiFi gebruiker</td><td>2 Mbps per gebruiker</td><td>Gemiddeld klantgebruik, niet piekstreaming</td></tr>
            <tr><td>PC / POS</td><td>2 Mbps per systeem</td><td>Balie, CRM, kassa, browsergebruik</td></tr>
            <tr><td>TV / IPTV</td><td>8 Mbps per scherm</td><td>HD-streaming of IPTV-achtige belasting</td></tr>
            <tr><td>Gelijktijdigheid</td><td>70%</td><td>Niet alle apparaten gebruiken tegelijk maximale capaciteit</td></tr>
            <tr><td>Reserve</td><td>25 Mbps</td><td>Marge voor updates, pieken en onbekende belasting</td></tr>
            <tr><td>Minimum advies</td><td>25 Mbps down / 10 Mbps up</td><td>Ondergrens voor kleine locaties</td></tr>
        </table>
    </div>
</div>
</body></html>
EOFHTML
exit 0
fi

# -----------------------------
# Result page
# -----------------------------
ERRORS=0
WARNINGS=0

HOSTNAME="$(hostname)"
NOW="$(date)"
REQ_DOWN="$(fmt_tenths "$REQUIRED_DOWNLOAD_T")"
REQ_UP="$(fmt_tenths "$REQUIRED_UPLOAD_T")"
RAW_DOWN="$(fmt_tenths "$RAW_DOWNLOAD_T")"
CONCURRENT_DOWN="$(fmt_tenths "$CONCURRENT_T")"
RESERVE="$(fmt_tenths "$RESERVE_T")"

cat <<EOFHTML
<div class="header">
    <h1>Matrix Full Test</h1>
    <p>Club: <b>${CLUB:-Onbekend}</b> &nbsp; | &nbsp; Router: <b>$HOSTNAME</b> &nbsp; | &nbsp; $NOW</p>
</div>
<div class="wrap">

<div class="grid">
    <div class="stat"><div class="label">Cardio / LED</div><div class="value">$CARDIO</div></div>
    <div class="stat"><div class="label">Touch</div><div class="value">$TOUCH</div></div>
    <div class="stat"><div class="label">EGYM</div><div class="value">$EGYM</div></div>
    <div class="stat"><div class="label">WiFi klanten</div><div class="value">$WIFI_USERS</div></div>
    <div class="stat"><div class="label">PC / POS</div><div class="value">$PCS</div></div>
    <div class="stat"><div class="label">TV / IPTV</div><div class="value">$TVS</div></div>
</div>

<div class="card">
    <h2>1. Benodigde internetcapaciteit</h2>
    <div class="grid-2">
        <div>
            <table>
                <tr><th>Onderdeel</th><th>Berekening</th><th>Download</th></tr>
                <tr><td>Cardio / LED</td><td>$CARDIO x 0.5 Mbps</td><td>$(fmt_tenths "$CARDIO_T") Mbps</td></tr>
                <tr><td>Touch consoles</td><td>$TOUCH x 3 Mbps</td><td>$(fmt_tenths "$TOUCH_T") Mbps</td></tr>
                <tr><td>EGYM toestellen</td><td>$EGYM x 0.5 Mbps</td><td>$(fmt_tenths "$EGYM_T") Mbps</td></tr>
                <tr><td>Klanten WiFi</td><td>$WIFI_USERS x 2 Mbps</td><td>$(fmt_tenths "$WIFI_T") Mbps</td></tr>
                <tr><td>PC / POS</td><td>$PCS x 2 Mbps</td><td>$(fmt_tenths "$PCS_T") Mbps</td></tr>
                <tr><td>TV / IPTV</td><td>$TVS x 8 Mbps</td><td>$(fmt_tenths "$TV_T") Mbps</td></tr>
            </table>
        </div>
        <div>
            <div class="note">
                <b>Formule:</b><br>
                Ruwe belasting: <b>$RAW_DOWN Mbps</b><br>
                Gelijktijdigheid: <b>$CONCURRENCY%</b> = $CONCURRENT_DOWN Mbps<br>
                Reserve: <b>$RESERVE Mbps</b><br><br>
                <b>Aanbevolen minimum:</b><br>
                Download: <b>$REQ_DOWN Mbps</b><br>
                Upload: <b>$REQ_UP Mbps</b>
                <p class="small">Upload wordt berekend als 20% van de aanbevolen download, met een minimum van 10 Mbps.</p>
            </div>
        </div>
    </div>
</div>
EOFHTML

# -----------------------------
# Connection and speedtest
# -----------------------------
ROUTE="$(ip route | grep '^default' | head -1)"
CONNECTION_TYPE="Unknown"
if echo "$ROUTE" | grep -q "eth1\|wan"; then
    CONNECTION_TYPE="WAN / Ethernet"
elif echo "$ROUTE" | grep -q "wlan"; then
    CONNECTION_TYPE="Customer WiFi"
elif echo "$ROUTE" | grep -q "qmimux\|wwan\|mob"; then
    CONNECTION_TYPE="LTE / 5G"
fi

echo "<div class='card'><h2>2. Actieve verbinding en speedtest</h2><pre>"
echo "Active route:"
echo "$ROUTE"
echo ""
echo "Connection Type: $CONNECTION_TYPE"
echo ""

if ping -c 3 -W 3 8.8.8.8 >/dev/null 2>&1; then
    echo "Internet Ping: PASS"
else
    echo "Internet Ping: FAIL"
    ERRORS=$((ERRORS+1))
fi

if nslookup google.com >/dev/null 2>&1; then
    echo "DNS: PASS"
else
    echo "DNS: FAIL"
    ERRORS=$((ERRORS+1))
fi

PUBLIC_IP="$(wget -q -O - https://api.ipify.org 2>/dev/null)"
echo "Public IP: ${PUBLIC_IP:-Not found}"
echo ""
echo "Speedtest:"

SPEED_OUTPUT=""
if [ "$CONNECTION_TYPE" = "WAN / Ethernet" ] || [ "$CONNECTION_TYPE" = "Customer WiFi" ]; then
    if command -v speedtest >/dev/null 2>&1; then
        echo "Running speedtest via $CONNECTION_TYPE..."
        echo ""
        SPEED_OUTPUT="$(echo y | speedtest 2>/dev/null)"
        echo "$SPEED_OUTPUT"
    else
        echo "Speedtest not installed."
        WARNINGS=$((WARNINGS+1))
    fi
elif [ "$CONNECTION_TYPE" = "LTE / 5G" ]; then
    echo "Skipped because active connection is LTE / 5G."
    echo "This prevents unnecessary mobile data usage."
    WARNINGS=$((WARNINGS+1))
else
    echo "Skipped because connection type is unknown."
    WARNINGS=$((WARNINGS+1))
fi

echo "</pre></div>"

DOWNLOAD="$(extract_download_mbps "$SPEED_OUTPUT")"
UPLOAD="$(extract_upload_mbps "$SPEED_OUTPUT")"
DOWNLOAD="$(num "$DOWNLOAD")"
UPLOAD="$(num "$UPLOAD")"
DOWNLOAD_T=$((DOWNLOAD * 10))
UPLOAD_T=$((UPLOAD * 10))

# -----------------------------
# Graphical capacity assessment
# -----------------------------
echo "<div class='card'><h2>3. Grafische beoordeling capaciteit</h2>"
if [ "$DOWNLOAD" -gt 0 ]; then
    bar "Download capaciteit" "$DOWNLOAD_T" "$REQUIRED_DOWNLOAD_T"
else
    echo "<p>$(status_badge WARNING) Download score niet berekend omdat speedtest is overgeslagen.</p>"
fi
if [ "$UPLOAD" -gt 0 ]; then
    bar "Upload capaciteit" "$UPLOAD_T" "$REQUIRED_UPLOAD_T"
else
    echo "<p>$(status_badge WARNING) Upload score niet berekend omdat speedtest is overgeslagen.</p>"
fi
echo "</div>"

# -----------------------------
# Local Matrix services
# -----------------------------
echo "<div class='card'><h2>4. Matrix Toolkit services</h2>"
echo "<table><tr><th>Service</th><th>Status</th><th>Details</th></tr>"
if wget -q -O - http://127.0.0.1:8080/index.html >/dev/null 2>&1; then
    echo "<tr><td>Matrix Toolkit</td><td>$(status_badge PASS)</td><td>Poort 8080 actief</td></tr>"
else
    echo "<tr><td>Matrix Toolkit</td><td>$(status_badge FAIL)</td><td>Poort 8080 niet bereikbaar</td></tr>"
    ERRORS=$((ERRORS+1))
fi
if wget -q -O - http://127.0.0.1:8081/cgi-bin/admin_login.sh >/dev/null 2>&1; then
    echo "<tr><td>Matrix Admin</td><td>$(status_badge PASS)</td><td>Poort 8081 login actief</td></tr>"
else
    echo "<tr><td>Matrix Admin</td><td>$(status_badge FAIL)</td><td>Poort 8081 login niet bereikbaar</td></tr>"
    ERRORS=$((ERRORS+1))
fi
echo "</table></div>"

# -----------------------------
# DNS host tests
# -----------------------------
echo "<div class='card'><h2>5. Matrix host DNS test</h2>"
echo "<table><tr><th>Host</th><th>Status</th></tr>"
for HOST in $HOSTS; do
    if nslookup "$HOST" >/dev/null 2>&1; then
        echo "<tr><td>$HOST</td><td>$(status_badge PASS)</td></tr>"
    else
        echo "<tr><td>$HOST</td><td>$(status_badge FAIL)</td></tr>"
        ERRORS=$((ERRORS+1))
    fi
done
echo "</table></div>"

# -----------------------------
# LTE info
# -----------------------------
echo "<div class='card'><h2>6. LTE / mobiele verbinding</h2><pre>"
if command -v gsmctl >/dev/null 2>&1; then
    echo "Signal:"
    gsmctl -q 2>/dev/null
    echo ""
    echo "Registration:"
    gsmctl -r 2>/dev/null
    echo ""
    echo "Operator:"
    gsmctl -o 2>/dev/null
else
    echo "gsmctl not available."
    WARNINGS=$((WARNINGS+1))
fi
echo "</pre></div>"

# -----------------------------
# Result score
# -----------------------------
if [ "$DOWNLOAD_T" -gt 0 ] && [ "$DOWNLOAD_T" -ge "$REQUIRED_DOWNLOAD_T" ]; then
    SCORE=100
elif [ "$DOWNLOAD_T" -gt 0 ]; then
    SCORE=$((DOWNLOAD_T * 100 / REQUIRED_DOWNLOAD_T))
else
    SCORE=0
fi

SCORE_CLASS="bad"
SCORE_TEXT="ISSUES FOUND"
if [ "$SCORE" -ge 80 ]; then SCORE_CLASS="good"; SCORE_TEXT="HEALTHY"; fi
if [ "$SCORE" -ge 50 ] && [ "$SCORE" -lt 80 ]; then SCORE_CLASS="warn"; SCORE_TEXT="WORKING WITH WARNINGS"; fi

echo "<div class='card'><h2>7. Resultaat en advies</h2>"
echo "<div class='score $SCORE_CLASS'>$SCORE%</div>"
echo "<p>$(status_badge "$SCORE_TEXT")</p>"
echo "<p><b>Errors:</b> $ERRORS<br><b>Warnings:</b> $WARNINGS</p>"
echo "<div class='note'><b>Advies:</b><br>"
if [ "$CONNECTION_TYPE" = "LTE / 5G" ]; then
    echo "Speedtest is niet uitgevoerd omdat de actieve verbinding LTE / 5G is. Dit voorkomt onnodig dataverbruik.<br>"
elif [ "$DOWNLOAD_T" -gt 0 ] && [ "$DOWNLOAD_T" -lt "$REQUIRED_DOWNLOAD_T" ]; then
    echo "De gemeten downloadsnelheid lijkt onvoldoende voor deze clubbezetting. Adviseer klantnetwerk of internetabonnement te controleren.<br>"
elif [ "$DOWNLOAD_T" -gt 0 ]; then
    echo "De gemeten downloadsnelheid lijkt voldoende voor deze clubbezetting.<br>"
else
    echo "Geen downloadadvies omdat speedtest niet is uitgevoerd.<br>"
fi
if [ "$UPLOAD_T" -gt 0 ] && [ "$UPLOAD_T" -lt "$REQUIRED_UPLOAD_T" ]; then
    echo "De gemeten uploadsnelheid lijkt onvoldoende. Dit kan invloed hebben op cloudsync en supportdiagnose.<br>"
elif [ "$UPLOAD_T" -gt 0 ]; then
    echo "De gemeten uploadsnelheid lijkt voldoende.<br>"
else
    echo "Geen uploadadvies omdat speedtest niet is uitgevoerd.<br>"
fi
echo "</div></div>"

cat <<'EOFHTML'
<div class="footer-actions">
    <button onclick="goHome()">Return to Home</button>
    <button onclick="goAdmin()">Return to Admin</button>
    <a class="btn orange" href="/cgi-bin/matrix_full_test.sh">Nieuwe Test</a>
</div>
</div>
</body>
</html>
EOFHTML
