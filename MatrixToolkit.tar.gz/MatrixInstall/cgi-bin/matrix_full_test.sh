#!/bin/sh

echo "Content-Type: text/html"
echo ""

HOSTS="
dapi.jfit.co
orion.jfit.co
mwtn.jfit.co
pt-client.jfit.co
facilitycalendar.jfit.co
frontend-config.jfit.co
config.jhtassets.com
images.jhtassets.com
location-ip.jfit.co
am4.matrixfitness.com
am4-api.jfit.co
console-event-service.jfit.co
console-event-service-prod.jfit.co
console-settings-store.jfit.co
youtube.jfit.co
myfitnesspal.jfit.co
www-weather-console.jfit.co
"

get_param() {
    echo "$QUERY_STRING" | tr '&' '\n' | grep "^$1=" | head -1 | cut -d'=' -f2-
}

urldecode() {
    echo "$1" | sed 's/+/ /g;s/%20/ /g;s/%2F/\//g;s/%3A/:/g'
}

num() {
    case "$1" in
        ''|*[!0-9]*) echo 0 ;;
        *) echo "$1" ;;
    esac
}

CLUB=$(urldecode "$(get_param club)")
CARDIO=$(num "$(get_param cardio)")
TOUCH=$(num "$(get_param touch)")
EGYM=$(num "$(get_param egym)")
WIFI_USERS=$(num "$(get_param wifi)")
PCS=$(num "$(get_param pcs)")
TVS=$(num "$(get_param tvs)")

if [ -z "$QUERY_STRING" ]; then
cat << EOF
<html>
<head>
<title>Matrix Full Test</title>
<style>
body { font-family:Arial; margin:20px; background:#f5f5f5; }
.card { background:white; padding:20px; border-radius:8px; max-width:760px; box-shadow:0 1px 4px rgba(0,0,0,0.12); }
label { display:block; font-weight:bold; margin-top:12px; }
input { width:320px; height:36px; font-size:16px; padding:5px; }
button { margin-top:20px; width:260px; height:55px; font-size:18px; font-weight:bold; background:#007bff; color:white; border:0; border-radius:6px; }
</style>
</head>
<body>
<div class="card">
<h1>Matrix Full Test</h1>
<p>Vul de clubgegevens in. De tool berekent daarna of de beschikbare internetverbinding voldoende lijkt.</p>

<form method="get">
<label>Clubnaam</label>
<input name="club" placeholder="Bijv. Basic-Fit Rotterdam">

<label>Aantal cardio machines</label>
<input name="cardio" type="number" value="0">

<label>Aantal Touch consoles</label>
<input name="touch" type="number" value="0">

<label>Aantal EGYM toestellen</label>
<input name="egym" type="number" value="0">

<label>Gemiddeld aantal klanten op WiFi</label>
<input name="wifi" type="number" value="0">

<label>Aantal PC's / kassa / balie systemen</label>
<input name="pcs" type="number" value="0">

<label>Aantal TV / IPTV schermen</label>
<input name="tvs" type="number" value="0">

<br>
<button type="submit">Start Full Test</button>
</form>
</div>
</body>
</html>
EOF
exit 0
fi

CARDIO_MB=$((CARDIO * 1))
TOUCH_MB=$((TOUCH * 1))
EGYM_MB=$((EGYM * 1))
WIFI_MB=$((WIFI_USERS * 3))
PCS_MB=$((PCS * 3))
TV_MB=$((TVS * 5))

REQUIRED_DOWNLOAD=$((CARDIO_MB + TOUCH_MB + EGYM_MB + WIFI_MB + PCS_MB + TV_MB + 20))
REQUIRED_UPLOAD=$(((CARDIO + TOUCH + EGYM) / 2 + WIFI_USERS / 2 + PCS + 10))

[ "$REQUIRED_DOWNLOAD" -lt 25 ] && REQUIRED_DOWNLOAD=25
[ "$REQUIRED_UPLOAD" -lt 10 ] && REQUIRED_UPLOAD=10

ERRORS=0
WARNINGS=0

ok() { echo "<span class='pass'>PASS</span>"; }
fail() { echo "<span class='fail'>FAIL</span>"; }
warn() { echo "<span class='warn'>WARNING</span>"; }

bar() {
    LABEL="$1"
    VALUE="$2"
    MAX="$3"

    [ "$MAX" -le 0 ] && MAX=1
    PERCENT=$((VALUE * 100 / MAX))
    [ "$PERCENT" -gt 100 ] && PERCENT=100

    CLASS="green"
    if [ "$PERCENT" -lt 50 ]; then CLASS="red"; fi
    if [ "$PERCENT" -ge 50 ] && [ "$PERCENT" -lt 80 ]; then CLASS="orange"; fi

    echo "<div class='bar-label'><b>$LABEL</b> - $VALUE / $MAX Mbps</div>"
    echo "<div class='bar'><div class='bar-fill $CLASS' style='width:${PERCENT}%;'>${PERCENT}%</div></div>"
}

cat << EOF
<html>
<head>
<title>Matrix Full Test</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body { font-family:Arial; margin:20px; background:#f5f5f5; color:#333; }
h1 { margin-bottom:5px; }
h2 { margin-top:25px; }
.grid { display:flex; flex-wrap:wrap; gap:20px; }
.card { background:white; border-radius:8px; padding:16px; box-shadow:0 1px 4px rgba(0,0,0,0.12); margin-bottom:20px; }
.card.small { width:245px; }
.card.large { width:100%; max-width:1100px; }
table { border-collapse:collapse; background:white; width:100%; }
th { background:#007bff; color:white; padding:8px; text-align:left; }
td { border:1px solid #ddd; padding:6px; }
.pass { color:green; font-weight:bold; }
.fail { color:red; font-weight:bold; }
.warn { color:orange; font-weight:bold; }
pre { background:#111; color:#eee; padding:15px; border-radius:6px; overflow:auto; }
.bar { width:100%; background:#ddd; border-radius:20px; overflow:hidden; margin-bottom:12px; height:28px; }
.bar-fill { height:28px; color:white; text-align:center; line-height:28px; font-weight:bold; }
.green { background:#28a745; }
.orange { background:#fd7e14; }
.red { background:#dc3545; }
.score { font-size:34px; font-weight:bold; }
button { width:220px; height:50px; font-size:16px; font-weight:bold; cursor:pointer; border:0; border-radius:6px; margin-right:10px; background:#007bff; color:white; }
</style>
</head>
<body>

<h1>Matrix Full Test</h1>
<p><b>Club:</b> $CLUB<br>
<b>Datum:</b> $(date)<br>
<b>Router:</b> $(hostname)</p>
EOF

echo "<div class='grid'>"
echo "<div class='card small'><b>Cardio</b><div class='score'>$CARDIO</div></div>"
echo "<div class='card small'><b>Touch</b><div class='score'>$TOUCH</div></div>"
echo "<div class='card small'><b>EGYM</b><div class='score'>$EGYM</div></div>"
echo "<div class='card small'><b>WiFi klanten</b><div class='score'>$WIFI_USERS</div></div>"
echo "<div class='card small'><b>PC / POS</b><div class='score'>$PCS</div></div>"
echo "<div class='card small'><b>TV / IPTV</b><div class='score'>$TVS</div></div>"
echo "</div>"

echo "<div class='card large'>"
echo "<h2>1. Benodigde internetcapaciteit</h2>"
echo "<table>"
echo "<tr><th>Onderdeel</th><th>Berekening</th><th>Download Mbps</th></tr>"
echo "<tr><td>Cardio machines</td><td>$CARDIO x 1 Mbps</td><td>$CARDIO_MB</td></tr>"
echo "<tr><td>Touch consoles</td><td>$TOUCH x 1 Mbps</td><td>$TOUCH_MB</td></tr>"
echo "<tr><td>EGYM toestellen</td><td>$EGYM x 1 Mbps</td><td>$EGYM_MB</td></tr>"
echo "<tr><td>Klanten WiFi</td><td>$WIFI_USERS x 3 Mbps</td><td>$WIFI_MB</td></tr>"
echo "<tr><td>PC / POS</td><td>$PCS x 3 Mbps</td><td>$PCS_MB</td></tr>"
echo "<tr><td>TV / IPTV</td><td>$TVS x 5 Mbps</td><td>$TV_MB</td></tr>"
echo "<tr><td>Reserve / marge</td><td>Standaard marge</td><td>20</td></tr>"
echo "<tr><th colspan='2'>Aanbevolen minimaal</th><th>$REQUIRED_DOWNLOAD Mbps download / $REQUIRED_UPLOAD Mbps upload</th></tr>"
echo "</table>"
echo "</div>"

echo "<div class='card large'>"
echo "<h2>2. Actieve verbinding & speedtest</h2>"
echo "<pre>"

ROUTE=$(ip route | grep "^default" | head -1)
echo "Active route:"
echo "$ROUTE"
echo ""

CONNECTION_TYPE="Unknown"

if echo "$ROUTE" | grep -q "eth1"; then
    CONNECTION_TYPE="WAN / Ethernet"
elif echo "$ROUTE" | grep -q "wlan"; then
    CONNECTION_TYPE="Customer WiFi"
elif echo "$ROUTE" | grep -q "qmimux\|wwan\|mob"; then
    CONNECTION_TYPE="LTE / 5G"
fi

echo "Connection Type: $CONNECTION_TYPE"
echo ""

if ping -c 3 -W 3 8.8.8.8 >/dev/null 2>&1; then
    echo "Internet Ping: PASS"
else
    echo "Internet Ping: FAIL"
    ERRORS=$((ERRORS+1))
fi

if nslookup google.com >/dev/null 2>&1; then
    echo "DNS: PASS"
else
    echo "DNS: FAIL"
    ERRORS=$((ERRORS+1))
fi

PUBLIC_IP=$(wget -q -O - https://api.ipify.org 2>/dev/null)
echo "Public IP: ${PUBLIC_IP:-Not found}"

echo ""
echo "Speedtest:"
SPEED_OUTPUT=""

if [ "$CONNECTION_TYPE" = "WAN / Ethernet" ] || [ "$CONNECTION_TYPE" = "Customer WiFi" ]; then
    if command -v speedtest >/dev/null 2>&1; then
        echo "Running speedtest via $CONNECTION_TYPE..."
        echo ""
        SPEED_OUTPUT=$(echo y | speedtest 2>/dev/null)
        echo "$SPEED_OUTPUT"
    else
        echo "Speedtest not installed."
        WARNINGS=$((WARNINGS+1))
    fi
elif [ "$CONNECTION_TYPE" = "LTE / 5G" ]; then
    echo "Skipped because active connection is LTE / 5G."
    echo "This prevents unnecessary mobile data usage."
    WARNINGS=$((WARNINGS+1))
else
    echo "Skipped because connection type is unknown."
    WARNINGS=$((WARNINGS+1))
fi

echo "</pre>"
echo "</div>"

DOWNLOAD=$(echo "$SPEED_OUTPUT" | grep -i "Average download speed" | tail -1 | sed 's/.*Average download speed is //;s/mbps.*//' | cut -d'.' -f1)
UPLOAD=$(echo "$SPEED_OUTPUT" | grep -i "Average upload speed" | tail -1 | sed 's/.*Average upload speed is //;s/mbps.*//' | cut -d'.' -f1)
DOWNLOAD=$(num "$DOWNLOAD")
UPLOAD=$(num "$UPLOAD")

echo "<div class='card large'>"
echo "<h2>3. Grafische beoordeling</h2>"

if [ "$DOWNLOAD" -gt 0 ]; then
    bar "Download capaciteit" "$DOWNLOAD" "$REQUIRED_DOWNLOAD"
else
    echo "<p class='warn'><b>Download score niet berekend</b> omdat speedtest is overgeslagen.</p>"
fi

if [ "$UPLOAD" -gt 0 ]; then
    bar "Upload capaciteit" "$UPLOAD" "$REQUIRED_UPLOAD"
else
    echo "<p class='warn'><b>Upload score niet berekend</b> omdat speedtest is overgeslagen.</p>"
fi

echo "</div>"

echo "<div class='card large'>"
echo "<h2>4. Matrix Toolkit Services</h2>"
echo "<table><tr><th>Service</th><th>Status</th><th>Details</th></tr>"

if wget -q -O - http://127.0.0.1:8080 >/dev/null 2>&1; then
    echo "<tr><td>Matrix Toolkit</td><td>$(ok)</td><td>Poort 8080 actief</td></tr>"
else
    echo "<tr><td>Matrix Toolkit</td><td>$(fail)</td><td>Poort 8080 niet bereikbaar</td></tr>"
    ERRORS=$((ERRORS+1))
fi

if wget -q -O - http://127.0.0.1:8081 >/dev/null 2>&1; then
    echo "<tr><td>Matrix Admin</td><td>$(ok)</td><td>Poort 8081 actief</td></tr>"
else
    echo "<tr><td>Matrix Admin</td><td>$(fail)</td><td>Poort 8081 niet bereikbaar</td></tr>"
    ERRORS=$((ERRORS+1))
fi

echo "</table></div>"

echo "<div class='card large'>"
echo "<h2>5. Matrix Host DNS Test</h2>"
echo "<div class='grid'>"
echo "<table><tr><th>Host</th><th>Status</th></tr>"

COUNT=0
for HOST in $HOSTS
do
    if nslookup "$HOST" >/dev/null 2>&1; then
        STATUS="$(ok)"
    else
        STATUS="$(fail)"
        ERRORS=$((ERRORS+1))
    fi

    echo "<tr><td>$HOST</td><td>$STATUS</td></tr>"
    COUNT=$((COUNT+1))

    if [ "$COUNT" -eq 10 ]; then
        echo "</table><table><tr><th>Host</th><th>Status</th></tr>"
    fi
done

echo "</table></div></div>"

echo "<div class='card large'>"
echo "<h2>6. LTE / Mobile Info</h2>"
echo "<pre>"
if command -v gsmctl >/dev/null 2>&1; then
    echo "Signal:"
    gsmctl -q 2>/dev/null
    echo ""
    echo "Registration:"
    gsmctl -r 2>/dev/null
    echo ""
    echo "Operator:"
    gsmctl -o 2>/dev/null
else
    echo "gsmctl not available."
    WARNINGS=$((WARNINGS+1))
fi
echo "</pre></div>"

echo "<div class='card large'>"
echo "<h2>7. Resultaat & advies</h2>"

if [ "$DOWNLOAD" -gt 0 ] && [ "$DOWNLOAD" -ge "$REQUIRED_DOWNLOAD" ]; then
    SCORE=100
elif [ "$DOWNLOAD" -gt 0 ]; then
    SCORE=$((DOWNLOAD * 100 / REQUIRED_DOWNLOAD))
else
    SCORE=0
fi

if [ "$SCORE" -ge 80 ]; then
    echo "<p class='pass score'>NETWORK HEALTH SCORE: $SCORE%</p>"
elif [ "$SCORE" -ge 50 ]; then
    echo "<p class='warn score'>NETWORK HEALTH SCORE: $SCORE%</p>"
else
    echo "<p class='fail score'>NETWORK HEALTH SCORE: $SCORE%</p>"
fi

if [ "$ERRORS" -eq 0 ] && [ "$WARNINGS" -eq 0 ]; then
    echo "<p class='pass'><b>OVERALL STATUS: HEALTHY</b></p>"
elif [ "$ERRORS" -eq 0 ]; then
    echo "<p class='warn'><b>OVERALL STATUS: WORKING WITH WARNINGS</b></p>"
else
    echo "<p class='fail'><b>OVERALL STATUS: ISSUES FOUND</b></p>"
fi

echo "<p><b>Errors:</b> $ERRORS<br><b>Warnings:</b> $WARNINGS</p>"

echo "<p><b>Advies:</b><br>"
if [ "$CONNECTION_TYPE" = "LTE / 5G" ]; then
    echo "Speedtest is niet uitgevoerd omdat de actieve verbinding LTE / 5G is. Dit voorkomt onnodig dataverbruik.<br>"
elif [ "$DOWNLOAD" -gt 0 ] && [ "$DOWNLOAD" -lt "$REQUIRED_DOWNLOAD" ]; then
    echo "Internet download lijkt onvoldoende voor deze clubbezetting.<br>"
elif [ "$DOWNLOAD" -gt 0 ]; then
    echo "Internet download lijkt voldoende voor deze clubbezetting.<br>"
else
    echo "Geen downloadadvies omdat speedtest niet is uitgevoerd.<br>"
fi

if [ "$UPLOAD" -gt 0 ] && [ "$UPLOAD" -lt "$REQUIRED_UPLOAD" ]; then
    echo "Internet upload lijkt onvoldoende voor deze clubbezetting.<br>"
elif [ "$UPLOAD" -gt 0 ]; then
    echo "Internet upload lijkt voldoende voor deze clubbezetting.<br>"
else
    echo "Geen uploadadvies omdat speedtest niet is uitgevoerd.<br>"
fi
echo "</p></div>"

cat << EOF
<br>
<button onclick="window.location='/'">Return to Home</button>
<button onclick="window.location='/admin/'">Return to Admin</button>
<button onclick="window.location='/cgi-bin/matrix_full_test.sh'">Nieuwe Test</button>

</body>
</html>
EOF