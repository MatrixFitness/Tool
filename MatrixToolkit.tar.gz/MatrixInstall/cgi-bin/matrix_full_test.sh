#!/bin/sh

echo "Content-Type: text/html"
echo ""

HOSTS="
dapi.jfit.co
orion.jfit.co
mwtn.jfit.co
pt-client.jfit.co
facilitycalendar.jfit.co
frontend-config.jfit.co
config.jhtassets.com
images.jhtassets.com
location-ip.jfit.co
am4.matrixfitness.com
am4-api.jfit.co
console-event-service.jfit.co
console-event-service-prod.jfit.co
console-event-service-staging.jfit.co
console-settings-store.jfit.co
dev-console-settings-store.jfit.co
dev-orion.jfit.co
qa-orion.jfit.co
staging-orion.jfit.co
staging-mwtn.jfit.co
staging-pt-client.jfit.co
staging-facilitycalendar.jfit.co
staging-weather-console.jfit.co
youtube.jfit.co
myfitnesspal.jfit.co
www-myfitnesspal-console.jfit.co
www-weather-console.jfit.co
"

echo "<html>"
echo "<head>"
echo "<title>Matrix Full Test</title>"
echo "<style>"
echo "body { font-family: Arial; margin:20px; background:#f5f5f5; }"
echo "h1 { color:#333; }"
echo ".container { display:flex; gap:20px; }"
echo "table { border-collapse:collapse; background:white; width:500px; }"
echo "th { background:#007bff; color:white; padding:8px; }"
echo "td { border:1px solid #ddd; padding:6px; }"
echo ".pass { color:green; font-weight:bold; }"
echo ".fail { color:red; font-weight:bold; }"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h1>Matrix Full Connectiviteit Test</h1>"

echo "<div class='container'>"

echo "<table>"
echo "<tr><th>Host</th><th>Status</th></tr>"

COUNT=0

for HOST in $HOSTS
do

    if nslookup "$HOST" >/dev/null 2>&1
    then
        STATUS="<span class='pass'>PASS</span>"
    else
        STATUS="<span class='fail'>FAIL</span>"
    fi

    echo "<tr><td>$HOST</td><td>$STATUS</td></tr>"

    COUNT=$((COUNT+1))

    if [ "$COUNT" -eq 14 ]
    then
        echo "</table>"
        echo "<table>"
        echo "<tr><th>Host</th><th>Status</th></tr>"
    fi

done

echo "</table>"
echo "</div>"

echo "<hr>"
echo "<p><b>Matrix Full Test voltooid.</b></p>"

echo "</body>"
echo "</html>"