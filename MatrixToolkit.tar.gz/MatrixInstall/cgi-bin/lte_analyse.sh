#!/bin/sh
/usr/local/matrix/web/cgi-bin/lte_analysis.sh
