#!/bin/sh
# Matrix Toolkit v60 - WiFi Manager Field Editor Fix
# No textarea editor. Each profile has its own normal input fields.

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
OLD_CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    # BusyBox-safe decoder for normal form fields.
    # Handles the characters we need for profile name, SSID and password.
    sed \
        -e 's/+/ /g' \
        -e 's/%0[Dd]//g' \
        -e 's/%0[Aa]/\
/g' \
        -e 's/%3[Dd]/=/g' \
        -e 's/%7[Bb]/{/g' \
        -e 's/%7[Dd]/}/g' \
        -e 's/%20/ /g' \
        -e 's/%21/!/g' \
        -e 's/%22/"/g' \
        -e 's/%23/#/g' \
        -e 's/%24/$/g' \
        -e 's/%25/%/g' \
        -e 's/%26/\&/g' \
        -e "s/%27/'/g" \
        -e 's/%28/(/g' \
        -e 's/%29/)/g' \
        -e 's/%2[Aa]/*/g' \
        -e 's/%2[Bb]/+/g' \
        -e 's/%2[Cc]/,/g' \
        -e 's/%2[Dd]/-/g' \
        -e 's/%2[Ee]/./g' \
        -e 's/%2[Ff]/\//g' \
        -e 's/%3[Aa]/:/g' \
        -e 's/%3[Bb]/;/g' \
        -e 's/%3[Cc]/</g' \
        -e 's/%3[Ee]/>/g' \
        -e 's/%3[Ff]/?/g' \
        -e 's/%40/@/g' \
        -e 's/%5[Bb]/[/g' \
        -e 's/%5[Cc]/\\/g' \
        -e 's/%5[Dd]/]/g' \
        -e 's/%5[Ee]/^/g' \
        -e 's/%5[Ff]/_/g' \
        -e 's/%60/`/g' \
        -e 's/%7[Cc]/|/g' \
        -e 's/%7[Ee]/~/g'
}

get_field() {
    FIELD="$1"
    printf '%s' "$POST_DATA" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode
}

read_post() {
    LEN="${CONTENT_LENGTH:-0}"
    [ "$LEN" -gt 0 ] 2>/dev/null || return 1
    POST_DATA="$(dd bs=1 count="$LEN" 2>/dev/null)"
    return 0
}

write_builtin_defaults() {
    cat > "$1" <<'EOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
EOF
}

ensure_config() {
    mkdir -p /usr/local/matrix

    if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then
        cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null
    fi

    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then
            cp -f "$DEFAULTS" "$CONFIG" 2>/dev/null
        else
            write_builtin_defaults "$CONFIG"
        fi
    fi

    if [ ! -f "$DEFAULTS" ]; then
        cp -f "$CONFIG" "$DEFAULTS" 2>/dev/null || write_builtin_defaults "$DEFAULTS"
    fi

    if [ ! -f "$PREVIOUS" ]; then
        cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    fi

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_count() {
    awk -F= '
        /^PROFILE[0-9]+_NAME=/ {
            n=$1
            gsub(/^PROFILE/,"",n)
            gsub(/_NAME$/,"",n)
            if (n>max) max=n
        }
        /^PROFILE[0-9]+_SSID=/ {
            n=$1
            gsub(/^PROFILE/,"",n)
            gsub(/_SSID$/,"",n)
            if (n>max) max=n
        }
        /^PROFILE[0-9]+_PASSWORD=/ {
            n=$1
            gsub(/^PROFILE/,"",n)
            gsub(/_PASSWORD$/,"",n)
            if (n>max) max=n
        }
        END { if (max=="") max=0; print max }
    ' "$CONFIG"
}

get_profile_value() {
    IDX="$1"
    KEY="$2"
    grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" | head -n1 | cut -d= -f2-
}

rebuild_config_update_profile() {
    IDX="$1"
    NEW_NAME="$2"
    NEW_SSID="$3"
    NEW_PASS="$4"

    TMP="/tmp/matrix_wifi_profiles_update.$$"
    COUNT="$(profile_count)"
    [ "$IDX" -gt "$COUNT" ] 2>/dev/null && COUNT="$IDX"

    : > "$TMP"

    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(get_profile_value "$i" NAME)"
        SSID="$(get_profile_value "$i" SSID)"
        PASS="$(get_profile_value "$i" PASSWORD)"

        if [ "$i" = "$IDX" ]; then
            NAME="$NEW_NAME"
            SSID="$NEW_SSID"
            PASS="$NEW_PASS"
        fi

        # Skip totally empty profiles.
        if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
            {
                echo "PROFILE${i}_NAME=$NAME"
                echo "PROFILE${i}_SSID=$SSID"
                echo "PROFILE${i}_PASSWORD=$PASS"
                echo ""
            } >> "$TMP"
        fi

        i=$((i+1))
    done

    cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

delete_profile() {
    IDX="$1"
    TMP="/tmp/matrix_wifi_profiles_delete.$$"
    COUNT="$(profile_count)"
    NEW=1

    cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null

    : > "$TMP"
    i=1
    while [ "$i" -le "$COUNT" ]; do
        if [ "$i" != "$IDX" ]; then
            NAME="$(get_profile_value "$i" NAME)"
            SSID="$(get_profile_value "$i" SSID)"
            PASS="$(get_profile_value "$i" PASSWORD)"
            if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
                {
                    echo "PROFILE${NEW}_NAME=$NAME"
                    echo "PROFILE${NEW}_SSID=$SSID"
                    echo "PROFILE${NEW}_PASSWORD=$PASS"
                    echo ""
                } >> "$TMP"
                NEW=$((NEW+1))
            fi
        fi
        i=$((i+1))
    done

    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

add_profile() {
    COUNT="$(profile_count)"
    IDX=$((COUNT+1))
    rebuild_config_update_profile "$IDX" "New Profile" "NewSSID" "password"
}

ensure_config

MSG=""
MSG_CLASS=""

if [ "$REQUEST_METHOD" = "POST" ]; then
    read_post
    ACTION="$(get_field action)"
    IDX="$(get_field profile)"

    case "$ACTION" in
        save)
            NAME="$(get_field name)"
            SSID="$(get_field ssid)"
            PASS="$(get_field password)"

            if [ -z "$IDX" ] || [ -z "$NAME" ] || [ -z "$SSID" ] || [ -z "$PASS" ]; then
                MSG="Profile was not saved. Name, SSID and password are required."
                MSG_CLASS="err"
            else
                rebuild_config_update_profile "$IDX" "$NAME" "$SSID" "$PASS"
                MSG="Profile $IDX saved."
                MSG_CLASS="ok"
                echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX saved name=$NAME ssid=$SSID" >> "$LOG"
            fi
            ;;
        delete)
            if [ -n "$IDX" ]; then
                delete_profile "$IDX"
                MSG="Profile $IDX deleted."
                MSG_CLASS="ok"
                echo "$(date '+%Y-%m-%d %H:%M:%S') Profile $IDX deleted" >> "$LOG"
            fi
            ;;
        add)
            add_profile
            MSG="New profile added."
            MSG_CLASS="ok"
            echo "$(date '+%Y-%m-%d %H:%M:%S') New profile added" >> "$LOG"
            ;;
    esac
fi

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"

CURRENT_SSID="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
[ -z "$CURRENT_SSID" ] && CURRENT_SSID="Unknown"

COUNT="$(profile_count)"
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
[ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

E_HOST="$(html_escape "$HOST")"
E_CURRENT_SSID="$(html_escape "$CURRENT_SSID")"
E_LAST="$(html_escape "$LAST")"
E_MSG="$(html_escape "$MSG")"

cat <<'EOF'
Content-Type: text/html

<!DOCTYPE html>
<html>
<head>
<title>Matrix WiFi Manager</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1040px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}
h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}
.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}
.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}
.profile{background:#fff;border:1px solid #ddd;border-radius:8px;padding:15px;margin:12px 0}
.profile h3{margin:0 0 10px 0;color:#005a9c}
.row{display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:10px;align-items:end}
.field label{display:block;font-size:12px;color:#666;font-weight:bold;margin-bottom:4px}
input[type=text],input[type=password]{width:100%;height:40px;border:1px solid #ccc;border-radius:6px;padding:0 8px;box-sizing:border-box;font-size:14px}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:11px 14px;margin:4px 4px 4px 0;font-size:14px}
.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.row{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}}
</style>
<script>
function confirmApply(name, ssid){
  return confirm('Apply WiFi profile: '+name+'\nSSID: '+ssid+'\n\nThis will reload the 5 GHz WiFi. Continue?');
}
function confirmDelete(name){
  return confirm('Delete profile: '+name+' ?');
}
function confirmPrevious(){
  return confirm('Restore previous profile configuration?');
}
function confirmFactory(){
  return confirm('Restore factory/default profiles?');
}
function togglePw(id){
  var x=document.getElementById(id);
  x.type = x.type === 'password' ? 'text' : 'password';
}
</script>
</head>
<body><div class="page">
EOF

cat <<EOF
<h1>Matrix WiFi Manager</h1>
<div class="topgrid">
  <div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="card"><div class="label">Current 5 GHz SSID</div><div class="value">$E_CURRENT_SSID</div></div>
  <div class="card"><div class="label">Profiles</div><div class="value">$COUNT</div></div>
  <div class="card"><div class="label">Target</div><div class="value">default_radio1</div></div>
</div>
EOF

[ -n "$MSG" ] && echo "<div class=\"card $MSG_CLASS\">$E_MSG</div>"

cat <<'EOF'
<div class="card">
<h2>Profiles</h2>
EOF

i=1
while [ "$i" -le "$COUNT" ]; do
    NAME="$(get_profile_value "$i" NAME)"
    SSID="$(get_profile_value "$i" SSID)"
    PASS="$(get_profile_value "$i" PASSWORD)"

    RESOLVED="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"

    E_NAME="$(html_escape "$NAME")"
    E_SSID_RAW="$(html_escape "$SSID")"
    E_SSID_RESOLVED="$(html_escape "$RESOLVED")"
    E_PASS="$(html_escape "$PASS")"

    STATUS="<span class=\"muted\">Available</span>"
    [ "$RESOLVED" = "$CURRENT_SSID" ] && STATUS="<span class=\"active\">Active</span>"

    cat <<EOF
<div class="profile">
<h3>Profile $i - $E_NAME</h3>
<form method="post" action="/cgi-bin/wifi_manager.sh">
<input type="hidden" name="action" value="save">
<input type="hidden" name="profile" value="$i">
<div class="row">
  <div class="field">
    <label>Name</label>
    <input type="text" name="name" value="$E_NAME">
  </div>
  <div class="field">
    <label>SSID <span class="muted">(resolved: $E_SSID_RESOLVED)</span></label>
    <input type="text" name="ssid" value="$E_SSID_RAW">
  </div>
  <div class="field">
    <label>Password</label>
    <input id="pw$i" type="password" name="password" value="$E_PASS">
  </div>
  <div>
    <button class="btn blue" type="submit">Save</button>
  </div>
</div>
<p>
<button class="btn grey" type="button" onclick="togglePw('pw$i')">Show / Hide</button>
<a class="btn green" onclick="return confirmApply('$E_NAME','$E_SSID_RESOLVED')" href="/cgi-bin/wifi_profile.sh?p=$i">Apply</a>
</p>
<p>Status: $STATUS</p>
</form>
<form method="post" action="/cgi-bin/wifi_manager.sh" onsubmit="return confirmDelete('$E_NAME')">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="profile" value="$i">
<button class="btn red" type="submit">Delete Profile</button>
</form>
</div>
EOF

    i=$((i+1))
done

cat <<'EOF'
<form method="post" action="/cgi-bin/wifi_manager.sh">
<input type="hidden" name="action" value="add">
<button class="btn orange" type="submit">+ Add Profile</button>
<a class="btn orange" onclick="return confirmPrevious()" href="/cgi-bin/wifi_profiles_restore_previous.sh">Restore Previous</a>
<a class="btn red" onclick="return confirmFactory()" href="/cgi-bin/wifi_profiles_reset.sh">Restore Factory Defaults</a>
<a class="btn blue" href="/">Back to Toolkit</a>
</form>
</div>
EOF

cat <<EOF
<div class="card">
<h2>Status</h2>
<p class="muted">Last change: $E_LAST</p>
<p class="muted">Active config: <b>$CONFIG</b></p>
<p class="muted">Previous config: <b>$PREVIOUS</b></p>
<p class="muted">Default config: <b>$DEFAULTS</b></p>
<p class="muted">This manager changes only the 5 GHz access point: <b>wireless.default_radio1</b>. The 2.4 GHz SSID stays unchanged.</p>
</div>
</div></body></html>
EOF
