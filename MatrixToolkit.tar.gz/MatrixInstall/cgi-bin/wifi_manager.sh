#!/bin/sh

# Matrix Toolkit - Dynamic WiFi Manager
# Shows all PROFILEn entries from /usr/local/matrix/config/matrix_wifi_profiles.conf

CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
DEFAULT_CONFIG="/usr/local/matrix/defaults/matrix_wifi_profiles.conf"
WIFI_IFACE="wireless.default_radio1"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"

CURRENT_SSID="$(uci get ${WIFI_IFACE}.ssid 2>/dev/null)"
[ -z "$CURRENT_SSID" ] && CURRENT_SSID="not available"

# Create local config from default when missing.
if [ ! -f "$CONFIG" ] && [ -f "$DEFAULT_CONFIG" ]; then
    mkdir -p /usr/local/matrix/config 2>/dev/null
    cp "$DEFAULT_CONFIG" "$CONFIG" 2>/dev/null
fi

echo "Content-Type: text/html"
echo ""

cat << EOF2
<!DOCTYPE html>
<html>
<head>
<title>Matrix Toolkit - WiFi Manager</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222;}
.page{max-width:1040px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08);}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px;}
h2{margin:20px 0 9px 0;color:#005a9c;font-size:19px;}
.note{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:14px 18px;line-height:1.55;color:#555;font-size:13px;margin-bottom:18px;}
.current{background:white;border:1px solid #ddd;border-radius:6px;padding:10px 12px;margin:10px 0 18px 0;font-size:14px;color:#333;}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:14px;}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;box-sizing:border-box;}
.card h3{margin:0 0 8px 0;color:#005a9c;font-size:17px;}
.card p{margin:0 0 12px 0;color:#555;font-size:13px;line-height:1.45;word-break:break-all;}
button{width:100%;height:46px;font-size:14px;font-weight:bold;cursor:pointer;border:none;border-radius:6px;color:white;margin:0;}
.green{background:#28a745;}.green:hover{background:#218838;}
.blue{background:#007bff;}.blue:hover{background:#0069d9;}
.orange{background:#fd7e14;}.orange:hover{background:#e46c0a;}
.red{background:#dc3545;}.red:hover{background:#c82333;}
.grey{background:#666;}.grey:hover{background:#555;}
.actions{display:flex;gap:16px;flex-wrap:wrap;margin-top:20px;}
.actions button{width:320px;}
a{color:#005a9c;}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.grid{grid-template-columns:1fr}.actions{display:block}.actions button{width:100%;margin-bottom:8px}}
</style>
</head>
<body>
<div class="page">
<h1>WiFi Manager</h1>
<div class="note">
Beheer de 5 GHz SSID-profielen van deze router. Alleen <b>wireless.default_radio1</b> wordt aangepast. De 2.4 GHz SSID blijft ongewijzigd.
</div>
<div class="current"><b>Current 5G SSID:</b> $(html_escape "$CURRENT_SSID")</div>
EOF2

if [ ! -f "$CONFIG" ]; then
    cat << EOF2
<h2>Geen profielbestand gevonden</h2>
<div class="note">
Actieve config ontbreekt:<br>
<code>$CONFIG</code><br><br>
Default config ontbreekt of kon niet gekopieerd worden:<br>
<code>$DEFAULT_CONFIG</code>
</div>
<div class="actions">
<button class="grey" onclick="window.location='/'">Terug naar Toolkit</button>
</div>
</div></body></html>
EOF2
    exit 1
fi

# shellcheck disable=SC1090
. "$CONFIG"

echo '<h2>Beschikbare profielen</h2>'
echo '<div class="grid">'
FOUND=0
i=1
while [ "$i" -le 20 ]; do
    eval "NAME=\${PROFILE${i}_NAME}"
    eval "SSID=\${PROFILE${i}_SSID}"
    eval "PASS=\${PROFILE${i}_PASSWORD}"
    if [ -n "$NAME" ] && [ -n "$SSID" ] && [ -n "$PASS" ]; then
        FOUND=1
        RESOLVED_SSID="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"
        ESC_NAME="$(html_escape "$NAME")"
        ESC_SSID="$(html_escape "$RESOLVED_SSID")"
        if [ "$RESOLVED_SSID" = "$CURRENT_SSID" ]; then
            CLASS="green"
            LABEL="Actief - opnieuw toepassen"
        else
            CLASS="blue"
            LABEL="Profiel toepassen"
        fi
        cat << EOF2
<div class="card">
<h3>$ESC_NAME</h3>
<p><b>SSID:</b> $ESC_SSID<br><b>Wachtwoord:</b> opgeslagen in profiel</p>
<button class="$CLASS" onclick="if(confirm('5G SSID wijzigen naar $ESC_SSID?')) window.location='/cgi-bin/wifi_profile.sh?p=$i'">$LABEL</button>
</div>
EOF2
    fi
    i=$((i+1))
done

echo '</div>'

if [ "$FOUND" = "0" ]; then
    cat << EOF2
<div class="note">Er zijn geen geldige profielen gevonden in <code>$CONFIG</code>.</div>
EOF2
fi

cat << EOF2
<div class="actions">
<button class="grey" onclick="window.location='/'">Terug naar Toolkit</button>
<button class="orange" onclick="if(confirm('Lokale WiFi-profielen vervangen door de standaard GitHub/default profielen?')) window.location='/cgi-bin/wifi_profiles_reset.sh'">Reset Profiles from GitHub Default</button>
</div>
</div>
</body>
</html>
EOF2
