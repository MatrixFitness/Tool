#!/bin/sh
# Matrix WiFi Manager v67 - Simple UI with WiFi Client Connections

LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"

ensure_wifi_files

ACTION="$(qs action)"
TYPE="$(qs type)"
IDX="$(qs p)"
IFACE="$(qs iface)"

case "$ACTION" in
    apply) profile_apply "$TYPE" "$IDX" ;;
    restore_matrix) restore_matrix_default_wifi ;;
    enable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='0' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface enabled iface=$IFACE" >> "$LOG"
        ;;
    disable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='1' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface disabled iface=$IFACE" >> "$LOG"
        ;;
    reload_wifi)
        wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi reload requested" >> "$LOG"
        ;;
    remove_client)
        [ -n "$IFACE" ] && wifi_client_remove "$IFACE"
        ;;
esac

HOST="$(hostname_value)"
SSID0="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
SSID1="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
DIS0="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
DIS1="$(uci get wireless.default_radio1.disabled 2>/dev/null)"
[ -z "$SSID0" ] && SSID0="Unknown"; [ -z "$SSID1" ] && SSID1="Unknown"
[ -z "$DIS0" ] && DIS0="0"; [ -z "$DIS1" ] && DIS1="0"
ACTIVE_PROFILE="$(active_system_profile_name)"
SC="$(profile_count_file "$SYSTEM_PROFILES")"; [ -z "$SC" ] && SC=0
UC="$(profile_count_file "$USER_PROFILES")"; [ -z "$UC" ] && UC=0
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"; [ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

E_HOST="$(html_escape "$HOST")"; E_SSID0="$(html_escape "$SSID0")"; E_SSID1="$(html_escape "$SSID1")"; E_ACTIVE="$(html_escape "$ACTIVE_PROFILE")"; E_LAST="$(html_escape "$LAST")"

echo "Content-Type: text/html"
echo ""
cat <<EOF
<!DOCTYPE html>
<html>
<head>
<title>Matrix WiFi Manager v67</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1120px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}
h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}
.current-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.current-item{background:white;border:1px solid #ddd;border-radius:8px;padding:14px}
.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}
.value{font-size:20px;font-weight:bold;color:#222;word-break:break-all;margin-top:4px}
.badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:bold;font-size:12px}
.badge.active{background:#dff3e4;color:#137333;border:1px solid #a8dab5}
.badge.same{background:#fff4ce;color:#8a5a00;border:1px solid #ead28a}
.badge.available{background:#e9f3ff;color:#005a9c;border:1px solid #b9d7f4}
.badge.disabled{background:#fde2e2;color:#a10000;border:1px solid #f3b3b3}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:11px 14px;margin:4px;font-size:14px}
.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
.profile-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.profile-simple-card{background:white;border:1px solid #d6d6d6;border-radius:10px;padding:15px;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.profile-simple-header{display:flex;justify-content:space-between;gap:10px;align-items:center;border-bottom:1px solid #eee;padding-bottom:10px;margin-bottom:10px}
.profile-simple-title{font-size:18px;font-weight:bold;color:#005a9c}
.profile-simple-row{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid #f0f0f0;padding:7px 0}
.profile-simple-row span{color:#666;font-weight:bold}
.profile-actions{margin-top:12px}
table{width:100%;border-collapse:collapse;background:white}
th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}
th{background:#f0f6fb;color:#005a9c}
.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.muted{color:#777;font-size:13px}
.advanced{margin-top:14px}.advanced summary{cursor:pointer;font-weight:bold;color:#005a9c;padding:10px;background:#f0f6fb;border-radius:6px}
.footer-actions{text-align:center;margin-top:18px}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.current-grid,.profile-grid{grid-template-columns:1fr}.profile-simple-header{display:block}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function confirmApply(n){return confirm('Apply profile: '+n+'\\n\\nWiFi will reload. Continue?');}
function confirmRestore(){return confirm('Restore Matrix Default WiFi?\\n\\n2.4 GHz = {HOSTNAME}_2G\\n5 GHz = {HOSTNAME}_5G\\n\\nWiFi will reload. Continue?');}
function confirmReload(){return confirm('Reload WiFi now?');}
function confirmDelete(n){return confirm('Delete user profile: '+n+' ?');}
function confirmIface(a,i,s){return confirm(a+' interface?\\n\\nInterface: '+i+'\\nSSID: '+s+'\\n\\nWiFi will reload. Continue?');}
function confirmRemoveClient(i,s,n){return confirm('Remove WiFi Client connection?\\n\\nSSID: '+s+'\\nInterface: '+i+'\\nNetwork: '+n+'\\n\\nThis only removes the client connection. Router WiFi Access Points will NOT be changed. Continue?');}
</script>
</head>
<body>
<div class="page">
<h1>Matrix WiFi Manager v67</h1>

<div class="card">
<h2>Current WiFi</h2>
<div class="current-grid">
  <div class="current-item"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="current-item"><div class="label">2.4 GHz</div><div class="value">$E_SSID0</div><p>$([ "$DIS0" = "1" ] && echo '<span class="badge disabled">DISABLED</span>' || echo '<span class="badge active">ACTIVE</span>')</p></div>
  <div class="current-item"><div class="label">5 GHz</div><div class="value">$E_SSID1</div><p>$([ "$DIS1" = "1" ] && echo '<span class="badge disabled">DISABLED</span>' || echo '<span class="badge active">ACTIVE</span>')</p></div>
</div>
<p><b>Current profile:</b> <span class="badge active">$E_ACTIVE</span></p>
<p><a class="btn red" onclick="return confirmRestore()" href="/cgi-bin/wifi_manager.sh?action=restore_matrix&nocache=$(date +%s)">Restore Matrix Default WiFi</a></p>
</div>

<div class="card">
<h2>Matrix System Profiles</h2>
<p class="muted">These profiles are always present on every new router and cannot be deleted.</p>
<div class="profile-grid">
EOF

i=1
while [ "$i" -le "$SC" ]; do
    system_profile_card "$i"
    i=$((i+1))
done

cat <<EOF
</div>
</div>

<div class="card">
<h2>Customer / User Profiles</h2>
<p class="muted">Create your own WiFi profiles for customers, service or temporary testing.</p>
EOF

if [ "$UC" -eq 0 ]; then
    echo '<p class="muted">No user profiles yet.</p>'
else
    echo '<div class="profile-grid">'
    i=1
    while [ "$i" -le "$UC" ]; do
        user_profile_card "$i"
        i=$((i+1))
    done
    echo '</div>'
fi

cat <<EOF
<p><a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add&type=user">+ Add User Profile</a></p>
</div>

<details class="advanced">
<summary>Advanced WiFi Details</summary>
<div class="card">
<h2>Access Point Interface Control</h2>
<p class="muted">These are WiFi networks broadcast by the router. WiFi client connections are shown separately below.</p>
<table>
<tr><th>Interface</th><th>Device</th><th>SSID</th><th>Status</th><th>Action</th></tr>
EOF

AP_COUNT=0
uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    MODE="$(uci get wireless.${IFACE_NAME}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] && continue

    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    DEVICE="$(uci get wireless.${IFACE_NAME}.device 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"; [ -z "$DEVICE" ] && DEVICE="-"; [ -z "$DISABLED" ] && DISABLED="0"
    E_IFACE="$(html_escape "$IFACE_NAME")"; E_SSID="$(html_escape "$SSID")"; E_DEVICE="$(html_escape "$DEVICE")"
    if [ "$DISABLED" = "1" ]; then
        STATUS='<span class="err">Disabled</span>'
        BTN="<a class=\"btn green\" onclick=\"return confirmIface('Enable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=enable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Enable</a>"
    else
        STATUS='<span class="ok">Enabled</span>'
        BTN="<a class=\"btn red\" onclick=\"return confirmIface('Disable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=disable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Disable</a>"
    fi
    echo "<tr><td><b>$E_IFACE</b></td><td>$E_DEVICE</td><td>$E_SSID</td><td>$STATUS</td><td>$BTN</td></tr>"
done

cat <<EOF
</table>
</div>

<div class="card">
<h2>WiFi Client Connections</h2>
<p class="muted">These are temporary WiFi connections used by the router itself for internet/WAN testing. They are not broadcast SSIDs.</p>
<table>
<tr><th>Interface</th><th>SSID</th><th>Mode</th><th>Network</th><th>Status</th><th>Action</th></tr>
EOF

CLIENT_FOUND=0
uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    MODE="$(uci get wireless.${IFACE_NAME}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] || continue

    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    NETWORK="$(uci get wireless.${IFACE_NAME}.network 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"; [ -z "$NETWORK" ] && NETWORK="-"; [ -z "$DISABLED" ] && DISABLED="0"

    E_IFACE="$(html_escape "$IFACE_NAME")"
    E_SSID="$(html_escape "$SSID")"
    E_NETWORK="$(html_escape "$NETWORK")"

    if [ "$DISABLED" = "1" ]; then
        STATUS='<span class="err">Disabled</span>'
    else
        STATUS='<span class="ok">Configured</span>'
    fi

    BTN="<a class=\"btn red\" onclick=\"return confirmRemoveClient('$E_IFACE','$E_SSID','$E_NETWORK')\" href=\"/cgi-bin/wifi_manager.sh?action=remove_client&iface=$E_IFACE&nocache=$(date +%s)\">Remove</a>"

    echo "<tr><td><b>$E_IFACE</b></td><td>$E_SSID</td><td>STA / Client</td><td>$E_NETWORK</td><td>$STATUS</td><td>$BTN</td></tr>"
    CLIENT_FOUND=1
done

cat <<EOF
</table>
<p class="muted">If you remove a client connection, the normal router WiFi Access Points remain unchanged.</p>
<p><a class="btn grey" onclick="return confirmReload()" href="/cgi-bin/wifi_manager.sh?action=reload_wifi&nocache=$(date +%s)">Reload WiFi</a></p>
<p class="muted">Last change: $E_LAST</p>
<p class="muted">System profiles: <b>$SYSTEM_PROFILES</b></p>
<p class="muted">User profiles: <b>$USER_PROFILES</b></p>
</div>
</details>

<div class="footer-actions">
<a class="btn blue" href="/">Back to Toolkit</a>
</div>

</div>
</body>
</html>
EOF
