#!/bin/sh
# Matrix Toolkit WiFi Manager v64 - radio action profiles
. /usr/local/matrix/web/cgi-bin/wifi_lib.sh
ensure_config
ACTION="$(qs action)"; IFACE="$(qs iface)"
case "$ACTION" in
    enable_iface) [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='0' && uci commit wireless && wifi reload >/dev/null 2>&1 && echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface enabled iface=$IFACE" >> "$LOG" ;;
    disable_iface) [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='1' && uci commit wireless && wifi reload >/dev/null 2>&1 && echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface disabled iface=$IFACE" >> "$LOG" ;;
    reload_wifi) wifi reload >/dev/null 2>&1; echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi reload requested from WiFi Manager" >> "$LOG" ;;
    restore_matrix_default) restore_matrix_default_wifi ;;
esac
HOST="$(hostname_value)"; SSID_2G="$(uci get ${RADIO0}.ssid 2>/dev/null)"; SSID_5G="$(uci get ${RADIO1}.ssid 2>/dev/null)"; [ -z "$SSID_2G" ] && SSID_2G="Unknown"; [ -z "$SSID_5G" ] && SSID_5G="Unknown"
COUNT="$(profile_count)"; [ -z "$COUNT" ] && COUNT=0
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"; [ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."
E_HOST="$(html_escape "$HOST")"; E_2G="$(html_escape "$SSID_2G")"; E_5G="$(html_escape "$SSID_5G")"; E_LAST="$(html_escape "$LAST")"
echo "Content-Type: text/html"; echo ""
cat <<EOF
<!DOCTYPE html><html><head><title>Matrix WiFi Manager</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"><style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1120px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:middle}th{background:#f0f6fb;color:#005a9c}input[type=text],input[type=password],select{width:100%;height:40px;border:1px solid #ccc;border-radius:6px;padding:0 8px;box-sizing:border-box;font-size:14px;background:white}.field{margin:12px 0}.field label{display:block;font-size:12px;color:#666;font-weight:bold;margin-bottom:4px}.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function confirmApply(n,s){return confirm('Apply WiFi profile: '+n+'\n\n'+s+'\n\nWiFi will reload. Continue?');}
function confirmDelete(n){return confirm('Delete profile: '+n+' ?');}
function confirmIface(a,i,s){return confirm(a+' WiFi interface?\n\nInterface: '+i+'\nSSID: '+s+'\n\nWiFi will reload. Continue?');}
function confirmReload(){return confirm('Reload WiFi now?');}
function confirmDefault(){return confirm('Restore Matrix Default WiFi?\n\n2.4 GHz = {HOSTNAME}_2G\n5 GHz = {HOSTNAME}_5G\n\nWiFi will reload. Continue?');}
</script></head><body><div class="page">
<h1>Matrix WiFi Manager v64</h1>
<div class="topgrid"><div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div><div class="card"><div class="label">Current 2.4 GHz</div><div class="value">$E_2G</div></div><div class="card"><div class="label">Current 5 GHz</div><div class="value">$E_5G</div></div><div class="card"><div class="label">Profiles</div><div class="value">$COUNT</div></div></div>
<div class="card"><h2>Emergency / Default</h2><p class="muted">Restore the safe default router WiFi without depending on saved profiles.</p><a class="btn red" onclick="return confirmDefault()" href="/cgi-bin/wifi_manager.sh?action=restore_matrix_default&nocache=$(date +%s)">Restore Matrix Default WiFi</a></div>
<div class="card"><h2>WiFi Interface Control</h2><table><tr><th>Interface</th><th>Device</th><th>SSID</th><th>Status</th><th>Action</th></tr>
EOF
uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"; DEVICE="$(uci get wireless.${IFACE_NAME}.device 2>/dev/null)"; DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"; [ -z "$DEVICE" ] && DEVICE="-"; [ -z "$DISABLED" ] && DISABLED="0"
    E_IFACE="$(html_escape "$IFACE_NAME")"; E_SSID="$(html_escape "$SSID")"; E_DEVICE="$(html_escape "$DEVICE")"
    if [ "$DISABLED" = "1" ]; then STATUS='<span class="err">Disabled</span>'; BTN="<a class=\"btn green\" href=\"/cgi-bin/wifi_manager.sh?action=enable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Enable</a>"; else STATUS='<span class="ok">Enabled</span>'; BTN="<a class=\"btn red\" href=\"/cgi-bin/wifi_manager.sh?action=disable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Disable</a>"; fi
    echo "<tr><td><b>$E_IFACE</b></td><td>$E_DEVICE</td><td>$E_SSID</td><td>$STATUS</td><td>$BTN</td></tr>"
done
cat <<EOF
</table><p><a class="btn grey" onclick="return confirmReload()" href="/cgi-bin/wifi_manager.sh?action=reload_wifi&nocache=$(date +%s)">Reload WiFi</a></p><p class="muted">This enables/disables existing WiFi interfaces and does not change saved profiles.</p></div>
<div class="card"><h2>Saved Profiles</h2><table><tr><th>#</th><th>Name</th><th>Radio 0 / 2.4 GHz</th><th>Radio 1 / 5 GHz</th><th>Status</th><th>Actions</th></tr>
EOF
i=1
while [ "$i" -le "$COUNT" ]; do
    NAME="$(profile_value "$i" NAME)"
    R0A="$(normalize_action "$(profile_value "$i" R0_ACTION)")"; R1A="$(normalize_action "$(profile_value "$i" R1_ACTION)")"
    R0S_RAW="$(profile_value "$i" R0_SSID)"; R1S_RAW="$(profile_value "$i" R1_SSID)"
    R0S="$(resolve_ssid "$R0S_RAW")"; R1S="$(resolve_ssid "$R1S_RAW")"
    [ "$R0A" = "KEEP" ] && R0TXT="Keep current" || R0TXT="$R0A $R0S"
    [ "$R0A" = "DISABLE" ] && R0TXT="Disable"
    [ "$R1A" = "KEEP" ] && R1TXT="Keep current" || R1TXT="$R1A $R1S"
    [ "$R1A" = "DISABLE" ] && R1TXT="Disable"
    E_NAME="$(html_escape "$NAME")"; E_R0="$(html_escape "$R0TXT")"; E_R1="$(html_escape "$R1TXT")"
    STATUS="<span class=\"muted\">Stored</span>"
    D0="$(uci get ${RADIO0}.disabled 2>/dev/null)"; D1="$(uci get ${RADIO1}.disabled 2>/dev/null)"; [ -z "$D0" ] && D0=0; [ -z "$D1" ] && D1=0
    MATCH0=0; MATCH1=0
    case "$R0A" in KEEP) MATCH0=1;; DISABLE) [ "$D0" = "1" ] && MATCH0=1;; SET) [ "$SSID_2G" = "$R0S" ] && [ "$D0" != "1" ] && MATCH0=1;; esac
    case "$R1A" in KEEP) MATCH1=1;; DISABLE) [ "$D1" = "1" ] && MATCH1=1;; SET) [ "$SSID_5G" = "$R1S" ] && [ "$D1" != "1" ] && MATCH1=1;; esac
    [ "$MATCH0" = "1" ] && [ "$MATCH1" = "1" ] && STATUS="<span class=\"active\">Current</span>"
    SUMMARY="Radio0: $R0TXT\nRadio1: $R1TXT"
    echo "<tr><td>$i</td><td><b>$E_NAME</b></td><td>$E_R0</td><td>$E_R1</td><td>$STATUS</td><td><a class=\"btn blue\" href=\"/cgi-bin/wifi_profile_edit.sh?p=$i\">Edit</a><a class=\"btn green\" href=\"/cgi-bin/wifi_profile.sh?p=$i\">Apply</a><a class=\"btn red\" href=\"/cgi-bin/wifi_profile_save.sh?action=delete&profile=$i\">Delete</a></td></tr>"
    i=$((i+1))
done
cat <<EOF
</table><p><a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add">+ Add Profile</a><a class="btn orange" href="/cgi-bin/wifi_profiles_restore_previous.sh">Restore Previous</a><a class="btn red" href="/cgi-bin/wifi_profiles_reset.sh">Restore Factory Profiles</a><a class="btn blue" href="/">Back to Toolkit</a></p></div>
<div class="card"><h2>Status</h2><p class="muted">Last change: $E_LAST</p><p class="muted">Profile config: <b>$CONFIG</b></p><p class="muted">Radio 0 target: <b>$RADIO0</b></p><p class="muted">Radio 1 target: <b>$RADIO1</b></p></div>
</div></body></html>
EOF
