#!/bin/sh
# Matrix Toolkit - WiFi Manager
# Shows and edits WiFi profiles. Applies profiles to wireless.default_radio1 only.

CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    # Decode form-urlencoded input. BusyBox-safe enough for normal SSID/password text.
    local data
    data="$(cat)"
    printf '%s' "$data" | sed 's/+/ /g;s/%0D//g;s/%0A/\n/g;s/%3D/=/Ig;s/%26/\&/Ig;s/%23/#/Ig;s/%20/ /g;s/%5F/_/Ig;s/%2D/-/Ig;s/%7B/{/Ig;s/%7D/}/Ig;s/%40/@/Ig;s/%21/!/Ig;s/%24/$/Ig;s/%2A/*/Ig;s/%2E/./Ig;s/%2F/\//Ig;s/%3A/:/Ig;s/%3B/;/Ig;s/%2B/+/Ig'
}

ensure_config() {
    mkdir -p /usr/local/matrix/config
    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then
            cp "$DEFAULTS" "$CONFIG"
        else
            cat > "$CONFIG" << 'EOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
EOF
        fi
    fi
}

save_profiles() {
    RAW="$(url_decode)"
    CONTENT="$(printf '%s' "$RAW" | sed -n 's/^profiles=//p')"
    if [ -z "$CONTENT" ]; then
        # If sed failed because the content includes newlines, strip leading profiles= another way.
        CONTENT="$(printf '%s' "$RAW" | sed '1s/^profiles=//')"
    fi
    if [ -n "$CONTENT" ]; then
        mkdir -p /usr/local/matrix/config
        cp "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
        printf '%s\n' "$CONTENT" > "$CONFIG"
        echo "$(date '+%Y-%m-%d %H:%M:%S') Profiles edited from WiFi Manager" >> "$LOG"
        SAVED="1"
    fi
}

ensure_config

if [ "$REQUEST_METHOD" = "POST" ]; then
    save_profiles
fi

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"
CURRENT_SSID="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
CURRENT_PASS="$(uci get wireless.default_radio1.key 2>/dev/null)"
[ -z "$CURRENT_SSID" ] && CURRENT_SSID="Unknown"

E_CURRENT_SSID="$(html_escape "$CURRENT_SSID")"
E_HOST="$(html_escape "$HOST")"
E_CONFIG_TEXT="$(html_escape "$(cat "$CONFIG" 2>/dev/null)")"
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
[ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."
E_LAST="$(html_escape "$LAST")"

cat << 'EOF'
Content-Type: text/html

<!DOCTYPE html>
<html>
<head>
<title>Matrix WiFi Manager</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1040px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.topgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:11px 14px;margin:4px 4px 4px 0;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}.tablewrap{overflow-x:auto}table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:middle}th{background:#f0f6fb;color:#005a9c}.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}textarea{width:100%;min-height:260px;font-family:Consolas,monospace;font-size:13px;border:1px solid #ccc;border-radius:6px;padding:10px;box-sizing:border-box}summary{cursor:pointer;font-weight:bold;color:#005a9c}.warn{color:#b35b00;font-weight:bold}@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function togglePasswords(){var x=document.querySelectorAll('.pw');x.forEach(function(e){e.textContent=e.getAttribute('data-pw-visible')==='1'?'********':e.getAttribute('data-pw');e.setAttribute('data-pw-visible',e.getAttribute('data-pw-visible')==='1'?'0':'1');});}
function confirmApply(name, ssid){return confirm('Apply WiFi profile: '+name+'\nSSID: '+ssid+'\n\nThis will reload the 5 GHz WiFi. Continue?');}
function confirmReset(){return confirm('Restore profiles from GitHub/default master?\n\nThis overwrites the local active profile config.');}
function confirmSave(){return confirm('Save profile configuration?\nA backup of the current config will be created.');}
</script>
</head>
<body><div class="page">
EOF

cat << EOF
<h1>Matrix WiFi Manager</h1>
<div class="topgrid">
  <div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="card"><div class="label">Current 5 GHz SSID</div><div class="value">$E_CURRENT_SSID</div></div>
  <div class="card"><div class="label">Target interface</div><div class="value">wireless.default_radio1</div></div>
</div>
EOF

[ "$SAVED" = "1" ] && echo '<div class="card active">Profile configuration saved.</div>'

cat << 'EOF'
<div class="card">
<h2>Available Profiles</h2>
<div class="tablewrap"><table>
<tr><th>Profile</th><th>SSID</th><th>Password</th><th>Status</th><th>Action</th></tr>
EOF

i=1
while :; do
    NAME="$(grep "^PROFILE${i}_NAME=" "$CONFIG" | head -n1 | cut -d= -f2-)"
    SSID="$(grep "^PROFILE${i}_SSID=" "$CONFIG" | head -n1 | cut -d= -f2-)"
    PASS="$(grep "^PROFILE${i}_PASSWORD=" "$CONFIG" | head -n1 | cut -d= -f2-)"
    [ -z "$NAME" ] && [ -z "$SSID" ] && [ -z "$PASS" ] && break
    RESOLVED="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"
    E_NAME="$(html_escape "$NAME")"
    E_SSID="$(html_escape "$RESOLVED")"
    E_PASS="$(html_escape "$PASS")"
    STATUS=""
    [ "$RESOLVED" = "$CURRENT_SSID" ] && STATUS="<span class=\"active\">Active</span>"
    [ -z "$STATUS" ] && STATUS="<span class=\"muted\">Available</span>"
    echo "<tr><td><b>$E_NAME</b><br><span class=\"muted\">Profile $i</span></td><td>$E_SSID</td><td><span class=\"pw\" data-pw=\"$E_PASS\" data-pw-visible=\"0\">********</span></td><td>$STATUS</td><td><a class=\"btn green\" onclick=\"return confirmApply('$E_NAME','$E_SSID')\" href=\"/cgi-bin/wifi_profile.sh?p=$i\">Apply</a></td></tr>"
    i=$((i+1))
done

cat << EOF
</table></div>
<p><button class="btn grey" onclick="togglePasswords()">Show / Hide Passwords</button>
<a class="btn red" onclick="return confirmReset()" href="/cgi-bin/wifi_profiles_reset.sh">Restore Default Profiles</a>
<a class="btn blue" href="/">Back to Toolkit</a></p>
</div>

<div class="card">
<h2>Status</h2>
<p class="muted">Last change: $E_LAST</p>
<p class="muted">This manager changes only the 5 GHz access point: <b>wireless.default_radio1</b>. The 2.4 GHz SSID stays unchanged.</p>
</div>

<div class="card">
<details>
<summary>Edit Profiles</summary>
<p class="warn">Be careful: this edits the active local profile file. Use the same PROFILE format.</p>
<form method="post" action="/cgi-bin/wifi_manager.sh" onsubmit="return confirmSave()">
<textarea name="profiles">$E_CONFIG_TEXT</textarea>
<br><button class="btn blue" type="submit">Save Profiles</button>
</form>
<p class="muted">Example: PROFILE4_NAME=Service, PROFILE4_SSID=ServiceWiFi, PROFILE4_PASSWORD=password</p>
</details>
</div>

</div></body></html>
EOF
