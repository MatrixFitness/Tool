#!/bin/sh
# Matrix Toolkit v60 - WiFi Manager
# Field based profile editor. No textarea save.

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
OLD_CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

write_builtin_defaults() {
    cat > "$1" <<'EOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
EOF
}

ensure_config() {
    mkdir -p /usr/local/matrix

    if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then
        cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null
    fi

    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then
            cp -f "$DEFAULTS" "$CONFIG" 2>/dev/null
        else
            write_builtin_defaults "$CONFIG"
        fi
    fi

    if [ ! -f "$DEFAULTS" ]; then
        cp -f "$CONFIG" "$DEFAULTS" 2>/dev/null || write_builtin_defaults "$DEFAULTS"
    fi

    if [ ! -f "$PREVIOUS" ]; then
        cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    fi

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_count() {
    awk -F= '
        /^PROFILE[0-9]+_NAME=/ { n=$1; gsub(/^PROFILE/,"",n); gsub(/_NAME$/,"",n); if (n>max) max=n }
        /^PROFILE[0-9]+_SSID=/ { n=$1; gsub(/^PROFILE/,"",n); gsub(/_SSID$/,"",n); if (n>max) max=n }
        /^PROFILE[0-9]+_PASSWORD=/ { n=$1; gsub(/^PROFILE/,"",n); gsub(/_PASSWORD$/,"",n); if (n>max) max=n }
        END { if (max=="") max=0; print max }
    ' "$CONFIG"
}

get_profile_value() {
    IDX="$1"
    KEY="$2"
    grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" | head -n1 | cut -d= -f2-
}

ensure_config

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"

CURRENT_SSID="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
[ -z "$CURRENT_SSID" ] && CURRENT_SSID="Unknown"

COUNT="$(profile_count)"
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
[ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

E_HOST="$(html_escape "$HOST")"
E_CURRENT_SSID="$(html_escape "$CURRENT_SSID")"
E_LAST="$(html_escape "$LAST")"

cat <<'EOF'
Content-Type: text/html

<!DOCTYPE html>
<html>
<head>
<title>Matrix WiFi Manager</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1040px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}
h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}
.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}
.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}
.profile{background:#fff;border:1px solid #ddd;border-radius:8px;padding:15px;margin:12px 0}
.profile h3{margin:0 0 10px 0;color:#005a9c}
.row{display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:10px;align-items:end}
.field label{display:block;font-size:12px;color:#666;font-weight:bold;margin-bottom:4px}
input[type=text],input[type=password]{width:100%;height:40px;border:1px solid #ccc;border-radius:6px;padding:0 8px;box-sizing:border-box;font-size:14px}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:11px 14px;margin:4px 4px 4px 0;font-size:14px}
.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.row{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}}
</style>
<script>
function confirmApply(name, ssid){
  return confirm('Apply WiFi profile: '+name+'\nSSID: '+ssid+'\n\nThis will reload the 5 GHz WiFi. Continue?');
}
function confirmDelete(name){
  return confirm('Delete profile: '+name+' ?');
}
function confirmPrevious(){
  return confirm('Restore previous profile configuration?');
}
function confirmFactory(){
  return confirm('Restore factory/default profiles?');
}
function togglePw(id){
  var x=document.getElementById(id);
  x.type = x.type === 'password' ? 'text' : 'password';
}
</script>
</head>
<body><div class="page">
EOF

cat <<EOF
<h1>Matrix WiFi Manager</h1>
<div class="topgrid">
  <div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="card"><div class="label">Current 5 GHz SSID</div><div class="value">$E_CURRENT_SSID</div></div>
  <div class="card"><div class="label">Profiles</div><div class="value">$COUNT</div></div>
  <div class="card"><div class="label">Target</div><div class="value">default_radio1</div></div>
</div>

<div class="card">
<h2>Profiles</h2>
EOF

i=1
while [ "$i" -le "$COUNT" ]; do
    NAME="$(get_profile_value "$i" NAME)"
    SSID="$(get_profile_value "$i" SSID)"
    PASS="$(get_profile_value "$i" PASSWORD)"
    RESOLVED="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"

    E_NAME="$(html_escape "$NAME")"
    E_SSID_RAW="$(html_escape "$SSID")"
    E_SSID_RESOLVED="$(html_escape "$RESOLVED")"
    E_PASS="$(html_escape "$PASS")"

    STATUS="<span class=\"muted\">Available</span>"
    [ "$RESOLVED" = "$CURRENT_SSID" ] && STATUS="<span class=\"active\">Active</span>"

    cat <<EOF
<div class="profile">
<h3>Profile $i - $E_NAME</h3>
<form method="get" action="/cgi-bin/wifi_profile_save.sh">
<input type="hidden" name="action" value="save">
<input type="hidden" name="profile" value="$i">
<div class="row">
  <div class="field">
    <label>Name</label>
    <input type="text" name="name" value="$E_NAME">
  </div>
  <div class="field">
    <label>SSID <span class="muted">(resolved: $E_SSID_RESOLVED)</span></label>
    <input type="text" name="ssid" value="$E_SSID_RAW">
  </div>
  <div class="field">
    <label>Password</label>
    <input id="pw$i" type="password" name="password" value="$E_PASS">
  </div>
  <div>
    <button class="btn blue" type="submit">Save</button>
  </div>
</div>
<p>
<button class="btn grey" type="button" onclick="togglePw('pw$i')">Show / Hide</button>
<a class="btn green" onclick="return confirmApply('$E_NAME','$E_SSID_RESOLVED')" href="/cgi-bin/wifi_profile.sh?p=$i">Apply</a>
</p>
<p>Status: $STATUS</p>
</form>
<form method="get" action="/cgi-bin/wifi_profile_save.sh" onsubmit="return confirmDelete('$E_NAME')">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="profile" value="$i">
<button class="btn red" type="submit">Delete Profile</button>
</form>
</div>
EOF
    i=$((i+1))
done

cat <<EOF
<form method="get" action="/cgi-bin/wifi_profile_save.sh">
<input type="hidden" name="action" value="add">
<button class="btn orange" type="submit">+ Add Profile</button>
<a class="btn orange" onclick="return confirmPrevious()" href="/cgi-bin/wifi_profiles_restore_previous.sh">Restore Previous</a>
<a class="btn red" onclick="return confirmFactory()" href="/cgi-bin/wifi_profiles_reset.sh">Restore Factory Defaults</a>
<a class="btn blue" href="/">Back to Toolkit</a>
</form>
</div>

<div class="card">
<h2>Status</h2>
<p class="muted">Last change: $E_LAST</p>
<p class="muted">Active config: <b>$CONFIG</b></p>
<p class="muted">Previous config: <b>$PREVIOUS</b></p>
<p class="muted">Default config: <b>$DEFAULTS</b></p>
<p class="muted">This manager changes only the 5 GHz access point: <b>wireless.default_radio1</b>. The 2.4 GHz SSID stays unchanged.</p>
</div>
</div></body></html>
EOF
