#!/bin/sh
# Matrix WiFi Manager v80 - Professional UI

LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"

ensure_wifi_files

ACTION="$(qs action)"
TYPE="$(qs type)"
IDX="$(qs p)"
IFACE="$(qs iface)"

case "$ACTION" in
    apply) profile_apply "$TYPE" "$IDX" ;;
    restore_matrix) restore_matrix_default_wifi ;;
    enable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='0' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface enabled iface=$IFACE" >> "$LOG"
        ;;
    disable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='1' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface disabled iface=$IFACE" >> "$LOG"
        ;;
    reload_wifi)
        wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi reload requested" >> "$LOG"
        ;;
    remove_client)
        [ -n "$IFACE" ] && wifi_client_remove "$IFACE"
        ;;
esac

VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
[ -z "$VERSION" ] && VERSION="80"
[ -z "$BUILD" ] && BUILD="2026-07-01"
[ -z "$RELEASE" ] && RELEASE="Production LTS"

HOST="$(hostname_value)"
SSID0="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
SSID1="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
DIS0="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
DIS1="$(uci get wireless.default_radio1.disabled 2>/dev/null)"
[ -z "$SSID0" ] && SSID0="Unknown"
[ -z "$SSID1" ] && SSID1="Unknown"
[ -z "$DIS0" ] && DIS0="0"
[ -z "$DIS1" ] && DIS1="0"

ACTIVE_PROFILE="$(active_system_profile_name)"
SC="$(profile_count_file "$SYSTEM_PROFILES")"; [ -z "$SC" ] && SC=0
UC="$(profile_count_file "$USER_PROFILES")"; [ -z "$UC" ] && UC=0
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"; [ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

# Customer WiFi / Survey Mode detection
# Runtime-based: do not show an old saved SSID as connected.
CLIENT_IFACE=""
CLIENT_SSID_CONFIGURED=""
CLIENT_SSID=""
CLIENT_NETWORK=""
CLIENT_DISABLED=""
CLIENT_DEV=""
CLIENT_IP=""
CLIENT_GW=""
SIGNAL="Unknown"
CHANNEL="Unknown"
BSSID="Unknown"
BAND="Unknown"
CUSTOMER_CONNECTED="NO"
CUSTOMER_STATUS_TEXT="Not connected"

uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read X; do
    MODE="$(uci get wireless.${X}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] || continue
    echo "$X|$(uci get wireless.${X}.ssid 2>/dev/null)|$(uci get wireless.${X}.network 2>/dev/null)|$(uci get wireless.${X}.disabled 2>/dev/null)"
    break
done > /tmp/matrix_wifi_client.$$

if [ -s /tmp/matrix_wifi_client.$$ ]; then
    CLIENT_IFACE="$(cut -d'|' -f1 /tmp/matrix_wifi_client.$$)"
    CLIENT_SSID_CONFIGURED="$(cut -d'|' -f2 /tmp/matrix_wifi_client.$$)"
    CLIENT_NETWORK="$(cut -d'|' -f3 /tmp/matrix_wifi_client.$$)"
    CLIENT_DISABLED="$(cut -d'|' -f4 /tmp/matrix_wifi_client.$$)"
fi
rm -f /tmp/matrix_wifi_client.$$ 2>/dev/null

[ -z "$CLIENT_NETWORK" ] && CLIENT_NETWORK="wan1"
[ -z "$CLIENT_DISABLED" ] && CLIENT_DISABLED="0"

CLIENT_DEV="$(ifstatus "$CLIENT_NETWORK" 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)"
[ -z "$CLIENT_DEV" ] && CLIENT_DEV="$CLIENT_IFACE"

IWINFO_OUT=""
[ -n "$CLIENT_DEV" ] && IWINFO_OUT="$(iwinfo "$CLIENT_DEV" info 2>/dev/null)"

# Actual/runtime association only.
CONNECTED_SSID="$(echo "$IWINFO_OUT" | sed -n 's/.*ESSID: *"\([^"]*\)".*/\1/p' | head -1)"
BSSID="$(echo "$IWINFO_OUT" | sed -n 's/.*Access Point: *\([0-9A-Fa-f:][0-9A-Fa-f:]*\).*/\1/p' | head -1)"
SIGNAL="$(echo "$IWINFO_OUT" | awk '/Signal:/ {print $2; exit}')"
CHANNEL="$(echo "$IWINFO_OUT" | awk '/Channel:/ {print $2; exit}')"

# Treat old configured SSID as only configuration, not connection.
if [ -n "$CONNECTED_SSID" ] && [ "$CONNECTED_SSID" != "unknown" ] && [ "$CONNECTED_SSID" != "off/any" ] && [ -n "$BSSID" ] && [ "$BSSID" != "Not-Associated" ] && [ "$BSSID" != "00:00:00:00:00:00" ]; then
    CLIENT_SSID="$CONNECTED_SSID"
    CLIENT_IP="$(ifstatus "$CLIENT_NETWORK" 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)"
    CLIENT_GW="$(ifstatus "$CLIENT_NETWORK" 2>/dev/null | grep '"nexthop"' | head -1 | cut -d'"' -f4)"
    if [ -n "$CLIENT_IP" ]; then
        CUSTOMER_CONNECTED="CONNECTED"
        CUSTOMER_STATUS_TEXT="Connected"
    else
        CUSTOMER_CONNECTED="ASSOCIATED"
        CUSTOMER_STATUS_TEXT="Associated, no IP"
    fi
else
    CLIENT_SSID=""
    CLIENT_IP=""
    CLIENT_GW=""
    SIGNAL="Unknown"
    CHANNEL="Unknown"
    BSSID="Unknown"
    if [ -n "$CLIENT_IFACE" ] && [ "$CLIENT_DISABLED" != "1" ] && [ -n "$CLIENT_SSID_CONFIGURED" ]; then
        CUSTOMER_CONNECTED="CONFIGURED"
        CUSTOMER_STATUS_TEXT="Configured only"
    else
        CUSTOMER_CONNECTED="NO"
        CUSTOMER_STATUS_TEXT="Not connected"
    fi
fi

[ -z "$CLIENT_SSID" ] && CLIENT_SSID="-"
[ -z "$SIGNAL" ] && SIGNAL="Unknown"
[ -z "$CHANNEL" ] && CHANNEL="Unknown"
[ -z "$BSSID" ] && BSSID="Unknown"

case "$CHANNEL" in
    ''|Unknown|Client) BAND="Unknown" ;;
    [1-9]|1[0-4]) BAND="2.4 GHz" ;;
    *) BAND="5 GHz" ;;
esac

INTERNET="Offline"
ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && INTERNET="Connected"

SIGNAL_RATING="Unknown"
HEALTH="Not Connected"
HEALTH_CLASS="warn"
SURVEY_MODE="Inactive"
if [ "$CUSTOMER_CONNECTED" = "CONNECTED" ]; then
    SURVEY_MODE="Active"
    HEALTH="Good"
    HEALTH_CLASS="ok"
    SIG_NUM="$(echo "$SIGNAL" | sed 's/[^0-9-]//g')"
    if [ -n "$SIG_NUM" ]; then
        if [ "$SIG_NUM" -ge -55 ]; then SIGNAL_RATING="Excellent"; HEALTH="Excellent"
        elif [ "$SIG_NUM" -ge -65 ]; then SIGNAL_RATING="Good"; HEALTH="Good"
        elif [ "$SIG_NUM" -ge -75 ]; then SIGNAL_RATING="Fair"; HEALTH="Fair"; HEALTH_CLASS="warn"
        else SIGNAL_RATING="Poor"; HEALTH="Poor"; HEALTH_CLASS="fail"
        fi
    fi
elif [ "$CUSTOMER_CONNECTED" = "ASSOCIATED" ]; then
    SURVEY_MODE="Associated"
    HEALTH="No IP"
    HEALTH_CLASS="warn"
elif [ "$CUSTOMER_CONNECTED" = "CONFIGURED" ]; then
    SURVEY_MODE="Configured"
    HEALTH="Configured only"
    HEALTH_CLASS="warn"
fi

# WAN Connection detection.
# Runtime/default-route based. Never use old saved WiFi config as active WAN.
WAN_IFACE=""
WAN_STATUS="Disconnected"
WAN_DEVICE=""
WAN_IP=""
WAN_GW=""
WAN_DNS=""
WAN_TYPE="Unknown"
WAN_LATENCY="Not tested"
WAN_LOSS="Not tested"
WAN_JITTER="Not tested"
WAN_QUALITY="Unknown"

DEFAULT_ROUTE="$(ip route 2>/dev/null | awk '$1=="default"{print; exit}')"
ACTIVE_GW="$(echo "$DEFAULT_ROUTE" | awk '{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}')"
ACTIVE_DEVICE="$(echo "$DEFAULT_ROUTE" | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
ACTIVE_IP=""
[ -n "$ACTIVE_DEVICE" ] && ACTIVE_IP="$(ip -4 addr show "$ACTIVE_DEVICE" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"

# Ethernet WAN details.
ETH_WAN_IFACE="wan"
ETH_WAN_DEVICE="$(ifstatus wan 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)"
[ -z "$ETH_WAN_DEVICE" ] && ETH_WAN_DEVICE="eth1"
ETH_WAN_IP="$(ifstatus wan 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)"
[ -z "$ETH_WAN_IP" ] && ETH_WAN_IP="$(ip -4 addr show "$ETH_WAN_DEVICE" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
ETH_WAN_GW="$(ifstatus wan 2>/dev/null | grep '"nexthop"' | head -1 | cut -d'"' -f4)"
[ -z "$ETH_WAN_GW" ] && [ "$ACTIVE_DEVICE" = "$ETH_WAN_DEVICE" ] && ETH_WAN_GW="$ACTIVE_GW"
ETH_WAN_STATUS="Disconnected"
[ -n "$ETH_WAN_IP" ] && ETH_WAN_STATUS="Connected"
ETH_WAN_ROLE="Standby"
if [ -n "$ETH_WAN_IP" ] && { [ "$ACTIVE_DEVICE" = "$ETH_WAN_DEVICE" ] || [ "$ACTIVE_IP" = "$ETH_WAN_IP" ]; }; then
    ETH_WAN_ROLE="Active"
fi

# Customer WiFi / STA WAN details. Only runtime connected WiFi can be active.
CUSTOMER_WAN_IFACE="$CLIENT_NETWORK"
[ -z "$CUSTOMER_WAN_IFACE" ] && CUSTOMER_WAN_IFACE="wan1"
CUSTOMER_WAN_DEVICE="$CLIENT_DEV"
CUSTOMER_WAN_IP="$CLIENT_IP"
CUSTOMER_WAN_GW="$CLIENT_GW"
CUSTOMER_WAN_STATUS="Disconnected"
if [ "$CUSTOMER_CONNECTED" = "CONNECTED" ]; then
    CUSTOMER_WAN_STATUS="Connected"
elif [ "$CUSTOMER_CONNECTED" = "ASSOCIATED" ]; then
    CUSTOMER_WAN_STATUS="Associated no IP"
elif [ "$CUSTOMER_CONNECTED" = "CONFIGURED" ]; then
    CUSTOMER_WAN_STATUS="Configured only"
fi

CUSTOMER_WAN_ROLE="Standby"
if [ "$CUSTOMER_CONNECTED" = "CONNECTED" ] && [ -n "$CUSTOMER_WAN_DEVICE" ] && [ "$ACTIVE_DEVICE" = "$CUSTOMER_WAN_DEVICE" ]; then
    CUSTOMER_WAN_ROLE="Active"
elif [ "$CUSTOMER_CONNECTED" = "CONNECTED" ] && [ -n "$CUSTOMER_WAN_IP" ] && [ "$ACTIVE_IP" = "$CUSTOMER_WAN_IP" ]; then
    CUSTOMER_WAN_ROLE="Active"
fi

# Active WAN summary based on default route.
if [ "$CUSTOMER_WAN_ROLE" = "Active" ]; then
    WAN_TYPE="Customer WiFi (WAN over WiFi)"
    WAN_IFACE="$CUSTOMER_WAN_IFACE"
    WAN_DEVICE="$CUSTOMER_WAN_DEVICE"
    WAN_IP="$CUSTOMER_WAN_IP"
    WAN_GW="$CUSTOMER_WAN_GW"
elif [ "$ETH_WAN_ROLE" = "Active" ]; then
    WAN_TYPE="Ethernet WAN"
    WAN_IFACE="$ETH_WAN_IFACE"
    WAN_DEVICE="$ETH_WAN_DEVICE"
    WAN_IP="$ETH_WAN_IP"
    WAN_GW="$ETH_WAN_GW"
elif echo "$ACTIVE_DEVICE" | grep -Eq 'wwan|qmimux|usb|mobile|lte'; then
    WAN_TYPE="LTE / Mobile WAN"
    WAN_IFACE="mobile"
    WAN_DEVICE="$ACTIVE_DEVICE"
    WAN_IP="$ACTIVE_IP"
    WAN_GW="$ACTIVE_GW"
else
    WAN_TYPE="WAN"
    WAN_IFACE="Unknown"
    WAN_DEVICE="$ACTIVE_DEVICE"
    WAN_IP="$ACTIVE_IP"
    WAN_GW="$ACTIVE_GW"
fi

[ -z "$WAN_DEVICE" ] && WAN_DEVICE="Unknown"
[ -z "$WAN_IP" ] && WAN_IP="No IP"
[ -z "$WAN_GW" ] && WAN_GW="Unknown"
[ "$WAN_IP" != "No IP" ] && WAN_STATUS="Connected"

WAN_DNS="$(ifstatus "$WAN_IFACE" 2>/dev/null | grep '"dns-server"' -A 20 | grep -oE '[0-9]+(\.[0-9]+){3}' | sort -u | tr '\n' ' ' | sed 's/ *$//')"
[ -z "$WAN_DNS" ] && WAN_DNS="$(awk '/^nameserver /{print $2}' /tmp/resolv.conf.auto /tmp/resolv.conf.d/resolv.conf.auto /etc/resolv.conf 2>/dev/null | sort -u | tr '\n' ' ' | sed 's/ *$//')"
[ -z "$WAN_DNS" ] && WAN_DNS="$(uci show network 2>/dev/null | grep '\.dns=' | sed "s/.*='//;s/'//" | tr ' ' '\n' | sort -u | tr '\n' ' ' | sed 's/ *$//')"
[ -z "$WAN_DNS" ] && WAN_DNS="Not detected"

PING_OUT="$(ping -c 5 -W 2 8.8.8.8 2>/dev/null)"
LOSS_VAL="$(echo "$PING_OUT" | awk -F',' '/packet loss/ {gsub(/% packet loss/,"",$3); gsub(/ /,"",$3); print $3}')"
AVG_VAL="$(echo "$PING_OUT" | awk -F'/' '/round-trip|rtt/ {print $5}')"
MIN_VAL="$(echo "$PING_OUT" | awk -F'/' '/round-trip|rtt/ {print $4}')"
MAX_VAL="$(echo "$PING_OUT" | awk -F'/' '/round-trip|rtt/ {print $6}')"
if [ -n "$AVG_VAL" ]; then
    WAN_LATENCY="$(awk "BEGIN {printf \"%.1f ms\", $AVG_VAL}" 2>/dev/null)"
    [ -z "$WAN_LATENCY" ] && WAN_LATENCY="${AVG_VAL} ms"
fi
[ -n "$LOSS_VAL" ] && WAN_LOSS="${LOSS_VAL}%"
if [ -n "$MIN_VAL" ] && [ -n "$MAX_VAL" ]; then
    WAN_JITTER="$(awk "BEGIN {printf \"%.1f ms\", ($MAX_VAL-$MIN_VAL)}" 2>/dev/null)"
fi

WAN_QUALITY="Unknown"
if [ "$LOSS_VAL" = "0" ] && [ -n "$AVG_VAL" ]; then
    AVG_INT="$(printf '%.0f' "$AVG_VAL" 2>/dev/null)"
    if [ "$AVG_INT" -le 30 ]; then WAN_QUALITY="Excellent"
    elif [ "$AVG_INT" -le 70 ]; then WAN_QUALITY="Good"
    else WAN_QUALITY="Fair"; fi
elif [ -n "$LOSS_VAL" ]; then
    WAN_QUALITY="Warning"
fi

PUBLIC_IP=""
PUBLIC_IP="$(nslookup myip.opendns.com resolver1.opendns.com 2>/dev/null | awk '/^Address[ \t]*[0-9]*:/ {ip=$NF} END{print ip}')"
echo "$PUBLIC_IP" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || PUBLIC_IP=""
[ -z "$PUBLIC_IP" ] && PUBLIC_IP="$(wget -qO- -T 4 http://ifconfig.me/ip 2>/dev/null | head -n1 | tr -d ' \r\n')"
echo "$PUBLIC_IP" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || PUBLIC_IP=""
[ -z "$PUBLIC_IP" ] && PUBLIC_IP="$(wget -qO- -T 4 http://api.ipify.org 2>/dev/null | head -n1 | tr -d ' \r\n')"
echo "$PUBLIC_IP" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || PUBLIC_IP=""
[ -z "$PUBLIC_IP" ] && PUBLIC_IP="$(wget -qO- -T 4 http://icanhazip.com 2>/dev/null | head -n1 | tr -d ' \r\n')"
echo "$PUBLIC_IP" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || PUBLIC_IP=""
[ -z "$PUBLIC_IP" ] && PUBLIC_IP="Not detected"

ROUTER_WIFI="ACTIVE"
[ "$DIS0" = "1" ] && [ "$DIS1" = "1" ] && ROUTER_WIFI="DISABLED"

E_HOST="$(html_escape "$HOST")"
E_SSID0="$(html_escape "$SSID0")"
E_SSID1="$(html_escape "$SSID1")"
E_ACTIVE="$(html_escape "$ACTIVE_PROFILE")"
E_LAST="$(html_escape "$LAST")"
E_CLIENT_SSID="$(html_escape "$CLIENT_SSID")"
E_CLIENT_IP="$(html_escape "$CLIENT_IP")"
E_CLIENT_GW="$(html_escape "$CLIENT_GW")"
E_CLIENT_IFACE="$(html_escape "$CLIENT_IFACE")"
E_CLIENT_NETWORK="$(html_escape "$CLIENT_NETWORK")"
E_SIGNAL="$(html_escape "$SIGNAL")"
E_SIGNAL_RATING="$(html_escape "$SIGNAL_RATING")"
E_CHANNEL="$(html_escape "$CHANNEL")"
E_BAND="$(html_escape "$BAND")"
E_BSSID="$(html_escape "$BSSID")"

E_WAN_IFACE="$(html_escape "$WAN_IFACE")"
E_WAN_STATUS="$(html_escape "$WAN_STATUS")"
E_WAN_DEVICE="$(html_escape "$WAN_DEVICE")"
E_WAN_IP="$(html_escape "$WAN_IP")"
E_WAN_GW="$(html_escape "$WAN_GW")"
E_WAN_DNS="$(html_escape "$WAN_DNS")"
E_WAN_TYPE="$(html_escape "$WAN_TYPE")"
E_PUBLIC_IP="$(html_escape "$PUBLIC_IP")"
E_WAN_LATENCY="$(html_escape "$WAN_LATENCY")"
E_WAN_LOSS="$(html_escape "$WAN_LOSS")"
E_WAN_JITTER="$(html_escape "$WAN_JITTER")"
E_WAN_QUALITY="$(html_escape "$WAN_QUALITY")"

E_ACTIVE_DEVICE="$(html_escape "$ACTIVE_DEVICE")"
E_ACTIVE_GW="$(html_escape "$ACTIVE_GW")"
E_ETH_WAN_STATUS="$(html_escape "$ETH_WAN_STATUS")"
E_ETH_WAN_ROLE="$(html_escape "$ETH_WAN_ROLE")"
E_ETH_WAN_IP="$(html_escape "$ETH_WAN_IP")"
E_ETH_WAN_GW="$(html_escape "$ETH_WAN_GW")"
E_ETH_WAN_DEVICE="$(html_escape "$ETH_WAN_DEVICE")"
E_CUSTOMER_WAN_STATUS="$(html_escape "$CUSTOMER_WAN_STATUS")"
E_CUSTOMER_WAN_ROLE="$(html_escape "$CUSTOMER_WAN_ROLE")"
E_CUSTOMER_WAN_IP="$(html_escape "$CUSTOMER_WAN_IP")"
E_CUSTOMER_WAN_GW="$(html_escape "$CUSTOMER_WAN_GW")"
E_CUSTOMER_WAN_DEVICE="$(html_escape "$CUSTOMER_WAN_DEVICE")"
E_CUSTOMER_STATUS_TEXT="$(html_escape "$CUSTOMER_STATUS_TEXT")"
E_CLIENT_SSID_CONFIGURED="$(html_escape "$CLIENT_SSID_CONFIGURED")"
E_DEFAULT_ROUTE="$(html_escape "$DEFAULT_ROUTE")"



echo "Content-Type: text/html; charset=UTF-8"
echo ""
cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix WiFi Manager v80</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--blue:#005a9c;--purple:#6f42c1;--yellow:#f0ad4e;--tools:#667085;--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1320px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}
.status-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:18px 0}.status-card{background:#fff;border:1px solid var(--border);border-radius:16px;padding:15px;box-shadow:var(--shadow)}.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:800}.value{margin-top:8px;font-size:20px;font-weight:900;word-break:break-word}.ok{color:var(--ok)}.warn{color:var(--warn)}.fail{color:var(--fail)}
.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);overflow:hidden;margin:16px 0}.card-head{padding:14px 16px;color:#fff;font-weight:900;letter-spacing:.03em;text-transform:uppercase;font-size:14px;background:var(--blue)}.card-head.green{background:var(--ok)}.card-head.purple{background:var(--purple)}.card-head.yellow{background:var(--yellow);color:#222}.card-head.grey{background:var(--tools)}.card-body{padding:16px}.card-desc{color:var(--muted);font-size:13px;line-height:1.45;margin:0 0 12px}
.metric-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:12px}.metric-label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800}.metric-value{font-size:18px;font-weight:900;margin-top:5px;word-break:break-word}.metric-extra{font-size:12px;color:var(--muted);margin-top:3px}
.badge{display:inline-block;border-radius:999px;padding:6px 10px;font-weight:900;font-size:12px}.badge.active,.badge.connected{background:#dff3e4;color:#137333;border:1px solid #a8dab5}.badge.same{background:#fff4ce;color:#8a5a00;border:1px solid #ead28a}.badge.available{background:#e9f3ff;color:#005a9c;border:1px solid #b9d7f4}.badge.disabled{background:#fde2e2;color:#a10000;border:1px solid #f3b3b3}.badge.warn{background:#fff4ce;color:#8a5a00;border:1px solid #ead28a}.badge.fail{background:#fde2e2;color:#a10000;border:1px solid #f3b3b3}
.btn{display:inline-block;border:none;border-radius:12px;color:white!important;text-decoration:none!important;font-weight:800;cursor:pointer;padding:11px 14px;margin:4px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
.profile-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.profile-simple-card{background:#fff;border:1px solid #d6d6d6;border-radius:14px;padding:15px;box-shadow:0 1px 4px rgba(0,0,0,.05)}.profile-simple-header{display:flex;justify-content:space-between;gap:10px;align-items:center;border-bottom:1px solid #eee;padding-bottom:10px;margin-bottom:10px}.profile-simple-title{font-size:18px;font-weight:900;color:#005a9c}.profile-simple-row{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid #f0f0f0;padding:7px 0}.profile-simple-row span{color:#666;font-weight:bold}.profile-actions{margin-top:12px}
table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid var(--border);padding:10px;text-align:left;vertical-align:top}th{background:#f0f6fb;color:#005a9c}.muted{color:var(--muted);font-size:13px}.advanced{margin-top:14px}.advanced summary{cursor:pointer;font-weight:900;color:#005a9c;padding:12px;background:#f0f6fb;border-radius:12px}.footer-actions{text-align:center;margin-top:18px}.survey-note{background:#eefaf0;border:1px solid #b6e2c0;border-left:6px solid var(--ok);padding:13px;border-radius:13px;line-height:1.45}
@media(max-width:1100px){.status-grid{grid-template-columns:repeat(2,1fr)}.metric-grid{grid-template-columns:repeat(2,1fr)}.profile-grid{grid-template-columns:1fr 1fr}}@media(max-width:720px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn{width:100%;text-align:center}.status-grid,.metric-grid,.profile-grid{grid-template-columns:1fr}.profile-simple-header{display:block}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function confirmApply(n){return confirm('Apply profile: '+n+'\\n\\nWiFi will reload. Continue?');}
function confirmRestore(){return confirm('Restore Matrix Default WiFi?\\n\\n2.4 GHz = {HOSTNAME}_2G\\n5 GHz = {HOSTNAME}_5G\\n\\nWiFi will reload. Continue?');}
function confirmReload(){return confirm('Reload WiFi now?');}
function confirmDelete(n){return confirm('Delete user profile: '+n+' ?');}
function confirmIface(a,i,s){return confirm(a+' interface?\\n\\nInterface: '+i+'\\nSSID: '+s+'\\n\\nWiFi will reload. Continue?');}
function confirmRemoveClient(i,s,n){return confirm('Disconnect Customer WiFi?\\n\\nSSID: '+s+'\\nInterface: '+i+'\\nNetwork: '+n+'\\n\\nRouter WiFi Access Points will NOT be changed. Continue?');}
</script>
</head>
<body>
<div class="page">
<section class="hero">
  <div>
    <h1>Matrix WiFi Manager v80</h1>
    <div class="sub">Professional WiFi control for router SSIDs, customer WiFi and survey mode</div>
    <div class="contact">Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE</div>
    <div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
  </div>
  <a class="top-btn" href="/">Back to Toolkit</a>
</section>

<section class="status-grid">
  <div class="status-card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="status-card"><div class="label">Current Profile</div><div class="value">$E_ACTIVE</div></div>
  <div class="status-card"><div class="label">Router WiFi</div><div class="value $([ "$ROUTER_WIFI" = "ACTIVE" ] && echo ok || echo fail)">$ROUTER_WIFI</div></div>
  <div class="status-card"><div class="label">Customer WiFi</div><div class="value $HEALTH_CLASS">$([ "$CUSTOMER_CONNECTED" = "CONNECTED" ] && echo CONNECTED || echo "$CUSTOMER_CONNECTED")</div></div>
  <div class="status-card"><div class="label">Survey Mode</div><div class="value $HEALTH_CLASS">$SURVEY_MODE</div></div>
</section>

<section class="card">
  <div class="card-head green">Customer WiFi Connection</div>
  <div class="card-body">
    <p class="card-desc">This is the temporary customer WiFi connection used by the router for WAN testing and the Matrix WiFi Survey.</p>
    <div class="metric-grid">
      <div class="metric"><div class="metric-label">Status</div><div class="metric-value $HEALTH_CLASS">$E_CUSTOMER_STATUS_TEXT</div><div class="metric-extra">Runtime WiFi status</div></div>
      <div class="metric"><div class="metric-label">Connected SSID</div><div class="metric-value">$E_CLIENT_SSID</div><div class="metric-extra">Configured: $E_CLIENT_SSID_CONFIGURED</div></div>
      <div class="metric"><div class="metric-label">Band / Channel</div><div class="metric-value">$E_BAND</div><div class="metric-extra">Channel $E_CHANNEL</div></div>
      <div class="metric"><div class="metric-label">Signal</div><div class="metric-value">$E_SIGNAL dBm</div><div class="metric-extra">$E_SIGNAL_RATING</div></div>
      <div class="metric"><div class="metric-label">IP Address</div><div class="metric-value">$E_CLIENT_IP</div><div class="metric-extra">WAN over WiFi</div></div>
      <div class="metric"><div class="metric-label">Gateway</div><div class="metric-value">$E_CLIENT_GW</div><div class="metric-extra">Customer network</div></div>
      <div class="metric"><div class="metric-label">Internet</div><div class="metric-value">$INTERNET</div><div class="metric-extra">Ping test</div></div>
      <div class="metric"><div class="metric-label">Health</div><div class="metric-value $HEALTH_CLASS">$HEALTH</div><div class="metric-extra">Connection health</div></div>
    </div>
    <p class="survey-note"><b>Survey Mode:</b> the router is temporarily connected to the customer's WiFi. Router WiFi Access Points remain active unless you disable them manually.</p>
    <p>
      <a class="btn blue" href="/cgi-bin/wifi_manager.sh?nocache=$(date +%s)">Refresh Status</a>
      $([ -n "$CLIENT_IFACE" ] && echo "<a class=\"btn red\" onclick=\"return confirmRemoveClient('$E_CLIENT_IFACE','$E_CLIENT_SSID','$E_CLIENT_NETWORK')\" href=\"/cgi-bin/wifi_manager.sh?action=remove_client&iface=$E_CLIENT_IFACE&nocache=$(date +%s)\">Disconnect Customer WiFi</a>")
    </p>
  </div>
</section>


<section class="card">
  <div class="card-head">WAN Connection</div>
  <div class="card-body">
    <p class="card-desc">This shows the real active internet path based on the router default route. Ethernet and Customer WiFi can both be connected, but only one is Active.</p>

    <div class="metric-grid">
      <div class="metric"><div class="metric-label">Active Internet Path</div><div class="metric-value">$E_WAN_TYPE</div><div class="metric-extra">Default route device: $E_ACTIVE_DEVICE</div></div>
      <div class="metric"><div class="metric-label">WAN Status</div><div class="metric-value $([ "$WAN_STATUS" = "Connected" ] && echo ok || echo fail)">$E_WAN_STATUS</div><div class="metric-extra">Gateway: $E_WAN_GW</div></div>
      <div class="metric"><div class="metric-label">WAN IP</div><div class="metric-value">$E_WAN_IP</div><div class="metric-extra">Router active WAN address</div></div>
      <div class="metric"><div class="metric-label">DNS</div><div class="metric-value">$E_WAN_DNS</div><div class="metric-extra">Configured DNS servers</div></div>
    </div>

    <div class="metric-grid" style="margin-top:12px">
      <div class="metric"><div class="metric-label">Ethernet WAN</div><div class="metric-value">$E_ETH_WAN_ROLE</div><div class="metric-extra">$E_ETH_WAN_STATUS | $E_ETH_WAN_IP | $E_ETH_WAN_DEVICE</div></div>
      <div class="metric"><div class="metric-label">Customer WiFi WAN</div><div class="metric-value">$E_CUSTOMER_WAN_ROLE</div><div class="metric-extra">$E_CUSTOMER_WAN_STATUS | $E_CLIENT_SSID | $E_CUSTOMER_WAN_IP</div></div>
      <div class="metric"><div class="metric-label">Public IP</div><div class="metric-value">$E_PUBLIC_IP</div><div class="metric-extra">External internet IP</div></div>
      <div class="metric"><div class="metric-label">Internet Quality</div><div class="metric-value">$E_WAN_QUALITY</div><div class="metric-extra">Quick 5-ping sample</div></div>
    </div>

    <div class="metric-grid" style="margin-top:12px">
      <div class="metric"><div class="metric-label">Latency</div><div class="metric-value">$E_WAN_LATENCY</div><div class="metric-extra">Average to 8.8.8.8</div></div>
      <div class="metric"><div class="metric-label">Packet Loss</div><div class="metric-value">$E_WAN_LOSS</div><div class="metric-extra">Loss to 8.8.8.8</div></div>
      <div class="metric"><div class="metric-label">Jitter</div><div class="metric-value">$E_WAN_JITTER</div><div class="metric-extra">Max minus min latency</div></div>
      <div class="metric"><div class="metric-label">Default Gateway</div><div class="metric-value">$E_ACTIVE_GW</div><div class="metric-extra">Route: $E_DEFAULT_ROUTE</div></div>
    </div>
  </div>
</section>

<section class="card">
  <div class="card-head">Router WiFi Networks</div>
  <div class="card-body">
    <p class="card-desc">These are WiFi networks broadcast by this Matrix router. They are separate from the customer WiFi connection.</p>
    <div class="metric-grid">
      <div class="metric"><div class="metric-label">2.4 GHz Router WiFi</div><div class="metric-value">$E_SSID0</div><div class="metric-extra">$([ "$DIS0" = "1" ] && echo DISABLED || echo Broadcasting)</div></div>
      <div class="metric"><div class="metric-label">5 GHz Router WiFi</div><div class="metric-value">$E_SSID1</div><div class="metric-extra">$([ "$DIS1" = "1" ] && echo DISABLED || echo Broadcasting)</div></div>
      <div class="metric"><div class="metric-label">Current Profile</div><div class="metric-value">$E_ACTIVE</div><div class="metric-extra">Applied Matrix profile</div></div>
      <div class="metric"><div class="metric-label">Quick Action</div><div class="metric-value"><a class="btn red" onclick="return confirmRestore()" href="/cgi-bin/wifi_manager.sh?action=restore_matrix&nocache=$(date +%s)">Restore Matrix Default</a></div><div class="metric-extra">Reset router SSIDs</div></div>
    </div>
  </div>
</section>

<section class="card">
  <div class="card-head purple">Matrix System Profiles</div>
  <div class="card-body">
    <p class="card-desc">These profiles are always present on every new router and cannot be deleted.</p>
    <div class="profile-grid">
EOF

i=1
while [ "$i" -le "$SC" ]; do
    system_profile_card "$i"
    i=$((i+1))
done

cat <<EOF
    </div>
  </div>
</section>

<section class="card">
  <div class="card-head yellow">Customer / User Profiles</div>
  <div class="card-body">
    <p class="card-desc">Create your own WiFi profiles for customers, service or temporary testing.</p>
EOF

if [ "$UC" -eq 0 ]; then
    echo '<p class="muted">No user profiles yet.</p>'
else
    echo '<div class="profile-grid">'
    i=1
    while [ "$i" -le "$UC" ]; do
        user_profile_card "$i"
        i=$((i+1))
    done
    echo '</div>'
fi

cat <<EOF
    <p><a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add&type=user">+ Add User Profile</a></p>
  </div>
</section>

<details class="advanced">
<summary>Advanced WiFi Details</summary>

<section class="card">
  <div class="card-head grey">Router Access Points</div>
  <div class="card-body">
    <p class="card-desc">These are SSIDs broadcast by the router.</p>
    <table>
      <tr><th>Interface</th><th>Device</th><th>SSID</th><th>Status</th><th>Action</th></tr>
EOF

uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    MODE="$(uci get wireless.${IFACE_NAME}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] && continue
    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    DEVICE="$(uci get wireless.${IFACE_NAME}.device 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"; [ -z "$DEVICE" ] && DEVICE="-"; [ -z "$DISABLED" ] && DISABLED="0"
    E_IFACE="$(html_escape "$IFACE_NAME")"; E_SSID="$(html_escape "$SSID")"; E_DEVICE="$(html_escape "$DEVICE")"
    if [ "$DISABLED" = "1" ]; then
        STATUS='<span class="fail">Disabled</span>'
        BTN="<a class=\"btn green\" onclick=\"return confirmIface('Enable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=enable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Enable</a>"
    else
        STATUS='<span class="ok">Broadcasting</span>'
        BTN="<a class=\"btn red\" onclick=\"return confirmIface('Disable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=disable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Disable</a>"
    fi
    echo "<tr><td><b>$E_IFACE</b></td><td>$E_DEVICE</td><td>$E_SSID</td><td>$STATUS</td><td>$BTN</td></tr>"
done

cat <<EOF
    </table>
  </div>
</section>

<section class="card">
  <div class="card-head grey">Customer WiFi Connection Details</div>
  <div class="card-body">
    <p class="card-desc">Technical view of WAN over WiFi / survey client mode.</p>
    <table>
      <tr><th>Interface</th><th>Connected SSID</th><th>Mode</th><th>WAN Network</th><th>Status</th><th>Action</th></tr>
EOF

uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    MODE="$(uci get wireless.${IFACE_NAME}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] || continue
    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    NETWORK="$(uci get wireless.${IFACE_NAME}.network 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"; [ -z "$NETWORK" ] && NETWORK="-"; [ -z "$DISABLED" ] && DISABLED="0"
    E_IFACE="$(html_escape "$IFACE_NAME")"; E_SSID="$(html_escape "$SSID")"; E_NETWORK="$(html_escape "$NETWORK")"
    if [ "$DISABLED" = "1" ]; then STATUS='<span class="fail">Disabled</span>'; else STATUS='<span class="ok">Connected / Configured</span>'; fi
    BTN="<a class=\"btn red\" onclick=\"return confirmRemoveClient('$E_IFACE','$E_SSID','$E_NETWORK')\" href=\"/cgi-bin/wifi_manager.sh?action=remove_client&iface=$E_IFACE&nocache=$(date +%s)\">Disconnect</a>"
    echo "<tr><td><b>$E_IFACE</b></td><td>$E_SSID</td><td>STA Client</td><td>$E_NETWORK</td><td>$STATUS</td><td>$BTN</td></tr>"
done

cat <<EOF
    </table>
    <p><a class="btn grey" onclick="return confirmReload()" href="/cgi-bin/wifi_manager.sh?action=reload_wifi&nocache=$(date +%s)">Reload WiFi</a></p>
    <p class="muted">Last change: $E_LAST</p>
    <p class="muted">System profiles: <b>$SYSTEM_PROFILES</b></p>
    <p class="muted">User profiles: <b>$USER_PROFILES</b></p>
  </div>
</section>
</details>

<div class="footer-actions">
  <a class="btn blue" href="/">Back to Toolkit</a>
</div>

</div>
</body>
</html>
EOF
