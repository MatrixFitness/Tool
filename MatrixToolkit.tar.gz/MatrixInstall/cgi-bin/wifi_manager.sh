#!/bin/sh
# Matrix Toolkit v60 - WiFi Manager
# Field-based profile manager. No textarea editor.
# Stores profiles in /usr/local/matrix/matrix_wifi_profiles.conf

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
OLD_CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    printf '%s' "$1" | sed \
        -e 's/+/ /g' \
        -e 's/%0[Dd]//g' \
        -e 's/%0[Aa]/ /g' \
        -e 's/%09/ /g' \
        -e 's/%20/ /g' \
        -e 's/%21/!/g' \
        -e 's/%22/"/g' \
        -e 's/%23/#/g' \
        -e 's/%24/$/g' \
        -e 's/%25/%/g' \
        -e 's/%26/\&/g' \
        -e "s/%27/'/g" \
        -e 's/%28/(/g' \
        -e 's/%29/)/g' \
        -e 's/%2[Aa]/*/g' \
        -e 's/%2[Bb]/+/g' \
        -e 's/%2[Cc]/,/g' \
        -e 's/%2[Dd]/-/g' \
        -e 's/%2[Ee]/./g' \
        -e 's/%2[Ff]/\//g' \
        -e 's/%3[Aa]/:/g' \
        -e 's/%3[Bb]/;/g' \
        -e 's/%3[Cc]/</g' \
        -e 's/%3[Dd]/=/g' \
        -e 's/%3[Ee]/>/g' \
        -e 's/%3[Ff]/?/g' \
        -e 's/%40/@/g' \
        -e 's/%5[Bb]/[/g' \
        -e 's/%5[Dd]/]/g' \
        -e 's/%5[Ff]/_/g' \
        -e 's/%7[Bb]/{/g' \
        -e 's/%7[Cc]/|/g' \
        -e 's/%7[Dd]/}/g'
}

get_qs() {
    KEY="$1"
    printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | sed -n "s/^${KEY}=//p" | head -n1 | while IFS= read -r v; do url_decode "$v"; done
}

write_builtin_defaults() {
    cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
DEFEOF
}

ensure_config() {
    mkdir -p /usr/local/matrix

    if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then
        cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null
    fi

    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then
            cp -f "$DEFAULTS" "$CONFIG" 2>/dev/null
        else
            write_builtin_defaults "$CONFIG"
        fi
    fi

    if [ ! -f "$DEFAULTS" ]; then
        cp -f "$CONFIG" "$DEFAULTS" 2>/dev/null || write_builtin_defaults "$DEFAULTS"
    fi

    if [ ! -f "$PREVIOUS" ]; then
        cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    fi

    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_name() { grep "^PROFILE${1}_NAME=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-; }
profile_ssid() { grep "^PROFILE${1}_SSID=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-; }
profile_pass() { grep "^PROFILE${1}_PASSWORD=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-; }

max_profile() {
    awk -F'[=_]' '/^PROFILE[0-9]+_NAME=|^PROFILE[0-9]+_SSID=|^PROFILE[0-9]+_PASSWORD=/ { if ($1 ~ /^PROFILE[0-9]+$/) { n=$1; sub("PROFILE","",n); if (n+0>max) max=n+0 } } END{print max+0}' "$CONFIG" 2>/dev/null
}

backup_config() {
    cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null
    cp -f "$CONFIG" "$CONFIG.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
}

save_profile() {
    P="$(get_qs p)"
    NAME="$(get_qs name)"
    SSID="$(get_qs ssid)"
    PASS="$(get_qs password)"

    case "$P" in *[!0-9]*|'') MESSAGE="Invalid profile number."; CLASS="err"; return ;; esac
    if [ -z "$NAME" ] || [ -z "$SSID" ] || [ -z "$PASS" ]; then
        MESSAGE="Name, SSID and Password are required. Nothing saved."
        CLASS="err"
        return
    fi

    ensure_config
    backup_config

    MAX="$(max_profile)"
    [ -z "$MAX" ] && MAX=0
    [ "$P" -gt "$MAX" ] && MAX="$P"
    TMP="/tmp/matrix_wifi_profiles.$$"
    : > "$TMP"

    i=1
    while [ "$i" -le "$MAX" ]; do
        if [ "$i" = "$P" ]; then
            N="$NAME"; S="$SSID"; K="$PASS"
        else
            N="$(profile_name "$i")"; S="$(profile_ssid "$i")"; K="$(profile_pass "$i")"
        fi

        if [ -n "$N" ] || [ -n "$S" ] || [ -n "$K" ]; then
            {
                echo "PROFILE${i}_NAME=$N"
                echo "PROFILE${i}_SSID=$S"
                echo "PROFILE${i}_PASSWORD=$K"
                echo ""
            } >> "$TMP"
        fi
        i=$((i+1))
    done

    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    MESSAGE="Profile $P saved."
    CLASS="ok"
    echo "$(date '+%Y-%m-%d %H:%M:%S') Saved profile $P ($NAME) SSID=$SSID" >> "$LOG"
}

delete_profile() {
    P="$(get_qs p)"
    case "$P" in *[!0-9]*|'') MESSAGE="Invalid profile number."; CLASS="err"; return ;; esac
    ensure_config
    backup_config
    MAX="$(max_profile)"
    [ -z "$MAX" ] && MAX=0
    TMP="/tmp/matrix_wifi_profiles.$$"
    : > "$TMP"
    out=1
    i=1
    while [ "$i" -le "$MAX" ]; do
        if [ "$i" != "$P" ]; then
            N="$(profile_name "$i")"; S="$(profile_ssid "$i")"; K="$(profile_pass "$i")"
            if [ -n "$N" ] || [ -n "$S" ] || [ -n "$K" ]; then
                {
                    echo "PROFILE${out}_NAME=$N"
                    echo "PROFILE${out}_SSID=$S"
                    echo "PROFILE${out}_PASSWORD=$K"
                    echo ""
                } >> "$TMP"
                out=$((out+1))
            fi
        fi
        i=$((i+1))
    done
    cp -f "$TMP" "$CONFIG"
    rm -f "$TMP"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    MESSAGE="Profile $P deleted."
    CLASS="ok"
    echo "$(date '+%Y-%m-%d %H:%M:%S') Deleted profile $P" >> "$LOG"
}

duplicate_profile() {
    P="$(get_qs p)"
    case "$P" in *[!0-9]*|'') MESSAGE="Invalid profile number."; CLASS="err"; return ;; esac
    N="$(profile_name "$P")"; S="$(profile_ssid "$P")"; K="$(profile_pass "$P")"
    if [ -z "$N" ] && [ -z "$S" ] && [ -z "$K" ]; then MESSAGE="Profile not found."; CLASS="err"; return; fi
    NEXT=$(( $(max_profile) + 1 ))
    ensure_config
    backup_config
    {
        echo "PROFILE${NEXT}_NAME=${N} Copy"
        echo "PROFILE${NEXT}_SSID=$S"
        echo "PROFILE${NEXT}_PASSWORD=$K"
        echo ""
    } >> "$CONFIG"
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    MESSAGE="Profile $P duplicated to profile $NEXT."
    CLASS="ok"
    echo "$(date '+%Y-%m-%d %H:%M:%S') Duplicated profile $P to $NEXT" >> "$LOG"
}

ensure_config
ACTION="$(get_qs action)"
case "$ACTION" in
    save) save_profile ;;
    delete) delete_profile ;;
    duplicate) duplicate_profile ;;
esac

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"
CURRENT_SSID="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
[ -z "$CURRENT_SSID" ] && CURRENT_SSID="Unknown"
MAX="$(max_profile)"
[ -z "$MAX" ] && MAX=0
NEXT=$((MAX + 1))
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
[ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

E_HOST="$(html_escape "$HOST")"
E_CURRENT_SSID="$(html_escape "$CURRENT_SSID")"
E_LAST="$(html_escape "$LAST")"
E_MESSAGE="$(html_escape "$MESSAGE")"

cat <<'HTMLEOF'
Content-Type: text/html

<!DOCTYPE html>
<html>
<head>
<title>Matrix WiFi Manager v60</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1040px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}.profile{border:1px solid #ddd;border-radius:8px;background:#fff;padding:14px;margin:12px 0}.profile.active{border-color:#28a745;box-shadow:0 0 0 2px rgba(40,167,69,.15)}.formgrid{display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:10px;align-items:end}input{height:40px;border:1px solid #ccc;border-radius:6px;padding:0 10px;font-size:14px;box-sizing:border-box;width:100%}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:11px 14px;margin:4px 4px 4px 0;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}.muted{color:#777;font-size:13px}.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.pill{display:inline-block;border-radius:999px;padding:3px 9px;font-size:12px;font-weight:bold;background:#eee}.pill.ok{background:#dff3e5;color:#1f8a3b}.actions{white-space:nowrap}@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.formgrid{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}.actions{white-space:normal}}
</style>
<script>
function cApply(n,s){return confirm('Apply WiFi profile: '+n+'\nSSID: '+s+'\n\nThis will reload the 5 GHz WiFi. Continue?')}
function cDelete(n){return confirm('Delete profile: '+n+'?')}
function cPrev(){return confirm('Restore previous profile configuration?')}
function cFactory(){return confirm('Restore factory/default profiles?')}
</script>
</head>
<body><div class="page">
HTMLEOF

cat <<EOF
<h1>Matrix WiFi Manager v60</h1>
<div class="topgrid">
  <div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="card"><div class="label">Current 5 GHz SSID</div><div class="value">$E_CURRENT_SSID</div></div>
  <div class="card"><div class="label">Profiles</div><div class="value">$MAX</div></div>
  <div class="card"><div class="label">Target</div><div class="value">default_radio1</div></div>
</div>
EOF

if [ -n "$MESSAGE" ]; then
    echo "<div class=\"card $CLASS\">$E_MESSAGE</div>"
fi

echo '<div class="card"><h2>Profiles</h2>'

i=1
while [ "$i" -le "$MAX" ]; do
    NAME="$(profile_name "$i")"; SSID="$(profile_ssid "$i")"; PASS="$(profile_pass "$i")"
    if [ -n "$NAME" ] || [ -n "$SSID" ] || [ -n "$PASS" ]; then
        RESOLVED="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"
        ACTIVE_CLASS="profile"
        STATUS="<span class=\"pill\">Available</span>"
        if [ "$RESOLVED" = "$CURRENT_SSID" ]; then
            ACTIVE_CLASS="profile active"
            STATUS="<span class=\"pill ok\">Active</span>"
        fi
        E_NAME="$(html_escape "$NAME")"; E_SSID="$(html_escape "$SSID")"; E_RES="$(html_escape "$RESOLVED")"; E_PASS="$(html_escape "$PASS")"
        cat <<EOF
<div class="$ACTIVE_CLASS">
<form method="get" action="/cgi-bin/wifi_manager.sh">
<input type="hidden" name="action" value="save">
<input type="hidden" name="p" value="$i">
<div class="formgrid">
  <div><div class="label">Profile $i name</div><input name="name" value="$E_NAME"></div>
  <div><div class="label">SSID <span class="muted">resolved: $E_RES</span></div><input name="ssid" value="$E_SSID"></div>
  <div><div class="label">Password</div><input name="password" value="$E_PASS"></div>
  <div class="actions"><button class="btn blue" type="submit">Save</button></div>
</div>
<p>$STATUS <a class="btn green" onclick="return cApply('$E_NAME','$E_RES')" href="/cgi-bin/wifi_profile.sh?p=$i">Apply</a> <a class="btn orange" href="/cgi-bin/wifi_manager.sh?action=duplicate&p=$i">Duplicate</a> <a class="btn red" onclick="return cDelete('$E_NAME')" href="/cgi-bin/wifi_manager.sh?action=delete&p=$i">Delete</a></p>
</form>
</div>
EOF
    fi
    i=$((i+1))
done

cat <<EOF
<div class="profile">
<form method="get" action="/cgi-bin/wifi_manager.sh">
<input type="hidden" name="action" value="save">
<input type="hidden" name="p" value="$NEXT">
<h2>Add Profile</h2>
<div class="formgrid">
  <div><div class="label">Name</div><input name="name" placeholder="Service"></div>
  <div><div class="label">SSID</div><input name="ssid" placeholder="ServiceWiFi"></div>
  <div><div class="label">Password</div><input name="password" placeholder="password"></div>
  <div class="actions"><button class="btn green" type="submit">Add</button></div>
</div>
</form>
</div>
<p>
<a class="btn orange" onclick="return cPrev()" href="/cgi-bin/wifi_profiles_restore_previous.sh">Restore Previous</a>
<a class="btn red" onclick="return cFactory()" href="/cgi-bin/wifi_profiles_reset.sh">Restore Factory Defaults</a>
<a class="btn blue" href="/">Back to Toolkit</a>
</p>
</div>

<div class="card"><h2>Status</h2>
<p class="muted">Last change: $E_LAST</p>
<p class="muted">Active config: <b>$CONFIG</b></p>
<p class="muted">Previous config: <b>$PREVIOUS</b></p>
<p class="muted">Default config: <b>$DEFAULTS</b></p>
<p class="muted">This manager changes only the 5 GHz access point: <b>wireless.default_radio1</b>. The 2.4 GHz SSID stays unchanged.</p>
</div>
</div></body></html>
EOF
