#!/bin/sh
# Matrix WiFi Manager v65.3
# Profile overview cards without UTF-8 emoji issues.

LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"

ensure_wifi_files

ACTION="$(qs action)"
TYPE="$(qs type)"
IDX="$(qs p)"
IFACE="$(qs iface)"

case "$ACTION" in
    apply)
        profile_apply "$TYPE" "$IDX"
        ;;
    restore_matrix)
        restore_matrix_default_wifi
        ;;
    enable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='0' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface enabled iface=$IFACE" >> "$LOG"
        ;;
    disable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='1' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface disabled iface=$IFACE" >> "$LOG"
        ;;
    reload_wifi)
        wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi reload requested" >> "$LOG"
        ;;
esac

radio_detail(){
    FILE="$1"
    IDX="$2"
    R="$3"
    LABEL="$4"

    ACTION="$(normalize_action "$(profile_value_file "$FILE" "$IDX" ${R}_ACTION)")"
    SSID_RAW="$(profile_value_file "$FILE" "$IDX" ${R}_SSID)"
    PASS="$(profile_value_file "$FILE" "$IDX" ${R}_PASSWORD)"
    SSID="$(resolve_ssid "$SSID_RAW")"

    E_ACTION="$(html_escape "$ACTION")"
    E_SSID="$(html_escape "$SSID")"
    E_PASS="$(html_escape "$PASS")"
    E_LABEL="$(html_escape "$LABEL")"

    case "$ACTION" in
        SET)
            cat <<EOF
<div class="radio-box">
  <div class="radio-title">$E_LABEL</div>
  <table class="mini-table">
    <tr><td>Action</td><td><span class="ok"><b>SET</b></span></td></tr>
    <tr><td>SSID</td><td><b>$E_SSID</b></td></tr>
    <tr><td>Password</td><td><span id="pw_${IDX}_${R}_$(basename "$FILE" | tr '.-' '__')">********</span> <button class="mini" onclick="togglePassword('pw_${IDX}_${R}_$(basename "$FILE" | tr '.-' '__')','$E_PASS');return false;">Show/Hide</button></td></tr>
    <tr><td>Security</td><td>WPA2-PSK</td></tr>
    <tr><td>After Apply</td><td>Radio will be enabled with this SSID</td></tr>
  </table>
</div>
EOF
            ;;
        DISABLE)
            cat <<EOF
<div class="radio-box">
  <div class="radio-title">$E_LABEL</div>
  <table class="mini-table">
    <tr><td>Action</td><td><span class="err"><b>DISABLE</b></span></td></tr>
    <tr><td>SSID</td><td>-</td></tr>
    <tr><td>Password</td><td>-</td></tr>
    <tr><td>Encryption</td><td>-</td></tr>
    <tr><td>After Apply</td><td>Radio/interface will be disabled</td></tr>
  </table>
</div>
EOF
            ;;
        *)
            cat <<EOF
<div class="radio-box">
  <div class="radio-title">$E_LABEL</div>
  <table class="mini-table">
    <tr><td>Action</td><td><span class="muted"><b>KEEP CURRENT</b></span></td></tr>
    <tr><td>SSID</td><td>Current router value</td></tr>
    <tr><td>Password</td><td>Current router value</td></tr>
    <tr><td>Security</td><td>Current router value</td></tr>
    <tr><td>After Apply</td><td>No change on this radio</td></tr>
  </table>
</div>
EOF
            ;;
    esac
}

profile_card(){
    TYPE="$1"
    FILE="$2"
    IDX="$3"
    LOCKED="$4"

    NAME="$(profile_value_file "$FILE" "$IDX" NAME)"
    [ -z "$NAME" ] && NAME="Profile $IDX"
    E_NAME="$(html_escape "$NAME")"
    STATUS="$(profile_status "$FILE" "$IDX")"

    if [ "$LOCKED" = "1" ]; then
        TITLE="<span class=\"system-label\">SYSTEM</span> $E_NAME"
        ACTIONS="<a class=\"btn green\" onclick=\"return confirmApply('$E_NAME')\" href=\"/cgi-bin/wifi_manager.sh?action=apply&type=$TYPE&p=$IDX\">Apply</a>"
    else
        TITLE="$E_NAME"
        ACTIONS="<a class=\"btn blue\" href=\"/cgi-bin/wifi_profile_edit.sh?type=user&p=$IDX\">Edit</a><a class=\"btn green\" onclick=\"return confirmApply('$E_NAME')\" href=\"/cgi-bin/wifi_manager.sh?action=apply&type=user&p=$IDX\">Apply</a><a class=\"btn red\" onclick=\"return confirmDelete('$E_NAME')\" href=\"/cgi-bin/wifi_profile_save.sh?action=delete&type=user&profile=$IDX\">Delete</a>"
    fi

    cat <<EOF
<div class="profile-card">
  <div class="profile-header">
    <div class="profile-title">$TITLE</div>
    <div class="profile-status">$STATUS</div>
  </div>
  <div class="radio-grid">
EOF
    radio_detail "$FILE" "$IDX" R0 "Radio 0 / 2.4 GHz"
    radio_detail "$FILE" "$IDX" R1 "Radio 1 / 5 GHz"
    cat <<EOF
  </div>
  $(profile_changes_after_apply "$FILE" "$IDX")
  <div class="profile-actions">$ACTIONS</div>
</div>
EOF
}

HOST="$(hostname_value)"
SSID0="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
SSID1="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
KEY0="$(uci get wireless.default_radio0.key 2>/dev/null)"
KEY1="$(uci get wireless.default_radio1.key 2>/dev/null)"
DIS0="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
DIS1="$(uci get wireless.default_radio1.disabled 2>/dev/null)"
[ -z "$SSID0" ] && SSID0="Unknown"
[ -z "$SSID1" ] && SSID1="Unknown"
[ -z "$DIS0" ] && DIS0="0"
[ -z "$DIS1" ] && DIS1="0"
SC="$(profile_count_file "$SYSTEM_PROFILES")"; [ -z "$SC" ] && SC=0
UC="$(profile_count_file "$USER_PROFILES")"; [ -z "$UC" ] && UC=0
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"; [ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

E_HOST="$(html_escape "$HOST")"
E_SSID0="$(html_escape "$SSID0")"
E_SSID1="$(html_escape "$SSID1")"
E_KEY0="$(html_escape "$KEY0")"
E_KEY1="$(html_escape "$KEY1")"
E_LAST="$(html_escape "$LAST")"

echo "Content-Type: text/html"
echo ""
cat <<EOF
<!DOCTYPE html>
<html>
<head>
<title>Matrix WiFi Manager v65.3</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1260px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}
h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}
.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}
.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}
.mini{border:1px solid #bbb;border-radius:4px;background:#eee;color:#222;padding:2px 6px;font-size:11px;cursor:pointer}
.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
table{width:100%;border-collapse:collapse;background:white}
th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}
th{background:#f0f6fb;color:#005a9c}
.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}
.profile-card{background:white;border:1px solid #d6d6d6;border-radius:10px;padding:15px;margin:14px 0;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.profile-header{display:flex;justify-content:space-between;gap:12px;align-items:center;border-bottom:1px solid #eee;padding-bottom:10px;margin-bottom:12px}
.profile-title{font-size:19px;font-weight:bold;color:#005a9c}.system-label{font-size:12px;background:#e9f3ff;border:1px solid #b9d7f4;border-radius:4px;padding:2px 6px;color:#005a9c;margin-right:6px}
.profile-status{font-size:14px}
.radio-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.radio-box{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:12px}
.radio-title{font-weight:bold;color:#333;margin-bottom:8px}
.mini-table td{padding:6px 8px;font-size:13px}
.mini-table td:first-child{width:110px;color:#666;font-weight:bold}
.profile-actions{margin-top:12px}.changes-box{background:#fff;border:1px solid #e5e5e5;border-radius:8px;padding:10px;margin-top:12px}.changes-title{font-weight:bold;color:#333;margin-bottom:8px}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.radio-grid{grid-template-columns:1fr}.profile-header{display:block}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function togglePassword(id, val){var el=document.getElementById(id);if(!el)return false;if(el.innerText==='********'){el.innerText=val;}else{el.innerText='********';}return false;}
function confirmApply(n){return confirm('Apply profile: '+n+'\\n\\nWiFi will reload. Continue?');}
function confirmIface(a,i,s){return confirm(a+' interface?\\n\\nInterface: '+i+'\\nSSID: '+s+'\\n\\nWiFi will reload. Continue?');}
function confirmRestore(){return confirm('Restore Matrix Default WiFi?\\n\\n2.4 GHz = {HOSTNAME}_2G\\n5 GHz = {HOSTNAME}_5G\\n\\nWiFi will reload. Continue?');}
function confirmReload(){return confirm('Reload WiFi now?');}
function confirmDelete(n){return confirm('Delete user profile: '+n+' ?');}
</script>
</head>
<body>
<div class="page">
<h1>Matrix WiFi Manager v65.3</h1>

<div class="topgrid">
  <div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="card"><div class="label">Radio 0 / 2.4 GHz</div><div class="value">$E_SSID0</div></div>
  <div class="card"><div class="label">Radio 1 / 5 GHz</div><div class="value">$E_SSID1</div></div>
  <div class="card"><div class="label">Profiles</div><div class="value">$SC system / $UC user</div></div>
</div>

<div class="card">
<h2>Current Router WiFi</h2>
<table>
<tr><th>Radio</th><th>SSID</th><th>Password</th><th>Status</th></tr>
<tr><td><b>Radio 0 / 2.4 GHz</b></td><td>$E_SSID0</td><td><span id="cur0pw">********</span> <button class="mini" onclick="togglePassword('cur0pw','$E_KEY0');return false;">Show/Hide</button></td><td>$([ "$DIS0" = "1" ] && echo '<span class="err">Disabled</span>' || echo '<span class="ok">Enabled</span>')</td></tr>
<tr><td><b>Radio 1 / 5 GHz</b></td><td>$E_SSID1</td><td><span id="cur1pw">********</span> <button class="mini" onclick="togglePassword('cur1pw','$E_KEY1');return false;">Show/Hide</button></td><td>$([ "$DIS1" = "1" ] && echo '<span class="err">Disabled</span>' || echo '<span class="ok">Enabled</span>')</td></tr>
</table>
<p>
<a class="btn red" onclick="return confirmRestore()" href="/cgi-bin/wifi_manager.sh?action=restore_matrix&nocache=$(date +%s)">Restore Matrix Default WiFi</a>
<a class="btn grey" onclick="return confirmReload()" href="/cgi-bin/wifi_manager.sh?action=reload_wifi&nocache=$(date +%s)">Reload WiFi</a>
</p>
</div>

<div class="card">
<h2>WiFi Interface Control</h2>
<table>
<tr><th>Interface</th><th>Device</th><th>SSID</th><th>Status</th><th>Action</th></tr>
EOF

uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    DEVICE="$(uci get wireless.${IFACE_NAME}.device 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"
    [ -z "$DEVICE" ] && DEVICE="-"
    [ -z "$DISABLED" ] && DISABLED="0"
    E_IFACE="$(html_escape "$IFACE_NAME")"; E_SSID="$(html_escape "$SSID")"; E_DEVICE="$(html_escape "$DEVICE")"
    if [ "$DISABLED" = "1" ]; then
        STATUS='<span class="err">Disabled</span>'
        BTN="<a class=\"btn green\" onclick=\"return confirmIface('Enable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=enable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Enable</a>"
    else
        STATUS='<span class="ok">Enabled</span>'
        BTN="<a class=\"btn red\" onclick=\"return confirmIface('Disable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=disable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Disable</a>"
    fi
    echo "<tr><td><b>$E_IFACE</b></td><td>$E_DEVICE</td><td>$E_SSID</td><td>$STATUS</td><td>$BTN</td></tr>"
done

cat <<EOF
</table>
<p class="muted">This enables/disables existing WiFi interfaces and does not change saved profiles.</p>
</div>

<div class="card">
<h2>System Profiles <span class="muted">(Matrix defaults, locked)</span></h2>
<p class="muted">These profiles are installed by Matrix Toolkit and cannot be deleted.</p>
EOF

i=1
while [ "$i" -le "$SC" ]; do
    profile_card "system" "$SYSTEM_PROFILES" "$i" "1"
    i=$((i+1))
done

cat <<EOF
</div>

<div class="card">
<h2>User Profiles</h2>
<p class="muted">Create your own WiFi configurations for customers, service or temporary test networks.</p>
EOF

if [ "$UC" -eq 0 ]; then
    echo '<p class="muted">No user profiles yet. Use Add User Profile to create customer or service WiFi presets.</p>'
fi

i=1
while [ "$i" -le "$UC" ]; do
    profile_card "user" "$USER_PROFILES" "$i" "0"
    i=$((i+1))
done

cat <<EOF
<p><a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add&type=user">+ Add User Profile</a></p>
</div>

<div class="card">
<h2>Status</h2>
<p class="muted">Last change: $E_LAST</p>
<p class="muted">System profiles: <b>$SYSTEM_PROFILES</b></p>
<p class="muted">User profiles: <b>$USER_PROFILES</b></p>
</div>

</div>
</body>
</html>
EOF
