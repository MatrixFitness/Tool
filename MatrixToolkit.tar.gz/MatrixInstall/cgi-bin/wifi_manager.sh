#!/bin/sh
# Matrix WiFi Manager v80 - Professional UI

LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"

ensure_wifi_files

ACTION="$(qs action)"
TYPE="$(qs type)"
IDX="$(qs p)"
IFACE="$(qs iface)"

case "$ACTION" in
    apply) profile_apply "$TYPE" "$IDX" ;;
    restore_matrix) restore_matrix_default_wifi ;;
    enable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='0' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface enabled iface=$IFACE" >> "$LOG"
        ;;
    disable_iface)
        [ -n "$IFACE" ] && uci set wireless.${IFACE}.disabled='1' && uci commit wireless && wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface disabled iface=$IFACE" >> "$LOG"
        ;;
    reload_wifi)
        wifi reload >/dev/null 2>&1
        echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi reload requested" >> "$LOG"
        ;;
    remove_client)
        [ -n "$IFACE" ] && wifi_client_remove "$IFACE"
        ;;
esac

VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-)"
[ -z "$VERSION" ] && VERSION="80"
[ -z "$BUILD" ] && BUILD="2026-07-01"
[ -z "$RELEASE" ] && RELEASE="Production LTS"

HOST="$(hostname_value)"
SSID0="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
SSID1="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
DIS0="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
DIS1="$(uci get wireless.default_radio1.disabled 2>/dev/null)"
[ -z "$SSID0" ] && SSID0="Unknown"
[ -z "$SSID1" ] && SSID1="Unknown"
[ -z "$DIS0" ] && DIS0="0"
[ -z "$DIS1" ] && DIS1="0"

ACTIVE_PROFILE="$(active_system_profile_name)"
SC="$(profile_count_file "$SYSTEM_PROFILES")"; [ -z "$SC" ] && SC=0
UC="$(profile_count_file "$USER_PROFILES")"; [ -z "$UC" ] && UC=0
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"; [ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

# Customer WiFi / Survey Mode detection
CLIENT_IFACE=""
CLIENT_SSID=""
CLIENT_NETWORK=""
CLIENT_DISABLED=""
uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read X; do
    MODE="$(uci get wireless.${X}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] || continue
    echo "$X|$(uci get wireless.${X}.ssid 2>/dev/null)|$(uci get wireless.${X}.network 2>/dev/null)|$(uci get wireless.${X}.disabled 2>/dev/null)"
    break
done > /tmp/matrix_wifi_client.$$

if [ -s /tmp/matrix_wifi_client.$$ ]; then
    CLIENT_IFACE="$(cut -d'|' -f1 /tmp/matrix_wifi_client.$$)"
    CLIENT_SSID="$(cut -d'|' -f2 /tmp/matrix_wifi_client.$$)"
    CLIENT_NETWORK="$(cut -d'|' -f3 /tmp/matrix_wifi_client.$$)"
    CLIENT_DISABLED="$(cut -d'|' -f4 /tmp/matrix_wifi_client.$$)"
fi
rm -f /tmp/matrix_wifi_client.$$ 2>/dev/null

[ -z "$CLIENT_SSID" ] && CLIENT_SSID="Not connected"
[ -z "$CLIENT_NETWORK" ] && CLIENT_NETWORK="wan1"
[ -z "$CLIENT_DISABLED" ] && CLIENT_DISABLED="0"

CLIENT_IP="$(ifstatus "$CLIENT_NETWORK" 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)"
CLIENT_GW="$(ifstatus "$CLIENT_NETWORK" 2>/dev/null | grep '"nexthop"' | head -1 | cut -d'"' -f4)"
CLIENT_DEV="$(ifstatus "$CLIENT_NETWORK" 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)"
[ -z "$CLIENT_DEV" ] && CLIENT_DEV="$CLIENT_IFACE"

IWINFO_OUT=""
[ -n "$CLIENT_DEV" ] && IWINFO_OUT="$(iwinfo "$CLIENT_DEV" info 2>/dev/null)"
CONNECTED_SSID="$(echo "$IWINFO_OUT" | sed -n 's/.*ESSID: *"\([^"]*\)".*/\1/p' | head -1)"
[ -n "$CONNECTED_SSID" ] && CLIENT_SSID="$CONNECTED_SSID"
SIGNAL="$(echo "$IWINFO_OUT" | awk '/Signal:/ {print $2; exit}')"
CHANNEL="$(echo "$IWINFO_OUT" | awk '/Channel:/ {print $2; exit}')"
BSSID="$(echo "$IWINFO_OUT" | sed -n 's/.*Access Point: *\([0-9A-Fa-f:][0-9A-Fa-f:]*\).*/\1/p' | head -1)"
[ -z "$SIGNAL" ] && SIGNAL="Unknown"
[ -z "$CHANNEL" ] && CHANNEL="Unknown"
[ -z "$BSSID" ] && BSSID="Unknown"
BAND="Unknown"
case "$CHANNEL" in
    ''|Unknown) BAND="Unknown" ;;
    [1-9]|1[0-4]) BAND="2.4 GHz" ;;
    *) BAND="5 GHz" ;;
esac

CUSTOMER_CONNECTED="NO"
[ -n "$CLIENT_IFACE" ] && [ "$CLIENT_DISABLED" != "1" ] && CUSTOMER_CONNECTED="CONFIGURED"
[ -n "$CLIENT_IP" ] && CUSTOMER_CONNECTED="CONNECTED"

INTERNET="Offline"
ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && INTERNET="Connected"

SIGNAL_RATING="Unknown"
HEALTH="Not Connected"
HEALTH_CLASS="warn"
SURVEY_MODE="Inactive"
if [ "$CUSTOMER_CONNECTED" = "CONNECTED" ]; then
    SURVEY_MODE="Active"
    HEALTH="Good"
    HEALTH_CLASS="ok"
    SIG_NUM="$(echo "$SIGNAL" | sed 's/[^0-9-]//g')"
    if [ -n "$SIG_NUM" ]; then
        if [ "$SIG_NUM" -ge -55 ]; then SIGNAL_RATING="Excellent"; HEALTH="Excellent"
        elif [ "$SIG_NUM" -ge -65 ]; then SIGNAL_RATING="Good"; HEALTH="Good"
        elif [ "$SIG_NUM" -ge -75 ]; then SIGNAL_RATING="Fair"; HEALTH="Fair"; HEALTH_CLASS="warn"
        else SIGNAL_RATING="Poor"; HEALTH="Poor"; HEALTH_CLASS="fail"
        fi
    fi
elif [ "$CUSTOMER_CONNECTED" = "CONFIGURED" ]; then
    HEALTH="Configured"
    HEALTH_CLASS="warn"
    SURVEY_MODE="Configured"
fi


# WAN Connection detection.
WAN_IFACE=""
WAN_STATUS="Disconnected"
WAN_DEVICE=""
WAN_IP=""
WAN_GW=""
WAN_DNS=""
WAN_TYPE="Unknown"

# Prefer the active default route.
WAN_GW="$(ip route 2>/dev/null | awk '/^default /{print $3; exit}')"
WAN_DEVICE="$(ip route 2>/dev/null | awk '/^default /{print $5; exit}')"
if [ -n "$WAN_DEVICE" ]; then
    WAN_IP="$(ip -4 addr show "$WAN_DEVICE" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
fi

# Try to map the active device to an OpenWrt network.
if [ -n "$WAN_DEVICE" ]; then
    for NET in wan wan1 wwan mobile lte; do
        DEV="$(ifstatus "$NET" 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)"
        ADDR="$(ifstatus "$NET" 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)"
        [ "$DEV" = "$WAN_DEVICE" ] || [ "$ADDR" = "$WAN_IP" ] || continue
        WAN_IFACE="$NET"
        [ -z "$WAN_IP" ] && WAN_IP="$ADDR"
        GW_TRY="$(ifstatus "$NET" 2>/dev/null | grep '"nexthop"' | head -1 | cut -d'"' -f4)"
        [ -n "$GW_TRY" ] && WAN_GW="$GW_TRY"
        break
    done
fi

# Fallback when default route mapping failed.
if [ -z "$WAN_IFACE" ]; then
    for NET in wan wan1 wwan mobile lte; do
        ifstatus "$NET" >/dev/null 2>&1 || continue
        ADDR="$(ifstatus "$NET" 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)"
        [ -n "$ADDR" ] || continue
        WAN_IFACE="$NET"
        WAN_IP="$ADDR"
        WAN_DEVICE="$(ifstatus "$NET" 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)"
        WAN_GW="$(ifstatus "$NET" 2>/dev/null | grep '"nexthop"' | head -1 | cut -d'"' -f4)"
        break
    done
fi

[ -z "$WAN_IFACE" ] && WAN_IFACE="Unknown"
[ -z "$WAN_DEVICE" ] && WAN_DEVICE="Unknown"
[ -z "$WAN_IP" ] && WAN_IP="No IP"
[ -z "$WAN_GW" ] && WAN_GW="Unknown"

# DNS servers from resolv.conf.auto or resolv.conf.
WAN_DNS="$(awk '/^nameserver /{print $2}' /tmp/resolv.conf.auto /etc/resolv.conf 2>/dev/null | sort -u | tr '\n' ' ' | sed 's/ *$//')"
[ -z "$WAN_DNS" ] && WAN_DNS="Unknown"

if [ "$WAN_IP" != "No IP" ]; then
    WAN_STATUS="Connected"
fi

# Determine user-friendly connection type.
if [ "$WAN_IFACE" = "$CLIENT_NETWORK" ] || [ "$WAN_DEVICE" = "$CLIENT_DEV" ] || [ "$WAN_IFACE" = "wan1" ]; then
    WAN_TYPE="Customer WiFi / WAN over WiFi"
elif echo "$WAN_DEVICE" | grep -Eq 'eth|br-|lan'; then
    WAN_TYPE="Ethernet WAN"
elif echo "$WAN_DEVICE" | grep -Eq 'wwan|qmimux|usb|mobile|lte'; then
    WAN_TYPE="LTE / Mobile WAN"
else
    WAN_TYPE="WAN"
fi

PUBLIC_IP="$(wget -qO- -T 4 http://ifconfig.me/ip 2>/dev/null | head -n1)"
echo "$PUBLIC_IP" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || PUBLIC_IP="Unknown"

ROUTER_WIFI="ACTIVE"
[ "$DIS0" = "1" ] && [ "$DIS1" = "1" ] && ROUTER_WIFI="DISABLED"

E_HOST="$(html_escape "$HOST")"
E_SSID0="$(html_escape "$SSID0")"
E_SSID1="$(html_escape "$SSID1")"
E_ACTIVE="$(html_escape "$ACTIVE_PROFILE")"
E_LAST="$(html_escape "$LAST")"
E_CLIENT_SSID="$(html_escape "$CLIENT_SSID")"
E_CLIENT_IP="$(html_escape "$CLIENT_IP")"
E_CLIENT_GW="$(html_escape "$CLIENT_GW")"
E_CLIENT_IFACE="$(html_escape "$CLIENT_IFACE")"
E_CLIENT_NETWORK="$(html_escape "$CLIENT_NETWORK")"
E_SIGNAL="$(html_escape "$SIGNAL")"
E_SIGNAL_RATING="$(html_escape "$SIGNAL_RATING")"
E_CHANNEL="$(html_escape "$CHANNEL")"
E_BAND="$(html_escape "$BAND")"
E_BSSID="$(html_escape "$BSSID")"

E_WAN_IFACE="$(html_escape "$WAN_IFACE")"
E_WAN_STATUS="$(html_escape "$WAN_STATUS")"
E_WAN_DEVICE="$(html_escape "$WAN_DEVICE")"
E_WAN_IP="$(html_escape "$WAN_IP")"
E_WAN_GW="$(html_escape "$WAN_GW")"
E_WAN_DNS="$(html_escape "$WAN_DNS")"
E_WAN_TYPE="$(html_escape "$WAN_TYPE")"
E_PUBLIC_IP="$(html_escape "$PUBLIC_IP")"


echo "Content-Type: text/html; charset=UTF-8"
echo ""
cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix WiFi Manager v80</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--blue:#005a9c;--purple:#6f42c1;--yellow:#f0ad4e;--tools:#667085;--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1320px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}
.status-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:18px 0}.status-card{background:#fff;border:1px solid var(--border);border-radius:16px;padding:15px;box-shadow:var(--shadow)}.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:800}.value{margin-top:8px;font-size:20px;font-weight:900;word-break:break-word}.ok{color:var(--ok)}.warn{color:var(--warn)}.fail{color:var(--fail)}
.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);overflow:hidden;margin:16px 0}.card-head{padding:14px 16px;color:#fff;font-weight:900;letter-spacing:.03em;text-transform:uppercase;font-size:14px;background:var(--blue)}.card-head.green{background:var(--ok)}.card-head.purple{background:var(--purple)}.card-head.yellow{background:var(--yellow);color:#222}.card-head.grey{background:var(--tools)}.card-body{padding:16px}.card-desc{color:var(--muted);font-size:13px;line-height:1.45;margin:0 0 12px}
.metric-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:12px}.metric-label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800}.metric-value{font-size:18px;font-weight:900;margin-top:5px;word-break:break-word}.metric-extra{font-size:12px;color:var(--muted);margin-top:3px}
.badge{display:inline-block;border-radius:999px;padding:6px 10px;font-weight:900;font-size:12px}.badge.active,.badge.connected{background:#dff3e4;color:#137333;border:1px solid #a8dab5}.badge.same{background:#fff4ce;color:#8a5a00;border:1px solid #ead28a}.badge.available{background:#e9f3ff;color:#005a9c;border:1px solid #b9d7f4}.badge.disabled{background:#fde2e2;color:#a10000;border:1px solid #f3b3b3}.badge.warn{background:#fff4ce;color:#8a5a00;border:1px solid #ead28a}.badge.fail{background:#fde2e2;color:#a10000;border:1px solid #f3b3b3}
.btn{display:inline-block;border:none;border-radius:12px;color:white!important;text-decoration:none!important;font-weight:800;cursor:pointer;padding:11px 14px;margin:4px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
.profile-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.profile-simple-card{background:#fff;border:1px solid #d6d6d6;border-radius:14px;padding:15px;box-shadow:0 1px 4px rgba(0,0,0,.05)}.profile-simple-header{display:flex;justify-content:space-between;gap:10px;align-items:center;border-bottom:1px solid #eee;padding-bottom:10px;margin-bottom:10px}.profile-simple-title{font-size:18px;font-weight:900;color:#005a9c}.profile-simple-row{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid #f0f0f0;padding:7px 0}.profile-simple-row span{color:#666;font-weight:bold}.profile-actions{margin-top:12px}
table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid var(--border);padding:10px;text-align:left;vertical-align:top}th{background:#f0f6fb;color:#005a9c}.muted{color:var(--muted);font-size:13px}.advanced{margin-top:14px}.advanced summary{cursor:pointer;font-weight:900;color:#005a9c;padding:12px;background:#f0f6fb;border-radius:12px}.footer-actions{text-align:center;margin-top:18px}.survey-note{background:#eefaf0;border:1px solid #b6e2c0;border-left:6px solid var(--ok);padding:13px;border-radius:13px;line-height:1.45}
@media(max-width:1100px){.status-grid{grid-template-columns:repeat(2,1fr)}.metric-grid{grid-template-columns:repeat(2,1fr)}.profile-grid{grid-template-columns:1fr 1fr}}@media(max-width:720px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn{width:100%;text-align:center}.status-grid,.metric-grid,.profile-grid{grid-template-columns:1fr}.profile-simple-header{display:block}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function confirmApply(n){return confirm('Apply profile: '+n+'\\n\\nWiFi will reload. Continue?');}
function confirmRestore(){return confirm('Restore Matrix Default WiFi?\\n\\n2.4 GHz = {HOSTNAME}_2G\\n5 GHz = {HOSTNAME}_5G\\n\\nWiFi will reload. Continue?');}
function confirmReload(){return confirm('Reload WiFi now?');}
function confirmDelete(n){return confirm('Delete user profile: '+n+' ?');}
function confirmIface(a,i,s){return confirm(a+' interface?\\n\\nInterface: '+i+'\\nSSID: '+s+'\\n\\nWiFi will reload. Continue?');}
function confirmRemoveClient(i,s,n){return confirm('Disconnect Customer WiFi?\\n\\nSSID: '+s+'\\nInterface: '+i+'\\nNetwork: '+n+'\\n\\nRouter WiFi Access Points will NOT be changed. Continue?');}
</script>
</head>
<body>
<div class="page">
<section class="hero">
  <div>
    <h1>Matrix WiFi Manager v80</h1>
    <div class="sub">Professional WiFi control for router SSIDs, customer WiFi and survey mode</div>
    <div class="contact">Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE</div>
    <div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
  </div>
  <a class="top-btn" href="/">Back to Toolkit</a>
</section>

<section class="status-grid">
  <div class="status-card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="status-card"><div class="label">Current Profile</div><div class="value">$E_ACTIVE</div></div>
  <div class="status-card"><div class="label">Router WiFi</div><div class="value $([ "$ROUTER_WIFI" = "ACTIVE" ] && echo ok || echo fail)">$ROUTER_WIFI</div></div>
  <div class="status-card"><div class="label">Customer WiFi</div><div class="value $HEALTH_CLASS">$([ "$CUSTOMER_CONNECTED" = "CONNECTED" ] && echo CONNECTED || echo "$CUSTOMER_CONNECTED")</div></div>
  <div class="status-card"><div class="label">Survey Mode</div><div class="value $HEALTH_CLASS">$SURVEY_MODE</div></div>
</section>

<section class="card">
  <div class="card-head green">Customer WiFi Connection</div>
  <div class="card-body">
    <p class="card-desc">This is the temporary customer WiFi connection used by the router for WAN testing and the Matrix WiFi Survey.</p>
    <div class="metric-grid">
      <div class="metric"><div class="metric-label">Status</div><div class="metric-value $HEALTH_CLASS">$([ "$CUSTOMER_CONNECTED" = "CONNECTED" ] && echo CONNECTED || echo "$CUSTOMER_CONNECTED")</div><div class="metric-extra">Customer WiFi</div></div>
      <div class="metric"><div class="metric-label">SSID</div><div class="metric-value">$E_CLIENT_SSID</div><div class="metric-extra">Connected customer network</div></div>
      <div class="metric"><div class="metric-label">Band / Channel</div><div class="metric-value">$E_BAND</div><div class="metric-extra">Channel $E_CHANNEL</div></div>
      <div class="metric"><div class="metric-label">Signal</div><div class="metric-value">$E_SIGNAL dBm</div><div class="metric-extra">$E_SIGNAL_RATING</div></div>
      <div class="metric"><div class="metric-label">IP Address</div><div class="metric-value">$E_CLIENT_IP</div><div class="metric-extra">WAN over WiFi</div></div>
      <div class="metric"><div class="metric-label">Gateway</div><div class="metric-value">$E_CLIENT_GW</div><div class="metric-extra">Customer network</div></div>
      <div class="metric"><div class="metric-label">Internet</div><div class="metric-value">$INTERNET</div><div class="metric-extra">Ping test</div></div>
      <div class="metric"><div class="metric-label">Health</div><div class="metric-value $HEALTH_CLASS">$HEALTH</div><div class="metric-extra">Connection health</div></div>
    </div>
    <p class="survey-note"><b>Survey Mode:</b> the router is temporarily connected to the customer's WiFi. Router WiFi Access Points remain active unless you disable them manually.</p>
    <p>
      <a class="btn blue" href="/cgi-bin/wifi_manager.sh?nocache=$(date +%s)">Refresh Status</a>
      $([ -n "$CLIENT_IFACE" ] && echo "<a class=\"btn red\" onclick=\"return confirmRemoveClient('$E_CLIENT_IFACE','$E_CLIENT_SSID','$E_CLIENT_NETWORK')\" href=\"/cgi-bin/wifi_manager.sh?action=remove_client&iface=$E_CLIENT_IFACE&nocache=$(date +%s)\">Disconnect Customer WiFi</a>")
    </p>
  </div>
</section>


<section class="card">
  <div class="card-head">WAN Connection</div>
  <div class="card-body">
    <p class="card-desc">This shows the actual WAN/internet connection the router is using. During a survey this can be the customer WiFi connection.</p>
    <div class="metric-grid">
      <div class="metric"><div class="metric-label">WAN Status</div><div class="metric-value $([ "$WAN_STATUS" = "Connected" ] && echo ok || echo fail)">$E_WAN_STATUS</div><div class="metric-extra">Active internet path</div></div>
      <div class="metric"><div class="metric-label">WAN Interface</div><div class="metric-value">$E_WAN_IFACE</div><div class="metric-extra">$E_WAN_DEVICE</div></div>
      <div class="metric"><div class="metric-label">Connection Type</div><div class="metric-value">$E_WAN_TYPE</div><div class="metric-extra">How internet is connected</div></div>
      <div class="metric"><div class="metric-label">WAN IP</div><div class="metric-value">$E_WAN_IP</div><div class="metric-extra">Router WAN address</div></div>
      <div class="metric"><div class="metric-label">Gateway</div><div class="metric-value">$E_WAN_GW</div><div class="metric-extra">Default gateway</div></div>
      <div class="metric"><div class="metric-label">DNS</div><div class="metric-value">$E_WAN_DNS</div><div class="metric-extra">Configured DNS servers</div></div>
      <div class="metric"><div class="metric-label">Internet</div><div class="metric-value">$INTERNET</div><div class="metric-extra">Ping to 8.8.8.8</div></div>
      <div class="metric"><div class="metric-label">Public IP</div><div class="metric-value">$E_PUBLIC_IP</div><div class="metric-extra">External internet IP</div></div>
    </div>
  </div>
</section>

<section class="card">
  <div class="card-head">Router WiFi Networks</div>
  <div class="card-body">
    <p class="card-desc">These are WiFi networks broadcast by this Matrix router. They are separate from the customer WiFi connection.</p>
    <div class="metric-grid">
      <div class="metric"><div class="metric-label">2.4 GHz Router WiFi</div><div class="metric-value">$E_SSID0</div><div class="metric-extra">$([ "$DIS0" = "1" ] && echo DISABLED || echo Broadcasting)</div></div>
      <div class="metric"><div class="metric-label">5 GHz Router WiFi</div><div class="metric-value">$E_SSID1</div><div class="metric-extra">$([ "$DIS1" = "1" ] && echo DISABLED || echo Broadcasting)</div></div>
      <div class="metric"><div class="metric-label">Current Profile</div><div class="metric-value">$E_ACTIVE</div><div class="metric-extra">Applied Matrix profile</div></div>
      <div class="metric"><div class="metric-label">Quick Action</div><div class="metric-value"><a class="btn red" onclick="return confirmRestore()" href="/cgi-bin/wifi_manager.sh?action=restore_matrix&nocache=$(date +%s)">Restore Matrix Default</a></div><div class="metric-extra">Reset router SSIDs</div></div>
    </div>
  </div>
</section>

<section class="card">
  <div class="card-head purple">Matrix System Profiles</div>
  <div class="card-body">
    <p class="card-desc">These profiles are always present on every new router and cannot be deleted.</p>
    <div class="profile-grid">
EOF

i=1
while [ "$i" -le "$SC" ]; do
    system_profile_card "$i"
    i=$((i+1))
done

cat <<EOF
    </div>
  </div>
</section>

<section class="card">
  <div class="card-head yellow">Customer / User Profiles</div>
  <div class="card-body">
    <p class="card-desc">Create your own WiFi profiles for customers, service or temporary testing.</p>
EOF

if [ "$UC" -eq 0 ]; then
    echo '<p class="muted">No user profiles yet.</p>'
else
    echo '<div class="profile-grid">'
    i=1
    while [ "$i" -le "$UC" ]; do
        user_profile_card "$i"
        i=$((i+1))
    done
    echo '</div>'
fi

cat <<EOF
    <p><a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add&type=user">+ Add User Profile</a></p>
  </div>
</section>

<details class="advanced">
<summary>Advanced WiFi Details</summary>

<section class="card">
  <div class="card-head grey">Router Access Points</div>
  <div class="card-body">
    <p class="card-desc">These are SSIDs broadcast by the router.</p>
    <table>
      <tr><th>Interface</th><th>Device</th><th>SSID</th><th>Status</th><th>Action</th></tr>
EOF

uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    MODE="$(uci get wireless.${IFACE_NAME}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] && continue
    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    DEVICE="$(uci get wireless.${IFACE_NAME}.device 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"; [ -z "$DEVICE" ] && DEVICE="-"; [ -z "$DISABLED" ] && DISABLED="0"
    E_IFACE="$(html_escape "$IFACE_NAME")"; E_SSID="$(html_escape "$SSID")"; E_DEVICE="$(html_escape "$DEVICE")"
    if [ "$DISABLED" = "1" ]; then
        STATUS='<span class="fail">Disabled</span>'
        BTN="<a class=\"btn green\" onclick=\"return confirmIface('Enable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=enable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Enable</a>"
    else
        STATUS='<span class="ok">Broadcasting</span>'
        BTN="<a class=\"btn red\" onclick=\"return confirmIface('Disable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=disable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Disable</a>"
    fi
    echo "<tr><td><b>$E_IFACE</b></td><td>$E_DEVICE</td><td>$E_SSID</td><td>$STATUS</td><td>$BTN</td></tr>"
done

cat <<EOF
    </table>
  </div>
</section>

<section class="card">
  <div class="card-head grey">Customer WiFi Connection Details</div>
  <div class="card-body">
    <p class="card-desc">Technical view of WAN over WiFi / survey client mode.</p>
    <table>
      <tr><th>Interface</th><th>Connected SSID</th><th>Mode</th><th>WAN Network</th><th>Status</th><th>Action</th></tr>
EOF

uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue
    MODE="$(uci get wireless.${IFACE_NAME}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] || continue
    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    NETWORK="$(uci get wireless.${IFACE_NAME}.network 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"; [ -z "$NETWORK" ] && NETWORK="-"; [ -z "$DISABLED" ] && DISABLED="0"
    E_IFACE="$(html_escape "$IFACE_NAME")"; E_SSID="$(html_escape "$SSID")"; E_NETWORK="$(html_escape "$NETWORK")"
    if [ "$DISABLED" = "1" ]; then STATUS='<span class="fail">Disabled</span>'; else STATUS='<span class="ok">Connected / Configured</span>'; fi
    BTN="<a class=\"btn red\" onclick=\"return confirmRemoveClient('$E_IFACE','$E_SSID','$E_NETWORK')\" href=\"/cgi-bin/wifi_manager.sh?action=remove_client&iface=$E_IFACE&nocache=$(date +%s)\">Disconnect</a>"
    echo "<tr><td><b>$E_IFACE</b></td><td>$E_SSID</td><td>STA Client</td><td>$E_NETWORK</td><td>$STATUS</td><td>$BTN</td></tr>"
done

cat <<EOF
    </table>
    <p><a class="btn grey" onclick="return confirmReload()" href="/cgi-bin/wifi_manager.sh?action=reload_wifi&nocache=$(date +%s)">Reload WiFi</a></p>
    <p class="muted">Last change: $E_LAST</p>
    <p class="muted">System profiles: <b>$SYSTEM_PROFILES</b></p>
    <p class="muted">User profiles: <b>$USER_PROFILES</b></p>
  </div>
</section>
</details>

<div class="footer-actions">
  <a class="btn blue" href="/">Back to Toolkit</a>
</div>

</div>
</body>
</html>
EOF
