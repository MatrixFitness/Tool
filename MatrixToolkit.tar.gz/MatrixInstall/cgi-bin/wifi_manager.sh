#!/bin/sh
# Matrix Toolkit WiFi Manager v60 - web-only 2G/5G/BOTH

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
OLD_CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

url_decode(){
sed -e 's/+/ /g' -e 's/%0[Dd]//g' -e 's/%0[Aa]/ /g' -e 's/%3[Dd]/=/g' \
-e 's/%7[Bb]/{/g' -e 's/%7[Dd]/}/g' -e 's/%20/ /g' -e 's/%21/!/g' \
-e 's/%23/#/g' -e 's/%24/$/g' -e 's/%25/%/g' -e 's/%26/\&/g' \
-e 's/%28/(/g' -e 's/%29/)/g' -e 's/%2[Aa]/*/g' -e 's/%2[Bb]/+/g' \
-e 's/%2[Cc]/,/g' -e 's/%2[Dd]/-/g' -e 's/%2[Ee]/./g' -e 's/%2[Ff]/\//g' \
-e 's/%3[Aa]/:/g' -e 's/%3[Bb]/;/g' -e 's/%3[Ff]/?/g' -e 's/%40/@/g' \
-e 's/%5[Bb]/[/g' -e 's/%5[Dd]/]/g' -e 's/%5[Ee]/^/g' -e 's/%5[Ff]/_/g' \
-e 's/%7[Cc]/|/g' -e 's/%7[Ee]/~/g'
}

qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode; }

write_defaults(){
cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default 5G
PROFILE1_BAND=5G
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM 2G
PROFILE2_BAND=2G
PROFILE2_SSID=egym
PROFILE2_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2

PROFILE3_NAME=Customer Both
PROFILE3_BAND=BOTH
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
DEFEOF
}

ensure_config(){
mkdir -p /usr/local/matrix 2>/dev/null
if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null; fi
if [ ! -f "$CONFIG" ]; then
  if [ -f "$DEFAULTS" ]; then cat "$DEFAULTS" > "$CONFIG" 2>/dev/null; else write_defaults "$CONFIG"; fi
fi
[ -f "$DEFAULTS" ] || write_defaults "$DEFAULTS"
[ -f "$PREVIOUS" ] || cat "$CONFIG" > "$PREVIOUS" 2>/dev/null
chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
}

profile_count(){ grep -o "^PROFILE[0-9][0-9]*_" "$CONFIG" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1; }
profile_value(){ IDX="$1"; KEY="$2"; grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-; }
backup_current(){ cat "$CONFIG" > "$PREVIOUS" 2>/dev/null; cat "$CONFIG" > "/tmp/matrix_wifi_profiles.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null; }
resolve_ssid(){ RAW="$1"; HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="Matrix"; printf '%s' "$RAW" | sed "s/{HOSTNAME}/$HOST/g"; }
normalize_band(){ B="$(printf '%s' "$1" | tr 'a-z' 'A-Z')"; case "$B" in 2G|2.4G|2.4GHZ) echo 2G;; 5G|5GHZ) echo 5G;; BOTH|ALL|2G+5G) echo BOTH;; *) echo 5G;; esac; }
band_label(){ case "$(normalize_band "$1")" in 2G) echo "2.4 GHz";; 5G) echo "5 GHz";; BOTH) echo "2.4 + 5 GHz";; esac; }

page_header(){
TITLE="$1"
cat <<EOF
Content-Type: text/html

<!DOCTYPE html><html><head><title>$TITLE</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.page{max-width:1080px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}table{width:100%;border-collapse:collapse;background:white}th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:middle}th{background:#f0f6fb;color:#005a9c}input[type=text],input[type=password],select{width:100%;height:40px;border:1px solid #ccc;border-radius:6px;padding:0 8px;box-sizing:border-box;font-size:14px;background:white}.field{margin:12px 0}.field label{display:block;font-size:12px;color:#666;font-weight:bold;margin-bottom:4px}.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>function confirmApply(n,b,s){return confirm('Apply WiFi profile: '+n+'\\nBand: '+b+'\\nSSID: '+s+'\\n\\nWiFi will reload. Continue?');}function confirmDelete(n){return confirm('Delete profile: '+n+' ?');}function confirmPrevious(){return confirm('Restore previous profile configuration?');}function confirmFactory(){return confirm('Restore factory/default profiles?');}function togglePw(id){var x=document.getElementById(id);x.type=x.type==='password'?'text':'password';}</script>
</head><body><div class="page">
EOF
}
page_footer(){ echo '</div></body></html>'; }

ensure_config
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="Matrix"
SSID_2G="$(uci get wireless.default_radio0.ssid 2>/dev/null)"; SSID_5G="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
[ -z "$SSID_2G" ] && SSID_2G="Unknown"; [ -z "$SSID_5G" ] && SSID_5G="Unknown"
COUNT="$(profile_count)"; [ -z "$COUNT" ] && COUNT=0
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"; [ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."
E_HOST="$(html_escape "$HOST")"; E_2G="$(html_escape "$SSID_2G")"; E_5G="$(html_escape "$SSID_5G")"; E_LAST="$(html_escape "$LAST")"
page_header "Matrix WiFi Manager"
cat <<EOF
<h1>Matrix WiFi Manager</h1><div class="topgrid"><div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div><div class="card"><div class="label">Current 2.4 GHz</div><div class="value">$E_2G</div></div><div class="card"><div class="label">Current 5 GHz</div><div class="value">$E_5G</div></div><div class="card"><div class="label">Profiles</div><div class="value">$COUNT</div></div></div><div class="card"><h2>Profiles</h2><table><tr><th>#</th><th>Name</th><th>Band</th><th>SSID</th><th>Password</th><th>Status</th><th>Actions</th></tr>
EOF
i=1
while [ "$i" -le "$COUNT" ]; do
 NAME="$(profile_value "$i" NAME)"; BAND="$(normalize_band "$(profile_value "$i" BAND)")"; SSID_RAW="$(profile_value "$i" SSID)"; RESOLVED="$(resolve_ssid "$SSID_RAW")"; BLABEL="$(band_label "$BAND")"
 E_NAME="$(html_escape "$NAME")"; E_BAND="$(html_escape "$BLABEL")"; E_SSID="$(html_escape "$RESOLVED")"
 STATUS="<span class=\"muted\">Available</span>"
 if [ "$BAND" = "2G" ] && [ "$RESOLVED" = "$SSID_2G" ]; then STATUS="<span class=\"active\">Active 2.4</span>"; fi
 if [ "$BAND" = "5G" ] && [ "$RESOLVED" = "$SSID_5G" ]; then STATUS="<span class=\"active\">Active 5</span>"; fi
 if [ "$BAND" = "BOTH" ] && [ "$RESOLVED" = "$SSID_2G" ] && [ "$RESOLVED" = "$SSID_5G" ]; then STATUS="<span class=\"active\">Active Both</span>"; fi
 echo "<tr><td>$i</td><td><b>$E_NAME</b></td><td>$E_BAND</td><td>$E_SSID</td><td>********</td><td>$STATUS</td><td><a class=\"btn blue\" href=\"/cgi-bin/wifi_profile_edit.sh?p=$i\">Edit</a><a class=\"btn green\" onclick=\"return confirmApply('$E_NAME','$E_BAND','$E_SSID')\" href=\"/cgi-bin/wifi_profile.sh?p=$i\">Apply</a><a class=\"btn red\" onclick=\"return confirmDelete('$E_NAME')\" href=\"/cgi-bin/wifi_profile_save.sh?action=delete&profile=$i\">Delete</a></td></tr>"
 i=$((i+1))
done
cat <<EOF
</table><p><a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add">+ Add Profile</a><a class="btn orange" onclick="return confirmPrevious()" href="/cgi-bin/wifi_profiles_restore_previous.sh">Restore Previous</a><a class="btn red" onclick="return confirmFactory()" href="/cgi-bin/wifi_profiles_reset.sh">Restore Factory Defaults</a><a class="btn blue" href="/">Back to Toolkit</a></p></div><div class="card"><h2>Status</h2><p class="muted">Last change: $E_LAST</p><p class="muted">2.4 GHz target: <b>wireless.default_radio0</b></p><p class="muted">5 GHz target: <b>wireless.default_radio1</b></p></div>
EOF
page_footer
