#!/bin/sh
# Matrix Toolkit WiFi Manager v63
# Integrated WiFi Interface Control + Profile Manager
# Web-only path: /usr/local/matrix/web/cgi-bin/wifi_manager.sh

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
OLD_CONFIG="/usr/local/matrix/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

url_decode(){
sed -e 's/+/ /g' -e 's/%0[Dd]//g' -e 's/%0[Aa]/ /g' -e 's/%3[Dd]/=/g' \
-e 's/%7[Bb]/{/g' -e 's/%7[Dd]/}/g' -e 's/%20/ /g' -e 's/%21/!/g' \
-e 's/%23/#/g' -e 's/%24/$/g' -e 's/%25/%/g' -e 's/%26/\&/g' \
-e 's/%28/(/g' -e 's/%29/)/g' -e 's/%2[Aa]/*/g' -e 's/%2[Bb]/+/g' \
-e 's/%2[Cc]/,/g' -e 's/%2[Dd]/-/g' -e 's/%2[Ee]/./g' -e 's/%2[Ff]/\//g' \
-e 's/%3[Aa]/:/g' -e 's/%3[Bb]/;/g' -e 's/%3[Ff]/?/g' -e 's/%40/@/g' \
-e 's/%5[Bb]/[/g' -e 's/%5[Dd]/]/g' -e 's/%5[Ee]/^/g' -e 's/%5[Ff]/_/g' \
-e 's/%7[Cc]/|/g' -e 's/%7[Ee]/~/g'
}

qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode; }

write_defaults(){
cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default Dual
PROFILE1_MODE=DUAL
PROFILE1_2G_SSID={HOSTNAME}_2G
PROFILE1_2G_PASSWORD=matrixfitness
PROFILE1_5G_SSID={HOSTNAME}_5G
PROFILE1_5G_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM 2.4 GHz
PROFILE2_MODE=SINGLE
PROFILE2_BAND=2G
PROFILE2_SSID=egym
PROFILE2_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2

PROFILE3_NAME=Customer Dual
PROFILE3_MODE=DUAL
PROFILE3_2G_SSID=ClubWifi
PROFILE3_2G_PASSWORD=Welkom123
PROFILE3_5G_SSID=ClubWifi_5G
PROFILE3_5G_PASSWORD=Welkom123
DEFEOF
}

profile_count(){ grep -o "^PROFILE[0-9][0-9]*_" "$CONFIG" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1; }
profile_value(){ IDX="$1"; KEY="$2"; grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-; }
backup_current(){ cat "$CONFIG" > "$PREVIOUS" 2>/dev/null; cat "$CONFIG" > "/tmp/matrix_wifi_profiles.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null; }
hostname_value(){ H="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$H" ] && H="$(hostname 2>/dev/null)"; [ -z "$H" ] && H="Matrix"; echo "$H"; }
resolve_ssid(){ RAW="$1"; HOST="$(hostname_value)"; printf '%s' "$RAW" | sed "s/{HOSTNAME}/$HOST/g"; }
normalize_mode(){ M="$(printf '%s' "$1" | tr 'a-z' 'A-Z')"; case "$M" in DUAL) echo DUAL;; *) echo SINGLE;; esac; }
normalize_band(){ B="$(printf '%s' "$1" | tr 'a-z' 'A-Z')"; case "$B" in 2G|2.4G|2.4GHZ) echo 2G;; 5G|5GHZ) echo 5G;; *) echo 5G;; esac; }
band_label(){ case "$(normalize_band "$1")" in 2G) echo "2.4 GHz";; 5G) echo "5 GHz";; esac; }

migrate_profiles_dual(){
    [ -f "$CONFIG" ] || return 0
    grep -q "^PROFILE[0-9][0-9]*_MODE=" "$CONFIG" 2>/dev/null && return 0

    TMP="/tmp/matrix_wifi_profiles_migrate.$$"
    COUNT="$(profile_count)"
    [ -z "$COUNT" ] && COUNT=0

    backup_current
    : > "$TMP"

    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(profile_value "$i" NAME)"
        SSID="$(profile_value "$i" SSID)"
        PASS="$(profile_value "$i" PASSWORD)"
        BAND="$(normalize_band "$(profile_value "$i" BAND)")"

        LOW_NAME="$(printf '%s' "$NAME" | tr 'A-Z' 'a-z')"
        LOW_SSID="$(printf '%s' "$SSID" | tr 'A-Z' 'a-z')"

        if echo "$LOW_NAME $LOW_SSID" | grep -q "egym"; then
            {
                echo "PROFILE${i}_NAME=${NAME:-EGYM 2.4 GHz}"
                echo "PROFILE${i}_MODE=SINGLE"
                echo "PROFILE${i}_BAND=2G"
                echo "PROFILE${i}_SSID=${SSID:-egym}"
                echo "PROFILE${i}_PASSWORD=${PASS:-9be5ff942822c22cdbe7010d7c1c18b2}"
                echo ""
            } >> "$TMP"
        elif [ "$i" = "1" ]; then
            {
                echo "PROFILE${i}_NAME=Matrix Default Dual"
                echo "PROFILE${i}_MODE=DUAL"
                echo "PROFILE${i}_2G_SSID={HOSTNAME}_2G"
                echo "PROFILE${i}_2G_PASSWORD=${PASS:-matrixfitness}"
                echo "PROFILE${i}_5G_SSID={HOSTNAME}_5G"
                echo "PROFILE${i}_5G_PASSWORD=${PASS:-matrixfitness}"
                echo ""
            } >> "$TMP"
        else
            {
                echo "PROFILE${i}_NAME=${NAME:-Profile $i}"
                echo "PROFILE${i}_MODE=SINGLE"
                echo "PROFILE${i}_BAND=$BAND"
                echo "PROFILE${i}_SSID=${SSID:-NewSSID}"
                echo "PROFILE${i}_PASSWORD=${PASS:-password}"
                echo ""
            } >> "$TMP"
        fi

        i=$((i+1))
    done

    cat "$TMP" > "$CONFIG"
    rm -f "$TMP" 2>/dev/null
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    echo "$(date '+%Y-%m-%d %H:%M:%S') Migrated WiFi profiles to v63 dual structure" >> "$LOG"
}

ensure_config(){
mkdir -p /usr/local/matrix 2>/dev/null
if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null; fi
if [ ! -f "$CONFIG" ]; then
  if [ -f "$DEFAULTS" ]; then cat "$DEFAULTS" > "$CONFIG" 2>/dev/null; else write_defaults "$CONFIG"; fi
fi
[ -f "$DEFAULTS" ] || write_defaults "$DEFAULTS"
[ -f "$PREVIOUS" ] || cat "$CONFIG" > "$PREVIOUS" 2>/dev/null
chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
migrate_profiles_dual
}

apply_interface_action(){
    ACTION="$1"
    IFACE="$2"
    [ -n "$ACTION" ] || return 0
    [ -n "$IFACE" ] || return 0

    SSID="$(uci get wireless.${IFACE}.ssid 2>/dev/null)"
    [ -z "$SSID" ] && SSID="Unknown"

    case "$ACTION" in
        enable_iface)
            uci set wireless.${IFACE}.disabled='0'
            uci commit wireless
            wifi reload >/dev/null 2>&1
            echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface enabled iface=$IFACE ssid=$SSID" >> "$LOG"
            ;;
        disable_iface)
            uci set wireless.${IFACE}.disabled='1'
            uci commit wireless
            wifi reload >/dev/null 2>&1
            echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi interface disabled iface=$IFACE ssid=$SSID" >> "$LOG"
            ;;
        reload_wifi)
            wifi reload >/dev/null 2>&1
            echo "$(date '+%Y-%m-%d %H:%M:%S') WiFi reload requested from WiFi Manager" >> "$LOG"
            ;;
    esac
}

page_header(){
TITLE="$1"
cat <<EOF
Content-Type: text/html

<!DOCTYPE html>
<html>
<head>
<title>$TITLE</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}
.page{max-width:1120px;margin:0 auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
h1{margin:0 0 14px 0;color:#005a9c;font-size:28px}
h2{margin:0 0 10px 0;color:#005a9c;font-size:20px}
.card{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:15px;margin:14px 0;line-height:1.55}
.topgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.label{font-size:12px;color:#666;text-transform:uppercase;font-weight:bold}
.value{font-size:18px;font-weight:bold;color:#222;word-break:break-all}
.btn{display:inline-block;border:none;border-radius:6px;color:white;text-decoration:none;font-weight:bold;cursor:pointer;padding:10px 13px;margin:3px;font-size:14px}
.blue{background:#007bff}.green{background:#28a745}.orange{background:#fd7e14}.red{background:#dc3545}.grey{background:#666}
table{width:100%;border-collapse:collapse;background:white}
th,td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:middle}
th{background:#f0f6fb;color:#005a9c}
.active{color:#1f8a3b;font-weight:bold}.muted{color:#777;font-size:13px}.err{color:#c82333;font-weight:bold}.ok{color:#1f8a3b;font-weight:bold}.warn{color:#b35b00;font-weight:bold}
@media(max-width:900px){body{margin:12px}.page{padding:16px}.topgrid{grid-template-columns:1fr}.btn{display:block;text-align:center;margin-bottom:8px}th,td{font-size:13px;padding:8px}}
</style>
<script>
function confirmApply(n,m,s){return confirm('Apply WiFi profile: '+n+'\\nMode: '+m+'\\n'+s+'\\n\\nWiFi will reload. Continue?');}
function confirmDelete(n){return confirm('Delete profile: '+n+' ?');}
function confirmPrevious(){return confirm('Restore previous profile configuration?');}
function confirmFactory(){return confirm('Restore factory/default profiles?');}
function confirmIface(action, iface, ssid){return confirm(action+' WiFi interface?\\n\\nInterface: '+iface+'\\nSSID: '+ssid+'\\n\\nWiFi will reload. Continue?');}
function confirmReload(){return confirm('Reload WiFi now?');}
</script>
</head>
<body>
<div class="page">
EOF
}
page_footer(){ echo '</div></body></html>'; }

ensure_config

ACTION="$(qs action)"
IFACE="$(qs iface)"
apply_interface_action "$ACTION" "$IFACE"

HOST="$(hostname_value)"
SSID_2G="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
SSID_5G="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
[ -z "$SSID_2G" ] && SSID_2G="Unknown"
[ -z "$SSID_5G" ] && SSID_5G="Unknown"

COUNT="$(profile_count)"
[ -z "$COUNT" ] && COUNT=0
LAST="$(tail -n 1 "$LOG" 2>/dev/null)"
[ -z "$LAST" ] && LAST="No WiFi profile changes logged yet."

E_HOST="$(html_escape "$HOST")"
E_2G="$(html_escape "$SSID_2G")"
E_5G="$(html_escape "$SSID_5G")"
E_LAST="$(html_escape "$LAST")"

page_header "Matrix WiFi Manager"

cat <<EOF
<h1>Matrix WiFi Manager v63</h1>
<div class="topgrid">
  <div class="card"><div class="label">Router</div><div class="value">$E_HOST</div></div>
  <div class="card"><div class="label">Current 2.4 GHz</div><div class="value">$E_2G</div></div>
  <div class="card"><div class="label">Current 5 GHz</div><div class="value">$E_5G</div></div>
  <div class="card"><div class="label">Profiles</div><div class="value">$COUNT</div></div>
</div>

<div class="card">
<h2>Restore Matrix Default WiFi</h2>
<p class="muted">Emergency restore to router default WiFi: <b>{HOSTNAME}_2G</b> and <b>{HOSTNAME}_5G</b>. This does not depend on saved profiles.</p>
<p><a class="btn red" onclick="return confirm('Restore Matrix Default WiFi?\n\n2.4 GHz = {HOSTNAME}_2G\n5 GHz = {HOSTNAME}_5G\n\nWiFi will reload. Continue?')" href="/cgi-bin/wifi_restore_matrix_default.sh">Restore Matrix Default WiFi</a></p>
</div>

<div class="card">
<h2>WiFi Interface Control</h2>
<table>
<tr><th>Interface</th><th>Device</th><th>SSID</th><th>Status</th><th>Action</th></tr>
EOF

uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read IFACE_NAME; do
    [ -n "$IFACE_NAME" ] || continue

    SSID="$(uci get wireless.${IFACE_NAME}.ssid 2>/dev/null)"
    DEVICE="$(uci get wireless.${IFACE_NAME}.device 2>/dev/null)"
    DISABLED="$(uci get wireless.${IFACE_NAME}.disabled 2>/dev/null)"

    [ -z "$SSID" ] && SSID="Unknown"
    [ -z "$DEVICE" ] && DEVICE="-"
    [ -z "$DISABLED" ] && DISABLED="0"

    E_IFACE="$(html_escape "$IFACE_NAME")"
    E_SSID="$(html_escape "$SSID")"
    E_DEVICE="$(html_escape "$DEVICE")"

    if [ "$DISABLED" = "1" ]; then
        STATUS='<span class="err">Disabled</span>'
        ACTION_BTN="<a class=\"btn green\" onclick=\"return confirmIface('Enable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=enable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Enable</a>"
    else
        STATUS='<span class="ok">Enabled</span>'
        ACTION_BTN="<a class=\"btn red\" onclick=\"return confirmIface('Disable','$E_IFACE','$E_SSID')\" href=\"/cgi-bin/wifi_manager.sh?action=disable_iface&iface=$E_IFACE&nocache=$(date +%s)\">Disable</a>"
    fi

    echo "<tr><td><b>$E_IFACE</b></td><td>$E_DEVICE</td><td>$E_SSID</td><td>$STATUS</td><td>$ACTION_BTN</td></tr>"
done

cat <<EOF
</table>
<p>
<a class="btn grey" onclick="return confirmReload()" href="/cgi-bin/wifi_manager.sh?action=reload_wifi&nocache=$(date +%s)">Reload WiFi</a>
</p>
<p class="muted">This section enables/disables existing WiFi interfaces. It does not change saved profiles.</p>
</div>

<div class="card">
<h2>Profiles</h2>
<table>
<tr><th>#</th><th>Name</th><th>Mode</th><th>2.4 GHz</th><th>5 GHz</th><th>Status</th><th>Actions</th></tr>
EOF

i=1
while [ "$i" -le "$COUNT" ]; do
 NAME="$(profile_value "$i" NAME)"
 MODE="$(normalize_mode "$(profile_value "$i" MODE)")"
 S2="-"; S5="-"; SUMMARY=""
 if [ "$MODE" = "DUAL" ]; then
   S2="$(resolve_ssid "$(profile_value "$i" 2G_SSID)")"
   S5="$(resolve_ssid "$(profile_value "$i" 5G_SSID)")"
   MODE_LABEL="Dual"
   SUMMARY="2.4: $S2\\\\n5: $S5"
 else
   BAND="$(normalize_band "$(profile_value "$i" BAND)")"
   SSID="$(resolve_ssid "$(profile_value "$i" SSID)")"
   MODE_LABEL="Single $(band_label "$BAND")"
   SUMMARY="$(band_label "$BAND"): $SSID"
   [ "$BAND" = "2G" ] && S2="$SSID" || S5="$SSID"
 fi

 E_NAME="$(html_escape "$NAME")"
 E_MODE="$(html_escape "$MODE_LABEL")"
 E_S2="$(html_escape "$S2")"
 E_S5="$(html_escape "$S5")"

 STATUS="<span class=\"muted\">Available</span>"
 if [ "$MODE" = "DUAL" ] && [ "$S2" = "$SSID_2G" ] && [ "$S5" = "$SSID_5G" ]; then STATUS="<span class=\"active\">Current Dual</span>"; fi
 if [ "$MODE" = "SINGLE" ]; then
   BAND="$(normalize_band "$(profile_value "$i" BAND)")"
   SSID="$(resolve_ssid "$(profile_value "$i" SSID)")"
   DISABLED0="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
   [ -z "$DISABLED0" ] && DISABLED0="0"
   if [ "$BAND" = "2G" ] && [ "$SSID" = "$SSID_2G" ]; then
      if [ "$DISABLED0" = "1" ]; then
          STATUS="<span class=\"warn\">Matches 2.4 but disabled</span>"
      else
          STATUS="<span class=\"active\">Current 2.4</span>"
      fi
   fi
   if [ "$BAND" = "5G" ] && [ "$SSID" = "$SSID_5G" ]; then STATUS="<span class=\"active\">Current 5</span>"; fi
 fi

 echo "<tr><td>$i</td><td><b>$E_NAME</b></td><td>$E_MODE</td><td>$E_S2</td><td>$E_S5</td><td>$STATUS</td><td><a class=\"btn blue\" href=\"/cgi-bin/wifi_profile_edit.sh?p=$i\">Edit</a><a class=\"btn green\" onclick=\"return confirmApply('$E_NAME','$E_MODE','$SUMMARY')\" href=\"/cgi-bin/wifi_profile.sh?p=$i\">Apply</a><a class=\"btn red\" onclick=\"return confirmDelete('$E_NAME')\" href=\"/cgi-bin/wifi_profile_save.sh?action=delete&profile=$i\">Delete</a></td></tr>"
 i=$((i+1))
done

cat <<EOF
</table>
<p>
<a class="btn orange" href="/cgi-bin/wifi_profile_save.sh?action=add">+ Add Profile</a>
<a class="btn orange" onclick="return confirmPrevious()" href="/cgi-bin/wifi_profiles_restore_previous.sh">Restore Previous</a>
<a class="btn red" onclick="return confirmFactory()" href="/cgi-bin/wifi_profiles_reset.sh">Restore Factory Defaults</a>
<a class="btn blue" href="/">Back to Toolkit</a>
</p>
</div>

<div class="card">
<h2>Status</h2>
<p class="muted">Last change: $E_LAST</p>
<p class="muted">Profile config: <b>$CONFIG</b></p>
<p class="muted">2.4 GHz target: <b>wireless.default_radio0</b></p>
<p class="muted">5 GHz target: <b>wireless.default_radio1</b></p>
</div>
EOF

page_footer
