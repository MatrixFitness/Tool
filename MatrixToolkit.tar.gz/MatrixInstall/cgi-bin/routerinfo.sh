#!/bin/sh

echo "Content-Type: text/html"
echo ""

ZT_HOME="/etc/zerotier"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"

HOSTNAME=$(ubus call system board 2>/dev/null | jsonfilter -e '@.hostname')
MODEL=$(ubus call system board 2>/dev/null | jsonfilter -e '@.model')
KERNEL=$(ubus call system board 2>/dev/null | jsonfilter -e '@.kernel')
FIRMWARE=$(cat /etc/version 2>/dev/null)
UPTIME=$(uptime | awk -F'up ' '{print $2}' | awk -F',' '{print $1}')

LANIP=$(ip -4 addr show br-lan 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
WANIP=$(ip -4 addr show eth1 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
LTEIP=$(ip -4 addr show qmimux0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
PUBLIC_IP=$(wget -q -O - https://api.ipify.org 2>/dev/null)

ROUTE=$(ip route | grep "^default" | head -1)

ACTIVE_DEV=$(echo "$ROUTE" | sed -n 's/.*dev \([^ ]*\).*/\1/p')
GATEWAY=$(echo "$ROUTE" | sed -n 's/.*via \([^ ]*\).*/\1/p')

[ -z "$ACTIVE_DEV" ] && ACTIVE_DEV="Unknown"
[ -z "$GATEWAY" ] && GATEWAY="N/A"

CONNECTION_TYPE="Unknown"

if echo "$ACTIVE_DEV" | grep -q "^eth"; then
    CONNECTION_TYPE="WAN / Ethernet"
elif echo "$ACTIVE_DEV" | grep -q "^wlan"; then
    CONNECTION_TYPE="Customer WiFi"
elif echo "$ACTIVE_DEV" | grep -q "qmimux\|wwan\|mob"; then
    CONNECTION_TYPE="LTE / 5G"
fi

WAN_STATUS=$(ubus call network.interface.wan status 2>/dev/null)
WAN_PROTO=$(echo "$WAN_STATUS" | grep '"proto"' | head -1 | cut -d'"' -f4)
WAN_DEVICE=$(echo "$WAN_STATUS" | grep '"device"' | head -1 | cut -d'"' -f4)
WAN_UPTIME=$(echo "$WAN_STATUS" | grep '"uptime"' | grep -o '[0-9]*' | head -1)

if [ -n "$WAN_UPTIME" ]; then
    HOURS=$((WAN_UPTIME / 3600))
    MINS=$(((WAN_UPTIME % 3600) / 60))
    WAN_UPTIME_TXT="${HOURS} uur ${MINS} min"
else
    WAN_UPTIME_TXT="Onbekend"
fi

DNS1=$(echo "$WAN_STATUS" | grep -A5 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '1p')
DNS2=$(echo "$WAN_STATUS" | grep -A5 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '2p')

OPERATOR=$(gsmctl -o 2>/dev/null)
TECH=$(gsmctl -t 2>/dev/null)
SIGNAL=$(gsmctl -q 2>/dev/null)
REGISTRATION=$(gsmctl -j 2>/dev/null)

[ -z "$OPERATOR" ] && OPERATOR="Not available"
[ -z "$TECH" ] && TECH="Not available"
[ -z "$SIGNAL" ] && SIGNAL="Not available"
[ -z "$REGISTRATION" ] && REGISTRATION="Unknown"
[ -z "$LANIP" ] && LANIP="Not available"
[ -z "$WANIP" ] && WANIP="Not available"
[ -z "$LTEIP" ] && LTEIP="Not available"
[ -z "$PUBLIC_IP" ] && PUBLIC_IP="Not available"
[ -z "$DNS1" ] && DNS1="Not available"
[ -z "$DNS2" ] && DNS2="Not available"
[ -z "$WAN_PROTO" ] && WAN_PROTO="Not available"
[ -z "$WAN_DEVICE" ] && WAN_DEVICE="Not available"


ZT_STATUS="Not installed"
ZT_NETWORKS=""
ZT_IP=""
ZT_URL_TOOLKIT=""
ZT_URL_ADMIN=""

if [ -x "$ZT_CLI" ]; then
    ZT_STATUS=$("$ZT_CLI" info 2>/dev/null)
    ZT_NETWORKS=$("$ZT_CLI" listnetworks 2>/dev/null)
    ZT_IP=$(ip addr | grep "10.74." | awk '{print $2}' | head -1 | cut -d/ -f1)

    if [ -n "$ZT_IP" ]; then
        ZT_URL_TOOLKIT="http://$ZT_IP:8080"
        ZT_URL_ADMIN="http://$ZT_IP:8081"
    fi
fi

[ -z "$ZT_STATUS" ] && ZT_STATUS="Not available"
[ -z "$ZT_NETWORKS" ] && ZT_NETWORKS="Not available"
[ -z "$ZT_IP" ] && ZT_IP="Not available"
[ -z "$ZT_URL_TOOLKIT" ] && ZT_URL_TOOLKIT="Not available"
[ -z "$ZT_URL_ADMIN" ] && ZT_URL_ADMIN="Not available"


check_cmd() {
    if "$@" >/dev/null 2>&1; then
        echo "<span class='pass'>PASS</span>"
    else
        echo "<span class='fail'>FAIL</span>"
    fi
}

cat << EOF
<html>
<head>
<title>Matrix Router Information</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">

<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background: #f5f5f5;
    color: #333;
}

.page {
    max-width: 1120px;
    margin: 0 auto;
}

h1 {
    margin: 0 0 5px 0;
    color: #005a9c;
    font-size: 28px;
}

h2 {
    margin: 0 0 12px 0;
    color: #005a9c;
    font-size: 19px;
}

.grid {
    display: flex;
    flex-wrap: wrap;
    gap: 18px;
}

.card {
    background: white;
    border-radius: 9px;
    padding: 16px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.12);
    margin-bottom: 18px;
    box-sizing: border-box;
}

.card.half {
    flex: 1;
    min-width: 480px;
}

.card.full {
    width: 100%;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th {
    background: #007bff;
    color: white;
    padding: 8px;
    text-align: left;
}

td {
    border: 1px solid #ddd;
    padding: 7px;
    vertical-align: top;
}

.pass {
    color: green;
    font-weight: bold;
}

.fail {
    color: red;
    font-weight: bold;
}

.warn {
    color: orange;
    font-weight: bold;
}

pre {
    background: #111;
    color: #eee;
    padding: 12px;
    border-radius: 6px;
    overflow: auto;
    white-space: pre-wrap;
}

.badge {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    background: #007bff;
}

.badge.lte {
    background: #fd7e14;
}

.badge.wan {
    background: #28a745;
}

.badge.unknown {
    background: #6c757d;
}

button {
    width: 210px;
    height: 48px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: 0;
    border-radius: 6px;
    margin-right: 10px;
    background: #007bff;
    color: white;
}

@media(max-width:900px){
    body { margin: 12px; }
    .card.half { min-width: 100%; }
    button { width: 100%; max-width: 420px; margin-bottom: 8px; }
}

</style>
</head>

<body>
<div class="page">

<h1>Matrix Router Information</h1>
<p><b>Datum:</b> $(date)</p>

<div class="grid">

<div class="card half">
<h2>Systeem</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Hostname</td><td>$HOSTNAME</td></tr>
<tr><td>Model</td><td>$MODEL</td></tr>
<tr><td>Firmware</td><td>$FIRMWARE</td></tr>
<tr><td>Kernel</td><td>$KERNEL</td></tr>
<tr><td>Uptime</td><td>$UPTIME</td></tr>
</table>
</div>

<div class="card half">
<h2>Actieve verbinding</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Type</td><td><span class="badge">$CONNECTION_TYPE</span></td></tr>
<tr><td>Default route</td><td>$ROUTE</td></tr>
<tr><td>Gateway</td><td>$GATEWAY</td></tr>
<tr><td>Interface</td><td>$ACTIVE_DEV</td></tr>
<tr><td>Public IP</td><td>$PUBLIC_IP</td></tr>
</table>
</div>

<div class="card half">
<h2>LAN / WAN</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>LAN IP</td><td>$LANIP</td></tr>
<tr><td>WAN IP</td><td>$WANIP</td></tr>
<tr><td>WAN Device</td><td>$WAN_DEVICE</td></tr>
<tr><td>WAN Protocol</td><td>$WAN_PROTO</td></tr>
<tr><td>WAN Uptime</td><td>$WAN_UPTIME_TXT</td></tr>
<tr><td>DNS 1</td><td>$DNS1</td></tr>
<tr><td>DNS 2</td><td>$DNS2</td></tr>
</table>
</div>

<div class="card half">
<h2>LTE / Mobiel netwerk</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>LTE IP</td><td>$LTEIP</td></tr>
<tr><td>Operator</td><td><span class="badge lte">$OPERATOR</span></td></tr>
<tr><td>Technologie</td><td><span class="badge">$TECH</span></td></tr>
</table>
<pre>$SIGNAL

Registration Status:
$REGISTRATION</pre>
</div>

<div class="card half">
<h2>Connectiviteit</h2>
<table>
<tr><th>Test</th><th>Status</th></tr>
<tr><td>Internet ping 8.8.8.8</td><td>$(check_cmd ping -c 2 -W 3 8.8.8.8)</td></tr>
<tr><td>DNS google.com</td><td>$(check_cmd nslookup google.com)</td></tr>
<tr><td>Matrix Cloud</td><td>$(check_cmd nslookup am4.matrixfitness.com)</td></tr>
<tr><td>Toolkit poort 8080</td><td>$(check_cmd wget -q -O - http://127.0.0.1:8080)</td></tr>
<tr><td>Admin poort 8081</td><td>$(check_cmd wget -q -O - http://127.0.0.1:8081)</td></tr>
</table>
</div>

<div class="card half">
<h2>ZeroTier Remote Access</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Status</td><td><pre>$ZT_STATUS</pre></td></tr>
<tr><td>ZeroTier IP</td><td>$ZT_IP</td></tr>
<tr><td>Toolkit Remote URL</td><td>$ZT_URL_TOOLKIT</td></tr>
<tr><td>Admin Remote URL</td><td>$ZT_URL_ADMIN</td></tr>
</table>
</div>

<div class="card full">
<h2>ZeroTier Networks</h2>
<pre>$ZT_NETWORKS</pre>
</div>

<div class="card full">
<h2>Open webpoorten</h2>
<pre>$(netstat -lnp | grep -E ":80|:443|:8080|:8081")</pre>
</div>

</div>

<br>
<button onclick="window.location='/'">Return to Home</button>
<button onclick="window.location='/admin/'">Return to Admin</button>

</div>
</body>
</html>
EOF