#!/bin/sh

echo "Content-Type: text/html"
echo ""

HOSTNAME=$(ubus call system board | jsonfilter -e '@.hostname')
MODEL=$(ubus call system board | jsonfilter -e '@.model')
KERNEL=$(ubus call system board | jsonfilter -e '@.kernel')

FIRMWARE=$(cat /etc/version)

UPTIME=$(uptime | awk -F'up ' '{print $2}' | awk -F',' '{print $1}')

LANIP=$(ip -4 addr show br-lan 2>/dev/null | grep inet | awk '{print $2}' | cut -d/ -f1)
WANIP=$(ip -4 addr show eth1 2>/dev/null | grep inet | awk '{print $2}' | cut -d/ -f1)
LTEIP=$(ip -4 addr show qmimux0 2>/dev/null | grep inet | awk '{print $2}' | cut -d/ -f1)

GATEWAY=$(ip route | grep default | head -1 | awk '{print $3}')

OPERATOR=$(gsmctl -o 2>/dev/null)
TECH=$(gsmctl -t 2>/dev/null)

RSSI=$(gsmctl -q 2>/dev/null | grep RSSI | awk '{print $2}')
RSRP=$(gsmctl -q 2>/dev/null | grep RSRP | awk '{print $2}')
RSRQ=$(gsmctl -q 2>/dev/null | grep RSRQ | awk '{print $2}')
SINR=$(gsmctl -q 2>/dev/null | grep SINR | awk '{print $2}')

echo "<html>"
echo "<head>"
echo "<title>Router Info</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;}"
echo "table{border-collapse:collapse;width:800px;}"
echo "th,td{border:1px solid #ccc;padding:8px;text-align:left;}"
echo "th{background:#f2f2f2;}"
echo ".pass{color:green;font-weight:bold;}"
echo ".fail{color:red;font-weight:bold;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h1>Router Info</h1>"

echo "<table>"

echo "<tr><th colspan='2'>Router</th></tr>"
echo "<tr><td>Hostname</td><td>$HOSTNAME</td></tr>"
echo "<tr><td>Model</td><td>$MODEL</td></tr>"
echo "<tr><td>Firmware</td><td>$FIRMWARE</td></tr>"
echo "<tr><td>Kernel</td><td>$KERNEL</td></tr>"
echo "<tr><td>Uptime</td><td>$UPTIME</td></tr>"

echo "<tr><th colspan='2'>Netwerk</th></tr>"
echo "<tr><td>LAN IP</td><td>$LANIP</td></tr>"
echo "<tr><td>WAN IP</td><td>$WANIP</td></tr>"
echo "<tr><td>Gateway</td><td>$GATEWAY</td></tr>"
echo "<tr><td>LTE IP</td><td>$LTEIP</td></tr>"

echo "<tr><th colspan='2'>Mobiel Netwerk</th></tr>"
echo "<tr><td>Operator</td><td>$OPERATOR</td></tr>"
echo "<tr><td>Technologie</td><td>$TECH</td></tr>"
echo "<tr><td>RSSI</td><td>$RSSI dBm</td></tr>"
echo "<tr><td>RSRP</td><td>$RSRP dBm</td></tr>"
echo "<tr><td>RSRQ</td><td>$RSRQ dB</td></tr>"
echo "<tr><td>SINR</td><td>$SINR dB</td></tr>"

echo "<tr><th colspan='2'>Connectiviteit</th></tr>"

if ping -c 1 8.8.8.8 >/dev/null 2>&1
then
echo "<tr><td>Internet</td><td class='pass'>PASS</td></tr>"
else
echo "<tr><td>Internet</td><td class='fail'>FAIL</td></tr>"
fi

if nslookup am4.matrixfitness.com >/dev/null 2>&1
then
echo "<tr><td>Matrix Cloud</td><td class='pass'>PASS</td></tr>"
else
echo "<tr><td>Matrix Cloud</td><td class='fail'>FAIL</td></tr>"
fi

echo "</table>"

echo "<br>"
echo "<a href='/index.html'>Terug naar Matrix Toolkit</a>"

echo "</body>"
echo "</html>"
