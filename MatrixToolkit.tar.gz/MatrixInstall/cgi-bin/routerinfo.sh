#!/bin/sh

echo "Content-Type: text/html"
echo ""

ZT_HOME="/etc/zerotier"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"

HOSTNAME=$(ubus call system board 2>/dev/null | jsonfilter -e '@.hostname')
MODEL=$(ubus call system board 2>/dev/null | jsonfilter -e '@.model')
KERNEL=$(ubus call system board 2>/dev/null | jsonfilter -e '@.kernel')
FIRMWARE=$(cat /etc/version 2>/dev/null)
UPTIME=$(uptime | awk -F'up ' '{print $2}' | awk -F',' '{print $1}')

LANIP=$(ip -4 addr show br-lan 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
WANIP=$(ip -4 addr show eth1 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
LTEIP=$(ip -4 addr show qmimux0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
PUBLIC_IP=$(wget -q -O - https://api.ipify.org 2>/dev/null)

ROUTE=$(ip route | grep "^default" | head -1)

ACTIVE_DEV=$(echo "$ROUTE" | sed -n 's/.*dev \([^ ]*\).*/\1/p')
GATEWAY=$(echo "$ROUTE" | sed -n 's/.*via \([^ ]*\).*/\1/p')

[ -z "$ACTIVE_DEV" ] && ACTIVE_DEV="Unknown"
[ -z "$GATEWAY" ] && GATEWAY="N/A"

CONNECTION_TYPE="Unknown"

if echo "$ACTIVE_DEV" | grep -q "^eth"; then
    CONNECTION_TYPE="WAN / Ethernet"
elif echo "$ACTIVE_DEV" | grep -q "^wlan"; then
    CONNECTION_TYPE="Customer WiFi"
elif echo "$ACTIVE_DEV" | grep -q "qmimux\|wwan\|mob"; then
    CONNECTION_TYPE="LTE / 5G"
fi

WAN_STATUS=$(ubus call network.interface.wan status 2>/dev/null)
WAN_PROTO=$(echo "$WAN_STATUS" | grep '"proto"' | head -1 | cut -d'"' -f4)
WAN_DEVICE=$(echo "$WAN_STATUS" | grep '"device"' | head -1 | cut -d'"' -f4)
WAN_UPTIME=$(echo "$WAN_STATUS" | grep '"uptime"' | grep -o '[0-9]*' | head -1)

if [ -n "$WAN_UPTIME" ]; then
    HOURS=$((WAN_UPTIME / 3600))
    MINS=$(((WAN_UPTIME % 3600) / 60))
    WAN_UPTIME_TXT="${HOURS} uur ${MINS} min"
else
    WAN_UPTIME_TXT="Onbekend"
fi

DNS1=$(echo "$WAN_STATUS" | grep -A5 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '1p')
DNS2=$(echo "$WAN_STATUS" | grep -A5 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '2p')

gsm_value() {
    CMD="$1"
    VALUE=""
    for TRY in 1 2 3; do
        VALUE=$(gsmctl "$CMD" 2>/dev/null)
        echo "$VALUE" | grep -qi "ERROR:" && VALUE=""
        [ -n "$VALUE" ] && break
        sleep 1
    done
    printf "%s" "$VALUE"
}

OPERATOR=$(gsm_value -o)
TECH=$(gsm_value -t)
SIGNAL=$(gsm_value -q)
REGISTRATION=$(gsm_value -j)

[ -z "$OPERATOR" ] && OPERATOR="Not available"
[ -z "$TECH" ] && TECH="Not available"
[ -z "$SIGNAL" ] && SIGNAL="Not available"
[ -z "$REGISTRATION" ] && REGISTRATION="Unknown"

ZT_STATUS="Not installed"
ZT_NETWORKS=""
ZT_IP=""
ZT_URL_TOOLKIT=""
ZT_URL_ADMIN=""

if [ -x "$ZT_CLI" ]; then
    ZT_STATUS=$("$ZT_CLI" info 2>/dev/null)
    ZT_NETWORKS=$("$ZT_CLI" listnetworks 2>/dev/null)
    ZT_IP=$(ip addr | grep "10.74." | awk '{print $2}' | head -1 | cut -d/ -f1)

    if [ -n "$ZT_IP" ]; then
        ZT_URL_TOOLKIT="http://$ZT_IP:8080"
        ZT_URL_ADMIN="http://$ZT_IP:8081"
    fi
fi

check_cmd() {
    if "$@" >/dev/null 2>&1; then
        echo "<span class='pass'>PASS</span>"
    else
        echo "<span class='fail'>FAIL</span>"
    fi
}

cat << EOF
<html>
<head>
<title>Router Info</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">

<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background: #f5f5f5;
    color: #333;
}

h1 {
    margin-bottom: 5px;
}

h2 {
    margin-top: 0;
}

.grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.card {
    background: white;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.12);
    margin-bottom: 20px;
}

.card.half {
    width: 520px;
}

.card.full {
    width: 100%;
    max-width: 1080px;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th {
    background: #007bff;
    color: white;
    padding: 8px;
    text-align: left;
}

td {
    border: 1px solid #ddd;
    padding: 7px;
    vertical-align: top;
}

.pass {
    color: green;
    font-weight: bold;
}

.fail {
    color: red;
    font-weight: bold;
}

.warn {
    color: orange;
    font-weight: bold;
}

pre {
    background: #111;
    color: #eee;
    padding: 12px;
    border-radius: 6px;
    overflow: auto;
    white-space: pre-wrap;
}

.badge {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    background: #007bff;
}

.badge.lte {
    background: #fd7e14;
}

.badge.wan {
    background: #28a745;
}

.badge.unknown {
    background: #6c757d;
}

button {
    width: 220px;
    height: 50px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: 0;
    border-radius: 6px;
    margin-right: 10px;
    background: #007bff;
    color: white;
}
</style>
</head>

<body>

<h1>Router Info</h1>
<p><b>Datum:</b> $(date)</p>

<div class="grid">

<div class="card half">
<h2>Systeem</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Hostname</td><td>$HOSTNAME</td></tr>
<tr><td>Model</td><td>$MODEL</td></tr>
<tr><td>Firmware</td><td>$FIRMWARE</td></tr>
<tr><td>Kernel</td><td>$KERNEL</td></tr>
<tr><td>Uptime</td><td>$UPTIME</td></tr>
</table>
</div>

<div class="card half">
<h2>Actieve verbinding</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Type</td><td><span class="badge">$CONNECTION_TYPE</span></td></tr>
<tr><td>Default route</td><td>$ROUTE</td></tr>
<tr><td>Gateway</td><td>$GATEWAY</td></tr>
<tr><td>Interface</td><td>$ACTIVE_DEV</td></tr>
<tr><td>Public IP</td><td>$PUBLIC_IP</td></tr>
</table>
</div>

<div class="card half">
<h2>LAN / WAN</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>LAN IP</td><td>$LANIP</td></tr>
<tr><td>WAN IP</td><td>$WANIP</td></tr>
<tr><td>WAN Device</td><td>$WAN_DEVICE</td></tr>
<tr><td>WAN Protocol</td><td>$WAN_PROTO</td></tr>
<tr><td>WAN Uptime</td><td>$WAN_UPTIME_TXT</td></tr>
<tr><td>DNS 1</td><td>$DNS1</td></tr>
<tr><td>DNS 2</td><td>$DNS2</td></tr>
</table>
</div>

<div class="card half">
<h2>LTE / Mobiel netwerk</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>LTE IP</td><td>$LTEIP</td></tr>
<tr><td>Operator</td><td>$OPERATOR</td></tr>
<tr><td>Technologie</td><td>$TECH</td></tr>
</table>
<pre>$SIGNAL

Registration:
$REGISTRATION</pre>
</div>

<div class="card half">
<h2>Connectiviteit</h2>
<table>
<tr><th>Test</th><th>Status</th></tr>
<tr><td>Internet ping 8.8.8.8</td><td>$(check_cmd ping -c 2 -W 3 8.8.8.8)</td></tr>
<tr><td>DNS google.com</td><td>$(check_cmd nslookup google.com)</td></tr>
<tr><td>Matrix Cloud</td><td>$(check_cmd nslookup am4.matrixfitness.com)</td></tr>
<tr><td>Toolkit poort 8080</td><td>$(check_cmd wget -q -O - http://127.0.0.1:8080)</td></tr>
<tr><td>Admin poort 8081</td><td>$(check_cmd wget -q -O - http://127.0.0.1:8081)</td></tr>
</table>
</div>

<div class="card half">
<h2>ZeroTier Remote Access</h2>
<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Status</td><td><pre>$ZT_STATUS</pre></td></tr>
<tr><td>ZeroTier IP</td><td>$ZT_IP</td></tr>
<tr><td>Toolkit Remote URL</td><td>$ZT_URL_TOOLKIT</td></tr>
<tr><td>Admin Remote URL</td><td>$ZT_URL_ADMIN</td></tr>
</table>
</div>

<div class="card full">
<h2>ZeroTier Networks</h2>
<pre>$ZT_NETWORKS</pre>
</div>

<div class="card full">
<h2>Open webpoorten</h2>
<pre>$(netstat -lnp | grep -E ":80|:443|:8080|:8081")</pre>
</div>

</div>

<br>
<button onclick="window.location='/'">Return to Home</button>
<button onclick="window.location='/admin/'">Return to Admin</button>

</body>
</html>
EOF