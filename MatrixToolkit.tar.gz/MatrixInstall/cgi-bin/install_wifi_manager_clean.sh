#!/bin/sh
# Install Matrix WiFi Manager clean final patch

SRC="$(dirname "$0")"
WEB="/usr/local/matrix/web/cgi-bin"
ADMIN="/usr/local/matrix/adminweb/cgi-bin"

mkdir -p "$WEB" "$ADMIN" /usr/local/matrix

for f in wifi_manager.sh wifi_profile_edit.sh wifi_profile_save.sh wifi_profiles_restore_previous.sh wifi_profiles_reset.sh; do
    if [ -f "$SRC/$f" ]; then
        cp -f "$SRC/$f" "$WEB/$f"
        cp -f "$SRC/$f" "$ADMIN/$f"
        chmod +x "$WEB/$f" "$ADMIN/$f"
    fi
done

chmod 666 /usr/local/matrix/matrix_wifi_profiles.conf /usr/local/matrix/matrix_wifi_profiles.default /usr/local/matrix/matrix_wifi_profiles.previous 2>/dev/null

echo "Matrix WiFi Manager clean final installed."
