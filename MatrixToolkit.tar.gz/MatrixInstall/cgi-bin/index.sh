#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

get_value() {
    KEY="$1"
    grep "^$KEY=" /usr/local/matrix/version.txt 2>/dev/null | cut -d'=' -f2-
}

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"

VERSION="$(get_value Version)"
BUILD="$(get_value Build)"
RELEASE="$(get_value Release)"
[ -z "$VERSION" ] && VERSION="74"
[ -z "$BUILD" ] && BUILD="2026-06-29"
[ -z "$RELEASE" ] && RELEASE="Production LTS"

ZT_IP=""
if [ -f /tmp/matrix_zerotier_status.cache ]; then
    ZT_IP="$(grep '^IP=' /tmp/matrix_zerotier_status.cache 2>/dev/null | head -n1 | cut -d= -f2-)"
fi
[ -z "$ZT_IP" ] && ZT_IP="$(ip -4 addr show 2>/dev/null | awk '/zt/ {f=1} f && /inet / {split($2,a,"/"); print a[1]; exit}')"

ZT_HEALTH=""
if [ -f /tmp/matrix_zerotier_status.cache ]; then
    ZT_HEALTH="$(grep '^HEALTH=' /tmp/matrix_zerotier_status.cache 2>/dev/null | head -n1 | cut -d= -f2-)"
fi
[ -z "$ZT_HEALTH" ] && ZT_HEALTH="UNKNOWN"

INTERNET_STATUS="UNKNOWN"
if ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
    INTERNET_STATUS="ONLINE"
else
    INTERNET_STATUS="OFFLINE"
fi

TOOLKIT_URL=""
ADMIN_URL=""
if [ -n "$ZT_IP" ]; then
    TOOLKIT_URL="http://$ZT_IP:8080/"
    ADMIN_URL="http://$ZT_IP:8081/cgi-bin/admin_login.sh"
fi


CLUB_FILE="/usr/local/matrix/clubname.txt"
CLUB="$(cat "$CLUB_FILE" 2>/dev/null)"
[ -z "$CLUB" ] && CLUB="Rob Bosman"

HOST_ONLY="${HTTP_HOST%%:*}"
[ -z "$HOST_ONLY" ] && HOST_ONLY="$HTTP_HOST"
cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Toolkit</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>

:root{
  --bg:#eef2f6;
  --panel:#ffffff;
  --text:#1f2933;
  --muted:#667085;
  --border:#d9e2ec;
  --shadow:0 8px 22px rgba(15,23,42,.08);
  --health:#1f8a3b;
  --network:#0077c8;
  --remote:#6f42c1;
  --tools:#f28c28;
  --admin:#3949ab;
  --danger:#c82333;
  --ok:#1f8a3b;
  --warn:#b35b00;
  --fail:#c82333;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1320px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:20px 22px;box-shadow:var(--shadow);display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.brand h1{margin:0;font-size:28px;line-height:1.1}
.brand .sub{opacity:.9;margin-top:6px;font-size:14px}
.top-actions{display:flex;gap:10px;flex-wrap:wrap}
.top-btn{background:rgba(255,255,255,.16);color:#fff;border:1px solid rgba(255,255,255,.35);text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700;display:inline-block}
.top-btn:hover{background:rgba(255,255,255,.26)}
.status-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}
.status-card{background:var(--panel);border:1px solid var(--border);border-radius:16px;padding:15px;box-shadow:var(--shadow)}
.status-label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}
.status-value{margin-top:8px;font-size:20px;font-weight:800}
.status-ok{color:var(--ok)}.status-warn{color:var(--warn)}.status-fail{color:var(--fail)}
.main-grid{display:grid;grid-template-columns:1fr 320px;gap:18px;align-items:start}
.card-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
.card{background:var(--panel);border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);overflow:hidden}
.card-head{padding:14px 16px;color:#fff;font-weight:800;letter-spacing:.03em;text-transform:uppercase;font-size:14px}
.card-health .card-head{background:var(--health)}
.card-network .card-head{background:var(--network)}
.card-remote .card-head{background:var(--remote)}
.card-tools .card-head{background:var(--tools)}
.card-admin .card-head{background:var(--admin)}
.card-body{padding:14px}
.card-desc{color:var(--muted);font-size:13px;line-height:1.35;margin:0 0 12px}
.tile{display:block;text-decoration:none;color:var(--text);background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:12px;margin:9px 0;transition:.12s ease;min-height:58px}
.tile:hover{transform:translateY(-1px);box-shadow:0 5px 14px rgba(15,23,42,.08);border-color:#b7c6d8}
.tile-title{font-weight:800;font-size:15px}
.tile-sub{font-size:12px;color:var(--muted);margin-top:4px;line-height:1.25}
.side{display:grid;gap:16px}
.info-panel{background:var(--panel);border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:16px}
.info-panel h2{margin:0 0 12px;font-size:16px;color:#0d3b66}
.info-row{border-top:1px solid var(--border);padding:10px 0}
.info-row:first-of-type{border-top:0}
.info-label{font-size:12px;color:var(--muted);text-transform:uppercase;font-weight:700;letter-spacing:.04em}
.info-value{font-size:14px;margin-top:4px;word-break:break-word}
.club-box{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
.club-box input{flex:1;min-width:180px;border:1px solid var(--border);border-radius:10px;padding:10px;font-size:15px}
.club-box button{border:none;background:#0d6efd;color:white;border-radius:10px;padding:10px 13px;font-weight:800}
.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}
@media (max-width:1180px){
  .main-grid{grid-template-columns:1fr}
  .card-grid{grid-template-columns:repeat(2,1fr)}
  .status-grid{grid-template-columns:repeat(2,1fr)}
}
@media (max-width:640px){
  .page{padding:10px}
  .hero{border-radius:14px;padding:16px}
  .brand h1{font-size:23px}
  .top-actions{width:100%}
  .top-btn{width:100%;text-align:center}
  .status-grid{grid-template-columns:1fr;gap:10px}
  .card-grid{grid-template-columns:1fr;gap:12px}
  .tile{min-height:64px;padding:14px}
  .tile-title{font-size:16px}
  .tile-sub{font-size:13px}
}

</style>
</head>
<body>
<div class="page">
  <section class="hero">
    <div class="brand">
      <h1>Matrix Toolkit</h1>
      <div class="sub">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
    </div>
    <div class="top-actions">
      <a class="top-btn" href="/cgi-bin/about.sh">Toolkit Info</a>
      <a class="top-btn" href="http://$HOST_ONLY:8081/cgi-bin/admin_login.sh">Admin</a>
    </div>
  </section>

  <section class="status-grid">
    <div class="status-card"><div class="status-label">Router</div><div class="status-value">$(html_escape "$HOST")</div></div>
    <div class="status-card"><div class="status-label">Internet</div><div class="status-value status-$( [ "$INTERNET_STATUS" = "ONLINE" ] && echo ok || echo fail )">$(html_escape "$INTERNET_STATUS")</div></div>
    <div class="status-card"><div class="status-label">ZeroTier</div><div class="status-value status-$( [ "$ZT_HEALTH" = "HEALTHY" ] && echo ok || echo warn )">$(html_escape "$ZT_HEALTH")</div></div>
    <div class="status-card"><div class="status-label">Version</div><div class="status-value">v$(html_escape "$VERSION")</div></div>
  </section>

  <section class="main-grid">
    <div class="card-grid">

      <div class="card card-health">
        <div class="card-head">Health Checks</div>
        <div class="card-body">
          <p class="card-desc">Tests en diagnose voor installatie en support.</p>
          <a class="tile" href="/cgi-bin/matrix_full_test.sh"><div class="tile-title">Full Test</div><div class="tile-sub">Complete basiscontrole</div></a>
          <a class="tile" href="/cgi-bin/diagnostics.sh"><div class="tile-title">Diagnostics</div><div class="tile-sub">Router en netwerkdiagnose</div></a>
          <a class="tile" href="/cgi-bin/about.sh"><div class="tile-title">Toolkit Info</div><div class="tile-sub">Versie, ZeroTier en systeeminfo</div></a>
        </div>
      </div>

      <div class="card card-network">
        <div class="card-head">Network & WiFi</div>
        <div class="card-body">
          <p class="card-desc">Router, WAN, LTE en WiFi beheer.</p>
          <a class="tile" href="/cgi-bin/router_info.sh"><div class="tile-title">Router Info</div><div class="tile-sub">Hostname, IP en interfaces</div></a>
          <a class="tile" href="/cgi-bin/wan_status.sh"><div class="tile-title">WAN Status</div><div class="tile-sub">Internet en gateway status</div></a>
          <a class="tile" href="/cgi-bin/lte_analysis.sh"><div class="tile-title">LTE Analysis</div><div class="tile-sub">Modemsignaal en kwaliteit</div></a>
          <a class="tile" href="/cgi-bin/wifi_survey.sh"><div class="tile-title">WiFi Survey</div><div class="tile-sub">Meting voor klantnetwerk</div></a>
          <a class="tile" href="/cgi-bin/wifi_manager.sh"><div class="tile-title">WiFi Manager</div><div class="tile-sub">Matrix, EGYM en klantprofielen</div></a>
        </div>
      </div>

      <div class="card card-remote">
        <div class="card-head">Remote & EGYM</div>
        <div class="card-body">
          <p class="card-desc">Remote access en EGYM-connectiviteit.</p>
          <a class="tile" href="/cgi-bin/zerotier_manager.sh"><div class="tile-title">ZeroTier Manager</div><div class="tile-sub">Remote access status en repair</div></a>
          <a class="tile" href="/cgi-bin/egym_firewall_test.sh"><div class="tile-title">Firewall Test</div><div class="tile-sub">Poorten en bereikbaarheid</div></a>
          <a class="tile" href="/cgi-bin/egym_ping_test.sh"><div class="tile-title">Ping Test</div><div class="tile-sub">Snelle EGYM verbindingstest</div></a>
        </div>
      </div>

      <div class="card card-tools">
        <div class="card-head">Maintenance</div>
        <div class="card-body">
          <p class="card-desc">Onderhoud en veilige acties.</p>
          <a class="tile" href="/cgi-bin/report_test.sh"><div class="tile-title">Reports</div><div class="tile-sub">Rapportage controleren</div></a>
          <a class="tile" href="/cgi-bin/restart_router.sh"><div class="tile-title">Restart Router</div><div class="tile-sub">Alleen gebruiken indien nodig</div></a>
        </div>
      </div>

    </div>

    <aside class="side">
      <div class="info-panel">
        <h2>Clubgegevens</h2>
        <form method="GET" action="/cgi-bin/save_clubname.sh" class="club-box">
          <input name="clubname" value="$(html_escape "$CLUB")">
          <button type="submit">Opslaan</button>
        </form>
      </div>

      <div class="info-panel">
        <h2>System Status</h2>
        <div class="info-row"><div class="info-label">Toolkit Version</div><div class="info-value">Matrix Toolkit v$(html_escape "$VERSION")</div></div>
        <div class="info-row"><div class="info-label">Build</div><div class="info-value">$(html_escape "$BUILD")</div></div>
        <div class="info-row"><div class="info-label">Release</div><div class="info-value">$(html_escape "$RELEASE")</div></div>
        <div class="info-row"><div class="info-label">ZeroTier IP</div><div class="info-value">$(html_escape "$ZT_IP")</div></div>
        <div class="info-row"><div class="info-label">Toolkit URL</div><div class="info-value">$(html_escape "$TOOLKIT_URL")</div></div>
        <div class="info-row"><div class="info-label">Admin URL</div><div class="info-value">$(html_escape "$ADMIN_URL")</div></div>
        <div class="info-row"><div class="info-label">Repository</div><div class="info-value">https://github.com/MatrixFitness/Tool</div></div>
      </div>
    </aside>
  </section>

  <div class="footer">Matrix Fitness &middot; Matrix Toolkit v$(html_escape "$VERSION")</div>
</div>
</body>
</html>
EOF
