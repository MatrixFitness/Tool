#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - CHANGE ADMIN PASSWORD FOR 8081 ADMIN
# =====================================================
# Uses Teltonika uhttpd basic authentication on matrix_admin_web.
# No admin_password.txt file is used.
# =====================================================

echo "Content-Type: text/html"
echo ""

DEFAULT_USER="admin"
MSG=""
MSG_CLASS="info"

url_decode_common() {
    sed 's/+/ /g; s/%21/!/g; s/%23/#/g; s/%24/\$/g; s/%25/%/g; s/%26/\&/g; s/%2B/+/g; s/%2D/-/g; s/%2E/./g; s/%3A/:/g; s/%3D/=/g; s/%40/@/g; s/%5F/_/g; s/%7E/~/g; s/%2f/\//g; s/%2F/\//g'
}

html_escape() {
    sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'
}

apply_admin_password() {
    PASS="$1"

    uci set uhttpd.matrix_admin_web='uhttpd'
    uci set uhttpd.matrix_admin_web.enable_basic_auth='1'
    uci set uhttpd.matrix_admin_web.realm='Matrix Toolkit Admin'
    uci set uhttpd.matrix_admin_web.username="$DEFAULT_USER"
    uci set uhttpd.matrix_admin_web.password="$PASS"
    uci commit uhttpd
}

if [ "$REQUEST_METHOD" = "POST" ]; then
    read POST_DATA

    NEWPASS_RAW="$(echo "$POST_DATA" | sed 's/.*newpass=//' | sed 's/&.*//')"
    CONFIRM_RAW="$(echo "$POST_DATA" | sed 's/.*confirm=//' | sed 's/&.*//')"

    NEWPASS="$(echo "$NEWPASS_RAW" | url_decode_common)"
    CONFIRM="$(echo "$CONFIRM_RAW" | url_decode_common)"

    if [ -z "$NEWPASS" ]; then
        MSG="Password cannot be empty."
        MSG_CLASS="error"
    elif [ "$NEWPASS" != "$CONFIRM" ]; then
        MSG="Passwords do not match."
        MSG_CLASS="error"
    elif [ ${#NEWPASS} -lt 6 ]; then
        MSG="Password must be at least 6 characters."
        MSG_CLASS="error"
    elif echo "$NEWPASS" | grep -q '[;&|`<>"\\ ]'; then
        MSG="Password contains unsafe characters. Use letters, numbers and characters like . _ - @ # ! : = +"
        MSG_CLASS="error"
    else
        apply_admin_password "$NEWPASS"
        rm -f /usr/local/matrix/admin_password.txt \
              /usr/local/matrix/web/cgi-bin/get_admin_password.sh \
              /usr/local/matrix/web/cgi-bin/set_admin_password.sh \
              /usr/local/matrix/adminweb/cgi-bin/get_admin_password.sh \
              /usr/local/matrix/adminweb/cgi-bin/set_admin_password.sh 2>/dev/null
        (sleep 2; /etc/init.d/uhttpd restart >/dev/null 2>&1) &
        MSG="Password changed. The admin webserver is restarting. Open Admin again on port 8081 and log in with the new password."
        MSG_CLASS="success"
    fi
fi

SAFE_MSG="$(echo "$MSG" | html_escape)"

cat <<HTML
<html>
<head>
<title>Change Admin Password</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
body { font-family: Arial, sans-serif; margin: 30px; background:#f5f5f5; }
.card { background:white; padding:22px; max-width:460px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.15); }
h1 { margin-top:0; color:#333; }
label { display:block; margin-top:12px; font-weight:bold; }
input { width:100%; box-sizing:border-box; padding:12px; margin-top:6px; font-size:16px; }
button { width:100%; padding:13px; margin-top:16px; font-size:16px; font-weight:bold; border:0; border-radius:6px; cursor:pointer; }
.save { background:#28a745; color:white; }
.back { background:#007bff; color:white; }
.success { color:#0a7a0a; font-weight:bold; margin-top:15px; }
.error { color:#b00020; font-weight:bold; margin-top:15px; }
.info { color:#555; margin-top:15px; }
.small { color:#666; font-size:13px; line-height:1.4; }
</style>
</head>
<body>
<div class="card">
<h1>Change Admin Password</h1>
<p class="small">This changes the Matrix Admin login on port 8081.</p>
<form method="POST">
<label>New password</label>
<input type="password" name="newpass" required autocomplete="new-password">
<label>Confirm password</label>
<input type="password" name="confirm" required autocomplete="new-password">
<button class="save" type="submit">Save New Password</button>
</form>
<div class="$MSG_CLASS">$SAFE_MSG</div>
<button class="back" onclick="window.location='/index.html'">Back to Admin</button>
<p class="small">Default username remains: <b>admin</b></p>
</div>
</body>
</html>
HTML
