#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

# =====================================================
# MATRIX TOOLKIT - CHANGE ADMIN PASSWORD
# Uses Matrix session login, not uhttpd basic auth.
# =====================================================

PASS_FILE="/usr/local/matrix/admin_password.txt"
MSG=""
MSG_CLASS="info"

url_decode_common() {
    sed 's/+/ /g; s/%21/!/g; s/%23/#/g; s/%24/\$/g; s/%25/%/g; s/%26/\&/g; s/%2B/+/g; s/%2D/-/g; s/%2E/./g; s/%3A/:/g; s/%3D/=/g; s/%40/@/g; s/%5F/_/g; s/%7E/~/g; s/%2f/\//g; s/%2F/\//g'
}
html_escape() { sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'; }

ensure_password_file() {
    if [ ! -f "$PASS_FILE" ]; then
        mkdir -p /usr/local/matrix
        printf 'Matrix2025' > "$PASS_FILE"
        chmod 644 "$PASS_FILE" 2>/dev/null
    fi
}

ensure_password_file

if [ "$REQUEST_METHOD" = "POST" ]; then
    read POST_DATA
    OLD_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^oldpass=' | cut -d= -f2-)"
    NEW_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^newpass=' | cut -d= -f2-)"
    CONFIRM_RAW="$(echo "$POST_DATA" | tr '&' '\n' | grep '^confirm=' | cut -d= -f2-)"

    OLD="$(echo "$OLD_RAW" | url_decode_common)"
    NEW="$(echo "$NEW_RAW" | url_decode_common)"
    CONFIRM="$(echo "$CONFIRM_RAW" | url_decode_common)"
    CURRENT="$(cat "$PASS_FILE" 2>/dev/null)"

    if [ "$OLD" != "$CURRENT" ]; then
        MSG="Current password is incorrect."
        MSG_CLASS="error"
    elif [ -z "$NEW" ]; then
        MSG="New password cannot be empty."
        MSG_CLASS="error"
    elif [ "$NEW" != "$CONFIRM" ]; then
        MSG="New passwords do not match."
        MSG_CLASS="error"
    elif [ ${#NEW} -lt 6 ]; then
        MSG="Password must be at least 6 characters."
        MSG_CLASS="error"
    elif echo "$NEW" | grep -q '[;&|`<>"\\ ]'; then
        MSG="Password contains unsafe characters. Use letters, numbers and characters like . _ - @ # ! : = +"
        MSG_CLASS="error"
    else
        printf '%s' "$NEW" > "$PASS_FILE"
        chmod 644 "$PASS_FILE" 2>/dev/null
        rm -rf /tmp/matrix_admin_sessions 2>/dev/null
        MSG="Password changed. Sessions were cleared. Please login again with the new password."
        MSG_CLASS="success"
    fi
fi

SAFE_MSG="$(echo "$MSG" | html_escape)"

echo "Content-Type: text/html"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""
cat <<HTML
<html>
<head>
<title>Change Admin Password</title>
<style>
body { font-family: Arial, sans-serif; margin:30px; background:#f5f5f5; }
.card { background:white; padding:22px; max-width:460px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.15); }
h1 { margin-top:0; color:#333; }
label { display:block; margin-top:12px; font-weight:bold; }
input { width:100%; box-sizing:border-box; padding:12px; margin-top:6px; font-size:16px; }
button { width:100%; padding:13px; margin-top:16px; font-size:16px; font-weight:bold; border:0; border-radius:6px; cursor:pointer; }
.save { background:#28a745; color:white; }
.back { background:#007bff; color:white; }
.success { color:#0a7a0a; font-weight:bold; margin-top:15px; }
.error { color:#b00020; font-weight:bold; margin-top:15px; }
.info { color:#555; margin-top:15px; }
.small { color:#666; font-size:13px; line-height:1.4; }
</style>
</head>
<body>
<div class="card">
<h1>Change Admin Password</h1>
<form method="POST">
<label>Current password</label>
<input type="password" name="oldpass" required autocomplete="current-password">
<label>New password</label>
<input type="password" name="newpass" required autocomplete="new-password">
<label>Confirm new password</label>
<input type="password" name="confirm" required autocomplete="new-password">
<button class="save" type="submit">Save New Password</button>
</form>
<div class="$MSG_CLASS">$SAFE_MSG</div>
<button class="back" onclick="window.location='/cgi-bin/admin_home.sh'">Back to Admin</button>
<p class="small">Default username remains: <b>admin</b></p>
</div>
</body>
</html>
HTML
