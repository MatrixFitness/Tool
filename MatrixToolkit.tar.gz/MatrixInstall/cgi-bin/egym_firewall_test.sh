#!/bin/sh

echo "Content-Type: text/html"
echo ""

OK=0
REJECTED=0
NORESPONSE=0

echo "<html>"
echo "<head>"
echo "<title>EGYM Connectiviteitstest</title>"
echo "<meta charset='UTF-8'>"

echo "<style>"
echo "body { font-family: Arial, sans-serif; margin: 20px; background:#f5f5f5; }"
echo "h1 { color:#333; }"
echo "table { border-collapse: collapse; width: 900px; background:white; }"
echo "th { background:#007bff; color:white; padding:10px; }"
echo "td { border:1px solid #ddd; padding:8px; }"
echo ".ok { color:green; font-weight:bold; }"
echo ".warn { color:orange; font-weight:bold; }"
echo ".info { color:#666; font-weight:bold; }"
echo ".summary {"
echo "background:white;"
echo "border:1px solid #ddd;"
echo "padding:15px;"
echo "width:420px;"
echo "margin-top:20px;"
echo "}"
echo "</style>"

echo "</head>"
echo "<body>"

echo "<h1>EGYM Connectiviteitstest</h1>"

echo "<table>"
echo "<tr>"
echo "<th>Bestemming</th>"
echo "<th>Status</th>"
echo "</tr>"

check_ip() {

    RESULT=$(timeout 5 curl -k -I -m 4 https://$1 2>&1)
    RET=$?

    if [ $RET -eq 0 ]
    then

        STATUS="<span class='ok'>Bereikbaar</span>"
        OK=$((OK+1))

    elif echo "$RESULT" | grep -qi "Connection reset by peer"
    then

        STATUS="<span class='warn'>Verbinding geweigerd</span>"
        REJECTED=$((REJECTED+1))

    else

        STATUS="<span class='info'>Geen reactie</span>"
        NORESPONSE=$((NORESPONSE+1))

    fi

    echo "<tr>"
    echo "<td>$1</td>"
    echo "<td>$STATUS</td>"
    echo "</tr>"
}

# Training / Updates / Toestelstatus

check_ip 104.199.66.167
check_ip 35.189.221.132
check_ip 104.199.91.64
check_ip 146.148.19.217
check_ip 104.155.57.166
check_ip 146.148.15.175
check_ip 3.127.32.71
check_ip 18.156.48.111
check_ip 3.124.243.61
check_ip 52.37.226.173
check_ip 35.84.145.167
check_ip 35.81.42.122

# Onderhoud op afstand

check_ip 35.198.87.78
check_ip 212.114.251.94
check_ip 192.158.31.31

echo "</table>"

TOTAL=$((OK+REJECTED+NORESPONSE))

echo "<div class='summary'>"
echo "<h3>Samenvatting</h3>"
echo "Bereikbaar: <b>$OK</b><br>"
echo "Verbinding geweigerd: <b>$REJECTED</b><br>"
echo "Geen reactie: <b>$NORESPONSE</b><br>"
echo "Totaal getest: <b>$TOTAL</b>"
echo "</div>"

echo "<br>"

echo "<h2 style='color:green'>STATUS: INTERNET VERBINDING OK</h2>"

echo "<p>"
echo "De router beschikt over een werkende internetverbinding en kan uitgaande HTTPS-verbindingen opzetten."
echo "</p>"

echo "<hr>"

echo "<h3>Toelichting</h3>"

echo "<ul>"

echo "<li><span class='ok'>Bereikbaar</span> - De router kon succesvol verbinding maken met het opgegeven IP-adres.</li>"

echo "<li><span class='warn'>Verbinding geweigerd</span> - Het IP-adres is bereikbaar, maar de server weigert de directe verbinding. Dit betekent meestal geen firewallprobleem.</li>"

echo "<li><span class='info'>Geen reactie</span> - Er werd binnen de ingestelde tijd geen antwoord ontvangen. Dit kan verschillende oorzaken hebben, zoals serverconfiguratie, cloudmigraties of gewijzigde netwerkarchitectuur.</li>"

echo "</ul>"

echo "<p>"
echo "De door EGYM opgegeven IP-adressen worden gebruikt voor communicatie met de EGYM infrastructuur. Omdat veel moderne cloudplatformen gebruikmaken van load balancers, beveiligingslagen en dynamische services, betekent een ontbrekende reactie niet automatisch dat een firewall verkeer blokkeert."
echo "</p>"

echo "<p>"
echo "Wanneer de EGYM-apparatuur normaal functioneert, synchroniseert en updates ontvangt, is dit de belangrijkste indicatie dat de netwerkverbinding correct werkt."
echo "</p>"

echo "<hr>"

echo "<small style='color:#666;'>"
echo "Deze test is bedoeld als hulpmiddel voor diagnose en geeft een indicatie van de huidige bereikbaarheid van de opgegeven bestemmingen."
echo "</small>"

echo "</body>"
echo "</html>"