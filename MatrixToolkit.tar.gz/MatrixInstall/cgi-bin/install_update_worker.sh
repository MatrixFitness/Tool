#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - INSTALL ROOT UPDATE WORKER
# =====================================================

WORKER="/usr/local/matrix/matrix_update_worker.sh"
STARTER="/usr/local/matrix/web/cgi-bin/update_github_start.sh"
LOGVIEW="/usr/local/matrix/web/cgi-bin/update_github_log.sh"

chmod +x "$WORKER" 2>/dev/null
chmod +x "$STARTER" 2>/dev/null
chmod +x "$LOGVIEW" 2>/dev/null

# Add worker to root cron once.
(crontab -l 2>/dev/null | grep -v "/usr/local/matrix/matrix_update_worker.sh"; \
 echo "* * * * * /usr/local/matrix/matrix_update_worker.sh") | crontab -

/etc/init.d/cron enable >/dev/null 2>&1
/etc/init.d/cron restart >/dev/null 2>&1

echo "Matrix root update worker installed."
echo "Cron runs every minute."
