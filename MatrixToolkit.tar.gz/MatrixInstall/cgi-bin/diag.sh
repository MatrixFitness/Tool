#!/bin/sh

echo "Content-Type: text/html"
echo ""

HOSTNAME=$(hostname 2>/dev/null)
NOW=$(date)

MATRIX_DIR="/usr/local/matrix"
VERSION_FILE="$MATRIX_DIR/version.txt"
LTE_CACHE="/tmp/matrix_lte_info.cache"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

badge() {
    STATUS="$1"
    case "$STATUS" in
        PASS|GOEDGEKEURD|OK|CONNECTED|Connected) echo "<span class='badge good'>$STATUS</span>" ;;
        WARNING|WAARSCHUWING|MATIG) echo "<span class='badge warn'>$STATUS</span>" ;;
        FAIL|AFGEKEURD|OFFLINE|Offline) echo "<span class='badge bad'>$STATUS</span>" ;;
        *) echo "<span class='badge neutral'>$STATUS</span>" ;;
    esac
}

is_number() {
    case "$1" in
        ''|*[!0-9-]*) return 1 ;;
        *) return 0 ;;
    esac
}

quality_text() {
    NAME="$1"
    VALUE="$2"

    if ! is_number "$VALUE"; then
        echo "Not available"
        return
    fi

    case "$NAME" in
        RSSI)
            [ "$VALUE" -ge -65 ] && echo "Uitstekend" && return
            [ "$VALUE" -ge -75 ] && echo "Goed" && return
            [ "$VALUE" -ge -85 ] && echo "Matig" && return
            echo "Slecht"
            ;;
        RSRP)
            [ "$VALUE" -ge -90 ] && echo "Uitstekend" && return
            [ "$VALUE" -ge -100 ] && echo "Goed" && return
            [ "$VALUE" -ge -110 ] && echo "Matig" && return
            echo "Slecht"
            ;;
        RSRQ)
            [ "$VALUE" -ge -10 ] && echo "Uitstekend" && return
            [ "$VALUE" -ge -14 ] && echo "Goed" && return
            [ "$VALUE" -ge -20 ] && echo "Matig" && return
            echo "Slecht"
            ;;
        SINR)
            [ "$VALUE" -ge 20 ] && echo "Uitstekend" && return
            [ "$VALUE" -ge 13 ] && echo "Goed" && return
            [ "$VALUE" -ge 0 ] && echo "Matig" && return
            echo "Slecht"
            ;;
    esac
}

quality_badge() {
    STATUS="$1"
    case "$STATUS" in
        Uitstekend|Goed) echo "<span class='badge good'>$STATUS</span>" ;;
        Matig) echo "<span class='badge warn'>$STATUS</span>" ;;
        Slecht) echo "<span class='badge bad'>$STATUS</span>" ;;
        *) echo "<span class='badge neutral'>$STATUS</span>" ;;
    esac
}

# System
UPTIME=$(uptime | awk -F'up ' '{print $2}' | awk -F',' '{print $1}')
MODEL=$(ubus call system board 2>/dev/null | jsonfilter -e '@.model')
FIRMWARE=$(cat /etc/version 2>/dev/null)
TOOLKIT_VERSION=$(get_value Version)
TOOLKIT_BUILD=$(get_value Build)

[ -z "$UPTIME" ] && UPTIME="Not available"
[ -z "$MODEL" ] && MODEL="Not available"
[ -z "$FIRMWARE" ] && FIRMWARE="Not available"
[ -z "$TOOLKIT_VERSION" ] && TOOLKIT_VERSION="Unknown"
[ -z "$TOOLKIT_BUILD" ] && TOOLKIT_BUILD="Unknown"

# Network / WAN
LANIP=$(ip -4 addr show br-lan 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1 | head -1)
WAN_STATUS=$(ubus call network.interface.wan status 2>/dev/null)
WANIP=$(echo "$WAN_STATUS" | grep -A4 '"ipv4-address"' | grep '"address"' | head -1 | cut -d'"' -f4)
GATEWAY=$(echo "$WAN_STATUS" | grep -A8 '"route"' | grep '"nexthop"' | head -1 | cut -d'"' -f4)
WAN_INTERFACE=$(echo "$WAN_STATUS" | grep '"device"' | head -1 | cut -d'"' -f4)
PROTOCOL=$(echo "$WAN_STATUS" | grep '"proto"' | head -1 | cut -d'"' -f4)
WAN_UPTIME=$(echo "$WAN_STATUS" | grep '"uptime"' | grep -o '[0-9]*' | head -1)
DNS1=$(echo "$WAN_STATUS" | grep -A8 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '1p')
DNS2=$(echo "$WAN_STATUS" | grep -A8 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '2p')
DEFAULT_ROUTE=$(ip route | grep "^default" | head -1)

[ -z "$LANIP" ] && LANIP="Not available"
[ -z "$WANIP" ] && WANIP="Not available"
[ -z "$GATEWAY" ] && GATEWAY="Not available"
[ -z "$WAN_INTERFACE" ] && WAN_INTERFACE="Not available"
[ -z "$PROTOCOL" ] && PROTOCOL="Not available"
[ -z "$DNS1" ] && DNS1="Not available"
[ -z "$DNS2" ] && DNS2="Not available"
[ -z "$DEFAULT_ROUTE" ] && DEFAULT_ROUTE="Not available"

if [ -n "$WAN_UPTIME" ]; then
    HOURS=$((WAN_UPTIME / 3600))
    MINS=$(((WAN_UPTIME % 3600) / 60))
    WAN_UPTIME_TXT="${HOURS} uur ${MINS} min"
else
    WAN_UPTIME_TXT="Onbekend"
fi

# LTE cache
LTEIP=$(ip -4 addr show qmimux0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1 | head -1)
if [ -f "$LTE_CACHE" ]; then
    LTE_UPDATED=$(grep "^UPDATED=" "$LTE_CACHE" | cut -d= -f2-)
    LTE_OPERATOR=$(grep "^OPERATOR=" "$LTE_CACHE" | cut -d= -f2-)
    LTE_TECH=$(grep "^TECH=" "$LTE_CACHE" | cut -d= -f2-)
    LTE_REGISTRATION=$(grep "^REGISTRATION=" "$LTE_CACHE" | cut -d= -f2-)
    LTE_SIGNAL=$(awk '/SIGNAL_START/{flag=1;next}/SIGNAL_END/{flag=0}flag' "$LTE_CACHE")
else
    LTE_UPDATED="Not available"
    LTE_OPERATOR="Not available"
    LTE_TECH="Not available"
    LTE_REGISTRATION="Unknown"
    LTE_SIGNAL="Not available"
fi

[ -z "$LTEIP" ] && LTEIP="Not available"
[ -z "$LTE_UPDATED" ] && LTE_UPDATED="Not available"
[ -z "$LTE_OPERATOR" ] && LTE_OPERATOR="Not available"
[ -z "$LTE_TECH" ] && LTE_TECH="Not available"
[ -z "$LTE_REGISTRATION" ] && LTE_REGISTRATION="Unknown"
[ -z "$LTE_SIGNAL" ] && LTE_SIGNAL="Not available"

RSSI=$(echo "$LTE_SIGNAL" | grep RSSI | awk '{print $2}')
RSRP=$(echo "$LTE_SIGNAL" | grep RSRP | awk '{print $2}')
RSRQ=$(echo "$LTE_SIGNAL" | grep RSRQ | awk '{print $2}')
SINR=$(echo "$LTE_SIGNAL" | grep SINR | awk '{print $2}')

RSSI_Q=$(quality_text RSSI "$RSSI")
RSRP_Q=$(quality_text RSRP "$RSRP")
RSRQ_Q=$(quality_text RSRQ "$RSRQ")
SINR_Q=$(quality_text SINR "$SINR")

[ -z "$RSSI" ] && RSSI="Not available"
[ -z "$RSRP" ] && RSRP="Not available"
[ -z "$RSRQ" ] && RSRQ="Not available"
[ -z "$SINR" ] && SINR="Not available"

# Connectivity
INTERNET_STATUS="FAIL"
DNS_STATUS="FAIL"
MATRIX_STATUS="FAIL"
ZT_STATUS="WARNING"
ZT_IP=$(ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)

if ping -c 2 -W 3 8.8.8.8 >/dev/null 2>&1; then
    INTERNET_STATUS="PASS"
fi

if nslookup google.com >/dev/null 2>&1; then
    DNS_STATUS="PASS"
fi

if nslookup am4.matrixfitness.com >/dev/null 2>&1; then
    MATRIX_STATUS="PASS"
fi

ZT_INFO="Not installed"
ZT_NETWORKS="Not available"
if [ -x "$ZT_CLI" ]; then
    ZT_INFO=$("$ZT_CLI" info 2>/dev/null)
    ZT_NETWORKS=$("$ZT_CLI" listnetworks 2>/dev/null)
    if echo "$ZT_INFO" | grep -q "ONLINE" && echo "$ZT_NETWORKS" | grep -q "OK PRIVATE"; then
        ZT_STATUS="PASS"
    elif [ -n "$ZT_IP" ]; then
        ZT_STATUS="WARNING"
    else
        ZT_STATUS="FAIL"
    fi
else
    ZT_STATUS="FAIL"
fi

[ -z "$ZT_IP" ] && ZT_IP="Not connected"

# Final judgement
ERRORS=0
WARNINGS=0
ACTIONS=""

add_action() {
    ACTIONS="${ACTIONS}<li>$1</li>"
}

[ "$INTERNET_STATUS" != "PASS" ] && ERRORS=$((ERRORS+1)) && add_action "Internet FAIL: controleer WAN-kabel, DHCP, gateway of klantinternet."
[ "$DNS_STATUS" != "PASS" ] && WARNINGS=$((WARNINGS+1)) && add_action "DNS probleem: controleer DNS-instellingen. Advies: 8.8.8.8 en 8.8.4.4 of klant-DNS."
[ "$MATRIX_STATUS" != "PASS" ] && ERRORS=$((ERRORS+1)) && add_action "Matrix Cloud FAIL: controleer internet, DNS en firewallregels richting Matrix/JHT hosts."
[ "$ZT_STATUS" = "FAIL" ] && WARNINGS=$((WARNINGS+1)) && add_action "ZeroTier offline: controleer ZeroTier service, autorisatie en netwerk."
[ "$ZT_STATUS" = "WARNING" ] && WARNINGS=$((WARNINGS+1)) && add_action "ZeroTier waarschuwing: IP bestaat mogelijk, maar CLI/netwerkcheck is niet volledig OK."

if [ "$SINR_Q" = "Slecht" ] || [ "$RSRQ_Q" = "Slecht" ]; then
    WARNINGS=$((WARNINGS+1))
    add_action "LTE kwaliteit laag: controleer routerpositie, antennes en mogelijke storing of drukke zendmast."
fi

if [ "$LTE_OPERATOR" = "Not available" ] && [ "$LTEIP" != "Not available" ]; then
    WARNINGS=$((WARNINGS+1))
    add_action "LTE IP aanwezig maar cachedata ontbreekt: controleer /usr/local/matrix/lte_info_cache.sh en cron."
fi

if [ -z "$ACTIONS" ]; then
    ACTIONS="<li>Geen directe acties nodig.</li>"
fi

FINAL_STATUS="GOEDGEKEURD"
FINAL_CLASS="good"
FINAL_TEXT="Belangrijkste controles zijn succesvol."

if [ "$ERRORS" -gt 0 ]; then
    FINAL_STATUS="AFGEKEURD"
    FINAL_CLASS="bad"
    FINAL_TEXT="Er zijn kritieke problemen gevonden."
elif [ "$WARNINGS" -gt 0 ]; then
    FINAL_STATUS="WAARSCHUWING"
    FINAL_CLASS="warn"
    FINAL_TEXT="De verbinding werkt, maar er zijn aandachtspunten."
fi

cat <<EOF
<html>
<head>
<title>Matrix Diagnostics Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
:root {
    --blue:#0b5cab;
    --blue2:#073b73;
    --bg:#eef2f6;
    --card:#ffffff;
    --text:#1f2937;
    --muted:#6b7280;
    --line:#d8dee8;
    --green:#198754;
    --orange:#fd7e14;
    --red:#dc3545;
}
* { box-sizing:border-box; }
body { font-family:Arial, Helvetica, sans-serif; margin:0; background:var(--bg); color:var(--text); }
.header { background:linear-gradient(135deg,var(--blue2),var(--blue)); color:white; padding:26px 30px; }
.header h1 { margin:0; font-size:30px; }
.header p { margin:8px 0 0 0; opacity:.9; }
.wrap { max-width:1180px; margin:24px auto; padding:0 18px; }
.grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.grid-3 { display:grid; grid-template-columns:repeat(3,1fr); gap:20px; }
@media (max-width:980px) { .grid-2,.grid-3 { grid-template-columns:1fr; } }
.card { background:var(--card); border-radius:14px; padding:20px; box-shadow:0 4px 14px rgba(20,34,64,.10); margin-bottom:20px; border:1px solid rgba(0,0,0,.04); }
.card h2 { margin:0 0 14px 0; font-size:21px; color:#102a43; }
table { border-collapse:collapse; width:100%; background:white; }
th { background:#eaf2fb; color:#0f335c; text-align:left; padding:10px; border-bottom:1px solid var(--line); }
td { border-bottom:1px solid var(--line); padding:10px; vertical-align:top; }
.badge { display:inline-block; padding:6px 11px; border-radius:999px; font-size:12px; font-weight:bold; color:white; }
.badge.good { background:var(--green); }
.badge.warn { background:var(--orange); }
.badge.bad { background:var(--red); }
.badge.neutral { background:#64748b; }
.result { border-left:6px solid var(--green); background:#f8fafc; padding:16px; border-radius:8px; }
.result.good { border-left-color:var(--green); }
.result.warn { border-left-color:var(--orange); }
.result.bad { border-left-color:var(--red); }
.result-title { font-size:30px; font-weight:bold; margin-bottom:8px; }
.result.good .result-title { color:var(--green); }
.result.warn .result-title { color:var(--orange); }
.result.bad .result-title { color:var(--red); }
.note { background:#f8fafc; border-left:4px solid var(--blue); padding:12px 14px; border-radius:8px; color:#334155; }
pre { background:#0f172a; color:#e5e7eb; padding:14px; border-radius:10px; overflow:auto; font-size:13px; white-space:pre-wrap; }
button, .btn { display:inline-block; min-width:175px; height:46px; line-height:46px; text-align:center; font-size:15px; font-weight:bold; cursor:pointer; border:0; border-radius:8px; margin:6px 8px 6px 0; background:var(--blue); color:white; text-decoration:none; }
.btn.secondary { background:#475569; }
.btn.orange { background:var(--orange); }
ul { margin-top:8px; }
li { margin-bottom:7px; }
@media(max-width:700px){ .header{padding:22px 18px;} .header h1{font-size:25px;} .wrap{padding:0 12px;} button,.btn{width:100%;} }
</style>
<script>
function goHome(){ window.location='/index.html'; }
function goAdmin(){ window.location = window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_home.sh'; }
</script>
</head>

<body>
<div class="header">
    <h1>Matrix Diagnostics Dashboard</h1>
    <p>Router: <b>$HOSTNAME</b> &nbsp; | &nbsp; $NOW</p>
</div>

<div class="wrap">

<div class="card">
    <h2>Diagnostics Status</h2>
    <div class="result $FINAL_CLASS">
        <div class="result-title">$FINAL_STATUS</div>
        <b>$FINAL_TEXT</b><br><br>
        Errors: <b>$ERRORS</b> &nbsp; | &nbsp; Warnings: <b>$WARNINGS</b>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <h2>Systeem</h2>
        <table>
            <tr><th>Onderdeel</th><th>Waarde</th></tr>
            <tr><td>Hostname</td><td>$HOSTNAME</td></tr>
            <tr><td>Model</td><td>$MODEL</td></tr>
            <tr><td>Firmware</td><td>$FIRMWARE</td></tr>
            <tr><td>Uptime</td><td>$UPTIME</td></tr>
            <tr><td>Toolkit Version</td><td>$TOOLKIT_VERSION</td></tr>
            <tr><td>Toolkit Build</td><td>$TOOLKIT_BUILD</td></tr>
        </table>
    </div>

    <div class="card">
        <h2>Netwerk / WAN</h2>
        <table>
            <tr><th>Onderdeel</th><th>Waarde</th></tr>
            <tr><td>LAN IP</td><td>$LANIP</td></tr>
            <tr><td>WAN IP</td><td>$WANIP</td></tr>
            <tr><td>Gateway</td><td>$GATEWAY</td></tr>
            <tr><td>DNS 1</td><td>$DNS1</td></tr>
            <tr><td>DNS 2</td><td>$DNS2</td></tr>
            <tr><td>WAN Interface</td><td>$WAN_INTERFACE</td></tr>
            <tr><td>Protocol</td><td>$PROTOCOL</td></tr>
            <tr><td>WAN Uptime</td><td>$WAN_UPTIME_TXT</td></tr>
        </table>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <h2>LTE / Mobiel netwerk</h2>
        <table>
            <tr><th>Onderdeel</th><th>Waarde</th></tr>
            <tr><td>LTE IP</td><td>$LTEIP</td></tr>
            <tr><td>Operator</td><td>$LTE_OPERATOR</td></tr>
            <tr><td>Technologie</td><td>$LTE_TECH</td></tr>
            <tr><td>Registratie</td><td>$LTE_REGISTRATION</td></tr>
            <tr><td>Cache updated</td><td>$LTE_UPDATED</td></tr>
            <tr><td>RSSI</td><td>$RSSI $(quality_badge "$RSSI_Q")</td></tr>
            <tr><td>RSRP</td><td>$RSRP $(quality_badge "$RSRP_Q")</td></tr>
            <tr><td>RSRQ</td><td>$RSRQ $(quality_badge "$RSRQ_Q")</td></tr>
            <tr><td>SINR</td><td>$SINR $(quality_badge "$SINR_Q")</td></tr>
        </table>
    </div>

    <div class="card">
        <h2>Connectiviteit</h2>
        <table>
            <tr><th>Test</th><th>Status</th></tr>
            <tr><td>Internet ping 8.8.8.8</td><td>$(badge "$INTERNET_STATUS")</td></tr>
            <tr><td>DNS resolve google.com</td><td>$(badge "$DNS_STATUS")</td></tr>
            <tr><td>Matrix Cloud am4.matrixfitness.com</td><td>$(badge "$MATRIX_STATUS")</td></tr>
            <tr><td>ZeroTier</td><td>$(badge "$ZT_STATUS")</td></tr>
            <tr><td>ZeroTier IP</td><td>$ZT_IP</td></tr>
        </table>
    </div>
</div>

<div class="card">
    <h2>Aanbevolen acties</h2>
    <div class="note">
        <ul>
            $ACTIONS
        </ul>
    </div>
</div>

<div class="card">
    <h2>Ruwe LTE data</h2>
    <pre>$LTE_SIGNAL</pre>
</div>

<div class="card">
    <button onclick="goHome()">Return to Home</button>
    <button onclick="goAdmin()">Return to Admin</button>
    <a class="btn secondary" href="/cgi-bin/routerinfo.sh">Router Info</a>
    <a class="btn secondary" href="/cgi-bin/wan.sh">WAN Status</a>
    <a class="btn secondary" href="/cgi-bin/lte.sh">LTE Analyse</a>
    <a class="btn orange" href="/cgi-bin/matrix_full_test.sh">Matrix Full Test</a>
</div>

</div>
</body>
</html>
EOF

exit 0
