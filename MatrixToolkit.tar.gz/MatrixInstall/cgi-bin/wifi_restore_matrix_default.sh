#!/bin/sh
LIB="/usr/local/matrix/web/cgi-bin/wifi_lib.sh"
[ -f "$LIB" ] && . "$LIB"
ensure_wifi_files
restore_matrix_default_wifi
HOST="$(hostname_value)"
echo "Content-Type: text/html"; echo ""; cat <<EOF
<!DOCTYPE html><html><head><title>Restore Matrix Default WiFi</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="4;url=/cgi-bin/wifi_manager.sh?nocache=$(date +%s)"><style>body{font-family:Arial;margin:20px;background:#f5f5f5}.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}h1{color:#005a9c}.ok{color:#1f8a3b;font-weight:bold}.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}</style></head><body><div class="box"><h1>Restore Matrix Default WiFi</h1><p class="ok">Matrix default WiFi restored.</p><p><b>2.4 GHz:</b> ${HOST}_2G</p><p><b>5 GHz:</b> ${HOST}_5G</p><p><b>Password:</b> ********</p><p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></p></div></body></html>
EOF
