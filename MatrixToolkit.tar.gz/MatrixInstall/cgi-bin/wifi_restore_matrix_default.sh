#!/bin/sh
# Matrix Toolkit - Restore Matrix Default WiFi
# Safe fallback independent from stored WiFi profiles.
# 2.4 GHz = {HOSTNAME}_2G
# 5 GHz   = {HOSTNAME}_5G

LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"

SSID_2G="${HOST}_2G"
SSID_5G="${HOST}_5G"
PASS="matrixfitness"

OLD_2G="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
OLD_5G="$(uci get wireless.default_radio1.ssid 2>/dev/null)"

uci set wireless.default_radio0.ssid="$SSID_2G"
uci set wireless.default_radio0.key="$PASS"
uci set wireless.default_radio0.encryption='psk2'
uci set wireless.default_radio0.disabled='0'

uci set wireless.default_radio1.ssid="$SSID_5G"
uci set wireless.default_radio1.key="$PASS"
uci set wireless.default_radio1.encryption='psk2'
uci set wireless.default_radio1.disabled='0'

uci commit wireless
wifi reload >/dev/null 2>&1

echo "$(date '+%Y-%m-%d %H:%M:%S') Restored Matrix Default WiFi old2=$OLD_2G old5=$OLD_5G new2=$SSID_2G new5=$SSID_5G" >> "$LOG"

E_HOST="$(html_escape "$HOST")"
E_2G="$(html_escape "$SSID_2G")"
E_5G="$(html_escape "$SSID_5G")"

echo "Content-Type: text/html"
echo ""
cat <<EOF
<!DOCTYPE html>
<html>
<head>
<title>Restore Matrix Default WiFi</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="4;url=/cgi-bin/wifi_manager.sh?nocache=$(date +%s)">
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5;color:#222}
.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}
h1{color:#005a9c}.ok{color:#1f8a3b;font-weight:bold}
.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}
</style>
</head>
<body>
<div class="box">
<h1>Restore Matrix Default WiFi</h1>
<p class="ok">Matrix default WiFi restored.</p>
<p><b>Router:</b> $E_HOST</p>
<p><b>2.4 GHz:</b> $E_2G</p>
<p><b>5 GHz:</b> $E_5G</p>
<p><b>Password:</b> ********</p>
<p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></p>
</div>
</body>
</html>
EOF
