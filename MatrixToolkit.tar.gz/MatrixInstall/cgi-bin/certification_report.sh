#!/bin/sh

echo "Content-Type: text/html"
echo ""

REPORTDIR="/usr/local/mnt/sda1/Backup/Reports"

mkdir -p "$REPORTDIR"

TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
REPORTFILE="$REPORTDIR/Matrix_Report_${TIMESTAMP}.html"

INTERNET="FAIL"
DNS="FAIL"
MATRIX="FAIL"

ping -c 1 8.8.8.8 >/dev/null 2>&1 && INTERNET="PASS"
nslookup am4.matrixfitness.com >/dev/null 2>&1 && DNS="PASS"
curl -s --connect-timeout 10 https://am4.matrixfitness.com >/dev/null 2>&1 && MATRIX="PASS"

PASSCOUNT=0
TOTALCOUNT=11

nslookup dapi.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup orion.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup mwtn.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup pt-client.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup facilitycalendar.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup frontend-config.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup config.jhtassets.com >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup images.jhtassets.com >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup location-ip.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup am4.matrixfitness.com >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))
nslookup am4-api.jfit.co >/dev/null 2>&1 && PASSCOUNT=$((PASSCOUNT+1))

WANIP=$(ubus call network.interface.wan status | grep '"address"' | head -1 | cut -d'"' -f4)

CLUBNAME=$(cat /usr/local/matrix/clubname.txt 2>/dev/null)

[ -z "$CLUBNAME" ] && CLUBNAME="Niet ingevuld"

if [ "$INTERNET" = "PASS" ] && 
[ "$DNS" = "PASS" ] && 
[ "$MATRIX" = "PASS" ] && 
[ "$PASSCOUNT" -eq "$TOTALCOUNT" ]
then
RESULT="GOEDGEKEURD"
RESULTCOLOR="green"
else
RESULT="AFGEKEURD"
RESULTCOLOR="red"
fi

DATESTR=$(date '+%d-%m-%Y')
TIMESTR=$(date '+%H:%M:%S')

TMPFILE="/tmp/matrix_report.html"

{

echo "<html>"
echo "<head>"
echo "<meta charset='UTF-8'>"
echo "<title>Matrix Opleverrapport</title>"

echo "<style>"
echo "body{font-family:Arial;margin:15px;font-size:14px;}"
echo "table{border-collapse:collapse;width:100%;margin-bottom:12px;}"
echo "th,td{border:1px solid #ccc;padding:6px;text-align:left;}"
echo "th{background:#005a9c;color:white;}"
echo "td:first-child{width:250px;font-weight:bold;background:#f8f9fa;}"
echo "@media print { button { display:none; } }"
echo "</style>"

echo "</head>"
echo "<body>"

echo "<button onclick='window.print()'>Opslaan als PDF</button>"

echo "<h1>Matrix Opleverrapport</h1>"
echo "<h2 style='color:$RESULTCOLOR'>RESULTAAT: $RESULT</h2>"

echo "<table>"
echo "<tr><th colspan='2'>Clubgegevens</th></tr>"
echo "<tr><td>Clubnaam</td><td>$CLUBNAME</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Netwerk</th></tr>"
echo "<tr><td>WAN IP Adres</td><td>$WANIP</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Connectiviteit</th></tr>"
echo "<tr><td>Internet Bereikbaar</td><td>$INTERNET</td></tr>"
echo "<tr><td>DNS Resolutie</td><td>$DNS</td></tr>"
echo "<tr><td>Matrix Cloud</td><td>$MATRIX</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Matrix Services</th></tr>"
echo "<tr><td>Bereikbare Services</td><td>$PASSCOUNT van $TOTALCOUNT</td></tr>"
echo "</table>"

echo "<table>"
echo "<tr><th colspan='2'>Oplevering</th></tr>"
echo "<tr><td>Datum</td><td>$DATESTR</td></tr>"
echo "<tr><td>Tijd</td><td>$TIMESTR</td></tr>"
echo "<tr><td>Rapportbestand</td><td>Matrix_Report_${TIMESTAMP}.html</td></tr>"
echo "</table>"

if [ "$RESULT" = "GOEDGEKEURD" ]
then
echo "<p style='color:green;font-weight:bold'>Installatie succesvol gevalideerd.</p>"
else
echo "<p style='color:red;font-weight:bold'>Installatie afgekeurd. Controleer internet en Matrix services.</p>"
fi

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2)

[ -z "$VERSION" ] && VERSION="Unknown"

echo "<hr>"
echo "<small>Matrix Toolkit v$VERSION</small>"

echo "</body>"
echo "</html>"

} > "$TMPFILE"

cp "$TMPFILE" "$REPORTFILE"

cat "$TMPFILE"
