#!/bin/sh

echo "Content-type: text/plain"
echo ""

echo "Router Info:"
uptime
ifconfig

exit 0