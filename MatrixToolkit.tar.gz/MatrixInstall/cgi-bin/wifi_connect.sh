#!/bin/sh

echo "Content-Type: text/html"
echo ""

SSID="$(echo "$QUERY_STRING" | sed -n 's/.*ssid=([^&]*).*/\1/p')"
PASSWORD="$(echo "$QUERY_STRING" | sed -n 's/.*password=([^&]*).*/\1/p')"

echo "<html>"
echo "<head>"
echo "<title>WiFi Debug</title>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Debug</h2>"

echo "<table border='1' cellpadding='5'>"
echo "<tr><td><b>QUERY_STRING</b></td><td>$QUERY_STRING</td></tr>"
echo "<tr><td><b>SSID</b></td><td>$SSID</td></tr>"
echo "<tr><td><b>PASSWORD</b></td><td>$PASSWORD</td></tr>"
echo "</table>"

echo "<br>"
echo "<a href='/wifi_survey.html'>Back</a>"

echo "</body>"
echo "</html>"
