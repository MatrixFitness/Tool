#!/bin/sh

echo "Content-Type: text/html"
echo ""

SSID="$(echo "$QUERY_STRING" | sed -n 's/.*ssid=\([^&]*\).*/\1/p' | sed 's/%20/ /g')"
PASSWORD="$(echo "$QUERY_STRING" | sed -n 's/.*password=\([^&]*\).*/\1/p' | sed 's/%20/ /g')"

mkdir -p /usr/local/matrix

uci show wireless.1 > /usr/local/matrix/wifi_backup.conf

uci set wireless.1.ssid="$SSID"
uci set wireless.1.key="$PASSWORD"
uci set wireless.1.encryption='sae-mixed'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'

uci commit wireless

wifi reload

sleep 20

echo "<html><body>"
echo "<h2>Customer WiFi Connection</h2>"

if ifstatus wan1 | grep -q '"up": true'
then
    echo "<p style='color:green'>CONNECTED</p>"
else
    echo "<p style='color:red'>FAILED</p>"
fi

echo "<a href='/wifi_survey.html'>Back</a>"
echo "</body></html>"