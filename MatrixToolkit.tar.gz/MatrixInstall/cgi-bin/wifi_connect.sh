#!/bin/sh

echo "Content-Type: text/html"
echo ""

# Get values from URL

SSID=$(echo "$QUERY_STRING" | cut -d'&' -f1 | cut -d'=' -f2-)
PASSWORD=$(echo "$QUERY_STRING" | cut -d'&' -f2 | cut -d'=' -f2-)

mkdir -p /usr/local/matrix

# Create WAN1 if missing

uci show network.wan1 >/dev/null 2>&1

if [ $? -ne 0 ]
then
uci set network.wan1=interface
uci set network.wan1.proto='dhcp'
uci set network.wan1.metric='5'
uci commit network
fi

# Create WiFi Client Interface if missing

uci show wireless.1 >/dev/null 2>&1

if [ $? -ne 0 ]
then
uci set wireless.1=wifi-iface
uci set wireless.1.device='radio0'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'
fi

# Save settings

uci set wireless.1.ssid="$SSID"
uci set wireless.1.key="$PASSWORD"
uci set wireless.1.encryption='psk2'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'

uci commit wireless

wifi reload

sleep 30

echo "<html>"
echo "<head>"
echo "<title>Customer WiFi Connection</title>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Connection</h2>"

if ifstatus wan1 2>/dev/null | grep -q '"up": true'
then

```
IPADDR=$(ifstatus wan1 | grep '"address"' | head -1 | cut -d'"' -f4)

echo "<p style='color:green'><b>CONNECTED</b></p>"
echo "<p><b>SSID:</b> $SSID</p>"
echo "<p><b>IP Address:</b> $IPADDR</p>"
```

else

```
echo "<p style='color:red'><b>FAILED</b></p>"
echo "<p><b>SSID:</b> $SSID</p>"
echo "<p>No DHCP lease received.</p>"
```

fi

echo "<br>"
echo "<a href='/wifi_survey.html'>Back</a>"

echo "</body>"
echo "</html>"
