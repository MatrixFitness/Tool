#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

# Read SSID and password from URL

SSID=$(echo "$QUERY_STRING" | cut -d'&' -f1 | cut -d'=' -f2-)
PASSWORD=$(echo "$QUERY_STRING" | cut -d'&' -f2 | cut -d'=' -f2-)

# Create WAN1 if missing

if ! uci show network.wan1 >/dev/null 2>&1
then
uci set network.wan1=interface
uci set network.wan1.proto='dhcp'
uci set network.wan1.metric='5'
uci commit network
fi

# Create WiFi client if missing

if ! uci show wireless.1 >/dev/null 2>&1
then
uci set wireless.1=wifi-iface
uci set wireless.1.device='radio0'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'
fi

# Configure customer WiFi

uci set wireless.1.ssid="$SSID"
uci set wireless.1.key="$PASSWORD"
uci set wireless.1.encryption='psk2'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'

uci commit wireless

# Reload WiFi

wifi reload

# Wait for association and DHCP

sleep 20

# Check connection

IPADDR=$(/sbin/ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)

# HTML Output

echo "<html>"
echo "<head>
<meta charset="UTF-8">"
echo "<title>Customer WiFi Connection</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;background:#f5f5f5;}"
echo "table{border-collapse:collapse;background:white;}"
echo "td{border:1px solid #cccccc;padding:8px;}"
echo "h2{color:#005a9c;}"
echo ".ok{color:green;font-size:22px;font-weight:bold;}"
echo ".fail{color:red;font-size:22px;font-weight:bold;}"
echo "button{padding:10px 20px;margin-right:10px;font-size:14px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Connection</h2>"

if [ -n "$IPADDR" ]
then


echo "<p class='ok'>CONNECTED SUCCESSFULLY</p>"

echo "<table>"
echo "<tr><td><b>SSID</b></td><td>$SSID</td></tr>"
echo "<tr><td><b>IP Address</b></td><td>$IPADDR</td></tr>"
echo "<tr><td><b>Status</b></td><td>Connected</td></tr>"
echo "</table>"

echo "<br>"
echo "<button onclick=\"window.location='/location_survey.html'\">Start Location Survey</button>"
echo "<button onclick=\"location.href='/wifi_survey.html'\">Back</button>"


else

echo "<p class='fail'>CONNECTION FAILED</p>"
echo "<p>No DHCP lease received from customer WiFi.</p>"

echo "<br>"
echo "<button onclick=\"location.href='/wifi_survey.html'\">Try Again</button>"

fi

echo "<br><br><hr>"
echo "<small>"
echo "Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE<br>"
echo "$COMPANY<br>"
echo "Created by $AUTHOR<br>"
echo "$EMAIL<br>"
echo "$MESSAGE"
echo "</small>"

echo "</body>"
echo "</html>"
