#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

# Read SSID and password from URL

SSID=$(echo "$QUERY_STRING" | cut -d'&' -f1 | cut -d'=' -f2-)
PASSWORD=$(echo "$QUERY_STRING" | cut -d'&' -f2 | cut -d'=' -f2-)

# Create WAN1 if missing

if ! uci show network.wan1 >/dev/null 2>&1
then
uci set network.wan1=interface
uci set network.wan1.proto='dhcp'
uci set network.wan1.metric='5'
uci commit network
fi

# Create WiFi client if missing

if ! uci show wireless.1 >/dev/null 2>&1
then
uci set wireless.1=wifi-iface
uci set wireless.1.device='radio0'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'
fi

# Configure customer WiFi

uci set wireless.1.ssid="$SSID"
uci set wireless.1.key="$PASSWORD"
uci set wireless.1.encryption='psk2'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'

uci commit wireless

# Reload WiFi

wifi reload

# Wait for association and DHCP

sleep 20

# Check connection

IPADDR=$(/sbin/ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)

# HTML Output

echo "<!DOCTYPE html>"
echo "<html>"
echo "<head>"
echo "<meta charset='UTF-8'>"
echo "<meta name='viewport' content='width=device-width, initial-scale=1'>"
echo "<title>Customer WiFi Connection</title>"
echo "<style>"
echo ":root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--fail:#c82333;--blue:#005a9c}"
echo "*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1200px;margin:0 auto;padding:18px}"
echo ".hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px}.contact{margin-top:7px;font-size:13px;opacity:.95}.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}"
echo ".card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:18px}.status{display:inline-block;border-radius:999px;background:var(--ok);color:#fff;padding:7px 12px;font-weight:800;font-size:13px;margin-bottom:12px}.status.fail{background:var(--fail)}table{width:100%;border-collapse:collapse;background:#fff;margin-top:10px}td,th{border:1px solid var(--border);padding:10px;text-align:left}th{background:#f0f6fb}.button-row{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer}.btn.secondary{background:#667085}.footer{color:var(--muted);font-size:12px;text-align:center;margin:22px 0 6px}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-btn,.btn{width:100%;text-align:center}.button-row{display:block}.button-row .btn{margin:6px 0}}"
echo "</style>"
echo "</head>"
echo "<body>"
echo "<div class='page'>"
echo "<section class='hero'>"
echo "<div>"
echo "<h1>Customer WiFi Connection</h1>"
echo "<div class='sub'>Connection result and next survey step</div>"
echo "<div class='contact'>Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE</div>"
echo "<div class='contact'>$COMPANY &middot; Created by $AUTHOR &middot; $EMAIL</div>"
echo "</div>"
echo "<a class='top-btn' href='/'>Back to Toolkit</a>"
echo "</section>"

if [ -n "$IPADDR" ]
then
echo "<div class='card'>"
echo "<div class='status'>CONNECTED SUCCESSFULLY</div>"
echo "<table>"
echo "<tr><th>Item</th><th>Result</th></tr>"
echo "<tr><td><b>SSID</b></td><td>$SSID</td></tr>"
echo "<tr><td><b>IP Address</b></td><td>$IPADDR</td></tr>"
echo "<tr><td><b>Status</b></td><td>Connected</td></tr>"
echo "</table>"
echo "<div class='button-row'>"
echo "<a class='btn' href='/location_survey.html'>Start Location Survey</a>"
echo "<a class='btn secondary' href='/cgi-bin/wifi_survey.sh'>Back</a>"
echo "</div>"
echo "</div>"
else
echo "<div class='card'>"
echo "<div class='status fail'>CONNECTION FAILED</div>"
echo "<p>No DHCP lease received from customer WiFi.</p>"
echo "<div class='button-row'>"
echo "<a class='btn secondary' href='/cgi-bin/wifi_survey.sh'>Try Again</a>"
echo "</div>"
echo "</div>"
fi

echo "<div class='footer'>Matrix Fitness &middot; Customer WiFi Survey</div>"
echo "</div>"
echo "</body>"
echo "</html>"
