#!/bin/sh

echo "Content-Type: text/html"
echo ""

SSID="$(echo "$QUERY_STRING" | sed -n 's/.*ssid=([^&]*).*/\1/p' | sed 's/%20/ /g')"
PASSWORD="$(echo "$QUERY_STRING" | sed -n 's/.*password=([^&]*).*/\1/p' | sed 's/%20/ /g')"

mkdir -p /usr/local/matrix

# Create wan1 if missing

uci show network.wan1 >/dev/null 2>&1

if [ $? -ne 0 ]
then
uci set network.wan1=interface
uci set network.wan1.proto='dhcp'
uci set network.wan1.metric='5'
uci commit network
fi

# Create WiFi client interface if missing

uci show wireless.1 >/dev/null 2>&1

if [ $? -ne 0 ]
then
uci set wireless.1=wifi-iface
uci set wireless.1.device='radio0'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'
fi

# Backup current settings

uci show wireless.1 > /usr/local/matrix/wifi_backup.conf

# Configure customer WiFi

uci set wireless.1.ssid="$SSID"
uci set wireless.1.key="$PASSWORD"
uci set wireless.1.encryption='psk2'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'

uci commit wireless

wifi reload

sleep 30

echo "<html><body>"
echo "<h2>Customer WiFi Connection</h2>"

if ifstatus wan1 2>/dev/null | grep -q '"up": true'
then

```
IPADDR=$(ifstatus wan1 | grep '"address"' | head -1 | cut -d'"' -f4)

SIGNAL=$(iwinfo 2>/dev/null | grep -A5 "$SSID" | grep Signal | awk '{print $2}')

echo "<p style='color:green'><b>CONNECTED</b></p>"
echo "<p>SSID: $SSID</p>"
echo "<p>IP Address: $IPADDR</p>"
echo "<p>Signal: $SIGNAL dBm</p>"
```

else

```
echo "<p style='color:red'><b>FAILED</b></p>"
echo "<p>SSID: $SSID</p>"
echo "<p>No DHCP lease received.</p>"
```

fi

echo "<br>"
echo "<a href='/wifi_survey.html'>Back</a>"
echo "</body></html>"