#!/bin/sh
echo "Content-Type: text/html; charset=UTF-8"
echo ""

VERSION="$(grep '^Version=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2)"
BUILD="$(grep '^Build=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2)"
RELEASE="$(grep '^Release=' /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2)"
[ -z "$VERSION" ] && VERSION="86"
[ -z "$BUILD" ] && BUILD="2026-07-02"
[ -z "$RELEASE" ] && RELEASE="Professional Edition"

url_decode() {
    printf '%s' "$1" | sed 's/+/ /g;s/%/\\x/g' | xargs -0 printf '%b' 2>/dev/null
}
get_qs() {
    KEY="$1"
    printf '%s' "$QUERY_STRING" | tr '&' '\n' | awk -F= -v k="$KEY" '$1==k{print substr($0,length(k)+2); exit}'
}

SSID="$(url_decode "$(get_qs ssid)")"
PASSWORD="$(url_decode "$(get_qs password)")"
BSSID="$(url_decode "$(get_qs bssid)")"
BAND="$(url_decode "$(get_qs band)")"
CHANNEL="$(url_decode "$(get_qs channel)")"
RADIO_SELECTED="$(url_decode "$(get_qs radio)")"

# Choose correct radio. Scanner-provided radio has highest priority.
RADIO="radio0"
if [ "$RADIO_SELECTED" = "radio0" ] || [ "$RADIO_SELECTED" = "radio1" ]; then
    RADIO="$RADIO_SELECTED"
fi
if [ -z "$RADIO_SELECTED" ]; then
case "$BAND" in
    *5*) RADIO="radio1" ;;
esac
fi
if [ -z "$RADIO_SELECTED" ] && echo "$CHANNEL" | grep -Eq '^[0-9]+$'; then
    [ "$CHANNEL" -gt 14 ] && RADIO="radio1"
    [ "$CHANNEL" -le 14 ] && RADIO="radio0"
fi

# WAN over WiFi should have higher metric than Ethernet WAN.
if ! uci show network.wan1 >/dev/null 2>&1; then
    uci set network.wan1=interface
fi
uci set network.wan1.proto='dhcp'
uci set network.wan1.metric='5'
uci commit network

# Use a named iface instead of generic wireless.1 when possible.
CLIENT_SECTION=""
uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d. -f2 | cut -d= -f1 | while read X; do
    MODE="$(uci get wireless.${X}.mode 2>/dev/null)"
    [ "$MODE" = "sta" ] || continue
    echo "$X"
    break
done > /tmp/matrix_sta_section.$$

if [ -s /tmp/matrix_sta_section.$$ ]; then
    CLIENT_SECTION="$(cat /tmp/matrix_sta_section.$$)"
else
    CLIENT_SECTION="matrix_customer_sta"
    uci set wireless.${CLIENT_SECTION}=wifi-iface
fi
rm -f /tmp/matrix_sta_section.$$ 2>/dev/null

uci set wireless.${CLIENT_SECTION}.device="$RADIO"
uci set wireless.${CLIENT_SECTION}.mode='sta'
uci set wireless.${CLIENT_SECTION}.network='wan1'
uci set wireless.${CLIENT_SECTION}.ssid="$SSID"
uci set wireless.${CLIENT_SECTION}.key="$PASSWORD"
uci set wireless.${CLIENT_SECTION}.encryption='psk2'
uci set wireless.${CLIENT_SECTION}.disabled='0'
# Do not lock BSSID by default. It can break roaming and some APs.
# Store selected BSSID as comment-style custom option for display/debug only.
[ -n "$BSSID" ] && uci set wireless.${CLIENT_SECTION}.matrix_selected_bssid="$BSSID"
uci set wireless.${CLIENT_SECTION}.matrix_selected_band="$BAND"
uci set wireless.${CLIENT_SECTION}.matrix_selected_channel="$CHANNEL"
uci commit wireless

wifi reload >/dev/null 2>&1

# Wait up to 45 seconds for association and DHCP.
IPADDR=""
STATUS_TEXT="Waiting for DHCP"
for T in 1 2 3 4 5 6 7 8 9; do
    sleep 5
    IPADDR="$(ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)"
    [ -n "$IPADDR" ] && break
done

if [ -n "$IPADDR" ]; then
    RESULT="CONNECTED SUCCESSFULLY"
    RESULT_CLASS="ok"
    STATUS_TEXT="Connected"
else
    RESULT="CONNECTION NOT READY"
    RESULT_CLASS="warn"
    STATUS_TEXT="No DHCP lease yet"
fi

GATEWAY="$(ifstatus wan1 2>/dev/null | grep '"nexthop"' | head -1 | cut -d'"' -f4)"
DEV="$(ifstatus wan1 2>/dev/null | grep '"device"' | head -1 | cut -d'"' -f4)"
IWINFO_OUT=""
[ -n "$DEV" ] && IWINFO_OUT="$(iwinfo "$DEV" info 2>/dev/null)"
CONNECTED_SSID="$(echo "$IWINFO_OUT" | sed -n 's/.*ESSID: *"\([^"]*\)".*/\1/p' | head -1)"
SIGNAL="$(echo "$IWINFO_OUT" | awk '/Signal:/ {print $2; exit}')"
AP="$(echo "$IWINFO_OUT" | sed -n 's/.*Access Point: *\([0-9A-Fa-f:][0-9A-Fa-f:]*\).*/\1/p' | head -1)"
[ -z "$CONNECTED_SSID" ] && CONNECTED_SSID="-"
[ -z "$SIGNAL" ] && SIGNAL="Unknown"
[ -z "$AP" ] && AP="-"
[ -z "$GATEWAY" ] && GATEWAY="-"
[ -z "$IPADDR" ] && IPADDR="-"

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Customer WiFi Connection</title>
<style>
:root{--bg:#eef2f6;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b05a00;--blue:#005a9c}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1100px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px}.contact{font-size:13px;margin-top:7px}.top-btn{display:inline-block;background:rgba(255,255,255,.16);color:#fff!important;border:1px solid rgba(255,255,255,.35);text-decoration:none!important;border-radius:12px;padding:11px 14px;font-weight:700}.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:18px}.status{font-size:28px;font-weight:900}.ok{color:var(--ok)}.warn{color:var(--warn)}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:12px}.label{font-size:12px;text-transform:uppercase;color:var(--muted);font-weight:800}.value{font-size:21px;font-weight:900;margin-top:6px}.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border-radius:12px;padding:12px 15px;font-weight:800;margin:8px 8px 0 0}.green{background:var(--ok)}
@media(max-width:760px){.grid{grid-template-columns:1fr}.page{padding:10px}}
</style>
EOF

if [ "$RESULT_CLASS" = "warn" ]; then
    echo "<meta http-equiv='refresh' content='5;url=/cgi-bin/wifi_connect_status.sh'>"
fi

cat <<EOF
</head>
<body>
<div class="page">
<section class="hero">
  <div>
    <h1>Customer WiFi Connection</h1>
    <div class="sub">Connection result and next survey step</div>
    <div class="contact">Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE</div>
    <div class="contact">Matrix Fitness · Created by Rob Bosman · rob.bosman@matrixfitness.nl</div>
  </div>
  <a class="top-btn" href="/cgi-bin/wifi_survey.sh">Back to WiFi Wizard</a>
</section>

<div class="card">
  <div class="status $RESULT_CLASS">$RESULT</div>
  <p>Status: $STATUS_TEXT</p>
  <div class="grid">
    <div class="metric"><div class="label">Selected SSID</div><div class="value">$SSID</div></div>
    <div class="metric"><div class="label">Radio</div><div class="value">$RADIO</div></div>
    <div class="metric"><div class="label">Band / Channel</div><div class="value">$BAND $CHANNEL</div></div>
    <div class="metric"><div class="label">Connected SSID</div><div class="value">$CONNECTED_SSID</div></div>
    <div class="metric"><div class="label">IP Address</div><div class="value">$IPADDR</div></div>
    <div class="metric"><div class="label">Gateway</div><div class="value">$GATEWAY</div></div>
    <div class="metric"><div class="label">Signal</div><div class="value">$SIGNAL dBm</div></div>
    <div class="metric"><div class="label">Connected AP</div><div class="value">$AP</div></div>
    <div class="metric"><div class="label">Expected AP</div><div class="value">$BSSID</div></div>
  </div>
  <div style="margin-top:14px">
EOF

if [ "$RESULT_CLASS" = "ok" ]; then
    echo "<a class='btn green' href='/cgi-bin/location_survey.sh'>Continue to Location Survey</a>"
else
    echo "<a class='btn' href='/cgi-bin/wifi_connect_status.sh'>Refresh Status</a>"
fi

cat <<EOF
    <a class="btn" href="/cgi-bin/wifi_survey.sh">Try Again</a>
    <a class="btn" href="/">Back to Toolkit</a>
  </div>
</div>
</div>
</body>
</html>
EOF
