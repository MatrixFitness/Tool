#!/bin/sh

echo "Content-Type: text/html"
echo ""

# Read parameters

SSID=$(echo "$QUERY_STRING" | cut -d'&' -f1 | cut -d'=' -f2-)
PASSWORD=$(echo "$QUERY_STRING" | cut -d'&' -f2 | cut -d'=' -f2-)

mkdir -p /usr/local/matrix

# Create wan1 if missing

uci show network.wan1 >/dev/null 2>&1

if [ $? -ne 0 ]
then
uci set network.wan1=interface
uci set network.wan1.proto='dhcp'
uci set network.wan1.metric='5'
uci commit network
fi

# Create WiFi client if missing

uci show wireless.1 >/dev/null 2>&1

if [ $? -ne 0 ]
then
uci set wireless.1=wifi-iface
uci set wireless.1.device='radio0'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'
fi

# Configure WiFi

uci set wireless.1.ssid="$SSID"
uci set wireless.1.key="$PASSWORD"
uci set wireless.1.encryption='psk2'
uci set wireless.1.mode='sta'
uci set wireless.1.network='wan1'

uci commit wireless

wifi reload

sleep 20

# Gather information

CONNECTED="NO"

if ifstatus wan1 2>/dev/null | grep -q '"up": true'
then
CONNECTED="YES"
fi

IPADDR=$(ifstatus wan1 2>/dev/null | grep '"address"' | head -1 | cut -d'"' -f4)

SIGNAL=$(iwinfo | grep -A10 "ESSID: "$SSID"" | grep "Signal:" | awk '{print $2}')

QUALITY=$(iwinfo | grep -A10 "ESSID: "$SSID"" | grep "Link Quality:" | awk '{print $3}')

# Output page

echo "<html>"
echo "<head>"
echo "<title>Customer WiFi Connection</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;}"
echo "table{border-collapse:collapse;width:650px;}"
echo "th{background:#005a9c;color:white;padding:8px;}"
echo "td{border:1px solid #ccc;padding:8px;}"
echo "td:first-child{font-weight:bold;background:#f5f5f5;width:250px;}"
echo ".ok{color:green;font-size:22px;font-weight:bold;}"
echo ".fail{color:red;font-size:22px;font-weight:bold;}"
echo "button{padding:10px 20px;font-size:14px;margin-right:10px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Connection</h2>"

if [ "$CONNECTED" = "YES" ]
then

```
echo "<p class='ok'>CONNECTED SUCCESSFULLY</p>"

echo "<table>"
echo "<tr><th colspan='2'>Connection Information</th></tr>"
echo "<tr><td>SSID</td><td>$SSID</td></tr>"
echo "<tr><td>IP Address</td><td>$IPADDR</td></tr>"
echo "<tr><td>Signal Strength</td><td>$SIGNAL dBm</td></tr>"
echo "<tr><td>Link Quality</td><td>$QUALITY</td></tr>"
echo "</table>"

echo "<br>"
echo "<button onclick=\"location.href='/cgi-bin/wifi_measure.sh'\">Run WiFi Survey</button>"
echo "<button onclick=\"location.href='/wifi_survey.html'\">Back</button>"
```

else

```
echo "<p class='fail'>CONNECTION FAILED</p>"

echo "<table>"
echo "<tr><th colspan='2'>Connection Information</th></tr>"
echo "<tr><td>SSID</td><td>$SSID</td></tr>"
echo "<tr><td>Status</td><td>No DHCP lease received</td></tr>"
echo "</table>"

echo "<br>"
echo "<button onclick=\"location.href='/wifi_survey.html'\">Try Again</button>"
```

fi

echo "</body>"
echo "</html>"
