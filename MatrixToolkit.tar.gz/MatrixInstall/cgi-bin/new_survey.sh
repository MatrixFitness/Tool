#!/bin/sh

SURVEY_DIR="/usr/local/matrix/survey"
LOCATIONS_FILE="$SURVEY_DIR/locations.txt"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"
CSV="$SURVEY_DIR/wifi_survey_results.csv"

mkdir -p "$SURVEY_DIR"
rm -f "$LOCATIONS_FILE" "$COMPLETED_FILE" "$CSV"

echo "Date,Location,SSID,IP Address,Signal,Rating,Link Quality,Bit Rate,Internet,DNS,Matrix" > "$CSV"

RAW=$(echo "$QUERY_STRING" | sed -n 's/.*locations=\([^&]*\).*/\1/p')
RAW=$(printf '%s' "$RAW" | sed 's/%7C/|/g;s/%20/ /g;s/%2F/\//g;s/%2D/-/g;s/%28/(/g;s/%29/)/g;s/%26/\&/g')

echo "$RAW" | tr '|' '\n' | sed '/^$/d' > "$LOCATIONS_FILE"
: > "$COMPLETED_FILE"

echo "Status: 302 Found"
echo "Location: /cgi-bin/next_location.sh"
echo ""
