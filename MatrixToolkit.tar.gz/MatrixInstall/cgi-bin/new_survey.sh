#!/bin/sh

rm -f /tmp/wifi_survey_results.csv

echo "Status: 302 Found"
echo "Location: /wifi_survey.html"
echo ""