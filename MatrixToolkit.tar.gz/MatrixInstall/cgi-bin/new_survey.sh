#!/bin/sh

echo "Content-Type: text/html"
echo ""

SURVEY_DIR="/usr/local/matrix/survey"
LOCATIONS_FILE="$SURVEY_DIR/locations.txt"
COMPLETED_FILE="$SURVEY_DIR/completed.txt"
CSV="$SURVEY_DIR/wifi_survey_results.csv"

html_start(){
cat <<HTML
<html>
<head>
<meta charset="UTF-8">
<title>Start WiFi Survey</title>
<style>
body{font-family:Arial;margin:30px;background:#f5f5f5;}
.card{background:white;max-width:760px;padding:22px;border:1px solid #ccc;border-radius:8px;}
.ok{color:green;font-weight:bold}.err{color:#b00020;font-weight:bold}
button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:#005a9c;color:white;cursor:pointer}.secondary{background:#666}
code,pre{background:#f3f3f3;padding:3px 5px;border-radius:4px;}
pre{padding:12px;white-space:pre-wrap;}
</style>
</head>
<body><div class="card">
HTML
}

html_end(){
cat <<HTML
</div></body></html>
HTML
}

url_decode(){
  # Basic URL decode for the characters used by the survey page.
  printf '%s' "$1" | sed 's/%7C/|/g;s/%7c/|/g;s/%20/ /g;s/%2F/\//g;s/%2f/\//g;s/%2D/-/g;s/%2d/-/g;s/%28/(/g;s/%29/)/g;s/%26/\&/g;s/%2B/+/g;s/+/ /g'
}

html_start

echo "<h1>Start New WiFi Survey</h1>"

# Create persistent survey folder. This must be writable by CGI/uhttpd.
if ! mkdir -p "$SURVEY_DIR" 2>/tmp/matrix_survey_mkdir.err; then
  echo "<p class='err'>Cannot create survey folder: $SURVEY_DIR</p>"
  echo "<p>Run this once via SSH as root:</p>"
  cat <<'HTML'
<pre>mkdir -p /usr/local/matrix/survey
chmod 777 /usr/local/matrix/survey</pre>
HTML
  echo "<button onclick=\"window.location='/location_survey.html'\">Back</button>"
  html_end
  exit 0
fi

# Make sure CGI/uhttpd can write survey state.
chmod 777 "$SURVEY_DIR" 2>/dev/null

# Check write permissions before continuing.
if ! touch "$SURVEY_DIR/.write_test" 2>/tmp/matrix_survey_write.err; then
  echo "<p class='err'>Survey folder exists, but CGI cannot write to it.</p>"
  echo "<p>Run this once via SSH as root:</p>"
  echo "<pre>chmod 777 /usr/local/matrix/survey</pre>"
  echo "<button onclick=\"window.location='/location_survey.html'\">Back</button>"
  html_end
  exit 0
fi
rm -f "$SURVEY_DIR/.write_test"

RAW=$(echo "$QUERY_STRING" | sed -n 's/.*locations=\([^&]*\).*/\1/p')
RAW=$(url_decode "$RAW")

if [ -z "$RAW" ]; then
  echo "<p class='err'>No locations selected.</p>"
  echo "<button onclick=\"window.location='/location_survey.html'\">Back</button>"
  html_end
  exit 0
fi

# Reset existing survey and create new persistent state.
rm -f "$LOCATIONS_FILE" "$COMPLETED_FILE" "$CSV"

echo "Date,Location,SSID,IP Address,Signal,Rating,Link Quality,Bit Rate,Band,Channel,BSSID,Roaming Assessment,Internet,DNS,Matrix,Latency,Packet Loss,Download Mbps,Speed Rating,Network Quality,Overall" > "$CSV"
echo "$RAW" | tr '|' '\n' | sed '/^$/d' > "$LOCATIONS_FILE"
: > "$COMPLETED_FILE"

COUNT=$(wc -l < "$LOCATIONS_FILE" 2>/dev/null)

echo "<p class='ok'>New survey started successfully.</p>"
echo "<p><b>Selected locations:</b> $COUNT</p>"
echo "<p>The survey state is stored in:</p>"
echo "<pre>$SURVEY_DIR</pre>"
echo "<p>You can power off the router between locations. After reconnecting WiFi, use <b>Continue Survey</b>.</p>"
echo "<button onclick=\"window.location='/cgi-bin/next_location.sh'\">Continue to First Location</button>"
echo "<button class='secondary' onclick=\"window.location='/location_survey.html'\">Back</button>"

html_end
exit 0
