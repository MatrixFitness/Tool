#!/bin/sh

echo "Content-Type: text/html"
echo ""

LTE_CACHE="/tmp/matrix_lte_info.cache"

if [ -f "$LTE_CACHE" ]; then
    LTE_UPDATED=$(grep "^UPDATED=" "$LTE_CACHE" | cut -d= -f2-)
    OPERATOR=$(grep "^OPERATOR=" "$LTE_CACHE" | cut -d= -f2-)
    TECH=$(grep "^TECH=" "$LTE_CACHE" | cut -d= -f2-)
    SIGNAL=$(awk '/SIGNAL_START/{flag=1;next}/SIGNAL_END/{flag=0}flag' "$LTE_CACHE")
else
    LTE_UPDATED="Not available"
    OPERATOR="Not available"
    TECH="Not available"
    SIGNAL="Not available"
fi

[ -z "$LTE_UPDATED" ] && LTE_UPDATED="Not available"
[ -z "$OPERATOR" ] && OPERATOR="Not available"
[ -z "$TECH" ] && TECH="Not available"
[ -z "$SIGNAL" ] && SIGNAL="Not available"

RSSI=$(echo "$SIGNAL" | grep RSSI | awk '{print $2}')
RSRP=$(echo "$SIGNAL" | grep RSRP | awk '{print $2}')
RSRQ=$(echo "$SIGNAL" | grep RSRQ | awk '{print $2}')
SINR=$(echo "$SIGNAL" | grep SINR | awk '{print $2}')

is_number() {
    case "$1" in
        ''|*[!0-9-]*) return 1 ;;
        *) return 0 ;;
    esac
}

quality_cell() {
    NAME="$1"
    VALUE="$2"
    UNIT="$3"
    EXCELLENT="$4"
    GOOD="$5"
    FAIR="$6"

    STATUS="Niet beschikbaar"
    COLOR="#6c757d"
    DISPLAY="Not available"

    if is_number "$VALUE"; then
        DISPLAY="$VALUE $UNIT"
        STATUS="Slecht"
        COLOR="#dc3545"

        if [ "$VALUE" -ge "$FAIR" ]; then STATUS="Matig"; COLOR="#ff9800"; fi
        if [ "$VALUE" -ge "$GOOD" ]; then STATUS="Goed"; COLOR="#8bc34a"; fi
        if [ "$VALUE" -ge "$EXCELLENT" ]; then STATUS="Uitstekend"; COLOR="#28a745"; fi
    fi

    echo "<tr><td>$NAME</td><td style='background:$COLOR;color:white'><b>$DISPLAY ($STATUS)</b></td></tr>"
}

SINR_SCORE=0
if is_number "$SINR"; then
    if [ "$SINR" -ge 13 ]; then SINR_SCORE=2
    elif [ "$SINR" -ge 0 ]; then SINR_SCORE=1
    else SINR_SCORE=0
    fi
fi

cat <<HTML
<html>
<head>
<title>LTE Analyse</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222;}
.card{background:white;border-radius:8px;padding:18px;max-width:980px;box-shadow:0 1px 4px rgba(0,0,0,.12);}
table{border-collapse:collapse;width:100%;margin-bottom:22px;background:white;}
th,td{border:1px solid #ccc;padding:8px;text-align:left;vertical-align:top;}
th{background:#f2f2f2;}
h1{margin-top:0;color:#005a9c;}
.note{background:#f8fafc;border-left:4px solid #007bff;padding:12px;border-radius:6px;margin-bottom:18px;}
button{width:220px;height:48px;font-size:15px;font-weight:bold;cursor:pointer;border:0;border-radius:6px;background:#007bff;color:white;}
@media(max-width:700px){body{margin:12px}.card{padding:14px}button{width:100%;}}
</style>
</head>
<body>
<div class="card">
<h1>LTE Analyse</h1>
<div class="note">
Deze pagina gebruikt de LTE root cache: <b>/tmp/matrix_lte_info.cache</b><br>
Laatste update: <b>$LTE_UPDATED</b>
</div>

<table>
<tr><th colspan="2" style="background:#007bff;color:white;font-size:18px;">Netwerk</th></tr>
<tr><td>Operator</td><td>$OPERATOR</td></tr>
<tr><td>Technologie</td><td>$TECH</td></tr>
</table>

<table>
<tr><th colspan="2" style="background:#6f42c1;color:white;font-size:18px;">Signaal Analyse</th></tr>
HTML

quality_cell "RSSI" "$RSSI" "dBm" -65 -75 -85
quality_cell "RSRP" "$RSRP" "dBm" -90 -100 -110
quality_cell "RSRQ" "$RSRQ" "dB" -10 -14 -20
quality_cell "SINR" "$SINR" "dB" 20 13 0

cat <<HTML
</table>

<table>
<tr><th colspan="2" style="background:#17a2b8;color:white;font-size:18px;">Uitleg</th></tr>
<tr><td><b>RSSI</b></td><td>Algemene sterkte van het ontvangen radiosignaal.</td></tr>
<tr><td><b>RSRP</b></td><td>Werkelijke sterkte van het 4G/5G signaal. Belangrijkste waarde voor bereik.</td></tr>
<tr><td><b>RSRQ</b></td><td>Kwaliteit van het radiosignaal. Hoe minder negatief, hoe beter.</td></tr>
<tr><td><b>SINR</b></td><td>Verhouding tussen bruikbaar signaal en storing. Hoe hoger, hoe beter.</td></tr>
</table>

<table>
<tr><th colspan="5" style="background:#343a40;color:white;font-size:18px;">Referentiewaarden</th></tr>
<tr>
<th>Waarde</th>
<th style="background:#28a745;color:white">Uitstekend</th>
<th style="background:#8bc34a;color:white">Goed</th>
<th style="background:#ff9800;color:white">Matig</th>
<th style="background:#dc3545;color:white">Slecht</th>
</tr>
<tr><td><b>RSSI</b></td><td>&gt; -65</td><td>-65 t/m -75</td><td>-75 t/m -85</td><td>&lt; -85</td></tr>
<tr><td><b>RSRP</b></td><td>&gt; -90</td><td>-90 t/m -100</td><td>-100 t/m -110</td><td>&lt; -110</td></tr>
<tr><td><b>RSRQ</b></td><td>&gt; -10</td><td>-10 t/m -14</td><td>-15 t/m -20</td><td>&lt; -20</td></tr>
<tr><td><b>SINR</b></td><td>&gt; 20</td><td>13 t/m 20</td><td>0 t/m 13</td><td>&lt; 0</td></tr>
</table>

<table>
<tr><th style="background:#495057;color:white;font-size:18px;">Eindbeoordeling</th></tr>
<tr><td>
HTML

if [ "$OPERATOR" = "Not available" ] && [ "$TECH" = "Not available" ]; then
    echo "<span style='color:#6c757d'><b>GEEN LTE DATA BESCHIKBAAR</b></span><br><br>"
    echo "De LTE cache bevat nog geen bruikbare modemdata.<br>"
    echo "<br><b>Advies:</b> Controleer of <code>/usr/local/matrix/lte_info_cache.sh</code> als root draait via cron."
elif [ "$SINR_SCORE" -ge 2 ]; then
    echo "<span style='color:green'><b>UITSTEKEND / GOED</b></span><br><br>"
    echo "Signaalkwaliteit is goed.<br>Geen directe actie benodigd."
elif [ "$SINR_SCORE" -eq 1 ]; then
    echo "<span style='color:orange'><b>MATIG</b></span><br><br>"
    echo "Verbinding werkt, maar betere antenneplaatsing kan prestaties verbeteren.<br>"
    echo "<br><b>Advies:</b> Controleer de positie van de router of gebruik een externe antenne."
else
    echo "<span style='color:red'><b>SLECHT</b></span><br><br>"
    echo "Hoge kans op lage snelheden en instabiele verbinding.<br>"
    echo "<br><b>Advies:</b> Controleer locatie, bekabeling en antennes."
fi

cat <<HTML
</td></tr>
</table>

<br>
<button onclick="window.location='/index.html'">Terug naar Matrix Toolkit</button>
</div>
</body>
</html>
HTML

exit 0
