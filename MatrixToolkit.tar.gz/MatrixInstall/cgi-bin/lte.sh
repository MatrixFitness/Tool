#!/bin/sh

echo "Content-Type: text/html"
echo ""

OPERATOR=$(gsmctl -o 2>/dev/null)
TECH=$(gsmctl -t 2>/dev/null)

RSSI=$(gsmctl -q 2>/dev/null | grep RSSI | awk '{print $2}')
RSRP=$(gsmctl -q 2>/dev/null | grep RSRP | awk '{print $2}')
RSRQ=$(gsmctl -q 2>/dev/null | grep RSRQ | awk '{print $2}')
SINR=$(gsmctl -q 2>/dev/null | grep SINR | awk '{print $2}')

# RSSI

RSSI_STATUS="Slecht"
RSSI_COLOR="#dc3545"

[ "$RSSI" -ge -85 ] && RSSI_STATUS="Matig" && RSSI_COLOR="#ff9800"
[ "$RSSI" -ge -75 ] && RSSI_STATUS="Goed" && RSSI_COLOR="#8bc34a"
[ "$RSSI" -ge -65 ] && RSSI_STATUS="Uitstekend" && RSSI_COLOR="#28a745"

# RSRP

RSRP_STATUS="Slecht"
RSRP_COLOR="#dc3545"

[ "$RSRP" -ge -110 ] && RSRP_STATUS="Matig" && RSRP_COLOR="#ff9800"
[ "$RSRP" -ge -100 ] && RSRP_STATUS="Goed" && RSRP_COLOR="#8bc34a"
[ "$RSRP" -ge -90 ] && RSRP_STATUS="Uitstekend" && RSRP_COLOR="#28a745"

# RSRQ

RSRQ_STATUS="Slecht"
RSRQ_COLOR="#dc3545"

[ "$RSRQ" -ge -20 ] && RSRQ_STATUS="Matig" && RSRQ_COLOR="#ff9800"
[ "$RSRQ" -ge -14 ] && RSRQ_STATUS="Goed" && RSRQ_COLOR="#8bc34a"
[ "$RSRQ" -ge -10 ] && RSRQ_STATUS="Uitstekend" && RSRQ_COLOR="#28a745"

# SINR

SINR_STATUS="Slecht"
SINR_COLOR="#dc3545"

[ "$SINR" -ge 0 ] && SINR_STATUS="Matig" && SINR_COLOR="#ff9800"
[ "$SINR" -ge 13 ] && SINR_STATUS="Goed" && SINR_COLOR="#8bc34a"
[ "$SINR" -ge 20 ] && SINR_STATUS="Uitstekend" && SINR_COLOR="#28a745"

echo "<html>"
echo "<head>"
echo "<title>LTE Analyse</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;}"
echo "table{border-collapse:collapse;width:900px;}"
echo "th,td{border:1px solid #ccc;padding:8px;text-align:left;}"
echo "th{background:#f2f2f2;}"
echo "h2{margin-top:30px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h1>LTE Analyse</h1>"

# NETWERK

echo "<table>"
echo "<tr><th colspan='2' style='background:#007bff;color:white;font-size:18px;'>Netwerk</th></tr>"
echo "<tr><td>Operator</td><td>$OPERATOR</td></tr>"
echo "<tr><td>Technologie</td><td>$TECH</td></tr>"
echo "</table>"

echo "<br><br>"

# SIGNAAL ANALYSE

echo "<table>"
echo "<tr><th colspan='2' style='background:#6f42c1;color:white;font-size:18px;'>Signaal Analyse</th></tr>"

echo "<tr><td>RSSI</td><td style='background:$RSSI_COLOR;color:white'><b>$RSSI dBm ($RSSI_STATUS)</b></td></tr>"

echo "<tr><td>RSRP</td><td style='background:$RSRP_COLOR;color:white'><b>$RSRP dBm ($RSRP_STATUS)</b></td></tr>"

echo "<tr><td>RSRQ</td><td style='background:$RSRQ_COLOR;color:white'><b>$RSRQ dB ($RSRQ_STATUS)</b></td></tr>"

echo "<tr><td>SINR</td><td style='background:$SINR_COLOR;color:white'><b>$SINR dB ($SINR_STATUS)</b></td></tr>"

echo "</table>"

echo "<br><br>"

# UITLEG

echo "<table>"
echo "<tr><th colspan='2' style='background:#17a2b8;color:white;font-size:18px;'>Uitleg</th></tr>"

echo "<tr><td><b>RSSI</b></td><td>Algemene sterkte van het ontvangen radiosignaal.</td></tr>"

echo "<tr><td><b>RSRP</b></td><td>Werkelijke sterkte van het 4G/5G signaal. Belangrijkste waarde voor bereik.</td></tr>"

echo "<tr><td><b>RSRQ</b></td><td>Kwaliteit van het radiosignaal. Hoe minder negatief, hoe beter.</td></tr>"

echo "<tr><td><b>SINR</b></td><td>Verhouding tussen bruikbaar signaal en storing. Hoe hoger, hoe beter.</td></tr>"

echo "</table>"

echo "<br><br>"

# REFERENTIEWAARDEN

echo "<table>"

echo "<tr><th colspan='5' style='background:#343a40;color:white;font-size:18px;'>Referentiewaarden</th></tr>"

echo "<tr>"
echo "<th>Waarde</th>"
echo "<th style='background:#28a745;color:white'>Uitstekend</th>"
echo "<th style='background:#8bc34a;color:white'>Goed</th>"
echo "<th style='background:#ff9800;color:white'>Matig</th>"
echo "<th style='background:#dc3545;color:white'>Slecht</th>"
echo "</tr>"

echo "<tr><td><b>RSSI</b></td><td>> -65</td><td>-65 t/m -75</td><td>-75 t/m -85</td><td>< -85</td></tr>"

echo "<tr><td><b>RSRP</b></td><td>> -90</td><td>-90 t/m -100</td><td>-100 t/m -110</td><td>< -110</td></tr>"

echo "<tr><td><b>RSRQ</b></td><td>> -10</td><td>-10 t/m -14</td><td>-15 t/m -20</td><td>< -20</td></tr>"

echo "<tr><td><b>SINR</b></td><td>> 20</td><td>13 t/m 20</td><td>0 t/m 13</td><td>< 0</td></tr>"

echo "</table>"

echo "<br><br>"

# EINDOORDEEL

echo "<table>"
echo "<tr><th style='background:#495057;color:white;font-size:18px;'>Eindbeoordeling</th></tr>"
echo "<tr><td>"

if [ "$SINR" -ge 13 ]
then
echo "<span style='color:green'><b>UITSTEKEND</b></span><br><br>"
echo "Signaalkwaliteit is zeer goed.<br>"
echo "Geen actie benodigd."
elif [ "$SINR" -ge 0 ]
then
echo "<span style='color:orange'><b>GOED / MATIG</b></span><br><br>"
echo "Verbinding werkt, maar betere antenneplaatsing kan prestaties verbeteren.<br>"
echo "<br><b>Advies:</b> Controleer de positie van de router of gebruik een externe antenne."
else
echo "<span style='color:red'><b>SLECHT</b></span><br><br>"
echo "Hoge kans op lage snelheden en instabiele verbinding.<br>"
echo "<br><b>Advies:</b> Controleer locatie, bekabeling en antennes."
fi

echo "</td></tr>"
echo "</table>"

echo "<br>"
echo "<a href='/index.html'>Terug naar Matrix Toolkit</a>"

echo "</body>"
echo "</html>"
