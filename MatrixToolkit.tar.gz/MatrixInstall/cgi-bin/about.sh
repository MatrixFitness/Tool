#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION_FILE="/usr/local/matrix/version.txt"

get_value() {
    grep "^$1=" "$VERSION_FILE" 2>/dev/null | cut -d= -f2-
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
GITHUB=$(get_value GitHub)
MESSAGE=$(get_value Message)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="Unknown"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Unknown"
[ -z "$EMAIL" ] && EMAIL="Unknown"
[ -z "$GITHUB" ] && GITHUB="Unknown"
[ -z "$MESSAGE" ] && MESSAGE="No release notes available."

cat << EOF
<html>
<head>
<title>About Matrix Toolkit</title>

<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">

<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
    background: #f5f5f5;
    color: #333;
}

.card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    max-width: 900px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.12);
    margin-bottom: 20px;
}

h1 {
    margin-bottom: 5px;
}

.version {
    font-size: 30px;
    font-weight: bold;
    color: #007bff;
    margin-bottom: 5px;
}

.subtext {
    color: #666;
    margin-bottom: 20px;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th {
    background: #007bff;
    color: white;
    padding: 8px;
    text-align: left;
}

td {
    border: 1px solid #ddd;
    padding: 8px;
    vertical-align: top;
}

.release-notes {
    background: #f8f9fa;
    border-left: 5px solid #007bff;
    padding: 15px;
    margin-top: 10px;
    white-space: pre-wrap;
    word-wrap: break-word;
    line-height: 1.6;
}

button {
    margin-top: 10px;
    width: 220px;
    height: 50px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    border: 0;
    border-radius: 6px;
    background: #007bff;
    color: white;
    margin-right: 10px;
}
</style>

</head>

<body>

<div class="card">

<h1>Matrix Toolkit</h1>

<div class="version">Version $VERSION</div>

<div class="subtext">
Build $BUILD &bull; Release $RELEASE
</div>

<table>
<tr><th>Onderdeel</th><th>Waarde</th></tr>
<tr><td>Company</td><td>$COMPANY</td></tr>
<tr><td>Author</td><td>$AUTHOR</td></tr>
<tr><td>Email</td><td>$EMAIL</td></tr>
<tr><td>GitHub</td><td>$GITHUB</td></tr>
<tr><td>Changes</td><td>$CHANGES</td></tr>
</table>

</div>

<div class="card">

<h2>Release Notes</h2>

<div class="release-notes">
$MESSAGE
</div>

</div>

<button onclick="window.location='/admin/'">Back to Admin</button>
<button onclick="window.location='/'">Home</button>

</body>
</html>
EOF