#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep "^Version=" /usr/local/matrix/version.txt | cut -d= -f2)
BUILD=$(grep "^Build=" /usr/local/matrix/version.txt | cut -d= -f2)
RELEASE=$(grep "^Release=" /usr/local/matrix/version.txt | cut -d= -f2)
CHANGES=$(grep "^Changes=" /usr/local/matrix/version.txt | cut -d= -f2)

echo "<html>"
echo "<head><title>About Matrix Toolkit</title></head>"
echo "<body style='font-family:Arial;margin:20px;'>"

echo "<h1>About Matrix Toolkit</h1>"

echo "<table border='1' cellpadding='5'>"
echo "<tr><td><b>Version</b></td><td>$VERSION</td></tr>"
echo "<tr><td><b>Build</b></td><td>$BUILD</td></tr>"
echo "<tr><td><b>Release</b></td><td>$RELEASE</td></tr>"
echo "<tr><td><b>Changes</b></td><td>$CHANGES</td></tr>"
echo "</table>"

echo "<br>"
echo "<a href='/admin/'>Back to Admin</a>"

echo "</body>"
echo "</html>"