#!/bin/sh
# Matrix Toolkit WiFi library v64 - radio action profiles

MATRIX_DIR="/usr/local/matrix"
CONFIG="$MATRIX_DIR/matrix_wifi_profiles.conf"
DEFAULTS="$MATRIX_DIR/matrix_wifi_profiles.default"
PREVIOUS="$MATRIX_DIR/matrix_wifi_profiles.previous"
OLD_CONFIG="$MATRIX_DIR/config/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"
RADIO0="wireless.default_radio0"
RADIO1="wireless.default_radio1"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
url_decode(){ sed -e 's/+/ /g' -e 's/%0[Dd]//g' -e 's/%0[Aa]/ /g' -e 's/%3[Dd]/=/g' -e 's/%7[Bb]/{/g' -e 's/%7[Dd]/}/g' -e 's/%20/ /g' -e 's/%21/!/g' -e 's/%23/#/g' -e 's/%24/$/g' -e 's/%25/%/g' -e 's/%26/\&/g' -e 's/%28/(/g' -e 's/%29/)/g' -e 's/%2[Aa]/*/g' -e 's/%2[Bb]/+/g' -e 's/%2[Cc]/,/g' -e 's/%2[Dd]/-/g' -e 's/%2[Ee]/./g' -e 's/%2[Ff]/\//g' -e 's/%3[Aa]/:/g' -e 's/%3[Bb]/;/g' -e 's/%3[Ff]/?/g' -e 's/%40/@/g' -e 's/%5[Bb]/[/g' -e 's/%5[Dd]/]/g' -e 's/%5[Ee]/^/g' -e 's/%5[Ff]/_/g' -e 's/%7[Cc]/|/g' -e 's/%7[Ee]/~/g'; }
qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode; }
hostname_value(){ H="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$H" ] && H="$(hostname 2>/dev/null)"; [ -z "$H" ] && H="Matrix"; echo "$H"; }
resolve_ssid(){ RAW="$1"; HOST="$(hostname_value)"; printf '%s' "$RAW" | sed "s/{HOSTNAME}/$HOST/g"; }
normalize_action(){ A="$(printf '%s' "$1" | tr 'a-z' 'A-Z')"; case "$A" in KEEP|DISABLE|SET) echo "$A";; *) echo KEEP;; esac; }
profile_count(){ grep -o "^PROFILE[0-9][0-9]*_" "$CONFIG" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1; }
profile_value(){ IDX="$1"; KEY="$2"; grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-; }
backup_current(){ [ -f "$CONFIG" ] && cat "$CONFIG" > "$PREVIOUS" 2>/dev/null; [ -f "$CONFIG" ] && cat "$CONFIG" > "/tmp/matrix_wifi_profiles.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null; }

write_defaults(){
cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default
PROFILE1_R0_ACTION=SET
PROFILE1_R0_SSID={HOSTNAME}_2G
PROFILE1_R0_PASSWORD=matrixfitness
PROFILE1_R1_ACTION=SET
PROFILE1_R1_SSID={HOSTNAME}_5G
PROFILE1_R1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM 2.4 GHz
PROFILE2_R0_ACTION=SET
PROFILE2_R0_SSID=egym
PROFILE2_R0_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2
PROFILE2_R1_ACTION=KEEP
PROFILE2_R1_SSID=
PROFILE2_R1_PASSWORD=

PROFILE3_NAME=Customer WiFi
PROFILE3_R0_ACTION=SET
PROFILE3_R0_SSID=ClubWifi
PROFILE3_R0_PASSWORD=Welkom123
PROFILE3_R1_ACTION=SET
PROFILE3_R1_SSID=ClubWifi_5G
PROFILE3_R1_PASSWORD=Welkom123
DEFEOF
}

migrate_profiles_v64(){
    [ -f "$CONFIG" ] || return 0
    grep -q "^PROFILE[0-9][0-9]*_R0_ACTION=" "$CONFIG" 2>/dev/null && return 0
    TMP="/tmp/matrix_wifi_profiles_migrate_v64.$$"
    COUNT="$(profile_count)"; [ -z "$COUNT" ] && COUNT=0
    backup_current
    : > "$TMP"
    i=1
    while [ "$i" -le "$COUNT" ]; do
        NAME="$(profile_value "$i" NAME)"
        LOW_NAME="$(printf '%s' "$NAME" | tr 'A-Z' 'a-z')"
        # old single/dual fields
        MODE="$(printf '%s' "$(profile_value "$i" MODE)" | tr 'a-z' 'A-Z')"
        SSID="$(profile_value "$i" SSID)"
        PASS="$(profile_value "$i" PASSWORD)"
        BAND="$(printf '%s' "$(profile_value "$i" BAND)" | tr 'a-z' 'A-Z')"
        S2="$(profile_value "$i" 2G_SSID)"; P2="$(profile_value "$i" 2G_PASSWORD)"
        S5="$(profile_value "$i" 5G_SSID)"; P5="$(profile_value "$i" 5G_PASSWORD)"
        LOW_SSID="$(printf '%s' "$SSID $S2 $S5" | tr 'A-Z' 'a-z')"
        if [ "$MODE" = "DUAL" ]; then
            [ -z "$S2" ] && S2="{HOSTNAME}_2G"; [ -z "$P2" ] && P2="matrixfitness"
            [ -z "$S5" ] && S5="{HOSTNAME}_5G"; [ -z "$P5" ] && P5="matrixfitness"
            {
                echo "PROFILE${i}_NAME=${NAME:-Profile $i}"
                echo "PROFILE${i}_R0_ACTION=SET"
                echo "PROFILE${i}_R0_SSID=$S2"
                echo "PROFILE${i}_R0_PASSWORD=$P2"
                echo "PROFILE${i}_R1_ACTION=SET"
                echo "PROFILE${i}_R1_SSID=$S5"
                echo "PROFILE${i}_R1_PASSWORD=$P5"
                echo ""
            } >> "$TMP"
        elif echo "$LOW_NAME $LOW_SSID" | grep -q "egym"; then
            {
                echo "PROFILE${i}_NAME=${NAME:-EGYM 2.4 GHz}"
                echo "PROFILE${i}_R0_ACTION=SET"
                echo "PROFILE${i}_R0_SSID=${SSID:-egym}"
                echo "PROFILE${i}_R0_PASSWORD=${PASS:-9be5ff942822c22cdbe7010d7c1c18b2}"
                echo "PROFILE${i}_R1_ACTION=KEEP"
                echo "PROFILE${i}_R1_SSID="
                echo "PROFILE${i}_R1_PASSWORD="
                echo ""
            } >> "$TMP"
        elif [ "$i" = "1" ]; then
            {
                echo "PROFILE${i}_NAME=Matrix Default"
                echo "PROFILE${i}_R0_ACTION=SET"
                echo "PROFILE${i}_R0_SSID={HOSTNAME}_2G"
                echo "PROFILE${i}_R0_PASSWORD=${PASS:-matrixfitness}"
                echo "PROFILE${i}_R1_ACTION=SET"
                echo "PROFILE${i}_R1_SSID={HOSTNAME}_5G"
                echo "PROFILE${i}_R1_PASSWORD=${PASS:-matrixfitness}"
                echo ""
            } >> "$TMP"
        else
            # old single profile: keep other radio
            if [ "$BAND" = "2G" ] || echo "$SSID" | grep -qi "_2g"; then R0A=SET; R1A=KEEP; else R0A=KEEP; R1A=SET; fi
            {
                echo "PROFILE${i}_NAME=${NAME:-Profile $i}"
                echo "PROFILE${i}_R0_ACTION=$R0A"
                if [ "$R0A" = "SET" ]; then echo "PROFILE${i}_R0_SSID=${SSID:-NewSSID}"; echo "PROFILE${i}_R0_PASSWORD=${PASS:-password}"; else echo "PROFILE${i}_R0_SSID="; echo "PROFILE${i}_R0_PASSWORD="; fi
                echo "PROFILE${i}_R1_ACTION=$R1A"
                if [ "$R1A" = "SET" ]; then echo "PROFILE${i}_R1_SSID=${SSID:-NewSSID}"; echo "PROFILE${i}_R1_PASSWORD=${PASS:-password}"; else echo "PROFILE${i}_R1_SSID="; echo "PROFILE${i}_R1_PASSWORD="; fi
                echo ""
            } >> "$TMP"
        fi
        i=$((i+1))
    done
    cat "$TMP" > "$CONFIG"
    rm -f "$TMP" 2>/dev/null
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    echo "$(date '+%Y-%m-%d %H:%M:%S') Migrated WiFi profiles to v64 radio action structure" >> "$LOG"
}

ensure_config(){
    mkdir -p "$MATRIX_DIR" 2>/dev/null
    if [ ! -f "$CONFIG" ] && [ -f "$OLD_CONFIG" ]; then cp -f "$OLD_CONFIG" "$CONFIG" 2>/dev/null; fi
    if [ ! -f "$CONFIG" ]; then
        if [ -f "$DEFAULTS" ]; then cat "$DEFAULTS" > "$CONFIG" 2>/dev/null; else write_defaults "$CONFIG"; fi
    fi
    [ -f "$DEFAULTS" ] || write_defaults "$DEFAULTS"
    [ -f "$PREVIOUS" ] || cat "$CONFIG" > "$PREVIOUS" 2>/dev/null
    chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null
    migrate_profiles_v64
}

apply_radio_action(){
    RADIO="$1"; ACTION="$2"; SSID_RAW="$3"; PASS="$4"
    TARGET="$RADIO0"; [ "$RADIO" = "R1" ] && TARGET="$RADIO1"
    ACTION="$(normalize_action "$ACTION")"
    case "$ACTION" in
        KEEP) return 0 ;;
        DISABLE) uci set ${TARGET}.disabled='1' ;;
        SET)
            SSID="$(resolve_ssid "$SSID_RAW")"
            uci set ${TARGET}.ssid="$SSID"
            uci set ${TARGET}.key="$PASS"
            uci set ${TARGET}.encryption='psk2'
            uci set ${TARGET}.disabled='0'
            ;;
    esac
}

restore_matrix_default_wifi(){
    HOST="$(hostname_value)"
    uci set ${RADIO0}.ssid="${HOST}_2G"
    uci set ${RADIO0}.key="matrixfitness"
    uci set ${RADIO0}.encryption='psk2'
    uci set ${RADIO0}.disabled='0'
    uci set ${RADIO1}.ssid="${HOST}_5G"
    uci set ${RADIO1}.key="matrixfitness"
    uci set ${RADIO1}.encryption='psk2'
    uci set ${RADIO1}.disabled='0'
    uci commit wireless
    wifi reload >/dev/null 2>&1
    echo "$(date '+%Y-%m-%d %H:%M:%S') Restored Matrix Default WiFi new2=${HOST}_2G new5=${HOST}_5G" >> "$LOG"
}
