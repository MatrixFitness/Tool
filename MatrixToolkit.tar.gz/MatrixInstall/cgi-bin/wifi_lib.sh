#!/bin/sh
# Matrix WiFi Library v65.3

MATRIX_DIR="/usr/local/matrix"
SYSTEM_PROFILES="$MATRIX_DIR/matrix_wifi_system_profiles.conf"
SYSTEM_DEFAULTS="$MATRIX_DIR/matrix_wifi_system_profiles.default"
USER_PROFILES="$MATRIX_DIR/matrix_wifi_user_profiles.conf"
LEGACY_PROFILES="$MATRIX_DIR/matrix_wifi_profiles.conf"
PREVIOUS_PROFILES="$MATRIX_DIR/matrix_wifi_profiles.previous"
LOG="/tmp/matrix_wifi_manager.log"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }

url_decode(){
sed -e 's/+/ /g' -e 's/%0[Dd]//g' -e 's/%0[Aa]/ /g' -e 's/%3[Dd]/=/g' \
-e 's/%7[Bb]/{/g' -e 's/%7[Dd]/}/g' -e 's/%20/ /g' -e 's/%21/!/g' \
-e 's/%23/#/g' -e 's/%24/$/g' -e 's/%25/%/g' -e 's/%26/\&/g' \
-e 's/%28/(/g' -e 's/%29/)/g' -e 's/%2[Aa]/*/g' -e 's/%2[Bb]/+/g' \
-e 's/%2[Cc]/,/g' -e 's/%2[Dd]/-/g' -e 's/%2[Ee]/./g' -e 's/%2[Ff]/\//g' \
-e 's/%3[Aa]/:/g' -e 's/%3[Bb]/;/g' -e 's/%3[Ff]/?/g' -e 's/%40/@/g' \
-e 's/%5[Bb]/[/g' -e 's/%5[Dd]/]/g' -e 's/%5[Ee]/^/g' -e 's/%5[Ff]/_/g' \
-e 's/%7[Cc]/|/g' -e 's/%7[Ee]/~/g'
}

qs(){ FIELD="$1"; printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode; }

write_system_defaults(){
cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default
PROFILE1_LOCKED=1
PROFILE1_R0_ACTION=SET
PROFILE1_R0_SSID={HOSTNAME}_2G
PROFILE1_R0_PASSWORD=matrixfitness
PROFILE1_R1_ACTION=SET
PROFILE1_R1_SSID={HOSTNAME}_5G
PROFILE1_R1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Only
PROFILE2_LOCKED=1
PROFILE2_R0_ACTION=SET
PROFILE2_R0_SSID=egym
PROFILE2_R0_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2
PROFILE2_R1_ACTION=KEEP
PROFILE2_R1_SSID=
PROFILE2_R1_PASSWORD=

PROFILE3_NAME=Matrix + EGYM
PROFILE3_LOCKED=1
PROFILE3_R0_ACTION=SET
PROFILE3_R0_SSID=egym
PROFILE3_R0_PASSWORD=9be5ff942822c22cdbe7010d7c1c18b2
PROFILE3_R1_ACTION=SET
PROFILE3_R1_SSID={HOSTNAME}_5G
PROFILE3_R1_PASSWORD=matrixfitness
DEFEOF
}

ensure_wifi_files(){
    mkdir -p "$MATRIX_DIR" 2>/dev/null

    if [ ! -f "$SYSTEM_DEFAULTS" ]; then
        write_system_defaults "$SYSTEM_DEFAULTS"
    fi

    # System profiles are managed by install/update and may be recreated safely.
    if [ ! -f "$SYSTEM_PROFILES" ]; then
        cp -f "$SYSTEM_DEFAULTS" "$SYSTEM_PROFILES" 2>/dev/null || write_system_defaults "$SYSTEM_PROFILES"
    fi

    # User profiles are router-local and must not be overwritten.
    if [ ! -f "$USER_PROFILES" ]; then
        : > "$USER_PROFILES"
        chmod 666 "$USER_PROFILES" 2>/dev/null
    fi

    # Legacy migration only once, only user/custom profiles after system defaults.
    if [ -f "$LEGACY_PROFILES" ] && ! grep -q "MigratedToV65=1" "$USER_PROFILES" 2>/dev/null; then
        migrate_legacy_to_user_profiles
        echo "# MigratedToV65=1" >> "$USER_PROFILES"
    fi

    chmod 666 "$SYSTEM_PROFILES" "$SYSTEM_DEFAULTS" "$USER_PROFILES" 2>/dev/null
}

hostname_value(){
    H="$(uci get system.@system[0].hostname 2>/dev/null)"
    [ -z "$H" ] && H="$(hostname 2>/dev/null)"
    [ -z "$H" ] && H="Matrix"
    echo "$H"
}

resolve_ssid(){
    RAW="$1"
    HOST="$(hostname_value)"
    printf '%s' "$RAW" | sed "s/{HOSTNAME}/$HOST/g"
}

normalize_action(){
    A="$(printf '%s' "$1" | tr 'a-z' 'A-Z')"
    case "$A" in SET|DISABLE|KEEP) echo "$A";; *) echo KEEP;; esac
}

profile_count_file(){
    FILE="$1"
    grep -o "^PROFILE[0-9][0-9]*_" "$FILE" 2>/dev/null | sed 's/^PROFILE//;s/_$//' | sort -n | tail -n 1
}

profile_value_file(){
    FILE="$1"; IDX="$2"; KEY="$3"
    grep "^PROFILE${IDX}_${KEY}=" "$FILE" 2>/dev/null | head -n1 | cut -d= -f2-
}

user_profile_next(){
    COUNT="$(profile_count_file "$USER_PROFILES")"
    [ -z "$COUNT" ] && COUNT=0
    echo $((COUNT+1))
}

backup_user_profiles(){
    cp -f "$USER_PROFILES" "$MATRIX_DIR/matrix_wifi_user_profiles.previous" 2>/dev/null
    cp -f "$USER_PROFILES" "$MATRIX_DIR/matrix_wifi_user_profiles.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null
}

profile_label_to_file(){
    TYPE="$1"
    case "$TYPE" in
        system) echo "$SYSTEM_PROFILES" ;;
        user) echo "$USER_PROFILES" ;;
        *) echo "" ;;
    esac
}

profile_apply(){
    TYPE="$1"; IDX="$2"
    FILE="$(profile_label_to_file "$TYPE")"
    [ -f "$FILE" ] || return 1

    NAME="$(profile_value_file "$FILE" "$IDX" NAME)"
    [ -z "$NAME" ] && return 1

    R0A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R0_ACTION)")"
    R1A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R1_ACTION)")"

    R0S="$(resolve_ssid "$(profile_value_file "$FILE" "$IDX" R0_SSID)")"
    R0P="$(profile_value_file "$FILE" "$IDX" R0_PASSWORD)"
    R1S="$(resolve_ssid "$(profile_value_file "$FILE" "$IDX" R1_SSID)")"
    R1P="$(profile_value_file "$FILE" "$IDX" R1_PASSWORD)"

    case "$R0A" in
        SET)
            uci set wireless.default_radio0.ssid="$R0S"
            uci set wireless.default_radio0.key="$R0P"
            uci set wireless.default_radio0.encryption='psk2'
            uci set wireless.default_radio0.disabled='0'
            ;;
        DISABLE)
            uci set wireless.default_radio0.disabled='1'
            ;;
    esac

    case "$R1A" in
        SET)
            uci set wireless.default_radio1.ssid="$R1S"
            uci set wireless.default_radio1.key="$R1P"
            uci set wireless.default_radio1.encryption='psk2'
            uci set wireless.default_radio1.disabled='0'
            ;;
        DISABLE)
            uci set wireless.default_radio1.disabled='1'
            ;;
    esac

    uci commit wireless
    wifi reload >/dev/null 2>&1
    sleep 2

    echo "$(date '+%Y-%m-%d %H:%M:%S') Applied $TYPE profile $IDX ($NAME) r0=$R0A/$R0S r1=$R1A/$R1S" >> "$LOG"
    return 0
}

restore_matrix_default_wifi(){
    HOST="$(hostname_value)"
    SSID_2G="${HOST}_2G"
    SSID_5G="${HOST}_5G"
    PASS="matrixfitness"

    uci set wireless.default_radio0.ssid="$SSID_2G"
    uci set wireless.default_radio0.key="$PASS"
    uci set wireless.default_radio0.encryption='psk2'
    uci set wireless.default_radio0.disabled='0'

    uci set wireless.default_radio1.ssid="$SSID_5G"
    uci set wireless.default_radio1.key="$PASS"
    uci set wireless.default_radio1.encryption='psk2'
    uci set wireless.default_radio1.disabled='0'

    uci commit wireless
    wifi reload >/dev/null 2>&1
    echo "$(date '+%Y-%m-%d %H:%M:%S') Emergency restored Matrix Default WiFi new2=$SSID_2G new5=$SSID_5G" >> "$LOG"
}

migrate_legacy_to_user_profiles(){
    [ -f "$LEGACY_PROFILES" ] || return 0
    LC="$(profile_count_file "$LEGACY_PROFILES")"
    [ -z "$LC" ] && LC=0

    # Only migrate profiles after first 3 to avoid duplicating system profiles.
    i=4
    while [ "$i" -le "$LC" ]; do
        NAME="$(profile_value_file "$LEGACY_PROFILES" "$i" NAME)"
        [ -z "$NAME" ] && NAME="Legacy Profile $i"
        NEW="$(user_profile_next)"
        {
            echo ""
            echo "PROFILE${NEW}_NAME=$NAME"
            echo "PROFILE${NEW}_LOCKED=0"
            echo "PROFILE${NEW}_R0_ACTION=KEEP"
            echo "PROFILE${NEW}_R0_SSID="
            echo "PROFILE${NEW}_R0_PASSWORD="
            echo "PROFILE${NEW}_R1_ACTION=SET"
            echo "PROFILE${NEW}_R1_SSID=$(profile_value_file "$LEGACY_PROFILES" "$i" SSID)"
            echo "PROFILE${NEW}_R1_PASSWORD=$(profile_value_file "$LEGACY_PROFILES" "$i" PASSWORD)"
        } >> "$USER_PROFILES"
        i=$((i+1))
    done
}

radio_summary(){
    FILE="$1"; IDX="$2"; R="$3"
    ACTION="$(normalize_action "$(profile_value_file "$FILE" "$IDX" ${R}_ACTION)")"
    SSID="$(profile_value_file "$FILE" "$IDX" ${R}_SSID)"
    PASS="$(profile_value_file "$FILE" "$IDX" ${R}_PASSWORD)"
    RESOLVED="$(resolve_ssid "$SSID")"

    E_RESOLVED="$(html_escape "$RESOLVED")"
    E_PASS="$(html_escape "$PASS")"

    case "$ACTION" in
        SET)
            echo "<div><b>SET</b></div><div>SSID: <b>$E_RESOLVED</b></div><div>Password: <span id=\"pw_${IDX}_${R}_$(basename "$FILE" | tr '.-' '__')\">********</span> <button class=\"mini\" onclick=\"togglePassword('pw_${IDX}_${R}_$(basename "$FILE" | tr '.-' '__')','$E_PASS');return false;\">Show/Hide</button></div>"
            ;;
        DISABLE)
            echo "<span class=\"err\"><b>DISABLE</b></span>"
            ;;
        *)
            echo "<span class=\"muted\"><b>KEEP CURRENT</b></span>"
            ;;
    esac
}

profile_result_status(){
    FILE="$1"; IDX="$2"
    CUR0="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
    CUR1="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
    CUR0P="$(uci get wireless.default_radio0.key 2>/dev/null)"
    CUR1P="$(uci get wireless.default_radio1.key 2>/dev/null)"
    DIS0="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
    DIS1="$(uci get wireless.default_radio1.disabled 2>/dev/null)"
    [ -z "$DIS0" ] && DIS0="0"
    [ -z "$DIS1" ] && DIS1="0"

    R0A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R0_ACTION)")"
    R1A="$(normalize_action "$(profile_value_file "$FILE" "$IDX" R1_ACTION)")"
    R0S="$(resolve_ssid "$(profile_value_file "$FILE" "$IDX" R0_SSID)")"
    R1S="$(resolve_ssid "$(profile_value_file "$FILE" "$IDX" R1_SSID)")"
    R0P="$(profile_value_file "$FILE" "$IDX" R0_PASSWORD)"
    R1P="$(profile_value_file "$FILE" "$IDX" R1_PASSWORD)"

    # Same Result means applying the profile would not change the current router state.
    SAME=1

    if [ "$R0A" = "SET" ]; then
        [ "$CUR0" != "$R0S" ] && SAME=0
        [ "$CUR0P" != "$R0P" ] && SAME=0
        [ "$DIS0" = "1" ] && SAME=0
    fi
    if [ "$R1A" = "SET" ]; then
        [ "$CUR1" != "$R1S" ] && SAME=0
        [ "$CUR1P" != "$R1P" ] && SAME=0
        [ "$DIS1" = "1" ] && SAME=0
    fi
    if [ "$R0A" = "DISABLE" ] && [ "$DIS0" != "1" ]; then SAME=0; fi
    if [ "$R1A" = "DISABLE" ] && [ "$DIS1" != "1" ]; then SAME=0; fi
    # KEEP always produces no change on that radio.

    if [ "$SAME" != "1" ]; then
        echo "<span class=\"muted\">Available</span>"
        return
    fi

    # Exact Match is stricter. It should only apply when the profile definition is
    # the clearest description of the current router state.
    # SET must match current SSID/password/enabled. DISABLE must match disabled.
    # KEEP can be exact only when the other radio is SET/DISABLE and this profile
    # was the last applied profile according to the log.
    NAME="$(profile_value_file "$FILE" "$IDX" NAME)"
    LAST="$(tail -n 1 "$LOG" 2>/dev/null)"

    if echo "$LAST" | grep -q "Applied .* profile $IDX ($NAME)"; then
        echo "<span class=\"active\">Exact Match</span>"
    else
        echo "<span class=\"warn\">Same Result</span>"
    fi
}

profile_status(){
    profile_result_status "$1" "$2"
}

radio_change_summary(){
    FILE="$1"; IDX="$2"; R="$3"; LABEL="$4"
    ACTION="$(normalize_action "$(profile_value_file "$FILE" "$IDX" ${R}_ACTION)")"

    if [ "$R" = "R0" ]; then
        CUR_SSID="$(uci get wireless.default_radio0.ssid 2>/dev/null)"
        CUR_PASS="$(uci get wireless.default_radio0.key 2>/dev/null)"
        CUR_DIS="$(uci get wireless.default_radio0.disabled 2>/dev/null)"
    else
        CUR_SSID="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
        CUR_PASS="$(uci get wireless.default_radio1.key 2>/dev/null)"
        CUR_DIS="$(uci get wireless.default_radio1.disabled 2>/dev/null)"
    fi
    [ -z "$CUR_DIS" ] && CUR_DIS="0"

    NEW_SSID="$(resolve_ssid "$(profile_value_file "$FILE" "$IDX" ${R}_SSID)")"
    NEW_PASS="$(profile_value_file "$FILE" "$IDX" ${R}_PASSWORD)"

    E_LABEL="$(html_escape "$LABEL")"
    E_CUR_SSID="$(html_escape "$CUR_SSID")"
    E_NEW_SSID="$(html_escape "$NEW_SSID")"

    case "$ACTION" in
        KEEP)
            echo "<tr><td><b>$E_LABEL</b></td><td colspan=\"2\"><span class=\"muted\">No change - keep current router value</span></td></tr>"
            ;;
        DISABLE)
            if [ "$CUR_DIS" = "1" ]; then
                echo "<tr><td><b>$E_LABEL</b></td><td colspan=\"2\"><span class=\"muted\">No change - already disabled</span></td></tr>"
            else
                echo "<tr><td><b>$E_LABEL</b></td><td>$E_CUR_SSID</td><td><span class=\"err\">Disabled</span></td></tr>"
            fi
            ;;
        SET)
            if [ "$CUR_DIS" = "0" ] && [ "$CUR_SSID" = "$NEW_SSID" ] && [ "$CUR_PASS" = "$NEW_PASS" ]; then
                echo "<tr><td><b>$E_LABEL</b></td><td colspan=\"2\"><span class=\"muted\">No change - already $E_NEW_SSID</span></td></tr>"
            else
                echo "<tr><td><b>$E_LABEL</b></td><td>$E_CUR_SSID</td><td>$E_NEW_SSID</td></tr>"
            fi
            ;;
    esac
}

profile_changes_after_apply(){
    FILE="$1"; IDX="$2"
    cat <<EOF
<div class="changes-box">
  <div class="changes-title">Changes after Apply</div>
  <table class="mini-table">
    <tr><th>Radio</th><th>Current</th><th>After Apply</th></tr>
EOF
    radio_change_summary "$FILE" "$IDX" R0 "Radio 0 / 2.4 GHz"
    radio_change_summary "$FILE" "$IDX" R1 "Radio 1 / 5 GHz"
    cat <<EOF
  </table>
</div>
EOF
}
