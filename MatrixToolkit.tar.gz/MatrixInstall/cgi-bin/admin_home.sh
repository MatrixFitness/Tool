#!/bin/sh

# Matrix Toolkit Admin Home
# Runs on Admin web server port 8081

printf "Content-Type: text/html\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

VERSION_FILE="/usr/local/matrix/version.txt"
BACKUP_DIR="/usr/local/mnt/sda1/Backup"
REPO_URL="https://github.com/MatrixFitness/Tool"

get_value() {
    KEY="$1"
    grep "^$KEY=" "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-
}

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
CHANGES=$(get_value Changes)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$CHANGES" ] && CHANGES="None"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Rob Bosman"
[ -z "$EMAIL" ] && EMAIL="rob.bosman@matrixfitness.nl"

ZT_IP=$(ip addr 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)
if [ -z "$ZT_IP" ]; then
    ZT_IP=$(ip -4 addr 2>/dev/null | awk '/inet / && /zt/ {print $2}' | cut -d/ -f1 | head -1)
fi
if [ -z "$ZT_IP" ] && [ -x /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh ]; then
    /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh >/dev/null 2>&1
    ZT_IP=$(grep '^IP=' /tmp/matrix_zerotier_status.cache 2>/dev/null | cut -d= -f2- | head -1)
fi
[ -z "$ZT_IP" ] && ZT_IP="Not available"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Matrix Toolkit Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
:root{--matrix:#005a9c;--bg:#f4f6f8;--card:#fff;--line:#d9e1e8;--text:#222;--muted:#5f6b76;--green:#28a745;--blue:#007bff;--purple:#6f42c1;--orange:#fd7e14;--red:#dc3545;--grey:#666;}
*{box-sizing:border-box;}body{font-family:Arial,Helvetica,sans-serif;margin:0;background:var(--bg);color:var(--text);}.page{max-width:1240px;margin:0 auto;padding:18px;}.hero{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px;margin-bottom:14px;box-shadow:0 2px 8px rgba(0,0,0,.06);display:flex;align-items:center;justify-content:space-between;gap:14px;}h1{margin:0;color:var(--matrix);font-size:28px;line-height:1.1;}.subtitle{font-size:13px;color:var(--muted);margin-top:6px;line-height:1.45;}.logout{min-width:120px;height:44px;border:0;border-radius:10px;background:var(--grey);color:white;font-weight:bold;font-size:15px;cursor:pointer;}.logout:hover{background:#555;}.card-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;align-items:stretch;}.tool-card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;box-shadow:0 2px 8px rgba(0,0,0,.05);border-top:6px solid var(--blue);}.tool-card.toolkit{border-top-color:var(--green);}.tool-card.update{border-top-color:var(--blue);}.tool-card.remote{border-top-color:var(--purple);}.tool-card.admin{border-top-color:var(--orange);}.card-head{display:flex;gap:10px;align-items:flex-start;margin-bottom:12px;}.icon{font-size:24px;line-height:1;width:30px;text-align:center;}.card-title{font-size:18px;font-weight:bold;color:#172331;margin:0;}.card-note{font-size:12px;color:var(--muted);margin-top:3px;line-height:1.35;}.action{display:block;width:100%;min-height:40px;margin:8px 0 0 0;padding:11px 10px;border:0;border-radius:9px;color:white;text-align:left;font-weight:bold;font-size:14px;text-decoration:none;cursor:pointer;line-height:1.2;}.action span{display:block;font-size:11px;font-weight:normal;opacity:.92;margin-top:3px;}.green{background:var(--green);}.blue{background:var(--blue);}.purple{background:var(--purple);}.orange{background:var(--orange);}.grey{background:var(--grey);}.red{background:var(--red);}.green:hover{background:#218838;}.blue:hover{background:#0069d9;}.purple:hover{background:#5b34a0;}.orange:hover{background:#e46c0a;}.grey:hover{background:#555;}.red:hover{background:#c82333;}.info-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-top:14px;}.info-card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:15px;line-height:1.55;color:var(--muted);font-size:13px;box-shadow:0 2px 8px rgba(0,0,0,.04);}.info-card h2{margin:0 0 9px 0;color:var(--matrix);font-size:17px;}a{color:var(--matrix);word-break:break-all;}.small{font-size:12px;color:var(--muted);margin-top:8px;}@media(max-width:1150px){.card-grid,.info-grid{grid-template-columns:repeat(2,minmax(0,1fr));}.page{max-width:820px;}}@media(max-width:640px){.page{padding:12px;}.hero{display:block;text-align:center;padding:16px;}h1{font-size:24px;}.logout{width:100%;margin-top:12px;}.card-grid,.info-grid{grid-template-columns:1fr;}.action{text-align:center;min-height:44px;font-size:14px;}.card-head{justify-content:center;text-align:center;}.icon{width:auto;}.subtitle{text-align:center;}}
</style>
<script>
function openToolkit(){ window.location = window.location.protocol + '//' + window.location.hostname + ':8080'; }
</script>
</head>
<body>
<div class="page">
    <div class="hero">
        <div>
            <h1>Matrix Toolkit Admin</h1>
            <div class="subtitle"><b>$(html_escape "$COMPANY")</b> | Created by $(html_escape "$AUTHOR") | <a href="mailto:$(html_escape "$EMAIL")">$(html_escape "$EMAIL")</a></div>
        </div>
        <button class="logout" onclick="window.location='/cgi-bin/admin_logout.sh'">Logout</button>
    </div>

    <div class="card-grid">
        <div class="tool-card toolkit">
            <div class="card-head"><div class="icon">✓</div><div><div class="card-title">Toolkit</div><div class="card-note">Openen en controleren.</div></div></div>
            <a class="action green" href="#" onclick="openToolkit(); return false;">Open Toolkit<span>Poort 8080</span></a>
            <a class="action green" href="/cgi-bin/about.sh">Toolkit Information<span>Versie en systeeminfo</span></a>
            <a class="action green" href="/cgi-bin/matrix_health.sh">Matrix Health Check<span>Admin health status</span></a>
        </div>
        <div class="tool-card update">
            <div class="card-head"><div class="icon">↻</div><div><div class="card-title">Update & Install</div><div class="card-note">Toolkit bijwerken of herstellen.</div></div></div>
            <a class="action blue" href="/cgi-bin/update_github_start.sh">Update from GitHub<span>Laatste release ophalen</span></a>
            <a class="action blue" href="/cgi-bin/install_update_worker.sh">Toolkit Install from USB<span>Lokale installatie uitvoeren</span></a>
        </div>
        <div class="tool-card remote">
            <div class="card-head"><div class="icon">◇</div><div><div class="card-title">ZeroTier</div><div class="card-note">Remote access en repair.</div></div></div>
            <a class="action purple" href="/cgi-bin/zerotier_manager.sh">ZeroTier Manager<span>Status, IP en repair</span></a>
            <a class="action purple" href="/cgi-bin/zerotier_setup.sh">ZeroTier Setup<span>Legacy setup/start</span></a>
        </div>
        <div class="tool-card admin">
            <div class="card-head"><div class="icon">⚙</div><div><div class="card-title">Backup & Security</div><div class="card-note">Beheer en beveiliging.</div></div></div>
            <a class="action orange" href="/cgi-bin/router_backup.sh">Router Config Backup<span>Routerconfiguratie opslaan</span></a>
            <a class="action orange" href="/cgi-bin/toolkit_backup.sh">Toolkit Backup<span>Toolkit bestanden opslaan</span></a>
            <a class="action grey" href="/cgi-bin/admin_change_password.sh">Change Admin Password<span>Admin wachtwoord wijzigen</span></a>
        </div>
    </div>

    <div class="info-grid">
        <div class="info-card"><h2>Toolkit Version</h2><b>Matrix Toolkit v$(html_escape "$VERSION")</b><br>Build $(html_escape "$BUILD")<br>Release $(html_escape "$RELEASE")<br>Changes: $(html_escape "$CHANGES")</div>
        <div class="info-card"><h2>Backup Location</h2>Backups are saved on the USB stick connected to the router.<br><br><b>Backup</b><div class="small">Router path: $(html_escape "$BACKUP_DIR")</div></div>
        <div class="info-card"><h2>ZeroTier Remote Access</h2>
HTML

if [ "$ZT_IP" = "Not available" ]; then
cat <<HTML
            ZeroTier IP: <b>Not available</b><br><span class="small">Check ZeroTier authorization and network status.</span>
HTML
else
cat <<HTML
            Toolkit: <a href="http://$ZT_IP:8080">http://$ZT_IP:8080</a><br>Admin: <a href="http://$ZT_IP:8081/cgi-bin/admin_login.sh">http://$ZT_IP:8081/cgi-bin/admin_login.sh</a>
HTML
fi

cat <<HTML
        </div>
        <div class="info-card"><h2>Repository</h2><a href="$REPO_URL">$REPO_URL</a></div>
    </div>
</div>
</body>
</html>
HTML
