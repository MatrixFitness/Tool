#!/bin/sh

# Matrix Toolkit Admin Home
# Runs on Admin web server port 8081

printf "Content-Type: text/html\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

VERSION_FILE="/usr/local/matrix/version.txt"
BACKUP_DIR="/usr/local/mnt/sda1/Backup"
REPO_URL="https://github.com/MatrixFitness/Tool"

get_value() {
    KEY="$1"
    grep "^$KEY=" "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-
}

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
COMPANY=$(get_value Company)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Rob Bosman"
[ -z "$EMAIL" ] && EMAIL="rob.bosman@matrixfitness.nl"

# First read the real ZeroTier IP from the router interfaces.
# This matches the method that already works on the Toolkit page.
ZT_IP=$(ip addr 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1)

# Fallback: some systems show the interface name on the same line.
if [ -z "$ZT_IP" ]; then
    ZT_IP=$(ip -4 addr 2>/dev/null | awk '/inet / && /zt/ {print $2}' | cut -d/ -f1 | head -1)
fi

# Fallback: use ZeroTier CLI when it returns a managed IP.
if [ -z "$ZT_IP" ] && command -v zerotier-cli >/dev/null 2>&1; then
    ZT_IP=$(zerotier-cli listnetworks 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\//){split($i,a,"/"); print a[1]; exit}}')
fi

[ -z "$ZT_IP" ] && ZT_IP="Not available"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Matrix Toolkit Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
body{
    font-family:Arial,Helvetica,sans-serif;
    margin:20px;
    background:#f5f5f5;
    color:#222;
}
.page{
    max-width:1040px;
    margin:0 auto;
    background:white;
    border:1px solid #ccc;
    border-radius:10px;
    padding:22px;
    box-shadow:0 2px 8px rgba(0,0,0,.08);
}
h1{
    margin:0;
    color:#005a9c;
    font-size:28px;
}
.header-title{
    margin:0 auto 14px auto;
    width:992px;
    max-width:100%;
}
.topbar{
    display:flex;
    justify-content:space-between;
    align-items:stretch;
    gap:16px;
    margin:0 auto 20px auto;
    width:992px;
    max-width:100%;
}
.creator-card{
    flex:1;
    background:#fafafa;
    border:1px solid #ddd;
    border-radius:8px;
    padding:0 18px;
    box-sizing:border-box;
    text-align:left;
    color:#555;
    font-size:13px;
    height:50px;
    display:flex;
    align-items:center;
}
.logout-small{
    width:150px;
    min-width:150px;
    height:50px;
    min-height:50px;
    margin:0;
    font-size:16px;
}
.dashboard{
    display:flex;
    gap:16px;
    align-items:flex-start;
    justify-content:space-between;
    margin:10px auto 0 auto;
    width:992px;
    max-width:100%;
}
.column{
    width:320px;
}
button{
    width:320px;
    height:48px;
    margin-bottom:9px;
    font-size:15px;
    font-weight:bold;
    cursor:pointer;
    border:none;
    border-radius:6px;
    color:white;
}
.green{background:#28a745;}
.green:hover{background:#218838;}
.blue{background:#007bff;}
.blue:hover{background:#0069d9;}
.orange{background:#fd7e14;}
.orange:hover{background:#e46c0a;}
.grey{background:#666;}
.grey:hover{background:#555;}
.info-grid{
    display:grid;
    grid-template-columns:repeat(2, 1fr);
    gap:16px;
    margin:24px auto 0 auto;
    width:992px;
    max-width:100%;
}
.card{
    background:#fafafa;
    border:1px solid #ddd;
    border-radius:8px;
    padding:15px;
    line-height:1.55;
    color:#555;
    font-size:13px;
    box-sizing:border-box;
}
.card h2{
    margin:0 0 9px 0;
    color:#005a9c;
    font-size:18px;
}
.small{
    color:#555;
    font-size:13px;
}
a{
    color:#005a9c;
    word-break:break-all;
}
@media(max-width:900px){
    body{margin:12px;}
    .page{padding:16px;}
    .header-title,
    .topbar,
    .dashboard,
    .info-grid{
        width:100%;
        max-width:420px;
        box-sizing:border-box;
    }
    .header-title{
        text-align:center;
    }
    .topbar{
        flex-direction:column;
        align-items:center;
        gap:10px;
        margin-bottom:16px;
    }
    .creator-card{
        width:100%;
        max-width:420px;
        text-align:center;
        min-height:0;
    }
    .logout-small{
        width:100%;
        max-width:420px;
        min-width:0;
        min-height:46px;
        height:46px;
    }
    .dashboard{
        flex-direction:column;
        align-items:center;
        gap:0;
    }
    .column{
        width:100%;
        max-width:420px;
        text-align:center;
    }
    button{
        width:100%;
        max-width:420px;
        height:46px;
        font-size:14px;
        margin-left:auto;
        margin-right:auto;
        margin-bottom:8px;
        display:block;
    }
    .info-grid{
        grid-template-columns:1fr;
    }
}
</style>
<script>
function openToolkit(){
    window.location = window.location.protocol + '//' + window.location.hostname + ':8080';
}
</script>
</head>
<body>
<div class="page">

<div class="header-title">
    <h1>Matrix Toolkit Admin</h1>
</div>

<div class="topbar">
    <div class="creator-card">
        <b>$(html_escape "$COMPANY")</b><br>
        Created by $(html_escape "$AUTHOR")<br>
        <a href="mailto:$(html_escape "$EMAIL")">$(html_escape "$EMAIL")</a>
    </div>
    <button class="grey logout-small" onclick="window.location='/cgi-bin/admin_logout.sh'">Logout</button>
</div>

<div class="dashboard">

    <div class="column">
        <button class="green" onclick="window.location='/cgi-bin/about.sh'">Toolkit Information</button>
        <button class="green" onclick="window.location='/cgi-bin/matrix_health.sh'">Matrix Health Check</button>
        <button class="green" onclick="openToolkit()">Open Toolkit</button>
    </div>

    <div class="column">
        <button class="blue" onclick="window.location='/cgi-bin/update_github_start.sh'">Update from GitHub</button>
        <button class="blue" onclick="window.location='/cgi-bin/install_update_worker.sh'">Toolkit Install from USB</button>
        <button class="blue" onclick="window.location='/cgi-bin/zerotier_setup.sh'">ZeroTier Setup</button>
    </div>

    <div class="column">
        <button class="orange" onclick="window.location='/cgi-bin/router_backup.sh'">Router Config Backup</button>
        <button class="orange" onclick="window.location='/cgi-bin/toolkit_backup.sh'">Toolkit Backup</button>
        <button class="orange" onclick="window.location='/cgi-bin/admin_change_password.sh'">Change Admin Password</button>
    </div>

</div>

<div class="info-grid">

    <div class="card">
        <h2>Toolkit Version</h2>
        <b>Matrix Toolkit v$(html_escape "$VERSION")</b><br>
        Build $(html_escape "$BUILD")<br>
        Release $(html_escape "$RELEASE")<br>
        Changes: None
    </div>

    <div class="card">
        <h2>Backup Location</h2>
        Backups are saved on the USB stick connected to the router.<br>
        When you remove the USB stick and open it on a Windows PC, you can find the backups in the folder:<br><br>
        <b>Backup</b>
        <div class="small">Router path: $(html_escape "$BACKUP_DIR")</div>
    </div>

    <div class="card">
        <h2>ZeroTier Remote Access</h2>
HTML

if [ "$ZT_IP" = "Not available" ]; then
cat <<HTML
        ZeroTier IP: <b>Not available</b><br>
        <span class="small">ZeroTier address was not detected on the router interfaces. Check ZeroTier authorization and network status.</span>
HTML
else
cat <<HTML
        Toolkit: <a href="http://$ZT_IP:8080">http://$ZT_IP:8080</a><br>
        Admin: <a href="http://$ZT_IP:8081/cgi-bin/admin_login.sh">http://$ZT_IP:8081/cgi-bin/admin_login.sh</a>
HTML
fi

cat <<HTML
    </div>

    <div class="card">
        <h2>Repository</h2>
        <a href="$REPO_URL">$REPO_URL</a>
    </div>

</div>

</div>
</body>
</html>
HTML

exit 0
