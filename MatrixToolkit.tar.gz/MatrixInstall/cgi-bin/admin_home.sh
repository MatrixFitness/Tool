#!/bin/sh

# Matrix Toolkit Admin Home
# Runs on Admin web server port 8081

printf "Content-Type: text/html\n\n"

SESSION_CHECK="/usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh"
[ -f "$SESSION_CHECK" ] && . "$SESSION_CHECK"

VERSION_FILE="/usr/local/matrix/version.txt"
BACKUP_DIR="/usr/local/mnt/sda1/Backup"

get_value() {
    KEY="$1"
    grep "^$KEY=" "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-
}

get_block() {
    KEY="$1"
    sed -n "/^${KEY}<<END$/,/^END$/p" "$VERSION_FILE" 2>/dev/null | sed '1d;$d'
}

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

VERSION=$(get_value Version)
BUILD=$(get_value Build)
RELEASE=$(get_value Release)
GITHUB=$(get_value GitHub)
AUTHOR=$(get_value Author)
EMAIL=$(get_value Email)
COMPANY=$(get_value Company)
CHANGES=$(get_value Changes)
NOTES=$(get_block Notes)

[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"
[ -z "$GITHUB" ] && GITHUB="https://github.com/MatrixFitness/Tool"
[ -z "$COMPANY" ] && COMPANY="Matrix Fitness"
[ -z "$AUTHOR" ] && AUTHOR="Rob Bosman"
[ -z "$EMAIL" ] && EMAIL="rob.bosman@matrixfitness.nl"
[ -z "$CHANGES" ] && CHANGES="None"

ZT_IP=""
if command -v zerotier-cli >/dev/null 2>&1; then
    ZT_IP=$(zerotier-cli listnetworks 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\//){split($i,a,"/"); print a[1]; exit}}')
fi
[ -z "$ZT_IP" ] && ZT_IP="Not available"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Matrix Toolkit Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
body{
    font-family:Arial,Helvetica,sans-serif;
    margin:20px;
    background:#f5f5f5;
    color:#222;
}
.page{
    max-width:980px;
    background:white;
    border:1px solid #ccc;
    border-radius:10px;
    padding:22px;
    box-shadow:0 2px 8px rgba(0,0,0,.08);
}
h1{
    margin:0 0 18px 0;
    color:#005a9c;
    font-size:28px;
}
.dashboard{
    display:flex;
    gap:22px;
    align-items:flex-start;
    margin-top:10px;
}
.column{
    width:260px;
}
button{
    width:260px;
    height:48px;
    margin-bottom:9px;
    font-size:15px;
    font-weight:bold;
    cursor:pointer;
    border:none;
    border-radius:6px;
    color:white;
}
.green{background:#28a745;}
.green:hover{background:#218838;}
.blue{background:#007bff;}
.blue:hover{background:#0069d9;}
.orange{background:#fd7e14;}
.orange:hover{background:#e46c0a;}
.grey{background:#666;}
.grey:hover{background:#555;}
.info-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:16px;
    margin-top:24px;
}
.card{
    background:#fafafa;
    border:1px solid #ddd;
    border-radius:8px;
    padding:15px;
    line-height:1.55;
}
.card h2{
    margin:0 0 9px 0;
    color:#005a9c;
    font-size:19px;
}
.small{
    color:#555;
    font-size:13px;
}
a{
    color:#005a9c;
    word-break:break-all;
}
@media(max-width:900px){
    body{margin:12px;}
    .page{padding:16px;}
    .dashboard{display:block;}
    .column{width:100%;}
    button{
        width:100%;
        max-width:320px;
        height:46px;
        font-size:14px;
        margin-bottom:8px;
    }
    .info-grid{grid-template-columns:1fr;}
}
</style>
<script>
function openToolkit(){
    window.location = window.location.protocol + '//' + window.location.hostname + ':8080';
}
</script>
</head>
<body>
<div class="page">
<h1>Matrix Toolkit Admin</h1>

<div class="dashboard">
    <div class="column">
        <button class="green" onclick="window.location='/cgi-bin/about.sh'">Toolkit Information</button>
        <button class="green" onclick="window.location='/cgi-bin/matrix_health_check.sh'">Matrix Health Check</button>
        <button class="green" onclick="openToolkit()">Open Toolkit</button>
    </div>

    <div class="column">
        <button class="blue" onclick="window.location='/cgi-bin/update_github_start.sh'">Update from GitHub</button>
        <button class="blue" onclick="window.location='/cgi-bin/install_usb.sh'">Toolkit Install from USB</button>
        <button class="blue" onclick="window.location='/cgi-bin/zerotier_setup.sh'">ZeroTier Setup</button>
    </div>

    <div class="column">
        <button class="orange" onclick="window.location='/cgi-bin/router_config_backup.sh'">Router Config Backup</button>
        <button class="orange" onclick="window.location='/cgi-bin/toolkit_backup.sh'">Toolkit Backup</button>
        <button class="orange" onclick="window.location='/cgi-bin/admin_change_password.sh'">Change Admin Password</button>
        <button class="grey" onclick="window.location='/cgi-bin/admin_logout.sh'">Logout</button>
    </div>
</div>

<div class="info-grid">
    <div class="card">
        <h2>Toolkit Version</h2>
        <b>Matrix Toolkit v$(html_escape "$VERSION")</b><br>
        Build $(html_escape "$BUILD")<br>
        Release $(html_escape "$RELEASE")<br><br>
        <b>Changes:</b><br>
        $(html_escape "$CHANGES")
        <br><br>
        <b>$(html_escape "$COMPANY")</b><br>
        Created by $(html_escape "$AUTHOR")<br>
        <a href="mailto:$(html_escape "$EMAIL")">$(html_escape "$EMAIL")</a>
    </div>

    <div class="card">
        <h2>Backup Location</h2>
        Backups are saved on the USB stick connected to the router.<br>
        When you remove the USB stick and open it on a Windows PC, open the folder:<br><br>
        <b>Backup</b>
        <div class="small">Router path: $(html_escape "$BACKUP_DIR")</div>
    </div>

    <div class="card">
        <h2>ZeroTier Remote Access</h2>
HTML

if [ "$ZT_IP" = "Not available" ]; then
cat <<HTML
        ZeroTier IP: <b>Not available</b><br>
        <span class="small">Run ZeroTier Setup first, or check if the device is authorized in ZeroTier Central.</span>
HTML
else
cat <<HTML
        Toolkit: <a href="http://$ZT_IP:8080">http://$ZT_IP:8080</a><br>
        Admin: <a href="http://$ZT_IP:8081/cgi-bin/admin_login.sh">http://$ZT_IP:8081/cgi-bin/admin_login.sh</a>
HTML
fi

cat <<HTML
    </div>

    <div class="card">
        <h2>Repository</h2>
        <a href="$(html_escape "$GITHUB")">$(html_escape "$GITHUB")</a>
    </div>
</div>

</div>
</body>
</html>
HTML

exit 0
