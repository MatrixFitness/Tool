#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

echo "Content-Type: text/html"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""
cat <<'HTML'
<!DOCTYPE html>
<html>
<head>
<title>Matrix Admin</title>
<style>
body { font-family: Arial, sans-serif; margin: 30px; background: #f5f5f5; }
h1 { margin-bottom: 20px; color: #333; }
.section { font-size: 20px; font-weight: bold; margin-bottom: 15px; }
.admin-table { border-collapse: collapse; }
.admin-table td { vertical-align: top; }
.spacer { width: 25px; }
button { width: 260px; height: 60px; margin-bottom: 10px; font-size: 17px; font-weight: bold; cursor: pointer; border: none; border-radius: 6px; }
.quick { background: #28a745; color: white; }
.advanced { background: #fd7e14; color: white; }
.remote { background: #007bff; color: white; }
.danger { background: #6c757d; color: white; }
.footer { margin-top: 20px; color: #666; font-size: 12px; }
</style>
</head>
<body>
<h1>Matrix Admin</h1>
<div class="section">Beheer</div>
<table class="admin-table"><tr>
<td>
<button class="quick" onclick="window.location='/cgi-bin/about.sh'">Toolkit Information</button><br>
<button class="remote" onclick="if(confirm('Run Matrix Health Check?')) window.location='/cgi-bin/matrix_health.sh'">Matrix Health Check</button><br>
<button class="remote" onclick="window.location=window.location.protocol + '//' + window.location.hostname + ':8080/index.html'">Open Toolkit</button>
</td>
<td class="spacer"></td>
<td>
<button class="advanced" onclick="if(confirm('Toolkit bijwerken vanaf GitHub?')) window.location='/cgi-bin/update_github_start.sh'">Update from GitHub</button><br>
<button class="advanced" onclick="if(confirm('Toolkit bijwerken vanaf USB?')) window.location='/cgi-bin/update_toolkit.sh'">Toolkit Install van USB</button><br>
<button class="remote" onclick="window.location='/cgi-bin/zerotier_setup.sh'">ZeroTier Setup</button>
</td>
<td class="spacer"></td>
<td>
<button class="quick" onclick="window.location='/cgi-bin/router_backup.sh'">Router Config Backup<br>(Naar USB)</button><br>
<button class="quick" onclick="window.location='/cgi-bin/toolkit_backup.sh'">Toolkit Backup<br>(Naar USB)</button><br>
<button class="advanced" onclick="window.location='/cgi-bin/admin_change_password.sh'">Change Admin Password</button><br>
<button class="danger" onclick="window.location='/cgi-bin/admin_logout.sh'">Logout</button>
</td>
</tr></table>
<div class="footer">
Backup locatie:<br>/usr/local/mnt/sda1/Backup<br><br>
<div id="versionFooter">Loading version info...</div>
</div>
<script>
fetch('/cgi-bin/version_footer.sh')
.then(response => response.text())
.then(data => { document.getElementById('versionFooter').innerHTML = data; })
.catch(() => { document.getElementById('versionFooter').innerHTML = 'Matrix Admin<br>Version info not available'; });
</script>
</body>
</html>
HTML
