#!/bin/sh

echo "Content-Type: text/html"
echo ""

echo "<html><body>"

echo "<h1>Router wordt herstart...</h1>"

echo "</body></html>"

reboot