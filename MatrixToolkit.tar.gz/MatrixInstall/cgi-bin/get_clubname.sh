#!/bin/sh

echo "Content-Type: text/plain"
echo ""

FILE="/usr/local/matrix/clubname.txt"

# Return club name if available
if [ -f "$FILE" ]
then
    CLUBNAME=$(cat "$FILE" 2>/dev/null)

    if [ -n "$CLUBNAME" ]
    then
        echo "$CLUBNAME"
    else
        echo "Unknown Club"
    fi
else
    echo "Unknown Club"
fi