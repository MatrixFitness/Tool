#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="MatrixRouter"
VERSION="$(get_value Version)"; [ -z "$VERSION" ] && VERSION="74.6"
page_start(){
TITLE="$1"; SUB="$2"
cat <<EOF
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>$TITLE</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{margin:0;background:#eef2f6;font-family:Arial,Helvetica,sans-serif;color:#1f2933}.page{max-width:1200px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:white;border-radius:18px;padding:20px 22px;display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;box-shadow:0 8px 22px rgba(15,23,42,.08)}h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:white;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:18px 0}.card{background:white;border:1px solid #d9e2ec;border-radius:16px;padding:15px;box-shadow:0 8px 22px rgba(15,23,42,.08)}.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:700;letter-spacing:.05em}.value{font-size:18px;font-weight:800;margin-top:7px;word-break:break-word}.ok{color:#1f8a3b}.warn{color:#b35b00}.fail{color:#c82333}pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto}.section{background:white;border:1px solid #d9e2ec;border-radius:18px;padding:16px;margin:16px 0;box-shadow:0 8px 22px rgba(15,23,42,.08)}table{width:100%;border-collapse:collapse;background:white}td,th{border:1px solid #d9e2ec;padding:9px;text-align:left}th{background:#f0f6fb}@media(max-width:800px){.grid{grid-template-columns:1fr}.page{padding:10px}.hero{border-radius:14px}h1{font-size:23px}.btn{width:100%;text-align:center}}
</style></head><body><div class="page"><div class="hero"><div><h1>$(html_escape "$TITLE")</h1><div class="sub">$(html_escape "$SUB")</div></div><a class="btn" href="/">Back to Toolkit</a></div>
EOF
}
page_end(){ echo "</div></body></html>"; }

CACHE="/tmp/matrix_lte_info.cache"
RAW=""
[ -f "$CACHE" ] && RAW="$(cat "$CACHE" 2>/dev/null)"
[ -z "$RAW" ] && RAW="$(gsmctl -q 2>/dev/null; gsmctl -p 2>/dev/null; gsmctl -s 2>/dev/null)"
WAN_LTE="$(ip -4 addr show qmimux0 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
[ -z "$WAN_LTE" ] && WAN_LTE="$(ip -4 addr show wwan0 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
page_start "LTE Analysis" "Mobiel modemsignaal en LTE status"
cat <<EOF
<div class="grid">
 <div class="card"><div class="label">LTE IP</div><div class="value">$(html_escape "$WAN_LTE")</div></div>
 <div class="card"><div class="label">Cache</div><div class="value">$( [ -f "$CACHE" ] && echo "Available" || echo "No cache" )</div></div>
 <div class="card"><div class="label">Interface</div><div class="value">qmimux0 / wwan0</div></div>
</div>
<div class="section"><h2>LTE Raw Data</h2><pre>$(html_escape "$RAW")</pre></div>
EOF
page_end
