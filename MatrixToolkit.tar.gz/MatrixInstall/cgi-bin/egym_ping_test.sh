#!/bin/sh

echo "Content-Type: text/html"
echo ""

echo "<html>"
echo "<head>"
echo "<title>EGYM Firewall Test</title>"
echo "</head>"
echo "<body style='font-family:Arial'>"

echo "<h1>EGYM Firewall Test</h1>"

echo "<table border='1' cellpadding='5' cellspacing='0'>"
echo "<tr><th>Bestemming</th><th>Status</th></tr>"

FAIL=0

check_ip() {

    if ping -c 1 -W 2 "$1" >/dev/null 2>&1
    then
        echo "<tr><td>$1</td><td><font color='green'><b>PASS</b></font></td></tr>"
    else
        echo "<tr><td>$1</td><td><font color='red'><b>FAIL</b></font></td></tr>"
        FAIL=1
    fi
}

# Training / Updates / Toestelstatus

check_ip 104.199.66.167
check_ip 35.189.221.132
check_ip 104.199.91.64
check_ip 146.148.19.217
check_ip 104.155.57.166
check_ip 146.148.15.175
check_ip 3.127.32.71
check_ip 18.156.48.111
check_ip 3.124.243.61
check_ip 52.37.226.173
check_ip 35.84.145.167
check_ip 35.81.42.122

# Onderhoud op afstand

check_ip 35.198.87.78
check_ip 212.114.251.94
check_ip 192.158.31.31

# DNS

check_ip 8.8.8.8
check_ip 8.8.4.4

echo "</table>"

echo "<hr>"

if [ "$FAIL" -eq 0 ]
then
    echo "<h2 style='color:green'>STATUS: GOEDGEKEURD</h2>"
    echo "<p>Alle EGYM firewall bestemmingen zijn bereikbaar.</p>"
else
    echo "<h2 style='color:orange'>STATUS: WAARSCHUWING</h2>"
    echo "<p>Niet alle EGYM firewall bestemmingen reageren.</p>"
    echo "<p>Let op: sommige servers blokkeren ping. Een FAIL betekent niet automatisch dat EGYM niet werkt.</p>"
fi

echo "</body>"
echo "</html>"