#!/bin/sh
# Install WiFi Interface Control and add button to WiFi Manager.

WEB="/usr/local/matrix/web/cgi-bin"
MANAGER="$WEB/wifi_manager.sh"

mkdir -p "$WEB"

cp -f wifi_interface_control.sh "$WEB/wifi_interface_control.sh"
chmod +x "$WEB/wifi_interface_control.sh"

if [ -f "$MANAGER" ] && ! grep -q "wifi_interface_control.sh" "$MANAGER"; then
    cp -f "$MANAGER" "$MANAGER.bak.interfacecontrol.$(date +%Y%m%d%H%M%S)"

    awk '
    {
        print
        if (!done && $0 ~ /<h1>Matrix WiFi Manager/) {
            print "<div class=\"card\">"
            print "<h2>WiFi Interface Control</h2>"
            print "<p class=\"muted\">Enable or disable any detected WiFi interface / SSID without changing saved profiles.</p>"
            print "<a class=\"btn blue\" href=\"/cgi-bin/wifi_interface_control.sh\">Open WiFi Interface Control</a>"
            print "</div>"
            done=1
        }
    }' "$MANAGER" > /tmp/wifi_manager_interfacecontrol.$$

    cat /tmp/wifi_manager_interfacecontrol.$$ > "$MANAGER"
    rm -f /tmp/wifi_manager_interfacecontrol.$$
    chmod +x "$MANAGER"
fi

echo "WiFi Interface Control installed."
echo "Open: http://<router-ip>:8080/cgi-bin/wifi_interface_control.sh"
