#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"
html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="MatrixRouter"
VERSION="$(get_value Version)"; [ -z "$VERSION" ] && VERSION="74.6"
page_start(){
TITLE="$1"; SUB="$2"
cat <<EOF
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>$TITLE</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{margin:0;background:#eef2f6;font-family:Arial,Helvetica,sans-serif;color:#1f2933}.page{max-width:1200px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:white;border-radius:18px;padding:20px 22px;display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;box-shadow:0 8px 22px rgba(15,23,42,.08)}h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:white;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:18px 0}.card{background:white;border:1px solid #d9e2ec;border-radius:16px;padding:15px;box-shadow:0 8px 22px rgba(15,23,42,.08)}.label{font-size:12px;color:#667085;text-transform:uppercase;font-weight:700;letter-spacing:.05em}.value{font-size:18px;font-weight:800;margin-top:7px;word-break:break-word}.ok{color:#1f8a3b}.warn{color:#b35b00}.fail{color:#c82333}pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto}.section{background:white;border:1px solid #d9e2ec;border-radius:18px;padding:16px;margin:16px 0;box-shadow:0 8px 22px rgba(15,23,42,.08)}table{width:100%;border-collapse:collapse;background:white}td,th{border:1px solid #d9e2ec;padding:9px;text-align:left}th{background:#f0f6fb}@media(max-width:800px){.grid{grid-template-columns:1fr}.page{padding:10px}.hero{border-radius:14px}h1{font-size:23px}.btn{width:100%;text-align:center}}
</style></head><body><div class="page"><div class="hero"><div><h1>$(html_escape "$TITLE")</h1><div class="sub">$(html_escape "$SUB")</div></div><a class="btn" href="/">Back to Toolkit</a></div>
EOF
}
page_end(){ echo "</div></body></html>"; }

PING_GW="UNKNOWN"; GW="$(ip route 2>/dev/null | awk '/default/{print $3; exit}')"; [ -n "$GW" ] && ping -c1 -W2 "$GW" >/dev/null 2>&1 && PING_GW="OK" || [ -n "$GW" ] && PING_GW="FAIL"
PING_NET="FAIL"; ping -c1 -W2 8.8.8.8 >/dev/null 2>&1 && PING_NET="OK"
DNS="FAIL"; nslookup matrixfitness.com >/dev/null 2>&1 && DNS="OK"
ZT_STATUS="UNKNOWN"; [ -x /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh ] && /usr/local/matrix/adminweb/cgi-bin/zerotier_status_worker.sh >/dev/null 2>&1; [ -f /tmp/matrix_zerotier_status.cache ] && ZT_STATUS="$(grep '^HEALTH=' /tmp/matrix_zerotier_status.cache | cut -d= -f2-)"
page_start "Diagnostics" "Snelle router- en netwerkdiagnose"
cat <<EOF
<div class="grid">
 <div class="card"><div class="label">Gateway Ping</div><div class="value $( [ "$PING_GW" = OK ] && echo ok || echo fail )">$(html_escape "$PING_GW")</div></div>
 <div class="card"><div class="label">Internet Ping</div><div class="value $( [ "$PING_NET" = OK ] && echo ok || echo fail )">$(html_escape "$PING_NET")</div></div>
 <div class="card"><div class="label">DNS</div><div class="value $( [ "$DNS" = OK ] && echo ok || echo fail )">$(html_escape "$DNS")</div></div>
 <div class="card"><div class="label">ZeroTier</div><div class="value">$(html_escape "$ZT_STATUS")</div></div>
 <div class="card"><div class="label">Memory</div><div class="value">$(html_escape "$(free -m 2>/dev/null | awk '/Mem:/{print $4 " MB free"}')")</div></div>
 <div class="card"><div class="label">Load</div><div class="value">$(html_escape "$(uptime | sed 's/.*load average: //')")</div></div>
</div>
<div class="section"><h2>Advanced Diagnostics</h2><pre>$(html_escape "$(date)

ROUTES:
$(ip route 2>/dev/null)

DNS:
$(cat /tmp/resolv.conf.d/resolv.conf.auto 2>/dev/null)

PROCESSES:
$(ps | grep -E 'uhttpd|zerotier' | grep -v grep)")</pre></div>
EOF
page_end
