#!/bin/sh

printf "Content-Type: text/html\n\n"

SURVEY_DIR="/usr/local/matrix/survey"
CSV="$SURVEY_DIR/wifi_survey_results.csv"
CLUB_FILE="/usr/local/matrix/clubname.txt"
VERSION_FILE="/usr/local/matrix/version.txt"

VERSION=$(grep '^Version=' "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-)
BUILD=$(grep '^Build=' "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-)
RELEASE=$(grep '^Release=' "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-)
COMPANY=$(grep '^Company=' "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-)
AUTHOR=$(grep '^Author=' "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-)
EMAIL=$(grep '^Email=' "$VERSION_FILE" 2>/dev/null | cut -d'=' -f2-)
CLUB=$(cat "$CLUB_FILE" 2>/dev/null)
[ -z "$CLUB" ] && CLUB="Not entered"
[ -z "$VERSION" ] && VERSION="Unknown"
[ -z "$BUILD" ] && BUILD="Unknown"
[ -z "$RELEASE" ] && RELEASE="Unknown"

html_escape(){
  printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

badge_class(){
  case "$1" in
    Excellent|PASS) echo "excellent";;
    Good) echo "good";;
    Fair|ATTENTION) echo "fair";;
    Poor|Weak) echo "poor";;
    Critical|FAIL) echo "critical";;
    *) echo "unknown";;
  esac
}

dot_class(){
  case "$1" in
    Excellent|PASS) echo "dot-excellent";;
    Good) echo "dot-good";;
    Fair|ATTENTION) echo "dot-fair";;
    Poor|Weak) echo "dot-poor";;
    Critical|FAIL) echo "dot-critical";;
    *) echo "dot-unknown";;
  esac
}

score_for_rating(){
  case "$1" in
    Excellent|PASS) echo 100;;
    Good) echo 85;;
    Fair|ATTENTION) echo 65;;
    Poor|Weak) echo 40;;
    Critical|FAIL) echo 0;;
    *) echo 50;;
  esac
}

signal_explain(){
  case "$1" in
    Excellent) echo "Excellent WiFi coverage. Suitable for Matrix connected equipment, updates and streaming with good margin.";;
    Good) echo "Good WiFi coverage. Suitable for normal Matrix operation.";;
    Fair) echo "Acceptable WiFi coverage. It can work, but improvement is recommended for permanent installations.";;
    Poor|Weak) echo "Weak WiFi coverage. Add an access point, move the AP closer or reposition equipment.";;
    Critical) echo "Critical WiFi coverage. Not suitable before the wireless design is improved.";;
    *) echo "Signal could not be interpreted.";;
  esac
}

speed_explain(){
  case "$1" in
    Excellent) echo "Excellent throughput. Suitable for updates, HD streaming, Virtual Active/iFIT and larger deployments.";;
    Good) echo "Good throughput. Suitable for normal Matrix connected equipment and most updates.";;
    Fair) echo "Usable throughput. Basic connectivity should work, but large downloads or streaming may be slow.";;
    Poor|Weak) echo "Low throughput. Check WiFi interference, AP load, WAN capacity or signal quality.";;
    Critical) echo "Critical throughput. Not recommended for connected equipment until improved.";;
    *) echo "Speed could not be measured.";;
  esac
}

quality_explain(){
  case "$1" in
    Excellent) echo "Very stable connection: low latency and no packet loss detected.";;
    Good) echo "Stable connection: latency is acceptable and packet loss is low.";;
    Fair) echo "Usable but with attention points. High latency or small packet loss may cause occasional delays.";;
    Poor|Weak) echo "Unstable connection. Packet loss or high latency can cause sync issues, slow logins or cloud timeouts.";;
    Critical) echo "Critical stability issue. Fix packet loss/latency before installation.";;
    *) echo "Network stability could not be measured.";;
  esac
}

recommendation_text(){
  case "$1" in
    PASS) echo "Suitable for Matrix Fitness equipment. No network action required for this location.";;
    ATTENTION) echo "Works, but improvement is recommended if equipment will stay here permanently.";;
    FAIL) echo "Do not approve this location before the failing network items are resolved.";;
    *) echo "Review manually.";;
  esac
}

notes_text(){
  RESULT="$1"; SIG="$2"; SPEED="$3"; QUALITY="$4"; CLOUD="$5"; BAND="$6"
  if [ "$RESULT" = "PASS" ]; then echo "No action required"; return; fi
  if [ "$CLOUD" = "FAIL" ]; then echo "Check Matrix Fitness Cloud Connectivity"; return; fi
  if [ "$QUALITY" = "Poor" ] || [ "$QUALITY" = "Critical" ]; then echo "Investigate latency or packet loss"; return; fi
  if [ "$SIG" = "Fair" ] || [ "$SIG" = "Poor" ] || [ "$SIG" = "Weak" ] || [ "$SIG" = "Critical" ]; then echo "Improve WiFi coverage"; return; fi
  if [ "$SPEED" = "Poor" ] || [ "$SPEED" = "Critical" ]; then echo "Check WiFi or internet throughput"; return; fi
  echo "Review manually"
}

cat <<HTML
<html>
<head>
<title>Matrix WiFi Survey Report</title>
<style>
:root{--blue:#005a9c;--green:#1f8a3b;--lightgreen:#5cb85c;--yellow:#f0ad4e;--orange:#e67e22;--red:#c0392b;--grey:#777;--bg:#f5f5f5;}
body{font-family:Arial,Helvetica,sans-serif;margin:0;background:var(--bg);color:#222;}
.page{max-width:1280px;margin:24px auto;background:#fff;border:1px solid #ccc;border-radius:10px;padding:26px;box-shadow:0 2px 8px rgba(0,0,0,.08);}
.report-header{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;border-bottom:3px solid #e5eef7;padding-bottom:18px;margin-bottom:18px}.logo{height:54px;max-width:260px;object-fit:contain}.report-title{text-align:right}.footer{display:flex;align-items:center;justify-content:space-between;border-top:1px solid #ddd;margin-top:24px;padding-top:12px}.footer img{height:28px}.connected-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.connected-grid div{padding:6px 0;border-bottom:1px solid #eee}.kpi-title{font-weight:bold;color:var(--blue);text-transform:uppercase;font-size:12px}.legend-box{border:1px solid #ddd;border-radius:9px;padding:16px;background:#fff}
h1{margin:0;color:var(--blue);font-size:30px;}h2{color:var(--blue);border-bottom:2px solid #e5eef7;padding-bottom:6px;margin-top:26px;}h3{margin-bottom:8px;}.meta{color:#555;margin-top:6px;line-height:1.6}.summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin:18px 0}.tile{border:1px solid #ddd;border-radius:9px;padding:16px;background:#fafafa}.tile .big{font-size:34px;font-weight:bold}.tile .label{color:#555;margin-top:4px}.scorebox{text-align:center;border-radius:12px;padding:22px;color:white}.scorebox .score{font-size:52px;font-weight:bold;line-height:1}.scorebox .rating{font-size:22px;font-weight:bold;margin-top:8px}.excellent{background:#1f8a3b;color:white}.good{background:#5cb85c;color:white}.fair{background:#f0ad4e;color:#222}.poor{background:#e67e22;color:white}.critical{background:#c0392b;color:white}.unknown{background:#777;color:white}.badge{display:inline-block;border-radius:999px;padding:5px 10px;font-weight:bold;font-size:12px;min-width:72px;text-align:center}.badge.excellent{background:#1f8a3b;color:white}.badge.good{background:#5cb85c;color:white}.badge.fair{background:#f0ad4e;color:#222}.badge.poor{background:#e67e22;color:white}.badge.critical{background:#c0392b;color:white}.badge.unknown{background:#777;color:white}.explain{background:#eef6ff;border-left:5px solid var(--blue);padding:14px;margin:14px 0;border-radius:4px;line-height:1.5}.note{background:#fff8e5;border-left:5px solid #f0ad4e;padding:12px;border-radius:4px;margin:12px 0}.detail-card{border:1px solid #ddd;border-radius:8px;padding:14px;margin:12px 0;background:#fff}.detail-card h3{margin-top:0;color:#005a9c}table{border-collapse:collapse;width:100%;font-size:13px;margin:12px 0 22px 0}th{background:var(--blue);color:#fff;text-align:left;padding:8px}td{border:1px solid #ccc;padding:8px;vertical-align:top}tr:nth-child(even) td{background:#fbfbfb}.legend td:first-child{font-weight:bold}.status-dot,.swatch{width:14px;height:14px;display:inline-block;border-radius:50%;vertical-align:middle;margin-right:7px;border:1px solid rgba(0,0,0,.18)}.swatch{width:18px;height:18px}.dot-excellent,.s-excellent{background:#1f8a3b}.dot-good,.s-good{background:#5cb85c}.dot-fair,.s-fair{background:#f0ad4e}.dot-poor,.s-poor{background:#e67e22}.dot-critical,.s-critical{background:#c0392b}.dot-unknown{background:#777}.metric-line{margin:4px 0}.small{font-size:12px;color:#555}.actions{margin-top:18px}button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:var(--blue);color:white;cursor:pointer}.secondary{background:#666}@media print{body{background:white}.page{box-shadow:none;border:0;margin:0;max-width:none}button{display:none}.pagebreak{page-break-before:always}}
</style>
</head>
<body><div class="page">
<div class="report-header">
  <div><img class="logo" src="/matrix_logo.png" alt="Matrix Fitness"><div class="meta"><b>Club:</b> $(html_escape "$CLUB")<br><b>Report generated:</b> $(date '+%Y-%m-%d %H:%M:%S')<br><b>Toolkit:</b> v$(html_escape "$VERSION") | Build $(html_escape "$BUILD") | $(html_escape "$RELEASE")</div></div>
  <div class="report-title"><h1>WiFi Survey Report</h1><div class="meta">Matrix Fitness Network Assessment</div></div>
</div>
HTML

if [ ! -f "$CSV" ]; then
  echo "<div class='note'><b>No survey results found.</b><br>Start a new survey first.</div>"
else
  TMP="/tmp/matrix_report_rows.$$"
  TMP_ANALYSIS="/tmp/matrix_report_analysis.$$"
  : > "$TMP"
  : > "$TMP_ANALYSIS"
  TOTAL=0; PASS_COUNT=0; ATT_COUNT=0; FAIL_COUNT=0; SCORE_SUM=0
  SIG_SCORE_SUM=0; SPEED_SCORE_SUM=0; QUALITY_SCORE_SUM=0; CLOUD_SCORE_SUM=0
  BEST_SPEED=""; WORST_SIGNAL=""; WORST_LOCATION=""; FIRST_DATE=""; LAST_DATE=""
  FIRST_SSID=""; FIRST_BAND=""; FIRST_CHANNEL=""; FIRST_BSSID=""; FIRST_APVENDOR=""; FIRST_ROAMING=""
  HEADER=1
  while IFS=',' read -r DATE LOCATION SSID IP SIGNAL RATING QUALITY BITRATE BAND CHANNEL BSSID APVENDOR ROAMING INTERNET DNS MATRIX LATENCY PACKETLOSS DOWNLOAD SPEEDRATING QUALITYRATING OVERALL; do
    if [ "$HEADER" = "1" ]; then HEADER=0; continue; fi
    [ -z "$DATE$LOCATION" ] && continue
    TOTAL=$((TOTAL+1))
    if [ -z "$FIRST_DATE" ]; then
      FIRST_DATE="$DATE"
      FIRST_SSID="$SSID"
      FIRST_BAND="$BAND"
      FIRST_CHANNEL="$CHANNEL"
      FIRST_BSSID="$BSSID"
      FIRST_APVENDOR="$APVENDOR"
      FIRST_ROAMING="$ROAMING"
    fi
    LAST_DATE="$DATE"
    [ "$OVERALL" = "PASS" ] && PASS_COUNT=$((PASS_COUNT+1))
    [ "$OVERALL" = "ATTENTION" ] && ATT_COUNT=$((ATT_COUNT+1))
    [ "$OVERALL" = "FAIL" ] && FAIL_COUNT=$((FAIL_COUNT+1))
    S1=$(score_for_rating "$RATING"); S2=$(score_for_rating "$SPEEDRATING"); S3=$(score_for_rating "$QUALITYRATING"); S4=$(score_for_rating "$OVERALL")
    CLOUD_SCORE=0; [ "$MATRIX" = "PASS" ] && CLOUD_SCORE=100
    LOC_SCORE=$(( (S1*35 + S2*20 + S3*35 + CLOUD_SCORE*10) / 100 ))
    SCORE_SUM=$((SCORE_SUM + LOC_SCORE))
    SIG_SCORE_SUM=$((SIG_SCORE_SUM + S1))
    SPEED_SCORE_SUM=$((SPEED_SCORE_SUM + S2))
    QUALITY_SCORE_SUM=$((QUALITY_SCORE_SUM + S3))
    CLOUD_SCORE_SUM=$((CLOUD_SCORE_SUM + CLOUD_SCORE))
    SIG_NUM=$(echo "$SIGNAL" | sed 's/[^0-9-]//g')
    if [ -n "$SIG_NUM" ]; then
      if [ -z "$WORST_SIGNAL" ] || [ "$SIG_NUM" -lt "$WORST_SIGNAL" ]; then WORST_SIGNAL="$SIG_NUM"; WORST_LOCATION="$LOCATION"; fi
    fi
    D_INT=$(echo "$DOWNLOAD" | cut -d'.' -f1 | sed 's/[^0-9]//g')
    if [ -n "$D_INT" ]; then
      if [ -z "$BEST_SPEED" ] || [ "$D_INT" -gt "$BEST_SPEED" ]; then BEST_SPEED="$D_INT"; fi
    fi
    OC=$(badge_class "$OVERALL"); RC=$(badge_class "$RATING"); SC=$(badge_class "$SPEEDRATING"); QC=$(badge_class "$QUALITYRATING")
    NOTE=$(notes_text "$OVERALL" "$RATING" "$SPEEDRATING" "$QUALITYRATING" "$MATRIX" "$BAND")
    printf '%s
' "<tr><td>$(html_escape "$LOCATION")</td><td><b>SSID:</b> $(html_escape "$SSID")<br><b>Band:</b> $(html_escape "$BAND")<br><b>Channel:</b> $(html_escape "$CHANNEL")<br><span class='small'>$(html_escape "$APVENDOR")<br>$(html_escape "$BSSID")</span></td><td>$(html_escape "$SIGNAL") dBm<br><span class='badge $RC'>$(html_escape "$RATING")</span></td><td>$(html_escape "$DOWNLOAD") Mbps<br><span class='badge $SC'>$(html_escape "$SPEEDRATING")</span></td><td>$(html_escape "$LATENCY") ms</td><td>$(html_escape "$PACKETLOSS")</td><td><span class='badge $QC'>$(html_escape "$QUALITYRATING")</span></td><td>$(html_escape "$INTERNET") / $(html_escape "$DNS") / $(html_escape "$MATRIX")</td><td><span class='badge $OC'>$(html_escape "$OVERALL")</span><br><span class='small'>Score: $LOC_SCORE/100</span></td><td>$(html_escape "$NOTE")</td></tr>" >> "$TMP"
    if [ "$OVERALL" = "ATTENTION" ] || [ "$OVERALL" = "FAIL" ]; then
      printf '%s
' "<div class='detail-card'><h3>$(html_escape "$LOCATION")</h3><p><span class='status-dot $(dot_class "$OVERALL")'></span><b>$(html_escape "$OVERALL")</b> - $(html_escape "$NOTE")</p><p><b>WiFi / AP:</b> SSID $(html_escape "$SSID"), $(html_escape "$BAND"), channel $(html_escape "$CHANNEL"), AP vendor $(html_escape "$APVENDOR"), BSSID $(html_escape "$BSSID").</p><p><b>Roaming assessment:</b> $(html_escape "$ROAMING")</p><p><b>Signal:</b> $(html_escape "$SIGNAL") dBm ($(html_escape "$RATING")). $(signal_explain "$RATING")</p><p><b>Speed:</b> $(html_escape "$DOWNLOAD") Mbps ($(html_escape "$SPEEDRATING")). $(speed_explain "$SPEEDRATING")</p><p><b>Stability:</b> latency $(html_escape "$LATENCY") ms, packet loss $(html_escape "$PACKETLOSS") ($(html_escape "$QUALITYRATING")). $(quality_explain "$QUALITYRATING")</p></div>" >> "$TMP_ANALYSIS"
    fi
  done < "$CSV"

  if [ "$TOTAL" -gt 0 ]; then
    OVERALL_SCORE=$((SCORE_SUM / TOTAL))
    WIFI_COVERAGE_SCORE=$((SIG_SCORE_SUM / TOTAL))
    INTERNET_PERFORMANCE_SCORE=$((SPEED_SCORE_SUM / TOTAL))
    NETWORK_STABILITY_SCORE=$((QUALITY_SCORE_SUM / TOTAL))
    CLOUD_CONNECTIVITY_SCORE=$((CLOUD_SCORE_SUM / TOTAL))
  else
    OVERALL_SCORE=0; WIFI_COVERAGE_SCORE=0; INTERNET_PERFORMANCE_SCORE=0; NETWORK_STABILITY_SCORE=0; CLOUD_CONNECTIVITY_SCORE=0
  fi
  if [ "$OVERALL_SCORE" -ge 90 ]; then OVERALL_RATING="Excellent"; OVERALL_CLASS="excellent";
  elif [ "$OVERALL_SCORE" -ge 75 ]; then OVERALL_RATING="Good"; OVERALL_CLASS="good";
  elif [ "$OVERALL_SCORE" -ge 60 ]; then OVERALL_RATING="Fair"; OVERALL_CLASS="fair";
  elif [ "$OVERALL_SCORE" -ge 40 ]; then OVERALL_RATING="Poor"; OVERALL_CLASS="poor";
  else OVERALL_RATING="Critical"; OVERALL_CLASS="critical"; fi
  WIFI_CLASS=$(badge_class "$OVERALL_RATING"); OVERALL_DOT=$(dot_class "$OVERALL_RATING")
  # Individual quality labels for dashboard tiles.
  metric_label(){ if [ "$1" -ge 90 ]; then echo Excellent; elif [ "$1" -ge 75 ]; then echo Good; elif [ "$1" -ge 60 ]; then echo Fair; elif [ "$1" -ge 40 ]; then echo Poor; else echo Critical; fi; }
  WIFI_LABEL=$(metric_label "$WIFI_COVERAGE_SCORE"); SPEED_LABEL=$(metric_label "$INTERNET_PERFORMANCE_SCORE"); STABILITY_LABEL=$(metric_label "$NETWORK_STABILITY_SCORE"); CLOUD_LABEL=$(metric_label "$CLOUD_CONNECTIVITY_SCORE")
  WIFI_DOT=$(dot_class "$WIFI_LABEL"); SPEED_DOT=$(dot_class "$SPEED_LABEL"); STABILITY_DOT=$(dot_class "$STABILITY_LABEL"); CLOUD_DOT=$(dot_class "$CLOUD_LABEL")

  cat <<HTML
<div class="summary-grid">
  <div class="scorebox $OVERALL_CLASS"><div class="score">$OVERALL_SCORE</div><div class="rating">$OVERALL_RATING</div><div>Overall WiFi Quality Score</div></div>
  <div class="tile"><div class="kpi-title">Connected WiFi Details</div><div class="connected-grid"><div><b>SSID</b><br>$(html_escape "$FIRST_SSID")</div><div><b>Band</b><br>$(html_escape "$FIRST_BAND")</div><div><b>Channel</b><br>$(html_escape "$FIRST_CHANNEL")</div><div><b>BSSID / AP MAC</b><br>$(html_escape "$FIRST_BSSID")</div><div><b>AP Vendor</b><br>$(html_escape "$FIRST_APVENDOR")</div><div><b>Roaming</b><br>$(html_escape "$FIRST_ROAMING")</div></div></div>
  <div class="legend-box"><div class="metric-line"><span class="status-dot dot-excellent"></span><b>PASS</b> <span class="small">Excellent / Good</span></div><div class="metric-line"><span class="status-dot dot-fair"></span><b>ATTENTION</b> <span class="small">Fair</span></div><div class="metric-line"><span class="status-dot dot-critical"></span><b>FAIL</b> <span class="small">Poor / Critical</span></div></div>
</div>
<div class="summary-grid">
  <div class="tile"><div class="big">$TOTAL</div><div class="label">Locations measured</div></div>
  <div class="tile"><div class="big">$PASS_COUNT / $ATT_COUNT / $FAIL_COUNT</div><div class="label">Pass / Attention / Fail</div></div>
  <div class="tile"><div class="big">$(html_escape "$WORST_SIGNAL") dBm</div><div class="label">Weakest signal: $(html_escape "$WORST_LOCATION")</div></div>
</div>
<h2>Network Quality Assessment</h2>
<div class="summary-grid">
  <div class="tile"><div class="metric-line"><span class="status-dot $WIFI_DOT"></span><b>WiFi Coverage</b></div><div class="big">$WIFI_COVERAGE_SCORE%</div><div class="label">Based on measured signal strength per location</div></div>
  <div class="tile"><div class="metric-line"><span class="status-dot $STABILITY_DOT"></span><b>Network Stability</b></div><div class="big">$NETWORK_STABILITY_SCORE%</div><div class="label">Based on latency and packet loss</div></div>
  <div class="tile"><div class="metric-line"><span class="status-dot $SPEED_DOT"></span><b>Internet Performance</b></div><div class="big">$INTERNET_PERFORMANCE_SCORE%</div><div class="label">Based on practical download throughput</div></div>
  <div class="tile"><div class="metric-line"><span class="status-dot $CLOUD_DOT"></span><b>Matrix Fitness Cloud Connectivity</b></div><div class="big">$CLOUD_CONNECTIVITY_SCORE%</div><div class="label">Based on Matrix Fitness cloud reachability</div></div>
</div>
<div class="explain"><b>Executive summary:</b><br>The score combines signal strength, practical download speed, latency, packet loss and Matrix Fitness Cloud Connectivity. For Matrix Fitness equipment, Matrix Fitness cloud services and other internet-connected devices and solutions supplied or supported by Matrix Fitness, network stability is more important than only a high download number. A location with 20 Mbps and 0% packet loss is usually better than 200 Mbps with packet loss.</div>
<h2>Measurement Results</h2>
<table><tr><th>Location</th><th>WiFi / Access Point</th><th>Signal</th><th>Download</th><th>Latency</th><th>Packet Loss</th><th>Network Quality</th><th>Internet / DNS / Matrix Fitness Cloud</th><th>Result</th><th>Notes</th></tr>
HTML
  cat "$TMP"
  echo "</table>"
  if [ -s "$TMP_ANALYSIS" ]; then
    echo "<h2>Areas Requiring Attention</h2>"
    cat "$TMP_ANALYSIS"
  else
    echo "<div class='explain'><b>Survey Summary:</b><br>All surveyed locations passed. No corrective actions are required.</div>"
  fi
  cat <<HTML
<h2>Conclusion</h2>
<div class="explain">
<p><span class="status-dot $WIFI_DOT"></span><b>WiFi Coverage:</b> $WIFI_LABEL</p>
<p><span class="status-dot $STABILITY_DOT"></span><b>Network Stability:</b> $STABILITY_LABEL</p>
<p><span class="status-dot $SPEED_DOT"></span><b>Internet Performance:</b> $SPEED_LABEL</p>
<p><span class="status-dot $CLOUD_DOT"></span><b>Matrix Fitness Cloud Connectivity:</b> $CLOUD_LABEL</p>
<p>The surveyed network is assessed for Matrix Fitness equipment, Matrix Fitness cloud services and other internet-connected devices and solutions supplied or supported by Matrix Fitness.</p>
<p><b>Overall Rating:</b> <span class="status-dot $OVERALL_DOT"></span>$OVERALL_RATING ($OVERALL_SCORE/100)</p>
</div>
HTML
  rm -f "$TMP" "$TMP_ANALYSIS"
fi

cat <<'HTML'
<div class="pagebreak"></div>
<h2>How to Read This Report</h2>
<div class="explain"><b>Important:</b> The figures below should be used together. Signal strength explains the radio connection to the access point. Download speed shows available throughput. Latency and packet loss show stability. Packet loss is often the biggest risk for cloud-connected equipment.</div>
<h3>WiFi Signal Strength</h3>
<table class="legend">
<tr><th>Color</th><th>dBm range</th><th>Rating</th><th>Meaning for Matrix Fitness equipment and supported connected solutions</th></tr>
<tr><td><span class="swatch s-excellent"></span>Dark green</td><td>-30 to -55 dBm</td><td>Excellent</td><td>Excellent coverage. Suitable for connected consoles, streaming, updates and future expansion.</td></tr>
<tr><td><span class="swatch s-good"></span>Green</td><td>-56 to -65 dBm</td><td>Good</td><td>Good coverage. Suitable for normal operation.</td></tr>
<tr><td><span class="swatch s-fair"></span>Yellow</td><td>-66 to -72 dBm</td><td>Fair</td><td>Works, but less margin. Improve if equipment is permanently installed here.</td></tr>
<tr><td><span class="swatch s-poor"></span>Orange</td><td>-73 to -80 dBm</td><td>Poor</td><td>Risk of disconnects, slow updates or unstable cloud communication.</td></tr>
<tr><td><span class="swatch s-critical"></span>Red</td><td>Below -80 dBm</td><td>Critical</td><td>Not suitable. Add or reposition access points before installation.</td></tr>
</table>
<h3>Download Speed</h3>
<table class="legend">
<tr><th>Color</th><th>Measured Mbps</th><th>Rating</th><th>Practical interpretation</th></tr>
<tr><td><span class="swatch s-excellent"></span>Dark green</td><td>&gt; 50 Mbps</td><td>Excellent</td><td>Suitable for updates, HD streaming, Virtual Active/iFIT and larger deployments.</td></tr>
<tr><td><span class="swatch s-good"></span>Green</td><td>20 - 50 Mbps</td><td>Good</td><td>Suitable for normal operation and most updates.</td></tr>
<tr><td><span class="swatch s-fair"></span>Yellow</td><td>10 - 20 Mbps</td><td>Fair</td><td>Usable. Large updates and streaming may take longer.</td></tr>
<tr><td><span class="swatch s-poor"></span>Orange</td><td>5 - 10 Mbps</td><td>Poor</td><td>Basic connectivity may work, but update and media performance can be poor.</td></tr>
<tr><td><span class="swatch s-critical"></span>Red</td><td>&lt; 5 Mbps</td><td>Critical</td><td>Not recommended for reliable connected equipment.</td></tr>
</table>
<h3>Latency</h3>
<table class="legend">
<tr><th>Color</th><th>Average latency</th><th>Rating</th><th>Meaning</th></tr>
<tr><td><span class="swatch s-excellent"></span>Dark green</td><td>&lt; 20 ms</td><td>Excellent</td><td>Very responsive network. Low latency helps reliable communication with Matrix Fitness cloud services and other internet-connected devices and solutions supplied or supported by Matrix Fitness.</td></tr>
<tr><td><span class="swatch s-good"></span>Green</td><td>20 - 50 ms</td><td>Good</td><td>Good response time for Matrix Fitness equipment, cloud services and other supported internet-connected solutions.</td></tr>
<tr><td><span class="swatch s-fair"></span>Yellow</td><td>50 - 100 ms</td><td>Fair</td><td>Acceptable, but cloud communication, synchronization or internet-connected equipment responses can feel slower.</td></tr>
<tr><td><span class="swatch s-poor"></span>Orange</td><td>100 - 200 ms</td><td>Poor</td><td>Risk of slow responses, synchronization delays or timeout-sensitive communication issues.</td></tr>
<tr><td><span class="swatch s-critical"></span>Red</td><td>&gt; 200 ms</td><td>Critical</td><td>Not recommended until WAN/WiFi stability is improved.</td></tr>
</table>
<h3>Packet Loss</h3>
<table class="legend">
<tr><th>Color</th><th>Packet loss</th><th>Rating</th><th>Meaning</th></tr>
<tr><td><span class="swatch s-excellent"></span>Dark green</td><td>0%</td><td>Excellent</td><td>No loss detected. Very stable connection.</td></tr>
<tr><td><span class="swatch s-good"></span>Green</td><td>&lt; 1%</td><td>Good</td><td>Small loss. Usually acceptable.</td></tr>
<tr><td><span class="swatch s-fair"></span>Yellow</td><td>1 - 3%</td><td>Fair</td><td>Attention required. Can cause occasional cloud or sync problems.</td></tr>
<tr><td><span class="swatch s-poor"></span>Orange</td><td>3 - 5%</td><td>Poor</td><td>Unstable. Investigate interference, roaming, AP load or WAN issues.</td></tr>
<tr><td><span class="swatch s-critical"></span>Red</td><td>&gt; 5%</td><td>Critical</td><td>Not suitable. Packet loss must be fixed before installation.</td></tr>
</table>

<h2>WiFi Frequency Band Reference</h2>
<table>
<tr><th>Band</th><th>Advantages</th><th>Considerations</th></tr>
<tr><td><b>2.4 GHz</b></td><td>Greater range and better wall penetration</td><td>Lower throughput and more susceptible to interference</td></tr>
<tr><td><b>5 GHz</b></td><td>Higher throughput and reduced interference</td><td>Shorter range and reduced penetration through walls</td></tr>
<tr><td><b>6 GHz</b></td><td>Highest throughput and lowest interference</td><td>Requires compatible equipment and has the shortest range</td></tr>
</table>
<div class="note"><b>Important:</b><br><br>The survey assessment is based on measured network performance, signal quality, latency and packet loss. A strong and stable 2.4 GHz connection may provide better overall performance than a weak 5 GHz connection.<br><br>Where available, 5 GHz networks often provide higher throughput and reduced interference. However, connection suitability should always be determined by the measured performance and stability at the installation location.</div>
<h2>Survey Result Reference</h2>
<table>
<tr><th>Result</th><th>Meaning</th><th>Recommended action</th></tr>
<tr><td><span class="badge excellent">PASS</span></td><td>Location is suitable.</td><td>No network action required.</td></tr>
<tr><td><span class="badge fair">ATTENTION</span></td><td>Location works, but has less margin.</td><td>Improve if equipment will stay here permanently.</td></tr>
<tr><td><span class="badge critical">FAIL</span></td><td>Location is not suitable yet.</td><td>Fix WiFi, DNS, internet, Matrix Fitness Cloud Connectivity, latency or packet loss first.</td></tr>
</table>
<div class="note"><b>Installer note:</b> This is a practical field test. The download value is an estimate from the router over the currently connected WiFi/internet connection. For final network acceptance, combine this report with AP placement, channel planning and customer firewall rules.</div>
HTML

cat <<HTML
<div class="actions"><button onclick="window.print()">Save as PDF</button><button class="secondary" onclick="window.location='/cgi-bin/next_location.sh'">Back to Progress</button><button class="secondary" onclick="window.location='/location_survey.html'">New Survey</button></div>
<div class="footer"><img src="/matrix_logo.png" alt="Matrix Fitness"><div class="small" style="text-align:right;">$COMPANY<br>Created by $AUTHOR | $EMAIL<br>Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE</div></div>
</div></body></html>
HTML
