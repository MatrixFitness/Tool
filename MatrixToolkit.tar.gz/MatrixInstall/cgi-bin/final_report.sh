#!/bin/sh

echo "Content-Type: text/html"
echo ""

SURVEY_DIR="/usr/local/matrix/survey"
CSV="$SURVEY_DIR/wifi_survey_results.csv"

explain_signal(){
  case "$1" in
    Excellent) echo "Excellent coverage";;
    Good) echo "Good coverage";;
    Fair) echo "Acceptable but improve if possible";;
    Weak) echo "Weak coverage. Add AP or move equipment";;
    *) echo "No signal rating";;
  esac
}

explain_speed(){
  case "$1" in
    Excellent) echo "Excellent throughput";;
    Good) echo "Good throughput";;
    Fair) echo "Usable but slow for updates";;
    Weak) echo "Low throughput. Check WiFi or internet";;
    *) echo "No speed result";;
  esac
}

cat <<HTML
<html><head><title>Final WiFi Survey Report</title>
<style>body{font-family:Arial;margin:30px;background:#f5f5f5;color:#222}.card{background:white;max-width:1200px;padding:22px;border:1px solid #ccc;border-radius:8px}.explain{background:#eef6ff;border-left:4px solid #005a9c;padding:12px;margin:12px 0}table{border-collapse:collapse;width:100%;font-size:13px}td,th{border:1px solid #ccc;padding:7px;text-align:left;vertical-align:top}th{background:#005a9c;color:white}.ok{color:green;font-weight:bold}.warn{color:#b36b00;font-weight:bold}.bad{color:#b00020;font-weight:bold}button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:#005a9c;color:white;cursor:pointer}.secondary{background:#666}</style>
</head><body><div class="card"><h1>Final WiFi Survey Report</h1>
<div class="explain"><b>Report explanation:</b><br>This report combines signal strength with a practical download speed estimate and network quality. Signal strength tells how well the router receives WiFi. Download Mbps shows what the WiFi/internet connection actually delivers at that location. Latency and packet loss show stability. For Matrix connected equipment a stable connection is more important than only a high speed number.</div>
HTML

if [ ! -f "$CSV" ]; then
  echo "<p>No survey results found.</p>"
else
  echo "<table>"
  HEADER=1
  PASS_COUNT=0; ATT_COUNT=0; FAIL_COUNT=0; TOTAL=0
  while IFS=',' read -r DATE LOCATION SSID IP SIGNAL RATING QUALITY BITRATE INTERNET DNS MATRIX LATENCY PACKETLOSS DOWNLOAD SPEEDRATING QUALITYRATING OVERALL; do
    if [ "$HEADER" = "1" ]; then
      echo "<tr><th>Date</th><th>Location</th><th>Signal</th><th>Signal Rating</th><th>Download Mbps</th><th>Speed Rating</th><th>Latency</th><th>Packet Loss</th><th>Internet</th><th>DNS</th><th>Matrix</th><th>Overall</th><th>Explanation</th></tr>"
      HEADER=0
      continue
    fi
    TOTAL=$((TOTAL+1))
    [ "$OVERALL" = "PASS" ] && PASS_COUNT=$((PASS_COUNT+1))
    [ "$OVERALL" = "ATTENTION" ] && ATT_COUNT=$((ATT_COUNT+1))
    [ "$OVERALL" = "FAIL" ] && FAIL_COUNT=$((FAIL_COUNT+1))
    SIG_EXPL=$(explain_signal "$RATING")
    SPD_EXPL=$(explain_speed "$SPEEDRATING")
    CLASS="ok"; [ "$OVERALL" = "ATTENTION" ] && CLASS="warn"; [ "$OVERALL" = "FAIL" ] && CLASS="bad"
    echo "<tr><td>$DATE</td><td>$LOCATION</td><td>$SIGNAL dBm</td><td>$RATING</td><td>$DOWNLOAD</td><td>$SPEEDRATING</td><td>$LATENCY ms</td><td>$PACKETLOSS</td><td>$INTERNET</td><td>$DNS</td><td>$MATRIX</td><td class='$CLASS'>$OVERALL</td><td>$SIG_EXPL<br>$SPD_EXPL<br>Network quality: $QUALITYRATING</td></tr>"
  done < "$CSV"
  echo "</table>"
  echo "<h2>Summary</h2>"
  echo "<p><b>Total locations:</b> $TOTAL<br><b>Pass:</b> $PASS_COUNT<br><b>Attention:</b> $ATT_COUNT<br><b>Fail:</b> $FAIL_COUNT</p>"
  echo "<div class='explain'><b>Advice:</b><br>Locations marked PASS are suitable. Locations marked ATTENTION work but should be improved if equipment will stay there permanently. Locations marked FAIL should be fixed before installation by improving WiFi coverage reducing interference checking DNS/internet or validating Matrix cloud access.</div>"
fi

cat <<HTML
<br>
<button onclick="window.print()">Save as PDF</button>
<button class="secondary" onclick="window.location='/cgi-bin/next_location.sh'">Back to Progress</button>
<button class="secondary" onclick="window.location='/location_survey.html'">New Survey</button>
</div></body></html>
HTML
