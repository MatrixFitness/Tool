#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
EMAIL=$(grep '^Email=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

CSV="/tmp/wifi_survey_results.csv"

echo "<html>"
echo "<head>"
echo "<title>Customer WiFi Site Survey</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;background:#f5f5f5;}"
echo "h2,h3{color:#333;}"
echo "table{border-collapse:collapse;width:900px;background:white;margin-bottom:15px;}"
echo "th{background:#005a9c;color:white;padding:8px;text-align:left;}"
echo "td{border:1px solid #ccc;padding:8px;}"
echo ".bar{width:900px;height:34px;border:1px solid #333;background:linear-gradient(to right,#e74c3c 0%,#e67e22 20%,#f1c40f 40%,#7ed957 65%,#27ae60 100%);}"
echo "button{padding:10px 20px;font-size:14px;margin-right:10px;}"
echo "@media print { button { display:none; } body{background:white;} }"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Site Survey Report</h2>"

if [ ! -f "$CSV" ]
then
    echo "<p>No measurements saved.</p>"
    echo "<button onclick=\"window.location='/location_survey.html'\">Start Survey</button>"
    echo "</body></html>"
    exit 0
fi

echo "<h3>Saved Measurements</h3>"
echo "<table>"
echo "<tr>"
echo "<th>Date</th>"
echo "<th>Location</th>"
echo "<th>Signal</th>"
echo "<th>Rating</th>"
echo "<th>Internet</th>"
echo "<th>DNS</th>"
echo "<th>Matrix</th>"
echo "</tr>"

tail -n +2 "$CSV" | while IFS=',' read DATE LOCATION SIGNAL RATING INTERNET DNS MATRIX
do
    echo "<tr>"
    echo "<td>$DATE</td>"
    echo "<td>$LOCATION</td>"
    echo "<td>$SIGNAL dBm</td>"
    echo "<td>$RATING</td>"
    echo "<td>$INTERNET</td>"
    echo "<td>$DNS</td>"
    echo "<td>$MATRIX</td>"
    echo "</tr>"
done

echo "</table>"

BEST=$(grep -c ",Excellent," "$CSV")
GOOD=$(grep -c ",Good," "$CSV")
FAIR=$(grep -c ",Fair," "$CSV")
WEAK=$(grep -c ",Weak," "$CSV")

echo "<h3>Summary</h3>"
echo "<table>"
echo "<tr><td><b>Excellent</b></td><td>$BEST</td></tr>"
echo "<tr><td><b>Good</b></td><td>$GOOD</td></tr>"
echo "<tr><td><b>Fair</b></td><td>$FAIR</td></tr>"
echo "<tr><td><b>Weak</b></td><td>$WEAK</td></tr>"
echo "</table>"

if [ "$WEAK" -gt 0 ]
then
    OVERALL="Additional WiFi coverage is recommended in one or more tested locations."
elif [ "$FAIR" -gt 0 ]
then
    OVERALL="WiFi coverage is usable, but some locations could be improved for better reliability."
else
    OVERALL="WiFi coverage looks suitable for Matrix and EGYM connected equipment in the tested locations."
fi

echo "<h3>Overall Assessment</h3>"
echo "<table>"
echo "<tr><td><b>Assessment</b></td><td>$OVERALL</td></tr>"
echo "</table>"

echo "<h3>WiFi Signal Quality Scale</h3>"
echo "<div class='bar'></div>"
echo "<table style='width:900px;margin-top:5px;background:transparent;'>"
echo "<tr>"
echo "<td style='border:none;text-align:left'><b>-90</b></td>"
echo "<td style='border:none;text-align:center'><b>-80</b></td>"
echo "<td style='border:none;text-align:center'><b>-70</b></td>"
echo "<td style='border:none;text-align:center'><b>-60</b></td>"
echo "<td style='border:none;text-align:center'><b>-50</b></td>"
echo "<td style='border:none;text-align:right'><b>-30 dBm</b></td>"
echo "</tr>"
echo "</table>"

echo "<h3>WiFi Signal Reference</h3>"
echo "<table>"
echo "<tr><th>Signal</th><th>Quality</th><th>Description</th></tr>"

echo "<tr style='background:#27ae60;color:white'>"
echo "<td><b>-30 dBm</b></td>"
echo "<td><b>Maximum Signal</b></td>"
echo "<td>Perfect connection. You are likely standing right next to the router.</td>"
echo "</tr>"

echo "<tr style='background:#2ecc71;color:white'>"
echo "<td><b>-50 dBm</b></td>"
echo "<td><b>Excellent</b></td>"
echo "<td>Optimal for demanding activities such as 4K streaming and large downloads.</td>"
echo "</tr>"

echo "<tr style='background:#7ed957'>"
echo "<td><b>-60 dBm</b></td>"
echo "<td><b>Good</b></td>"
echo "<td>Reliable for streaming, video calls and connected fitness equipment.</td>"
echo "</tr>"

echo "<tr style='background:#f1c40f'>"
echo "<td><b>-67 dBm</b></td>"
echo "<td><b>Minimum Reliable</b></td>"
echo "<td>Lowest recommended reading for stable browsing and video conferences.</td>"
echo "</tr>"

echo "<tr style='background:#f39c12'>"
echo "<td><b>-70 dBm</b></td>"
echo "<td><b>Okay / Marginal</b></td>"
echo "<td>Basic use may work, but latency, buffering or delays may occur.</td>"
echo "</tr>"

echo "<tr style='background:#e67e22;color:white'>"
echo "<td><b>-80 dBm</b></td>"
echo "<td><b>Weak</b></td>"
echo "<td>Frequent dropouts, loading delays and buffering are expected.</td>"
echo "</tr>"

echo "<tr style='background:#e74c3c;color:white'>"
echo "<td><b>-90 dBm</b></td>"
echo "<td><b>Dead Zone</b></td>"
echo "<td>Connection is virtually unusable.</td>"
echo "</tr>"

echo "</table>"

echo "<br>"
echo "<button onclick='window.print()'>Save as PDF</button>"
echo "<button onclick=\"window.location='/location_survey.html'\">Continue Survey</button>"
echo "<button onclick=\"window.location='/cgi-bin/new_survey.sh'\">Start New Survey</button>"

echo "<br><br><hr>"
echo "<small>"
echo "Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE<br>"
echo "$COMPANY<br>"
echo "Created by $AUTHOR<br>"
echo "$EMAIL<br>"
echo "$MESSAGE"
echo "</small>"

echo "</body>"
echo "</html>"
