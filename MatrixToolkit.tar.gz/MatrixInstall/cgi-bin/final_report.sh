#!/bin/sh

echo "Content-Type: text/html"
echo ""

SURVEY_DIR="/usr/local/matrix/survey"
CSV="$SURVEY_DIR/wifi_survey_results.csv"

cat <<HTML
<html><head><title>Final WiFi Survey Report</title>
<style>body{font-family:Arial;margin:30px;background:#f5f5f5}.card{background:white;max-width:1000px;padding:22px;border:1px solid #ccc;border-radius:8px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{border:1px solid #ccc;padding:7px;text-align:left}th{background:#005a9c;color:white}button{padding:12px 18px;font-size:15px;margin:6px 8px 6px 0;border:0;border-radius:5px;background:#005a9c;color:white;cursor:pointer}.secondary{background:#666}</style>
</head><body><div class="card"><h1>Final WiFi Survey Report</h1>
HTML

if [ ! -f "$CSV" ]; then
  echo "<p>No survey results found.</p>"
else
  echo "<table>"
  HEADER=1
  while IFS=',' read -r DATE LOCATION SSID IP SIGNAL RATING QUALITY BITRATE INTERNET DNS MATRIX; do
    if [ "$HEADER" = "1" ]; then
      echo "<tr><th>Date</th><th>Location</th><th>SSID</th><th>IP</th><th>Signal</th><th>Rating</th><th>Quality</th><th>Bit Rate</th><th>Internet</th><th>DNS</th><th>Matrix</th></tr>"
      HEADER=0
      continue
    fi
    echo "<tr><td>$DATE</td><td>$LOCATION</td><td>$SSID</td><td>$IP</td><td>$SIGNAL</td><td>$RATING</td><td>$QUALITY</td><td>$BITRATE</td><td>$INTERNET</td><td>$DNS</td><td>$MATRIX</td></tr>"
  done < "$CSV"
  echo "</table>"
fi

cat <<HTML
<br>
<button onclick="window.print()">Save as PDF</button>
<button class="secondary" onclick="window.location='/cgi-bin/next_location.sh'">Back to Progress</button>
<button class="secondary" onclick="window.location='/location_survey.html'">New Survey</button>
</div></body></html>
HTML
