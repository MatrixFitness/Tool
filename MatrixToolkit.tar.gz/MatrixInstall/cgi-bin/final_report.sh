#!/bin/sh

echo "Content-Type: text/html"
echo ""

VERSION=$(grep '^Version=' /usr/local/matrix/version.txt | cut -d'=' -f2)
BUILD=$(grep '^Build=' /usr/local/matrix/version.txt | cut -d'=' -f2)
RELEASE=$(grep '^Release=' /usr/local/matrix/version.txt | cut -d'=' -f2)
AUTHOR=$(grep '^Author=' /usr/local/matrix/version.txt | cut -d'=' -f2)
COMPANY=$(grep '^Company=' /usr/local/matrix/version.txt | cut -d'=' -f2)
MESSAGE=$(grep '^Message=' /usr/local/matrix/version.txt | cut -d'=' -f2-)

CSV="/tmp/wifi_survey_results.csv"

echo "<html>"
echo "<head>"
echo "<title>Customer WiFi Site Survey</title>"
echo "<style>"
echo "body{font-family:Arial;margin:20px;}"
echo "table{border-collapse:collapse;width:900px;}"
echo "th{background:#005a9c;color:white;padding:8px;}"
echo "td{border:1px solid #ccc;padding:8px;}"
echo "</style>"
echo "</head>"
echo "<body>"

echo "<h2>Customer WiFi Site Survey Report</h2>"

if [ ! -f "$CSV" ]
then
    echo "<p>No measurements saved.</p>"
    echo "</body></html>"
    exit 0
fi

echo "<table>"
echo "<tr>"
echo "<th>Date</th>"
echo "<th>Location</th>"
echo "<th>Signal</th>"
echo "<th>Rating</th>"
echo "<th>Internet</th>"
echo "<th>DNS</th>"
echo "<th>Matrix</th>"
echo "</tr>"

tail -n +2 "$CSV" | while IFS=',' read DATE LOCATION SIGNAL RATING INTERNET DNS MATRIX
do
    echo "<tr>"
    echo "<td>$DATE</td>"
    echo "<td>$LOCATION</td>"
    echo "<td>$SIGNAL dBm</td>"
    echo "<td>$RATING</td>"
    echo "<td>$INTERNET</td>"
    echo "<td>$DNS</td>"
    echo "<td>$MATRIX</td>"
    echo "</tr>"
done

echo "</table>"

echo "<br>"

BEST=$(grep -c ",Excellent," "$CSV")
GOOD=$(grep -c ",Good," "$CSV")
FAIR=$(grep -c ",Fair," "$CSV")
WEAK=$(grep -c ",Weak," "$CSV")

echo "<h3>Summary</h3>"

echo "<table>"
echo "<tr><td>Excellent</td><td>$BEST</td></tr>"
echo "<tr><td>Good</td><td>$GOOD</td></tr>"
echo "<tr><td>Fair</td><td>$FAIR</td></tr>"
echo "<tr><td>Weak</td><td>$WEAK</td></tr>"
echo "</table>"

echo "<br>"

echo "<button onclick='window.print()'>Save as PDF</button>"

echo "<button onclick=\"window.location='/location_survey.html'\">Continue Survey</button>"

echo "<button onclick=\"window.location='/cgi-bin/new_survey.sh'\">Start New Survey</button>"

echo "<br><br><hr>"
echo "<small>"
echo "Matrix Toolkit v$VERSION | Build $BUILD | $RELEASE<br>"
echo "$COMPANY<br>"
echo "Created by $AUTHOR<br>"
echo "$MESSAGE"
echo "</small>"

echo "</body>"
echo "</html>"