#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ADMIN SESSION CHECK
# =====================================================
# Source this file at the top of sensitive CGI scripts:
# . /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0
# =====================================================

SESSION_DIR="/tmp/matrix_admin_sessions"
SESSION_TTL="28800" # 8 hours
COOKIE_NAME="MatrixAdminSession"
LOGIN_URL="/cgi-bin/admin_login.sh"

html_escape() {
    sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'
}

get_cookie_value() {
    echo "$HTTP_COOKIE" | tr ';' '\n' | sed 's/^ *//' | grep "^${COOKIE_NAME}=" | head -1 | cut -d= -f2-
}

redirect_login() {
    echo "Content-Type: text/html"
    echo "Cache-Control: no-cache, no-store, must-revalidate"
    echo "Pragma: no-cache"
    echo "Expires: 0"
    echo ""
    cat <<HTML
<html>
<head>
<title>Matrix Admin Login Required</title>
<meta http-equiv="refresh" content="0;url=${LOGIN_URL}">
<script>window.location='${LOGIN_URL}';</script>
</head>
<body style="font-family:Arial;margin:30px;">
<h2>Login required</h2>
<p><a href="${LOGIN_URL}">Open Matrix Admin Login</a></p>
</body>
</html>
HTML
}

SID="$(get_cookie_value)"

# Only allow simple token characters.
case "$SID" in
    ''|*[!A-Za-z0-9_-]*)
        redirect_login
        return 1 2>/dev/null || exit 1
        ;;
esac

SESSION_FILE="$SESSION_DIR/$SID"
if [ ! -f "$SESSION_FILE" ]; then
    redirect_login
    return 1 2>/dev/null || exit 1
fi

NOW="$(date +%s 2>/dev/null)"
CREATED="$(cat "$SESSION_FILE" 2>/dev/null)"
case "$NOW:$CREATED" in
    *[!0-9:]*|:*)
        rm -f "$SESSION_FILE" 2>/dev/null
        redirect_login
        return 1 2>/dev/null || exit 1
        ;;
esac

AGE=$((NOW - CREATED))
if [ "$AGE" -gt "$SESSION_TTL" ] 2>/dev/null; then
    rm -f "$SESSION_FILE" 2>/dev/null
    redirect_login
    return 1 2>/dev/null || exit 1
fi

# Refresh session timestamp on valid use.
echo "$NOW" > "$SESSION_FILE" 2>/dev/null
return 0 2>/dev/null || exit 0
