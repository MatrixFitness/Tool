#!/bin/sh

echo "Content-Type: text/html"
echo ""

STATUS=$(ubus call network.interface.wan status)

WANIP=$(echo "$STATUS" | grep '"address"' | head -1 | cut -d'"' -f4)
GATEWAY=$(echo "$STATUS" | grep '"nexthop"' | head -1 | cut -d'"' -f4)
DEVICE=$(echo "$STATUS" | grep '"device"' | head -1 | cut -d'"' -f4)
PROTO=$(echo "$STATUS" | grep '"proto"' | head -1 | cut -d'"' -f4)

DNS1=$(echo "$STATUS" | grep -A3 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '1p')
DNS2=$(echo "$STATUS" | grep -A3 '"dns-server"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | sed -n '2p')

UPTIME=$(echo "$STATUS" | grep '"uptime"' | grep -o '[0-9]*')

LANIP=$(ip addr show br-lan | grep "inet " | awk '{print $2}' | cut -d/ -f1)

HOURS=$((UPTIME / 3600))
MINS=$(((UPTIME % 3600) / 60))

if [ "$HOURS" -gt 0 ]
then
    UPTIME_TXT="${HOURS} uur ${MINS} min"
else
    UPTIME_TXT="${MINS} min"
fi

echo "<html>"
echo "<head>"
echo "<title>WAN Status</title>"
echo "</head>"
echo "<body style='font-family:Arial'>"

echo "<h1>WAN Status</h1>"

echo "<table border='1' cellpadding='6' cellspacing='0'>"
echo "<tr><td><b>WAN IP</b></td><td>$WANIP</td></tr>"
echo "<tr><td><b>Gateway</b></td><td>$GATEWAY</td></tr>"
echo "<tr><td><b>DNS 1</b></td><td>$DNS1</td></tr>"
echo "<tr><td><b>DNS 2</b></td><td>$DNS2</td></tr>"
echo "<tr><td><b>LAN IP</b></td><td>$LANIP</td></tr>"
echo "<tr><td><b>WAN Interface</b></td><td>$DEVICE</td></tr>"
echo "<tr><td><b>Protocol</b></td><td>$PROTO</td></tr>"
echo "<tr><td><b>WAN Uptime</b></td><td>$UPTIME_TXT</td></tr>"
echo "</table>"

echo "<br>"

if ping -c 3 8.8.8.8 >/dev/null 2>&1
then
    echo "<h2 style='color:green'>STATUS: GOEDGEKEURD</h2>"
    echo "<p>Internet bereikbaar</p>"
else
    echo "<h2 style='color:red'>STATUS: AFGEKEURD</h2>"
    echo "<p>Geen internetverbinding</p>"
fi

echo "</body>"
echo "</html>"