#!/bin/sh
# Matrix Network Installation Report v76
# Clean installer report. Raw command output only in Advanced section.

printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

get_value(){
    grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-
}

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"

VERSION="$(get_value Version)"
[ -z "$VERSION" ] && VERSION="76"

NOW="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"

WAN_IF="$(ip route show default 2>/dev/null | awk '{print $5; exit}')"
GW="$(ip route show default 2>/dev/null | awk '{print $3; exit}')"

# Sometimes Teltonika/OpenWrt outputs odd fields; validate gateway must look like an IP.
echo "$GW" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || GW=""

WAN_IP=""
[ -n "$WAN_IF" ] && WAN_IP="$(ip -4 addr show "$WAN_IF" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"

LAN_IP="$(ip -4 addr show br-lan 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
ZT_IF="$(ip link 2>/dev/null | awk -F': ' '/zt/{print $2; exit}')"
ZT_IP=""
[ -n "$ZT_IF" ] && ZT_IP="$(ip -4 addr show "$ZT_IF" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"

DNS_SERVERS="$(awk '/nameserver/{print $2}' /tmp/resolv.conf.d/resolv.conf.auto /etc/resolv.conf 2>/dev/null | sort -u | grep -v '^::1$' | tr '\n' ' ')"
[ -z "$DNS_SERVERS" ] && DNS_SERVERS="Unknown"

score=100
warnings=0
failures=0

decrease(){
    TYPE="$1"
    case "$TYPE" in
        small) score=$((score-3)) ;;
        warn) score=$((score-8)); warnings=$((warnings+1)) ;;
        fail) score=$((score-20)); failures=$((failures+1)) ;;
    esac
}

safe_num(){
    printf '%s' "$1" | sed 's/[^0-9.]//g'
}

ping_collect(){
    TARGET="$1"
    COUNT="$2"
    LABEL="$3"

    RAW="$(ping -c "$COUNT" -W 2 "$TARGET" 2>&1)"
    LOSS="$(printf '%s\n' "$RAW" | awk -F',' '/packet loss/{for(i=1;i<=NF;i++) if($i ~ /packet loss/){gsub(/[^0-9.]/,"",$i); print $i; exit}}')"
    [ -z "$LOSS" ] && LOSS="100"

    STATS_LINE="$(printf '%s\n' "$RAW" | awk -F'=' '/round-trip|rtt/{print $2; exit}')"
    MIN="-"; AVG="-"; MAX="-"; JITTER="-"

    if [ -n "$STATS_LINE" ]; then
        MIN="$(printf '%s' "$STATS_LINE" | awk -F'/' '{print $1}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        AVG="$(printf '%s' "$STATS_LINE" | awk -F'/' '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        MAX="$(printf '%s' "$STATS_LINE" | awk -F'/' '{print $3}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        MIN="$(safe_num "$MIN")"
        AVG="$(safe_num "$AVG")"
        MAX="$(safe_num "$MAX")"
        if [ -n "$MIN" ] && [ -n "$MAX" ]; then
            JITTER="$(awk -v max="$MAX" -v min="$MIN" 'BEGIN{printf "%.1f", max-min}')"
        fi
    fi

    [ -z "$MIN" ] && MIN="-"
    [ -z "$AVG" ] && AVG="-"
    [ -z "$MAX" ] && MAX="-"
    [ -z "$JITTER" ] && JITTER="-"

    printf '%s|%s|%s|%s|%s|%s|%s' "$LOSS" "$MIN" "$AVG" "$MAX" "$JITTER" "$LABEL" "$(printf '%s' "$RAW" | sed 's/|/ /g')"
}

latency_grade(){
    AVG="$1"
    if [ -z "$AVG" ] || [ "$AVG" = "-" ]; then echo "FAIL"; return; fi
    V="$(awk -v n="$AVG" 'BEGIN{printf "%.0f", n}')"
    if [ "$V" -le 20 ]; then echo "EXCELLENT"
    elif [ "$V" -le 40 ]; then echo "GOOD"
    elif [ "$V" -le 80 ]; then echo "ACCEPTABLE"
    else echo "POOR"; fi
}

loss_grade(){
    LOSS="$1"
    if [ -z "$LOSS" ]; then echo "FAIL"; return; fi
    V="$(awk -v n="$LOSS" 'BEGIN{printf "%.0f", n}')"
    if [ "$V" -eq 0 ]; then echo "EXCELLENT"
    elif [ "$V" -le 1 ]; then echo "WARNING"
    else echo "FAIL"; fi
}

jitter_grade(){
    J="$1"
    if [ -z "$J" ] || [ "$J" = "-" ]; then echo "UNKNOWN"; return; fi
    V="$(awk -v n="$J" 'BEGIN{printf "%.0f", n}')"
    if [ "$V" -le 3 ]; then echo "EXCELLENT"
    elif [ "$V" -le 8 ]; then echo "GOOD"
    elif [ "$V" -le 15 ]; then echo "WARNING"
    else echo "POOR"; fi
}

class_for(){
    case "$1" in
        EXCELLENT|GOOD|PASS|READY|OK) echo "ok" ;;
        ACCEPTABLE|WARNING|UNKNOWN|MANUAL|OPTIONAL) echo "warn" ;;
        *) echo "fail" ;;
    esac
}

apply_result(){
    case "$1" in
        EXCELLENT|PASS|READY|OK) ;;
        GOOD) decrease small ;;
        ACCEPTABLE|WARNING|UNKNOWN|MANUAL|OPTIONAL) decrease warn ;;
        POOR|FAIL|CRITICAL) decrease fail ;;
    esac
}

dns_check(){
    DOMAIN="$1"
    RAW="$(nslookup "$DOMAIN" 2>&1)"
    STATUS="FAIL"
    # Accept normal OpenWrt nslookup output if at least one Address line exists after a Name line.
    echo "$RAW" | grep -q "Name:" && echo "$RAW" | grep -q "Address" && STATUS="PASS"
    printf '%s|%s' "$STATUS" "$(printf '%s' "$RAW" | sed 's/|/ /g')"
}

mtu_check(){
    if ping -c1 -W2 -s 1472 -M do 8.8.8.8 >/dev/null 2>&1; then
        echo "1500|PASS|Standard MTU works"
    elif ping -c1 -W2 -s 1464 -M do 8.8.8.8 >/dev/null 2>&1; then
        echo "1492|WARNING|Reduced MTU / PPPoE possible"
    else
        echo "UNKNOWN|WARNING|Could not verify MTU"
    fi
}

# Run fast tests.
GW_RESULT=""
if [ -n "$GW" ]; then
    GW_RESULT="$(ping_collect "$GW" 5 "Gateway")"
else
    GW_RESULT="100|-|-|-|-|Gateway|No valid gateway found"
fi

INET_RESULT="$(ping_collect 8.8.8.8 10 "Internet")"
DNS_GOOGLE="$(dns_check google.com)"
DNS_MATRIX="$(dns_check matrixfitness.com)"
DNS_EGYM="$(dns_check egym.com)"
MTU_RESULT="$(mtu_check)"

# Parse gateway
GW_LOSS="$(printf '%s' "$GW_RESULT" | cut -d'|' -f1)"
GW_MIN="$(printf '%s' "$GW_RESULT" | cut -d'|' -f2)"
GW_AVG="$(printf '%s' "$GW_RESULT" | cut -d'|' -f3)"
GW_MAX="$(printf '%s' "$GW_RESULT" | cut -d'|' -f4)"
GW_JITTER="$(printf '%s' "$GW_RESULT" | cut -d'|' -f5)"
GW_RAW="$(printf '%s' "$GW_RESULT" | cut -d'|' -f7-)"

# Parse internet
INET_LOSS="$(printf '%s' "$INET_RESULT" | cut -d'|' -f1)"
INET_MIN="$(printf '%s' "$INET_RESULT" | cut -d'|' -f2)"
INET_AVG="$(printf '%s' "$INET_RESULT" | cut -d'|' -f3)"
INET_MAX="$(printf '%s' "$INET_RESULT" | cut -d'|' -f4)"
INET_JITTER="$(printf '%s' "$INET_RESULT" | cut -d'|' -f5)"
INET_RAW="$(printf '%s' "$INET_RESULT" | cut -d'|' -f7-)"

GW_LAT_GRADE="$(latency_grade "$GW_AVG")"
GW_LOSS_GRADE="$(loss_grade "$GW_LOSS")"
INET_LAT_GRADE="$(latency_grade "$INET_AVG")"
INET_LOSS_GRADE="$(loss_grade "$INET_LOSS")"
INET_JITTER_GRADE="$(jitter_grade "$INET_JITTER")"

DNS_GOOGLE_STATUS="$(printf '%s' "$DNS_GOOGLE" | cut -d'|' -f1)"
DNS_MATRIX_STATUS="$(printf '%s' "$DNS_MATRIX" | cut -d'|' -f1)"
DNS_EGYM_STATUS="$(printf '%s' "$DNS_EGYM" | cut -d'|' -f1)"
DNS_GOOGLE_RAW="$(printf '%s' "$DNS_GOOGLE" | cut -d'|' -f2-)"
DNS_MATRIX_RAW="$(printf '%s' "$DNS_MATRIX" | cut -d'|' -f2-)"
DNS_EGYM_RAW="$(printf '%s' "$DNS_EGYM" | cut -d'|' -f2-)"

MTU_VALUE="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f1)"
MTU_STATUS="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f2)"
MTU_TEXT="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f3-)"

apply_result "$GW_LAT_GRADE"
apply_result "$GW_LOSS_GRADE"
apply_result "$INET_LAT_GRADE"
apply_result "$INET_LOSS_GRADE"
apply_result "$INET_JITTER_GRADE"
apply_result "$DNS_GOOGLE_STATUS"
apply_result "$DNS_MATRIX_STATUS"
apply_result "$DNS_EGYM_STATUS"
apply_result "$MTU_STATUS"

[ "$score" -lt 0 ] && score=0

FINAL="READY"
FINAL_CLASS="ok"
FINAL_TEXT="Customer network is suitable for Matrix and EGYM equipment."
if [ "$score" -lt 90 ]; then
    FINAL="READY WITH NOTES"
    FINAL_CLASS="ok"
    FINAL_TEXT="Network is usable. Minor points should be checked if problems occur."
fi
if [ "$score" -lt 75 ]; then
    FINAL="ATTENTION REQUIRED"
    FINAL_CLASS="warn"
    FINAL_TEXT="Network has warnings. Investigate before final handover."
fi
if [ "$score" -lt 60 ]; then
    FINAL="NOT READY"
    FINAL_CLASS="fail"
    FINAL_TEXT="Network does not meet the recommended quality. Resolve issues before installation handover."
fi

box(){
    LABEL="$1"; VALUE="$2"; EXTRA="$3"
    cat <<EOF
<div class="metric">
  <div class="metric-label">$(html_escape "$LABEL")</div>
  <div class="metric-value">$(html_escape "$VALUE")</div>
  <div class="metric-extra">$(html_escape "$EXTRA")</div>
</div>
EOF
}

card_open(){
    TITLE="$1"; STATUS="$2"; CLASS="$3"; SUB="$4"
    cat <<EOF
<div class="test-card $CLASS">
  <div class="test-head">
    <div>
      <h3>$(html_escape "$TITLE")</h3>
      <p>$(html_escape "$SUB")</p>
    </div>
    <div class="badge $CLASS">$(html_escape "$STATUS")</div>
  </div>
  <div class="metric-grid">
EOF
}

card_close(){
    EXPLAIN="$1"; ACTION="$2"
    cat <<EOF
  </div>
  <details>
    <summary>Explanation and recommendation</summary>
    <div class="explain">
      <p><b>Meaning:</b> $(html_escape "$EXPLAIN")</p>
      <p><b>Action:</b> $(html_escape "$ACTION")</p>
    </div>
  </details>
</div>
EOF
}

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Network Installation Report</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333;--blue:#005a9c}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1280px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:white;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:white;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}
.cert{background:white;border:1px solid var(--border);border-radius:20px;box-shadow:var(--shadow);padding:20px;margin:18px 0;display:grid;grid-template-columns:240px 1fr;gap:18px;align-items:center}
.score-ring{border-radius:18px;background:#f8fafc;border:1px solid var(--border);padding:18px;text-align:center}
.score{font-size:44px;font-weight:900;line-height:1}.score small{font-size:18px;color:var(--muted)}.status{font-size:24px;font-weight:900;margin:0 0 8px}.status.ok{color:var(--ok)}.status.warn{color:var(--warn)}.status.fail{color:var(--fail)}
.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}.sum-card{background:white;border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow);padding:15px}.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}.value{margin-top:8px;font-size:18px;font-weight:800;word-break:break-word}
.tests{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.test-card{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:15px;border-top:6px solid var(--ok)}.test-card.warn{border-top-color:var(--warn)}.test-card.fail{border-top-color:var(--fail)}
.test-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.test-card h3{margin:0;font-size:18px}.test-card p{margin:5px 0 0;color:var(--muted);font-size:13px;line-height:1.35}
.badge{border-radius:999px;padding:6px 10px;color:white;font-size:12px;font-weight:800;background:var(--ok);white-space:nowrap}.badge.warn{background:var(--warn)}.badge.fail{background:var(--fail)}
.metric-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:12px}.metric{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:11px}.metric-label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:800}.metric-value{font-size:18px;font-weight:900;margin-top:5px}.metric-extra{font-size:12px;color:var(--muted);margin-top:3px}
details{margin-top:12px}summary{cursor:pointer;color:#0d3b66;font-weight:800}.explain{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:12px;margin-top:9px;line-height:1.45;color:#344054}
.section{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:16px;margin:16px 0}.section h2{margin:0 0 12px;color:#0d3b66}.bigtable{width:100%;border-collapse:collapse}.bigtable td,.bigtable th{border:1px solid var(--border);padding:9px;text-align:left}.bigtable th{background:#f0f6fb}
pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px}
@media(max-width:1000px){.cert{grid-template-columns:1fr}.summary{grid-template-columns:repeat(2,1fr)}.tests{grid-template-columns:1fr}}
@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.summary{grid-template-columns:1fr}.metric-grid{grid-template-columns:1fr}.btn{width:100%;text-align:center}.test-head{display:block}.badge{display:inline-block;margin-top:10px}}
</style>
</head>
<body>
<div class="page">
  <div class="hero">
    <div>
      <h1>Matrix Network Installation Report</h1>
      <div class="sub">WAN quality certification for Matrix & EGYM</div>
    </div>
    <a class="btn" href="/">Back to Toolkit</a>
  </div>

  <div class="cert">
    <div class="score-ring">
      <div class="score">$(html_escape "$score")<small>/100</small></div>
      <div class="label">Network Score</div>
    </div>
    <div>
      <div class="status $FINAL_CLASS">$(html_escape "$FINAL")</div>
      <p><b>Final verdict:</b> $(html_escape "$FINAL_TEXT")</p>
      <p><b>Router:</b> $(html_escape "$HOST") &nbsp; <b>Report time:</b> $(html_escape "$NOW")</p>
    </div>
  </div>

  <div class="summary">
    <div class="sum-card"><div class="label">WAN Interface</div><div class="value">$(html_escape "$WAN_IF")</div></div>
    <div class="sum-card"><div class="label">WAN IP</div><div class="value">$(html_escape "$WAN_IP")</div></div>
    <div class="sum-card"><div class="label">Gateway</div><div class="value">$(html_escape "$GW")</div></div>
    <div class="sum-card"><div class="label">DNS</div><div class="value">$(html_escape "$DNS_SERVERS")</div></div>
  </div>

  <div class="tests">
EOF

C="$(class_for "$GW_LAT_GRADE")"
card_open "Gateway Test" "$GW_LAT_GRADE" "$C" "Local path between router and customer gateway."
box "Average" "${GW_AVG} ms" "Target: $GW"
box "Min / Max" "${GW_MIN} / ${GW_MAX} ms" "Local latency"
box "Packet Loss" "${GW_LOSS}%" "$GW_LOSS_GRADE"
box "Jitter" "${GW_JITTER} ms" "Latency variation"
card_close "The gateway is the first device on the customer network. It should normally respond below 2 ms with 0% packet loss." "If this fails, check cable, switch port, VLAN, modem/router or local customer network."

C="$(class_for "$INET_LAT_GRADE")"
card_open "Internet Latency" "$INET_LAT_GRADE" "$C" "Delay between router and public internet."
box "Average" "${INET_AVG} ms" "Target: 8.8.8.8"
box "Min / Max" "${INET_MIN} / ${INET_MAX} ms" "Internet latency"
box "Result" "$INET_LAT_GRADE" "Lower is better"
box "Impact" "Cloud sync" "Login, updates and remote support"
card_close "This measures how quickly the router reaches the internet. Low latency improves cloud sync, login and remote services." "If latency is high, check ISP, firewall, router load or LTE signal quality."

C="$(class_for "$INET_LOSS_GRADE")"
card_open "Packet Loss" "$INET_LOSS_GRADE" "$C" "Checks whether packets disappear."
box "Loss" "${INET_LOSS}%" "Target: 8.8.8.8"
box "Packets" "10" "Fast test"
box "Result" "$INET_LOSS_GRADE" "0% is expected"
box "Risk" "Disconnects" "Sync and update failures"
card_close "Packet loss is more serious than high latency. Even fast internet becomes unreliable when packets are lost." "If loss is detected, check ISP, cables, switches, WiFi backhaul, firewall load or LTE signal."

C="$(class_for "$INET_JITTER_GRADE")"
card_open "Jitter" "$INET_JITTER_GRADE" "$C" "Checks if latency is stable."
box "Jitter" "${INET_JITTER} ms" "Max minus min"
box "Min latency" "${INET_MIN} ms" "Best response"
box "Max latency" "${INET_MAX} ms" "Worst response"
box "Result" "$INET_JITTER_GRADE" "Stable is better"
card_close "Jitter means latency variation. Stable latency is important for cloud communication and remote support." "If jitter is high, check congestion, WiFi interference, LTE signal or overloaded network equipment."

DNS_OVERALL="PASS"
[ "$DNS_GOOGLE_STATUS" = "PASS" ] && [ "$DNS_MATRIX_STATUS" = "PASS" ] && [ "$DNS_EGYM_STATUS" = "PASS" ] || DNS_OVERALL="WARNING"
C="$(class_for "$DNS_OVERALL")"
card_open "DNS Lookup" "$DNS_OVERALL" "$C" "Checks if cloud names resolve."
box "Google" "$DNS_GOOGLE_STATUS" "google.com"
box "Matrix" "$DNS_MATRIX_STATUS" "matrixfitness.com"
box "EGYM" "$DNS_EGYM_STATUS" "egym.com"
box "Servers" "$DNS_SERVERS" "Configured DNS"
card_close "DNS translates names into IP addresses. If DNS fails, cloud services may not connect even when ping works." "Use reliable DNS servers and check customer firewall DNS rules."

C="$(class_for "$MTU_STATUS")"
card_open "MTU Test" "$MTU_STATUS" "$C" "Checks if normal packet size works."
box "Detected" "$MTU_VALUE" "MTU result"
box "Status" "$MTU_STATUS" "$MTU_TEXT"
box "Normal" "1500" "Standard ethernet"
box "PPPoE" "1492" "Often acceptable"
card_close "MTU controls packet size. Wrong MTU can cause strange HTTPS, VPN or cloud issues." "1500 is normal. 1492 is common on PPPoE. If unknown, investigate only if VPN/cloud issues occur."

card_open "Speed Test" "MANUAL" "warn" "Not run automatically."
box "Status" "Skipped" "Fast report mode"
box "Why" "Can hang" "Teltonika routers"
box "Run when" "Needed" "Bandwidth suspected"
box "Command" "speedtest" "Manual CLI"
card_close "Bandwidth is useful for updates and multiple devices, but this fast report avoids long blocking speedtests." "Run speedtest manually if the customer complains about slow downloads or updates."

card_open "Long Stability Test" "OPTIONAL" "warn" "Not run automatically."
box "Fast test" "10 pings" "This report"
box "Deep test" "100 pings" "Manual"
box "Use for" "Intermittent issues" "Random disconnects"
box "Command" "ping -c 100 8.8.8.8" "CLI"
card_close "A longer test helps find intermittent packet loss or unstable internet." "Use this when customer reports random offline or sync issues."

cat <<EOF
  </div>

  <div class="section">
    <h2>Installer Summary</h2>
    <table class="bigtable">
      <tr><th>Area</th><th>Measured values</th><th>Result</th></tr>
      <tr><td>Gateway</td><td>avg ${GW_AVG} ms, loss ${GW_LOSS}%</td><td>$GW_LAT_GRADE / $GW_LOSS_GRADE</td></tr>
      <tr><td>Internet</td><td>avg ${INET_AVG} ms, min ${INET_MIN} ms, max ${INET_MAX} ms</td><td>$INET_LAT_GRADE</td></tr>
      <tr><td>Packet Loss</td><td>${INET_LOSS}%</td><td>$INET_LOSS_GRADE</td></tr>
      <tr><td>Jitter</td><td>${INET_JITTER} ms</td><td>$INET_JITTER_GRADE</td></tr>
      <tr><td>DNS</td><td>Google $DNS_GOOGLE_STATUS, Matrix $DNS_MATRIX_STATUS, EGYM $DNS_EGYM_STATUS</td><td>$DNS_OVERALL</td></tr>
      <tr><td>MTU</td><td>$MTU_VALUE - $MTU_TEXT</td><td>$MTU_STATUS</td></tr>
    </table>
  </div>

  <details class="section">
    <summary><b>Advanced Diagnostics</b></summary>
    <h2>Gateway Ping</h2><pre>$(html_escape "$GW_RAW")</pre>
    <h2>Internet Ping 8.8.8.8</h2><pre>$(html_escape "$INET_RAW")</pre>
    <h2>DNS Google</h2><pre>$(html_escape "$DNS_GOOGLE_RAW")</pre>
    <h2>DNS Matrix</h2><pre>$(html_escape "$DNS_MATRIX_RAW")</pre>
    <h2>DNS EGYM</h2><pre>$(html_escape "$DNS_EGYM_RAW")</pre>
  </details>
</div>
</body>
</html>
EOF
