#!/bin/sh
printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"
VERSION="$(get_value Version)"
[ -z "$VERSION" ] && VERSION="75"

WAN_IF="$(ip route 2>/dev/null | awk '/default/{print $5; exit}')"
GW="$(ip route 2>/dev/null | awk '/default/{print $3; exit}')"
WAN_IP="$(ip -4 addr show "$WAN_IF" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
DNS_SERVERS="$(awk '/nameserver/{print $2}' /tmp/resolv.conf.d/resolv.conf.auto /etc/resolv.conf 2>/dev/null | sort -u | tr '\n' ' ')"
[ -z "$DNS_SERVERS" ] && DNS_SERVERS="Unknown"

score=100
warn_count=0
fail_count=0

grade_latency(){ V="$1"; [ -z "$V" ] && echo "UNKNOWN" && return; VINT="$(printf "%.0f" "$V" 2>/dev/null)"; if [ "$VINT" -le 20 ]; then echo "EXCELLENT"; elif [ "$VINT" -le 40 ]; then echo "GOOD"; elif [ "$VINT" -le 80 ]; then echo "ACCEPTABLE"; else echo "POOR"; fi; }
grade_loss(){ V="$1"; [ -z "$V" ] && echo "UNKNOWN" && return; VINT="$(printf "%.0f" "$V" 2>/dev/null)"; if [ "$VINT" -eq 0 ]; then echo "EXCELLENT"; elif [ "$VINT" -le 1 ]; then echo "WARNING"; else echo "FAIL"; fi; }
grade_jitter(){ V="$1"; [ -z "$V" ] && echo "UNKNOWN" && return; VINT="$(printf "%.0f" "$V" 2>/dev/null)"; if [ "$VINT" -le 3 ]; then echo "EXCELLENT"; elif [ "$VINT" -le 8 ]; then echo "GOOD"; elif [ "$VINT" -le 15 ]; then echo "WARNING"; else echo "POOR"; fi; }
score_status(){ case "$1" in EXCELLENT|GOOD|PASS|OK) echo "ok";; ACCEPTABLE|WARNING|UNKNOWN|INFO) echo "warn";; *) echo "fail";; esac; }
apply_score(){ case "$1" in EXCELLENT|PASS|OK) ;; GOOD) score=$((score-3));; ACCEPTABLE|WARNING|UNKNOWN) score=$((score-8)); warn_count=$((warn_count+1));; POOR|FAIL) score=$((score-18)); fail_count=$((fail_count+1));; esac; }

ping_stats(){
    TARGET="$1"; COUNT="$2"
    OUT="$(ping -c "$COUNT" -W 2 "$TARGET" 2>&1)"
    LOSS="$(printf '%s' "$OUT" | sed -n 's/.* \([0-9.]*\)% packet loss.*/\1/p' | head -n1)"
    AVG="$(printf '%s' "$OUT" | awk -F'/' '/round-trip|rtt/{print $5; exit}')"
    MIN="$(printf '%s' "$OUT" | awk -F'/' '/round-trip|rtt/{print $4; exit}')"
    MAX="$(printf '%s' "$OUT" | awk -F'/' '/round-trip|rtt/{print $6; exit}')"
    [ -z "$LOSS" ] && LOSS="100"; [ -z "$AVG" ] && AVG=""; [ -z "$MIN" ] && MIN=""; [ -z "$MAX" ] && MAX=""
    JITTER=""; [ -n "$MIN" ] && [ -n "$MAX" ] && JITTER="$(awk -v max="$MAX" -v min="$MIN" 'BEGIN{printf "%.1f", max-min}')"
    printf '%s|%s|%s|%s|%s|%s' "$LOSS" "$MIN" "$AVG" "$MAX" "$JITTER" "$(printf '%s' "$OUT" | sed 's/|/ /g')"
}

dns_test(){
    DOMAIN="$1"; OUT="$(nslookup "$DOMAIN" 2>&1)"; STATUS="FAIL"; echo "$OUT" | grep -q "Address" && STATUS="PASS"; printf '%s|%s' "$STATUS" "$(printf '%s' "$OUT" | sed 's/|/ /g')"
}

mtu_test(){
    if ping -c1 -W2 -s 1472 -M do 8.8.8.8 >/dev/null 2>&1; then echo "1500|PASS|Standard 1500 MTU works"
    elif ping -c1 -W2 -s 1464 -M do 8.8.8.8 >/dev/null 2>&1; then echo "1492|WARNING|Likely PPPoE or reduced MTU"
    else echo "UNKNOWN|WARNING|MTU test not conclusive"; fi
}

GATEWAY_RESULT=""; [ -n "$GW" ] && GATEWAY_RESULT="$(ping_stats "$GW" 20)"
INET1_RESULT="$(ping_stats 8.8.8.8 20)"
INET2_RESULT="$(ping_stats 1.1.1.1 20)"
LOSS_RESULT="$(ping_stats 8.8.8.8 100)"
DNS_GOOGLE="$(dns_test google.com)"
DNS_MATRIX="$(dns_test matrixfitness.com)"
DNS_EGYM="$(dns_test egym.com)"
MTU_RESULT="$(mtu_test)"
ROUTE_OUT="$(traceroute -m 8 8.8.8.8 2>&1)"
SPEED_OUT="speedtest command not installed on this router."; SPEED_STATUS="UNKNOWN"; SPEED_DL=""; SPEED_UL=""; SPEED_PING=""
if command -v speedtest >/dev/null 2>&1; then
    SPEED_OUT="$(speedtest 2>&1)"; SPEED_STATUS="AVAILABLE"
    SPEED_DL="$(printf '%s' "$SPEED_OUT" | sed -n 's/.*Download:[[:space:]]*\([^ ]* [A-Za-z/]*\).*/\1/p' | head -n1)"
    SPEED_UL="$(printf '%s' "$SPEED_OUT" | sed -n 's/.*Upload:[[:space:]]*\([^ ]* [A-Za-z/]*\).*/\1/p' | head -n1)"
    SPEED_PING="$(printf '%s' "$SPEED_OUT" | sed -n 's/.*Latency:[[:space:]]*\([^ ]* ms\).*/\1/p' | head -n1)"
fi

INET_LOSS="$(printf '%s' "$INET1_RESULT" | cut -d'|' -f1)"; INET_MIN="$(printf '%s' "$INET1_RESULT" | cut -d'|' -f2)"; INET_AVG="$(printf '%s' "$INET1_RESULT" | cut -d'|' -f3)"; INET_MAX="$(printf '%s' "$INET1_RESULT" | cut -d'|' -f4)"; INET_JITTER="$(printf '%s' "$INET1_RESULT" | cut -d'|' -f5)"
INET_LAT_GRADE="$(grade_latency "$INET_AVG")"; INET_LOSS_GRADE="$(grade_loss "$INET_LOSS")"; INET_JITTER_GRADE="$(grade_jitter "$INET_JITTER")"
apply_score "$INET_LAT_GRADE"; apply_score "$INET_LOSS_GRADE"; apply_score "$INET_JITTER_GRADE"
GW_LOSS="$(printf '%s' "$GATEWAY_RESULT" | cut -d'|' -f1)"; GW_AVG="$(printf '%s' "$GATEWAY_RESULT" | cut -d'|' -f3)"; GW_JITTER="$(printf '%s' "$GATEWAY_RESULT" | cut -d'|' -f5)"
GW_LAT_GRADE="$(grade_latency "$GW_AVG")"; GW_LOSS_GRADE="$(grade_loss "$GW_LOSS")"; apply_score "$GW_LAT_GRADE"; apply_score "$GW_LOSS_GRADE"
DNS_GOOGLE_STATUS="$(printf '%s' "$DNS_GOOGLE" | cut -d'|' -f1)"; DNS_MATRIX_STATUS="$(printf '%s' "$DNS_MATRIX" | cut -d'|' -f1)"; DNS_EGYM_STATUS="$(printf '%s' "$DNS_EGYM" | cut -d'|' -f1)"
[ "$DNS_GOOGLE_STATUS" = "PASS" ] || apply_score "FAIL"; [ "$DNS_MATRIX_STATUS" = "PASS" ] || apply_score "WARNING"; [ "$DNS_EGYM_STATUS" = "PASS" ] || apply_score "WARNING"
MTU_VALUE="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f1)"; MTU_STATUS="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f2)"; MTU_TEXT="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f3)"; apply_score "$MTU_STATUS"
[ "$score" -lt 0 ] && score=0
FINAL="EXCELLENT"; FINAL_CLASS="ok"; FINAL_TEXT="Network is suitable for Matrix and EGYM installation."
[ "$score" -lt 90 ] && FINAL="GOOD" && FINAL_CLASS="ok" && FINAL_TEXT="Network looks usable. Minor points should be checked if problems occur."
[ "$score" -lt 75 ] && FINAL="ATTENTION" && FINAL_CLASS="warn" && FINAL_TEXT="Network is usable but has warnings. Investigate before final handover."
[ "$score" -lt 60 ] && FINAL="POOR" && FINAL_CLASS="fail" && FINAL_TEXT="Network quality is not reliable enough. Customer network or ISP should be checked."

card(){
TITLE="$1"; VALUE="$2"; CLASS="$3"; TEXT="$4"; EXPLAIN="$5"
cat <<EOF
<div class="test-card"><div class="test-head"><div><h3>$(html_escape "$TITLE")</h3><p>$(html_escape "$TEXT")</p></div><div class="badge $CLASS">$(html_escape "$VALUE")</div></div><details><summary>What does this mean?</summary><div class="explain">$(html_escape "$EXPLAIN")</div></details></div>
EOF
}

cat <<EOF
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>WAN Quality Test</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}.page{max-width:1280px;margin:0 auto;padding:18px}.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:white;border-radius:18px;padding:20px 22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}.hero h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:white;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}.summary{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:18px 0}.sum-card{background:white;border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow);padding:15px}.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}.value{margin-top:8px;font-size:20px;font-weight:800;word-break:break-word}.ok{color:var(--ok)}.warn{color:var(--warn)}.fail{color:var(--fail)}.verdict{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin:16px 0;border-left:9px solid var(--ok)}.verdict.warn{border-left-color:var(--warn)}.verdict.fail{border-left-color:var(--fail)}.verdict h2{margin:0 0 6px;font-size:26px}.tests{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.test-card{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:15px}.test-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.test-card h3{margin:0;font-size:18px}.test-card p{margin:5px 0 0;color:var(--muted);font-size:13px;line-height:1.35}.badge{border-radius:999px;padding:6px 10px;color:white;font-size:12px;font-weight:800;background:var(--ok);white-space:nowrap}.badge.warn{background:var(--warn)}.badge.fail{background:var(--fail)}details{margin-top:12px}summary{cursor:pointer;color:#0d3b66;font-weight:800}.explain{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:12px;margin-top:9px;line-height:1.45;color:#344054}.section{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:16px;margin:16px 0}.section h2{margin:0 0 12px;color:#0d3b66}pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px}table{width:100%;border-collapse:collapse}td,th{border:1px solid var(--border);padding:9px;text-align:left}th{background:#f0f6fb}@media(max-width:1000px){.summary{grid-template-columns:repeat(2,1fr)}.tests{grid-template-columns:1fr}}@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.summary{grid-template-columns:1fr}.btn{width:100%;text-align:center}.test-head{display:block}.badge{display:inline-block;margin-top:10px}}
</style></head><body><div class="page"><div class="hero"><div><h1>WAN Quality Test</h1><div class="sub">Matrix & EGYM internet quality report for $(html_escape "$HOST")</div></div><a class="btn" href="/">Back to Toolkit</a></div>
<div class="summary"><div class="sum-card"><div class="label">Score</div><div class="value $FINAL_CLASS">$(html_escape "$score") / 100</div></div><div class="sum-card"><div class="label">WAN Interface</div><div class="value">$(html_escape "$WAN_IF")</div></div><div class="sum-card"><div class="label">WAN IP</div><div class="value">$(html_escape "$WAN_IP")</div></div><div class="sum-card"><div class="label">Gateway</div><div class="value">$(html_escape "$GW")</div></div><div class="sum-card"><div class="label">DNS</div><div class="value">$(html_escape "$DNS_SERVERS")</div></div></div>
<div class="verdict $FINAL_CLASS"><h2>$(html_escape "$FINAL")</h2><p><b>Final verdict:</b> $(html_escape "$FINAL_TEXT")</p></div><div class="tests">
EOF
card "Gateway Latency" "$GW_LAT_GRADE" "$(score_status "$GW_LAT_GRADE")" "Average: ${GW_AVG:-unknown} ms, loss: ${GW_LOSS:-unknown}%" "This checks the local customer gateway. If this is bad, the problem is local: cable, switch, modem, VLAN or customer network."
card "Internet Latency" "$INET_LAT_GRADE" "$(score_status "$INET_LAT_GRADE")" "Average: ${INET_AVG:-unknown} ms, min: ${INET_MIN:-unknown}, max: ${INET_MAX:-unknown}" "This measures how quickly the router reaches the internet. High latency can cause slow cloud communication, delayed sync and unstable updates."
card "Packet Loss" "$INET_LOSS_GRADE" "$(score_status "$INET_LOSS_GRADE")" "Loss to 8.8.8.8: ${INET_LOSS:-unknown}%" "Packet loss means data disappears during transmission. Even a fast connection becomes unreliable with packet loss."
card "Jitter" "$INET_JITTER_GRADE" "$(score_status "$INET_JITTER_GRADE")" "Jitter: ${INET_JITTER:-unknown} ms" "Jitter measures stability. If latency jumps up and down, cloud services can behave unstable."
card "DNS Lookup" "$DNS_GOOGLE_STATUS" "$(score_status "$DNS_GOOGLE_STATUS")" "Google: $DNS_GOOGLE_STATUS, Matrix: $DNS_MATRIX_STATUS, EGYM: $DNS_EGYM_STATUS" "DNS translates names into IP addresses. Slow or failing DNS can stop Matrix or EGYM cloud services from connecting."
card "MTU Test" "$MTU_STATUS" "$(score_status "$MTU_STATUS")" "Detected: $MTU_VALUE - $MTU_TEXT" "MTU controls packet size. Wrong MTU can break VPN, HTTPS or cloud traffic in strange ways."
card "Speed Test" "$SPEED_STATUS" "$(score_status "$SPEED_STATUS")" "Download: ${SPEED_DL:-unknown}, Upload: ${SPEED_UL:-unknown}, Latency: ${SPEED_PING:-unknown}" "Bandwidth matters for updates, media and multiple devices. If speedtest is unavailable, install or enable the speedtest package."
card "Route Test" "INFO" "warn" "Traceroute to 8.8.8.8 completed" "Traceroute shows where traffic goes and helps identify if latency starts locally, at the ISP, or further on the internet."
cat <<EOF
</div><div class="section"><h2>Detailed Results</h2><table><tr><th>Test</th><th>Value</th><th>Result</th></tr><tr><td>Gateway</td><td>avg ${GW_AVG:-unknown} ms, loss ${GW_LOSS:-unknown}%</td><td>$GW_LAT_GRADE / $GW_LOSS_GRADE</td></tr><tr><td>Internet 8.8.8.8</td><td>avg ${INET_AVG:-unknown} ms, jitter ${INET_JITTER:-unknown} ms, loss ${INET_LOSS:-unknown}%</td><td>$INET_LAT_GRADE / $INET_JITTER_GRADE / $INET_LOSS_GRADE</td></tr><tr><td>DNS</td><td>Google $DNS_GOOGLE_STATUS, Matrix $DNS_MATRIX_STATUS, EGYM $DNS_EGYM_STATUS</td><td>See cards</td></tr><tr><td>MTU</td><td>$MTU_VALUE</td><td>$MTU_STATUS</td></tr><tr><td>Speedtest</td><td>${SPEED_DL:-unknown} down / ${SPEED_UL:-unknown} up</td><td>$SPEED_STATUS</td></tr></table></div>
<details class="section"><summary><b>Advanced Raw Output</b></summary><h2>Ping 8.8.8.8</h2><pre>$(html_escape "$(printf '%s' "$INET1_RESULT" | cut -d'|' -f6-)")</pre><h2>Packet Loss 100 ping test</h2><pre>$(html_escape "$(printf '%s' "$LOSS_RESULT" | cut -d'|' -f6-)")</pre><h2>Traceroute</h2><pre>$(html_escape "$ROUTE_OUT")</pre><h2>Speedtest</h2><pre>$(html_escape "$SPEED_OUT")</pre></details></div></body></html>
EOF
