#!/bin/sh
# Matrix WAN Quality Test v75.2
# Readable version: clean values in cards, raw output only in Advanced.

printf "Content-Type: text/html; charset=UTF-8\n\n"

html_escape(){ printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
get_value(){ grep "^$1=" /usr/local/matrix/version.txt 2>/dev/null | cut -d= -f2-; }

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="MatrixRouter"

VERSION="$(get_value Version)"
[ -z "$VERSION" ] && VERSION="75.2"

WAN_IF="$(ip route 2>/dev/null | awk '/default/{print $5; exit}')"
GW="$(ip route 2>/dev/null | awk '/default/{print $3; exit}')"
WAN_IP="$(ip -4 addr show "$WAN_IF" 2>/dev/null | awk '/inet /{split($2,a,"/"); print a[1]; exit}')"
DNS_SERVERS="$(awk '/nameserver/{print $2}' /tmp/resolv.conf.d/resolv.conf.auto /etc/resolv.conf 2>/dev/null | sort -u | tr '\n' ' ')"
[ -z "$DNS_SERVERS" ] && DNS_SERVERS="Unknown"

score=100

grade_latency(){
    V="$1"
    [ -z "$V" ] && echo "UNKNOWN" && return
    VINT="$(printf "%.0f" "$V" 2>/dev/null)"
    if [ "$VINT" -le 20 ]; then echo "EXCELLENT"
    elif [ "$VINT" -le 40 ]; then echo "GOOD"
    elif [ "$VINT" -le 80 ]; then echo "ACCEPTABLE"
    else echo "POOR"; fi
}
grade_loss(){
    V="$1"
    [ -z "$V" ] && echo "UNKNOWN" && return
    VINT="$(printf "%.0f" "$V" 2>/dev/null)"
    if [ "$VINT" -eq 0 ]; then echo "EXCELLENT"
    elif [ "$VINT" -le 1 ]; then echo "WARNING"
    else echo "FAIL"; fi
}
grade_jitter(){
    V="$1"
    [ -z "$V" ] && echo "UNKNOWN" && return
    VINT="$(printf "%.0f" "$V" 2>/dev/null)"
    if [ "$VINT" -le 3 ]; then echo "EXCELLENT"
    elif [ "$VINT" -le 8 ]; then echo "GOOD"
    elif [ "$VINT" -le 15 ]; then echo "WARNING"
    else echo "POOR"; fi
}
css_class(){
    case "$1" in EXCELLENT|GOOD|PASS|OK) echo "ok";; ACCEPTABLE|WARNING|UNKNOWN|INFO|MANUAL|OPTIONAL) echo "warn";; *) echo "fail";; esac
}
apply_score(){
    case "$1" in
        EXCELLENT|PASS|OK) ;;
        GOOD) score=$((score-3)) ;;
        ACCEPTABLE|WARNING|UNKNOWN|MANUAL|OPTIONAL) score=$((score-8)) ;;
        POOR|FAIL) score=$((score-18)) ;;
    esac
}

ping_stats(){
    TARGET="$1"
    COUNT="$2"
    OUT="$(ping -c "$COUNT" -W 2 "$TARGET" 2>&1)"
    LOSS="$(printf '%s' "$OUT" | sed -n 's/.* \([0-9.]*\)% packet loss.*/\1/p' | head -n1)"
    MIN="$(printf '%s' "$OUT" | awk -F'/' '/round-trip|rtt/{print $4; exit}')"
    AVG="$(printf '%s' "$OUT" | awk -F'/' '/round-trip|rtt/{print $5; exit}')"
    MAX="$(printf '%s' "$OUT" | awk -F'/' '/round-trip|rtt/{print $6; exit}')"
    [ -z "$LOSS" ] && LOSS="100"
    [ -z "$MIN" ] && MIN="-"
    [ -z "$AVG" ] && AVG="-"
    [ -z "$MAX" ] && MAX="-"
    JITTER="-"
    if [ "$MIN" != "-" ] && [ "$MAX" != "-" ]; then
        JITTER="$(awk -v max="$MAX" -v min="$MIN" 'BEGIN{printf "%.1f", max-min}')"
    fi
    printf '%s|%s|%s|%s|%s|%s' "$LOSS" "$MIN" "$AVG" "$MAX" "$JITTER" "$(printf '%s' "$OUT" | sed 's/|/ /g')"
}

dns_status(){
    DOMAIN="$1"
    OUT="$(nslookup "$DOMAIN" 2>&1)"
    STATUS="FAIL"
    echo "$OUT" | grep -q "Address" && STATUS="PASS"
    printf '%s|%s' "$STATUS" "$(printf '%s' "$OUT" | sed 's/|/ /g')"
}

mtu_status(){
    if ping -c1 -W2 -s 1472 -M do 8.8.8.8 >/dev/null 2>&1; then
        echo "1500|PASS|Standard 1500 MTU works"
    elif ping -c1 -W2 -s 1464 -M do 8.8.8.8 >/dev/null 2>&1; then
        echo "1492|WARNING|Likely PPPoE or reduced MTU"
    else
        echo "UNKNOWN|WARNING|MTU test not conclusive"
    fi
}

# Fast tests
GW_RESULT=""
[ -n "$GW" ] && GW_RESULT="$(ping_stats "$GW" 5)"
INET_RESULT="$(ping_stats 8.8.8.8 10)"
DNS_GOOGLE="$(dns_status google.com)"
DNS_MATRIX="$(dns_status matrixfitness.com)"
DNS_EGYM="$(dns_status egym.com)"
MTU_RESULT="$(mtu_status)"

GW_LOSS="$(printf '%s' "$GW_RESULT" | cut -d'|' -f1)"
GW_MIN="$(printf '%s' "$GW_RESULT" | cut -d'|' -f2)"
GW_AVG="$(printf '%s' "$GW_RESULT" | cut -d'|' -f3)"
GW_MAX="$(printf '%s' "$GW_RESULT" | cut -d'|' -f4)"
GW_JITTER="$(printf '%s' "$GW_RESULT" | cut -d'|' -f5)"
GW_RAW="$(printf '%s' "$GW_RESULT" | cut -d'|' -f6-)"

INET_LOSS="$(printf '%s' "$INET_RESULT" | cut -d'|' -f1)"
INET_MIN="$(printf '%s' "$INET_RESULT" | cut -d'|' -f2)"
INET_AVG="$(printf '%s' "$INET_RESULT" | cut -d'|' -f3)"
INET_MAX="$(printf '%s' "$INET_RESULT" | cut -d'|' -f4)"
INET_JITTER="$(printf '%s' "$INET_RESULT" | cut -d'|' -f5)"
INET_RAW="$(printf '%s' "$INET_RESULT" | cut -d'|' -f6-)"

GW_LAT_GRADE="$(grade_latency "$GW_AVG")"
GW_LOSS_GRADE="$(grade_loss "$GW_LOSS")"
INET_LAT_GRADE="$(grade_latency "$INET_AVG")"
INET_LOSS_GRADE="$(grade_loss "$INET_LOSS")"
INET_JITTER_GRADE="$(grade_jitter "$INET_JITTER")"

DNS_GOOGLE_STATUS="$(printf '%s' "$DNS_GOOGLE" | cut -d'|' -f1)"
DNS_MATRIX_STATUS="$(printf '%s' "$DNS_MATRIX" | cut -d'|' -f1)"
DNS_EGYM_STATUS="$(printf '%s' "$DNS_EGYM" | cut -d'|' -f1)"
DNS_GOOGLE_RAW="$(printf '%s' "$DNS_GOOGLE" | cut -d'|' -f2-)"
DNS_MATRIX_RAW="$(printf '%s' "$DNS_MATRIX" | cut -d'|' -f2-)"
DNS_EGYM_RAW="$(printf '%s' "$DNS_EGYM" | cut -d'|' -f2-)"

MTU_VALUE="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f1)"
MTU_STATUS="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f2)"
MTU_TEXT="$(printf '%s' "$MTU_RESULT" | cut -d'|' -f3-)"

apply_score "$GW_LAT_GRADE"
apply_score "$GW_LOSS_GRADE"
apply_score "$INET_LAT_GRADE"
apply_score "$INET_LOSS_GRADE"
apply_score "$INET_JITTER_GRADE"
[ "$DNS_GOOGLE_STATUS" = "PASS" ] || apply_score "FAIL"
[ "$DNS_MATRIX_STATUS" = "PASS" ] || apply_score "WARNING"
[ "$DNS_EGYM_STATUS" = "PASS" ] || apply_score "WARNING"
apply_score "$MTU_STATUS"
[ "$score" -lt 0 ] && score=0

FINAL="EXCELLENT"; FINAL_CLASS="ok"; FINAL_TEXT="Customer network is suitable for Matrix and EGYM equipment. No action required."
[ "$score" -lt 90 ] && FINAL="GOOD" && FINAL_CLASS="ok" && FINAL_TEXT="Network is usable. Minor points should be checked if problems occur."
[ "$score" -lt 75 ] && FINAL="ATTENTION" && FINAL_CLASS="warn" && FINAL_TEXT="Network has warnings. Investigate before final handover."
[ "$score" -lt 60 ] && FINAL="CRITICAL" && FINAL_CLASS="fail" && FINAL_TEXT="Network does not meet the recommended quality. Resolve issues before installation handover."

result_table(){
    LABEL1="$1"; VALUE1="$2"; LABEL2="$3"; VALUE2="$4"; LABEL3="$5"; VALUE3="$6"; LABEL4="$7"; VALUE4="$8"
    cat <<EOF
<table class="mini">
<tr><td>$LABEL1</td><td><b>$(html_escape "$VALUE1")</b></td></tr>
<tr><td>$LABEL2</td><td><b>$(html_escape "$VALUE2")</b></td></tr>
<tr><td>$LABEL3</td><td><b>$(html_escape "$VALUE3")</b></td></tr>
<tr><td>$LABEL4</td><td><b>$(html_escape "$VALUE4")</b></td></tr>
</table>
EOF
}

card_start(){
    TITLE="$1"; STATUS="$2"; CLASS="$3"; SUB="$4"
    cat <<EOF
<div class="test-card $CLASS">
  <div class="test-head">
    <div><h3>$(html_escape "$TITLE")</h3><p>$(html_escape "$SUB")</p></div>
    <div class="badge $CLASS">$(html_escape "$STATUS")</div>
  </div>
EOF
}
card_end(){
    EXPLAIN="$1"; RECOMMEND="$2"
    cat <<EOF
  <details>
    <summary>Explanation and recommendation</summary>
    <div class="explain">
      <p><b>What this means:</b> $(html_escape "$EXPLAIN")</p>
      <p><b>Recommended action:</b> $(html_escape "$RECOMMEND")</p>
    </div>
  </details>
</div>
EOF
}

cat <<EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>WAN Quality Test</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--fail:#c82333;--blue:#005a9c}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1280px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:white;border-radius:18px;padding:20px 22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.9;margin-top:6px}
.btn{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);color:white;text-decoration:none;border-radius:12px;padding:11px 14px;font-weight:700}
.summary{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:18px 0}
.sum-card{background:white;border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow);padding:15px}
.label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}
.value{margin-top:8px;font-size:20px;font-weight:800;word-break:break-word}
.ok{color:var(--ok)}.warn{color:var(--warn)}.fail{color:var(--fail)}
.verdict{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin:16px 0;border-left:9px solid var(--ok)}
.verdict.warn{border-left-color:var(--warn)}.verdict.fail{border-left-color:var(--fail)}
.verdict h2{margin:0 0 6px;font-size:26px}
.tests{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
.test-card{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:15px;border-top:6px solid var(--ok)}
.test-card.warn{border-top-color:var(--warn)}.test-card.fail{border-top-color:var(--fail)}
.test-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
.test-card h3{margin:0;font-size:18px}.test-card p{margin:5px 0 0;color:var(--muted);font-size:13px;line-height:1.35}
.badge{border-radius:999px;padding:6px 10px;color:white;font-size:12px;font-weight:800;background:var(--ok);white-space:nowrap}
.badge.warn{background:var(--warn)}.badge.fail{background:var(--fail)}
.mini{width:100%;border-collapse:collapse;margin-top:12px;background:#fff}.mini td{border:1px solid var(--border);padding:9px}.mini td:first-child{color:var(--muted);font-weight:700;width:45%}
details{margin-top:12px}summary{cursor:pointer;color:#0d3b66;font-weight:800}
.explain{background:#f8fafc;border:1px solid var(--border);border-radius:12px;padding:12px;margin-top:9px;line-height:1.45;color:#344054}
.section{background:white;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:16px;margin:16px 0}
.section h2{margin:0 0 12px;color:#0d3b66}
pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:14px;border-radius:14px;overflow:auto;font-size:12px}
.bigtable{width:100%;border-collapse:collapse}.bigtable td,.bigtable th{border:1px solid var(--border);padding:9px;text-align:left}.bigtable th{background:#f0f6fb}
@media(max-width:1000px){.summary{grid-template-columns:repeat(2,1fr)}.tests{grid-template-columns:1fr}}
@media(max-width:640px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.summary{grid-template-columns:1fr}.btn{width:100%;text-align:center}.test-head{display:block}.badge{display:inline-block;margin-top:10px}}
</style>
</head>
<body>
<div class="page">
  <div class="hero">
    <div><h1>WAN Quality Test</h1><div class="sub">Readable Matrix & EGYM internet quality report for $(html_escape "$HOST")</div></div>
    <a class="btn" href="/">Back to Toolkit</a>
  </div>

  <div class="summary">
    <div class="sum-card"><div class="label">Score</div><div class="value $FINAL_CLASS">$(html_escape "$score") / 100</div></div>
    <div class="sum-card"><div class="label">WAN Interface</div><div class="value">$(html_escape "$WAN_IF")</div></div>
    <div class="sum-card"><div class="label">WAN IP</div><div class="value">$(html_escape "$WAN_IP")</div></div>
    <div class="sum-card"><div class="label">Gateway</div><div class="value">$(html_escape "$GW")</div></div>
    <div class="sum-card"><div class="label">DNS</div><div class="value">$(html_escape "$DNS_SERVERS")</div></div>
  </div>

  <div class="verdict $FINAL_CLASS">
    <h2>$(html_escape "$FINAL")</h2>
    <p><b>Final verdict:</b> $(html_escape "$FINAL_TEXT")</p>
  </div>

  <div class="tests">
EOF

GW_CLASS="$(css_class "$GW_LAT_GRADE")"
card_start "Gateway Test" "$GW_LAT_GRADE" "$GW_CLASS" "Local connection between router and customer gateway."
result_table "Average latency" "${GW_AVG} ms" "Min / Max" "${GW_MIN} / ${GW_MAX} ms" "Packet loss" "${GW_LOSS}%" "Jitter" "${GW_JITTER} ms"
card_end "The gateway is the first device on the customer network. A healthy local gateway should normally respond below 2 ms with 0% packet loss." "If this fails, check cabling, switch port, VLAN, modem/router and local customer network."

INET_CLASS="$(css_class "$INET_LAT_GRADE")"
card_start "Internet Latency" "$INET_LAT_GRADE" "$INET_CLASS" "Delay between the router and the internet."
result_table "Average latency" "${INET_AVG} ms" "Min / Max" "${INET_MIN} / ${INET_MAX} ms" "Target" "8.8.8.8" "Result" "$INET_LAT_GRADE"
card_end "This shows how quickly the router reaches the internet. Low latency improves cloud sync, login and remote services." "If latency is high, check ISP quality, customer firewall, overloaded router or mobile signal quality."

LOSS_CLASS="$(css_class "$INET_LOSS_GRADE")"
card_start "Packet Loss" "$INET_LOSS_GRADE" "$LOSS_CLASS" "Checks if data disappears during transmission."
result_table "Packet loss" "${INET_LOSS}%" "Target" "8.8.8.8" "Packets" "10 fast test" "Result" "$INET_LOSS_GRADE"
card_end "Packet loss is more serious than high latency. Even a fast line becomes unreliable when packets are lost." "If packet loss is detected, check ISP, WiFi backhaul, cables, switches, firewall load or LTE signal."

JITTER_CLASS="$(css_class "$INET_JITTER_GRADE")"
card_start "Jitter" "$INET_JITTER_GRADE" "$JITTER_CLASS" "Checks if latency is stable."
result_table "Jitter" "${INET_JITTER} ms" "Min latency" "${INET_MIN} ms" "Max latency" "${INET_MAX} ms" "Result" "$INET_JITTER_GRADE"
card_end "Jitter means latency variation. Stable latency is important for cloud communication and remote support." "If jitter is high, check congestion, WiFi interference, LTE signal, or overloaded network equipment."

DNS_CLASS="$(css_class "$DNS_GOOGLE_STATUS")"
card_start "DNS Lookup" "$DNS_GOOGLE_STATUS" "$DNS_CLASS" "Checks if internet names can be resolved."
result_table "Google" "$DNS_GOOGLE_STATUS" "Matrix" "$DNS_MATRIX_STATUS" "EGYM" "$DNS_EGYM_STATUS" "DNS servers" "$DNS_SERVERS"
card_end "DNS translates names like egym.com into IP addresses. If DNS fails, cloud services may not connect even when ping works." "Use reliable DNS servers such as Google DNS or Cloudflare DNS and check customer firewall DNS rules."

MTU_CLASS="$(css_class "$MTU_STATUS")"
card_start "MTU Test" "$MTU_STATUS" "$MTU_CLASS" "Checks if normal packet size works."
result_table "Detected MTU" "$MTU_VALUE" "Status" "$MTU_STATUS" "Meaning" "$MTU_TEXT" "Target" "8.8.8.8"
card_end "MTU controls packet size. Wrong MTU can cause strange HTTPS, VPN or cloud issues." "1500 is normal. 1492 is common on PPPoE. If unknown, only investigate if VPN/cloud problems occur."

card_start "Speed Test" "MANUAL" "warn" "Skipped in fast mode to prevent the page from hanging."
result_table "Status" "Not tested" "Reason" "Speedtest can take long" "Advice" "Run manually if needed" "Command" "speedtest"
card_end "Bandwidth matters for updates and multiple devices, but it is not the only quality indicator." "Run speedtest manually when bandwidth is suspected to be too low."

card_start "Long Stability Test" "OPTIONAL" "warn" "Skipped in fast mode."
result_table "Status" "Not tested" "Fast test" "10 pings" "Deep test" "Manual 100 pings" "Advice" "Use for intermittent issues"
card_end "A longer test is useful when the customer reports random disconnects or intermittent cloud problems." "Run a longer packet loss test when needed, for example ping -c 100 8.8.8.8."

cat <<EOF
  </div>

  <div class="section">
    <h2>Detailed Summary</h2>
    <table class="bigtable">
      <tr><th>Test</th><th>Measured values</th><th>Result</th></tr>
      <tr><td>Gateway</td><td>avg ${GW_AVG} ms, min ${GW_MIN} ms, max ${GW_MAX} ms, loss ${GW_LOSS}%</td><td>$GW_LAT_GRADE / $GW_LOSS_GRADE</td></tr>
      <tr><td>Internet</td><td>avg ${INET_AVG} ms, min ${INET_MIN} ms, max ${INET_MAX} ms</td><td>$INET_LAT_GRADE</td></tr>
      <tr><td>Packet Loss</td><td>${INET_LOSS}% to 8.8.8.8</td><td>$INET_LOSS_GRADE</td></tr>
      <tr><td>Jitter</td><td>${INET_JITTER} ms</td><td>$INET_JITTER_GRADE</td></tr>
      <tr><td>DNS</td><td>Google $DNS_GOOGLE_STATUS, Matrix $DNS_MATRIX_STATUS, EGYM $DNS_EGYM_STATUS</td><td>$DNS_GOOGLE_STATUS</td></tr>
      <tr><td>MTU</td><td>$MTU_VALUE - $MTU_TEXT</td><td>$MTU_STATUS</td></tr>
    </table>
  </div>

  <details class="section">
    <summary><b>Advanced Raw Output</b></summary>
    <h2>Gateway Ping</h2><pre>$(html_escape "$GW_RAW")</pre>
    <h2>Internet Ping 8.8.8.8</h2><pre>$(html_escape "$INET_RAW")</pre>
    <h2>DNS Google</h2><pre>$(html_escape "$DNS_GOOGLE_RAW")</pre>
    <h2>DNS Matrix</h2><pre>$(html_escape "$DNS_MATRIX_RAW")</pre>
    <h2>DNS EGYM</h2><pre>$(html_escape "$DNS_EGYM_RAW")</pre>
  </details>
</div>
</body>
</html>
EOF
