#!/bin/sh

echo "Content-Type: text/plain"
echo ""

if [ -f /usr/local/matrix/admin_password.txt ]
then
    cat /usr/local/matrix/admin_password.txt
else
    echo "MatrixFitness2026"
fi