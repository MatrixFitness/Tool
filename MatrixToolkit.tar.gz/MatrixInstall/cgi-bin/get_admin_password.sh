#!/bin/sh

echo "Content-Type: text/plain"
echo ""

PASS_FILE="/usr/local/matrix/admin_password.txt"

if [ -f "$PASS_FILE" ]; then
    cat "$PASS_FILE"
else
    echo "MatrixFitness2026"
fi
