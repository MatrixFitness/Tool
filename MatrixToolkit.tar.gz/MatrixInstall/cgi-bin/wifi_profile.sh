#!/bin/sh
# Matrix Toolkit v60 - Apply WiFi profile to 5 GHz AP

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
PREVIOUS="/usr/local/matrix/matrix_wifi_profiles.previous"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() { printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'; }
write_builtin_defaults() { cat > "$1" <<'DEFEOF'
PROFILE1_NAME=Matrix Default
PROFILE1_SSID={HOSTNAME}_5G
PROFILE1_PASSWORD=matrixfitness

PROFILE2_NAME=EGYM Service
PROFILE2_SSID=EGYM
PROFILE2_PASSWORD=matrixfitness

PROFILE3_NAME=Customer WiFi
PROFILE3_SSID=ClubWifi
PROFILE3_PASSWORD=Welkom123
DEFEOF
}
ensure_config() { mkdir -p /usr/local/matrix; [ -f "$CONFIG" ] || { [ -f "$DEFAULTS" ] && cp -f "$DEFAULTS" "$CONFIG" || write_builtin_defaults "$CONFIG"; }; [ -f "$DEFAULTS" ] || cp -f "$CONFIG" "$DEFAULTS" 2>/dev/null || write_builtin_defaults "$DEFAULTS"; [ -f "$PREVIOUS" ] || cp -f "$CONFIG" "$PREVIOUS" 2>/dev/null; chmod 666 "$CONFIG" "$DEFAULTS" "$PREVIOUS" 2>/dev/null; }
get_qs() { printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | sed -n "s/^${1}=//p" | head -n1; }
ensure_config
P="$(get_qs p)"; case "$P" in *[!0-9]*|'') P="1" ;; esac
HOST="$(uci get system.@system[0].hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"; [ -z "$HOST" ] && HOST="Matrix"
NAME="$(grep "^PROFILE${P}_NAME=" "$CONFIG" | head -n1 | cut -d= -f2-)"
SSID="$(grep "^PROFILE${P}_SSID=" "$CONFIG" | head -n1 | cut -d= -f2-)"
PASS="$(grep "^PROFILE${P}_PASSWORD=" "$CONFIG" | head -n1 | cut -d= -f2-)"
SSID_RESOLVED="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"
OLD_SSID="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
if [ -z "$SSID_RESOLVED" ] || [ -z "$PASS" ]; then
    MSG="Profile $P is incomplete. Nothing applied."; CLASS="err"
else
    uci set wireless.default_radio1.ssid="$SSID_RESOLVED"
    uci set wireless.default_radio1.key="$PASS"
    uci set wireless.default_radio1.encryption='psk2'
    uci commit wireless
    wifi reload >/dev/null 2>&1 || true
    sleep 2
    VERIFY="$(uci get wireless.default_radio1.ssid 2>/dev/null)"
    if [ "$VERIFY" = "$SSID_RESOLVED" ]; then
        MSG="Profile applied successfully."; CLASS="ok"
        echo "$(date '+%Y-%m-%d %H:%M:%S') Applied profile $P ($NAME) SSID=$SSID_RESOLVED previous=$OLD_SSID" >> "$LOG"
    else
        MSG="Profile was saved, but SSID verification failed. Current SSID: $VERIFY"; CLASS="err"
        echo "$(date '+%Y-%m-%d %H:%M:%S') WARNING applying profile $P ($NAME) target=$SSID_RESOLVED verify=$VERIFY" >> "$LOG"
    fi
fi
E_MSG="$(html_escape "$MSG")"; E_NAME="$(html_escape "$NAME")"; E_SSID="$(html_escape "$SSID_RESOLVED")"
cat <<EOF
Content-Type: text/html

<html><head><title>Apply WiFi Profile</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="4;url=/cgi-bin/wifi_manager.sh"><style>body{font-family:Arial;margin:20px;background:#f5f5f5}.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}h1{color:#005a9c}.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}</style></head><body><div class="box"><h1>Apply WiFi Profile</h1><p class="$CLASS">$E_MSG</p><p><b>Profile:</b> $E_NAME<br><b>5 GHz SSID:</b> $E_SSID<br><b>Password:</b> ********</p><p>You will return to WiFi Manager automatically.</p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></div></body></html>
EOF
