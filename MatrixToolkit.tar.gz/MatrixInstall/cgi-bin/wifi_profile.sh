#!/bin/sh
# Matrix Toolkit - WiFi Profile Apply CLEAN FIX
# Applies selected profile from:
# /usr/local/matrix/matrix_wifi_profiles.conf

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
LOG="/tmp/matrix_wifi_manager.log"
TARGET="wireless.default_radio1"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

url_decode() {
    sed -e 's/+/ /g' \
        -e 's/%20/ /g' \
        -e 's/%3[Dd]/=/g' \
        -e 's/%26/\&/g'
}

qs() {
    FIELD="$1"
    printf '%s' "$QUERY_STRING" | tr '&' '\n' | grep "^${FIELD}=" | head -n1 | cut -d= -f2- | url_decode
}

get_profile_value() {
    IDX="$1"
    KEY="$2"
    grep "^PROFILE${IDX}_${KEY}=" "$CONFIG" 2>/dev/null | head -n1 | cut -d= -f2-
}

page() {
    TITLE="$1"
    MSG="$2"
    CLASS="$3"
    EXTRA="$4"

    E_MSG="$(html_escape "$MSG")"

    echo "Content-Type: text/html"
    echo ""
    cat <<EOF
<!DOCTYPE html>
<html>
<head>
<title>Matrix WiFi Manager</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5;url=/cgi-bin/wifi_manager.sh?nocache=$(date +%s)">
<style>
body{font-family:Arial;margin:20px;background:#f5f5f5;color:#222}
.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}
h1{color:#005a9c}
.ok{color:#1f8a3b;font-weight:bold}
.err{color:#c82333;font-weight:bold}
.warn{color:#b35b00;font-weight:bold}
.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}
pre{background:#f6f6f6;border:1px solid #ddd;border-radius:6px;padding:10px;white-space:pre-wrap}
</style>
</head>
<body>
<div class="box">
<h1>$TITLE</h1>
<p class="$CLASS">$E_MSG</p>
$EXTRA
<p><a class="btn" href="/cgi-bin/wifi_manager.sh?nocache=$(date +%s)">Back to WiFi Manager</a></p>
</div>
</body>
</html>
EOF
}

IDX="$(qs p)"
[ -z "$IDX" ] && IDX="$(qs profile)"

if [ -z "$IDX" ]; then
    page "Matrix WiFi Manager" "No profile number was received." "err" ""
    exit 0
fi

if [ ! -f "$CONFIG" ]; then
    page "Matrix WiFi Manager" "Config file not found: $CONFIG" "err" ""
    exit 0
fi

NAME="$(get_profile_value "$IDX" NAME)"
SSID="$(get_profile_value "$IDX" SSID)"
PASS="$(get_profile_value "$IDX" PASSWORD)"

if [ -z "$NAME" ] || [ -z "$SSID" ] || [ -z "$PASS" ]; then
    EXTRA="<pre>Profile: $IDX
Name: $NAME
SSID: $SSID
Password length: $(printf '%s' "$PASS" | wc -c)
Config: $CONFIG</pre>"
    page "Matrix WiFi Manager" "Profile missing or incomplete." "err" "$EXTRA"
    echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR profile $IDX missing/incomplete name=$NAME ssid=$SSID" >> "$LOG"
    exit 0
fi

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"

RESOLVED_SSID="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"
OLD_SSID="$(uci get ${TARGET}.ssid 2>/dev/null)"

# Backup current wireless config if possible
uci export wireless > /tmp/matrix_wireless_before_apply.conf 2>/dev/null

uci set ${TARGET}.ssid="$RESOLVED_SSID"
uci set ${TARGET}.key="$PASS"
uci set ${TARGET}.encryption="psk2"
uci commit wireless

wifi reload >/dev/null 2>&1
sleep 2

CURRENT="$(uci get ${TARGET}.ssid 2>/dev/null)"

if [ "$CURRENT" = "$RESOLVED_SSID" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') Applied profile $IDX ($NAME) SSID=$RESOLVED_SSID previous=$OLD_SSID" >> "$LOG"
    EXTRA="<p><b>Profile:</b> $(html_escape "$NAME")</p>
<p><b>5 GHz SSID:</b> $(html_escape "$RESOLVED_SSID")</p>
<p><b>Password:</b> ********</p>
<p class=\"warn\">The 5 GHz WiFi access point is reloading.</p>"
    page "Apply WiFi Profile" "Profile applied successfully." "ok" "$EXTRA"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') WARNING profile $IDX saved but verification failed expected=$RESOLVED_SSID current=$CURRENT" >> "$LOG"
    EXTRA="<pre>Expected SSID: $RESOLVED_SSID
Current SSID: $CURRENT
Profile: $IDX
Name: $NAME</pre>"
    page "Apply WiFi Profile" "Profile was written but verification failed." "warn" "$EXTRA"
fi
