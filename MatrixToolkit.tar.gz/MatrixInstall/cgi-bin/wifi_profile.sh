#!/bin/sh
# Matrix Toolkit - Apply WiFi Profile
# Applies selected profile to 5 GHz AP only: wireless.default_radio1

CONFIG="/usr/local/matrix/matrix_wifi_profiles.conf"
DEFAULTS="/usr/local/matrix/matrix_wifi_profiles.default"
LOG="/tmp/matrix_wifi_manager.log"

html_escape() {
    printf '%s' "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g;s/"/\&quot;/g'
}

get_query_value() {
    KEY="$1"
    echo "$QUERY_STRING" | tr '&' '\n' | sed -n "s/^${KEY}=//p" | head -n1 | sed 's/%20/ /g;s/+/ /g'
}

echo "Content-Type: text/html"
echo ""

P="$(get_query_value p)"
case "$P" in
    ''|*[!0-9]*) P="" ;;
esac

if [ -z "$P" ]; then
    MSG="No profile selected."
elif [ ! -f "$CONFIG" ]; then
    mkdir -p /usr/local/matrix/config
    if [ -f "$DEFAULTS" ]; then
        cp "$DEFAULTS" "$CONFIG"
    fi
fi

if [ -z "$P" ] || [ ! -f "$CONFIG" ]; then
    cat << EOF
<html><head><title>WiFi Profile</title><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{font-family:Arial;margin:20px;background:#f5f5f5}.box{max-width:720px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}.err{color:#c82333;font-weight:bold}.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}</style></head><body><div class="box"><h1>Matrix WiFi Manager</h1><p class="err">Unable to apply WiFi profile.</p><p>Profile missing or config file not found.</p><a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a></div></body></html>
EOF
    exit 0
fi

# Load profile values safely enough for simple key=value config
NAME="$(grep "^PROFILE${P}_NAME=" "$CONFIG" | head -n1 | cut -d= -f2-)"
SSID="$(grep "^PROFILE${P}_SSID=" "$CONFIG" | head -n1 | cut -d= -f2-)"
PASS="$(grep "^PROFILE${P}_PASSWORD=" "$CONFIG" | head -n1 | cut -d= -f2-)"

HOST="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="$(hostname 2>/dev/null)"
[ -z "$HOST" ] && HOST="Matrix"

SSID="$(printf '%s' "$SSID" | sed "s/{HOSTNAME}/$HOST/g")"

if [ -z "$SSID" ] || [ -z "$PASS" ]; then
    RESULT="Profile $P is incomplete. SSID or password is empty."
    OK="0"
else
    uci set wireless.default_radio1.ssid="$SSID" 2>/tmp/matrix_wifi_error
    uci set wireless.default_radio1.key="$PASS" 2>>/tmp/matrix_wifi_error
    uci set wireless.default_radio1.encryption='psk2' 2>>/tmp/matrix_wifi_error
    uci commit wireless 2>>/tmp/matrix_wifi_error
    wifi reload >/tmp/matrix_wifi_reload.log 2>&1
    CODE="$?"
    if [ "$CODE" = "0" ]; then
        RESULT="Profile applied successfully."
        OK="1"
        echo "$(date '+%Y-%m-%d %H:%M:%S') Applied profile $P ($NAME) SSID=$SSID" >> "$LOG"
    else
        RESULT="Profile was saved but WiFi reload returned an error. Check router WiFi status."
        OK="0"
        echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR applying profile $P ($NAME) SSID=$SSID" >> "$LOG"
    fi
fi

E_NAME="$(html_escape "$NAME")"
E_SSID="$(html_escape "$SSID")"
E_RESULT="$(html_escape "$RESULT")"
CLASS="ok"; [ "$OK" = "1" ] || CLASS="err"

cat << EOF
<html>
<head>
<title>WiFi Profile Applied</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5;url=/cgi-bin/wifi_manager.sh">
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f5f5f5;color:#222}.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px;box-shadow:0 2px 8px rgba(0,0,0,.08)}h1{color:#005a9c}.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.row{background:#fafafa;border:1px solid #ddd;border-radius:8px;padding:12px;margin:12px 0}.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}
</style>
</head>
<body><div class="box">
<h1>Matrix WiFi Manager</h1>
<p class="$CLASS">$E_RESULT</p>
<div class="row"><b>Profile:</b> $E_NAME<br><b>5 GHz SSID:</b> $E_SSID<br><b>Password:</b> ********</div>
<p>The 5 GHz WiFi access point is reloading. You will return to WiFi Manager automatically.</p>
<a class="btn" href="/cgi-bin/wifi_manager.sh">Back to WiFi Manager</a>
</div></body></html>
EOF
