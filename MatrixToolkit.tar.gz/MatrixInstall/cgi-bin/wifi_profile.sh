#!/bin/sh
# Matrix Toolkit WiFi Apply v64
. /usr/local/matrix/web/cgi-bin/wifi_lib.sh
ensure_config
IDX="$(qs p)"; [ -z "$IDX" ] && IDX="$(qs profile)"
MSG="Profile missing or config file not found."; CLASS="err"; NAME=""; SUMMARY=""
if [ -n "$IDX" ] && [ -f "$CONFIG" ]; then
    NAME="$(profile_value "$IDX" NAME)"
    R0A="$(normalize_action "$(profile_value "$IDX" R0_ACTION)")"; R1A="$(normalize_action "$(profile_value "$IDX" R1_ACTION)")"
    R0S="$(profile_value "$IDX" R0_SSID)"; R0P="$(profile_value "$IDX" R0_PASSWORD)"
    R1S="$(profile_value "$IDX" R1_SSID)"; R1P="$(profile_value "$IDX" R1_PASSWORD)"
    if [ -n "$NAME" ]; then
        apply_radio_action R0 "$R0A" "$R0S" "$R0P"
        apply_radio_action R1 "$R1A" "$R1S" "$R1P"
        uci commit wireless
        wifi reload >/dev/null 2>&1
        sleep 2
        MSG="Profile applied successfully."; CLASS="ok"
        SUMMARY="Radio 0: $R0A $(resolve_ssid "$R0S")<br>Radio 1: $R1A $(resolve_ssid "$R1S")"
        echo "$(date '+%Y-%m-%d %H:%M:%S') Applied profile $IDX ($NAME) r0=$R0A $(resolve_ssid "$R0S") r1=$R1A $(resolve_ssid "$R1S")" >> "$LOG"
    fi
fi
E_MSG="$(html_escape "$MSG")"; E_NAME="$(html_escape "$NAME")"
echo "Content-Type: text/html"; echo ""
cat <<EOF
<!DOCTYPE html><html><head><title>Apply WiFi Profile</title><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="5;url=/cgi-bin/wifi_manager.sh?nocache=$(date +%s)"><style>body{font-family:Arial;margin:20px;background:#f5f5f5}.box{max-width:760px;margin:auto;background:white;border:1px solid #ccc;border-radius:10px;padding:22px}h1{color:#005a9c}.ok{color:#1f8a3b;font-weight:bold}.err{color:#c82333;font-weight:bold}.btn{display:inline-block;background:#007bff;color:white;padding:12px 18px;border-radius:6px;text-decoration:none;font-weight:bold}</style></head><body><div class="box"><h1>Apply WiFi Profile</h1><p class="$CLASS">$E_MSG</p><p><b>Profile:</b> $E_NAME</p><p>$SUMMARY</p><p><b>Password:</b> ********</p><p><a class="btn" href="/cgi-bin/wifi_manager.sh?nocache=$(date +%s)">Back to WiFi Manager</a></p></div></body></html>
EOF
