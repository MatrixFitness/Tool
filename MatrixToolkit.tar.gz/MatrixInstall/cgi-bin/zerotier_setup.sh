#!/bin/sh

echo "Content-Type: text/html"
echo ""

ZEROTIER_NETWORK_ID="cf719fd5409699a2"
LOG="/tmp/zerotier_setup.log"

html_start() {
cat << EOF
<html>
<head>
<title>ZeroTier Setup</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body {
    font-family: Arial, sans-serif;
    margin: 20px;
}
pre {
    background: #f5f5f5;
    padding: 15px;
    border-radius: 5px;
}
button {
    width: 220px;
    height: 50px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}
</style>
</head>
<body>
<h2>ZeroTier Setup</h2>
<pre>
EOF
}

html_end() {
cat << EOF
</pre>

<br>

<button onclick="window.location='/admin/'">
Return to Admin
</button>

</body>
</html>
EOF
}

html_start

echo "======================================="
echo " MATRIX TOOLKIT - ZEROTIER SETUP"
echo "======================================="
echo ""

echo "Network ID:"
echo "$ZEROTIER_NETWORK_ID"
echo ""

echo "Checking internet connection..."

ping -c 2 1.1.1.1 >/dev/null 2>&1

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: No internet connection detected."
    html_end
    exit 1
fi

echo "Internet connection OK."
echo ""

echo "Updating package list..."

opkg update >> "$LOG" 2>&1

echo "Done."
echo ""

echo "Checking ZeroTier installation..."

if command -v zerotier-cli >/dev/null 2>&1
then
    echo "ZeroTier already installed."
else
    echo "Installing ZeroTier..."

    opkg install zerotier >> "$LOG" 2>&1

    if [ $? -ne 0 ]; then
        echo ""
        echo "ERROR: ZeroTier installation failed."
        echo ""
        echo "Log:"
        cat "$LOG"
        html_end
        exit 1
    fi

    echo "ZeroTier installed successfully."
fi

echo ""

echo "Enabling service..."
/etc/init.d/zerotier enable >> "$LOG" 2>&1

echo "Starting service..."
/etc/init.d/zerotier start >> "$LOG" 2>&1

sleep 10

echo ""
echo "Joining Matrix Support Network..."

zerotier-cli join "$ZEROTIER_NETWORK_ID" >> "$LOG" 2>&1

sleep 10

echo ""
echo "Current Status:"
echo "----------------"

zerotier-cli status

echo ""
echo "Joined Networks:"
echo "----------------"

zerotier-cli listnetworks

echo ""
echo "Node ID:"
echo "----------------"

zerotier-cli info

echo ""
echo "======================================="
echo " SETUP COMPLETED"
echo "======================================="
echo ""

echo "Next Step:"
echo "1. Open https://my.zerotier.com"
echo "2. Open Network $ZEROTIER_NETWORK_ID"
echo "3. Authorize this router (Auth checkbox)"
echo "4. Note the assigned ZeroTier IP"
echo ""
echo "After authorization you can remotely access:"
echo ""
echo "https://<ZEROTIER-IP>"
echo ""
echo "Example:"
echo "https://10.x.x.x"

html_end