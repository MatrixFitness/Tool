#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ZEROTIER WEB STARTER v3.1
# =====================================================
# Safe for the Admin web page.
# - Does NOT perform root actions directly.
# - Detects if ZeroTier is already configured.
# - Detects ACCESS_DENIED and tells user to authorize.
# - Creates /tmp/matrix_zerotier_request only when setup is needed.
# - Root worker /usr/local/matrix/matrix_zerotier_worker.sh does the real setup.
# =====================================================

REQ="/tmp/matrix_zerotier_request"
LOG="/tmp/matrix_zerotier.log"
LOCK="/tmp/matrix_zerotier_worker.lock"
NETWORK_ID="cf719fd5409699a2"
ZT_HOME="/etc/zerotier"
MATRIX_WEB_PORT="8080"
MATRIX_ADMIN_PORT="8081"

now() { date '+%Y-%m-%d %H:%M:%S'; }

find_zt_cli() {
    for p in /usr/local/usr/bin/zerotier-cli /usr/bin/zerotier-cli /overlay/root/upper/usr/bin/zerotier-cli; do
        [ -x "$p" ] && echo "$p" && return
    done
    command -v zerotier-cli 2>/dev/null
}

get_zt_ip_from_status() {
    echo "$1" | awk '/^200 listnetworks / && $2 != "<nwid>" {
        for (i=1;i<=NF;i++) if ($i ~ /^10\.74\./) { sub(/\/.*$/, "", $i); print $i; exit }
    }'
}

get_zt_dev_from_status() {
    echo "$1" | awk '/^200 listnetworks / && $2 != "<nwid>" { print $(NF-1); exit }'
}

ZT_CLI="$(find_zt_cli)"
ZT_INFO=""
ZT_NETWORKS=""
ZT_ALL=""
ZT_IP=""
ZT_DEV=""
ZT_STATE="not_installed"

if [ -n "$ZT_CLI" ]; then
    ZT_INFO="$($ZT_CLI -D$ZT_HOME info 2>&1)"
    ZT_NETWORKS="$($ZT_CLI -D$ZT_HOME listnetworks 2>&1)"
    ZT_ALL="$ZT_INFO
$ZT_NETWORKS"
    ZT_IP="$(get_zt_ip_from_status "$ZT_NETWORKS")"
    ZT_DEV="$(get_zt_dev_from_status "$ZT_NETWORKS")"

    if echo "$ZT_NETWORKS" | grep -q " $NETWORK_ID "; then
        if echo "$ZT_NETWORKS" | grep -q " OK "; then
            ZT_STATE="ok"
        elif echo "$ZT_NETWORKS" | grep -q " ACCESS_DENIED "; then
            ZT_STATE="access_denied"
        elif echo "$ZT_NETWORKS" | grep -q " REQUESTING_CONFIGURATION "; then
            ZT_STATE="requesting_configuration"
        else
            ZT_STATE="joined_unknown"
        fi
    elif echo "$ZT_INFO" | grep -q "ONLINE"; then
        ZT_STATE="online_not_joined"
    fi
fi

# Only create a request when ZeroTier is not already configured or waiting for authorization.
# This makes the button safe to press again on a working router.
if [ "$ZT_STATE" != "ok" ] && [ "$ZT_STATE" != "access_denied" ] && [ ! -f "$REQ" ] && [ ! -f "$LOCK" ]; then
    echo "$(now) ZeroTier setup requested from Matrix Admin." > "$LOG"
    echo "$NETWORK_ID" > "$REQ"
fi

echo "Content-Type: text/html"
echo ""

cat <<HTML
<html>
<head>
<meta charset="UTF-8">
<title>ZeroTier Setup</title>
HTML

# Refresh only while worker/request is active. Do not keep refreshing when already OK.
if [ -f "$REQ" ] || [ -f "$LOCK" ]; then
    echo '<meta http-equiv="refresh" content="5">'
fi

cat <<HTML
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.card { background: white; padding: 20px; border-radius: 8px; max-width: 950px; box-shadow: 0 1px 4px rgba(0,0,0,0.12); }
pre { background: #111; color: #eee; padding: 15px; border-radius: 6px; white-space: pre-wrap; overflow:auto; min-height: 220px; }
button { margin-top: 15px; margin-right: 10px; min-width: 180px; height: 46px; font-size: 15px; font-weight: bold; cursor: pointer; border: 0; border-radius: 6px; background: #007bff; color: white; }
.ok { color: green; font-weight: bold; }
.warn { color: #b26a00; font-weight: bold; }
.err { color: red; font-weight: bold; }
.info { color: #005bbb; font-weight: bold; }
.small { color: #555; }
</style>
</head>
<body>
<div class="card">
<h2>ZeroTier Setup</h2>
HTML

case "$ZT_STATE" in
    ok)
        echo "<p class='ok'>Status: ZeroTier is already configured and online.</p>"
        echo "<p><b>Network:</b> $NETWORK_ID<br>"
        [ -n "$ZT_IP" ] && echo "<b>ZeroTier IP:</b> $ZT_IP<br>"
        [ -n "$ZT_DEV" ] && echo "<b>Interface:</b> $ZT_DEV<br>"
        echo "</p>"
        if [ -n "$ZT_IP" ]; then
            echo "<p><b>Toolkit:</b> http://$ZT_IP:$MATRIX_WEB_PORT<br>"
            echo "<b>Admin:</b> http://$ZT_IP:$MATRIX_ADMIN_PORT/cgi-bin/admin_home.sh</p>"
        fi
        ;;
    access_denied)
        echo "<p class='warn'>Status: ZeroTier is installed and joined, but not authorized yet.</p>"
        echo "<p>Open ZeroTier Central and authorize this router.</p>"
        echo "<p><b>Network:</b> $NETWORK_ID"
        [ -n "$ZT_DEV" ] && echo "<br><b>Interface:</b> $ZT_DEV"
        echo "</p>"
        ;;
    requesting_configuration|joined_unknown)
        echo "<p class='warn'>Status: ZeroTier is joined but waiting for configuration.</p>"
        echo "<p>This usually means authorization in ZeroTier Central is still pending.</p>"
        ;;
    *)
        if [ -f "$REQ" ]; then
            echo "<p class='warn'>Status: waiting for root worker...</p>"
        elif [ -f "$LOCK" ]; then
            echo "<p class='warn'>Status: ZeroTier setup is running...</p>"
        else
            echo "<p class='info'>Status: ZeroTier setup request has been created.</p>"
        fi
        echo "<p class='small'>This page uses the root worker, so the web page does not need direct root permissions.</p>"
        ;;
esac

echo "<pre>"
if [ -f "$LOG" ]; then
    cat "$LOG" 2>/dev/null
else
    echo "No ZeroTier log available yet."
fi

echo ""
echo "Current ZeroTier status:"
if [ -n "$ZT_ALL" ]; then
    echo "$ZT_ALL"
else
    echo "zerotier-cli not found yet or ZeroTier is not installed."
fi

echo "</pre>"

cat <<HTML
<button onclick="window.location='/cgi-bin/zerotier_setup.sh'">Refresh / Check Again</button>
<button onclick="window.location=window.location.protocol + '//' + window.location.hostname + ':$MATRIX_ADMIN_PORT/cgi-bin/admin_home.sh'">Return to Admin</button>
<button onclick="window.location=window.location.protocol + '//' + window.location.hostname + ':$MATRIX_WEB_PORT/index.html'">Toolkit Home</button>
</div>
</body>
</html>
HTML
