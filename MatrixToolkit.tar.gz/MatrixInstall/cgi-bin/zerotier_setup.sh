#!/bin/sh

# =====================================================
# MATRIX TOOLKIT - ZEROTIER WEB STARTER
# =====================================================
# This CGI page does NOT perform root actions directly.
# It creates a request file in /tmp. The root cron worker
# /usr/local/matrix/matrix_zerotier_worker.sh performs
# the actual ZeroTier installation/configuration.
# =====================================================

REQ="/tmp/matrix_zerotier_request"
LOG="/tmp/matrix_zerotier.log"
LOCK="/tmp/matrix_zerotier_worker.lock"
NETWORK_ID="cf719fd5409699a2"

now() { date '+%Y-%m-%d %H:%M:%S'; }

# Create request when page is opened/clicked.
# This is safe for uhttpd because /tmp is writable.
if [ ! -f "$REQ" ] && [ ! -f "$LOCK" ]; then
    echo "$(now) ZeroTier setup requested from Matrix Admin." > "$LOG"
    echo "$NETWORK_ID" > "$REQ"
fi

echo "Content-Type: text/html"
echo ""

cat <<HTML
<html>
<head>
<title>ZeroTier Setup</title>
<meta http-equiv="refresh" content="5">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.card { background: white; padding: 20px; border-radius: 8px; max-width: 950px; box-shadow: 0 1px 4px rgba(0,0,0,0.12); }
pre { background: #111; color: #eee; padding: 15px; border-radius: 6px; white-space: pre-wrap; overflow:auto; min-height: 260px; }
button { margin-top: 15px; margin-right: 10px; min-width: 180px; height: 46px; font-size: 15px; font-weight: bold; cursor: pointer; border: 0; border-radius: 6px; background: #007bff; color: white; }
.warn { color: #b26a00; font-weight: bold; }
.ok { color: green; font-weight: bold; }
</style>
</head>
<body>
<div class="card">
<h2>ZeroTier Setup</h2>
<p>This page starts the ZeroTier setup through the root worker. The page refreshes every 5 seconds.</p>
HTML

if [ -f "$REQ" ]; then
    echo "<p class='warn'>Status: waiting for root worker...</p>"
elif [ -f "$LOCK" ]; then
    echo "<p class='warn'>Status: ZeroTier setup is running...</p>"
else
    echo "<p class='ok'>Status: no pending request. Check the log below for the result.</p>"
fi

echo "<pre>"
if [ -f "$LOG" ]; then
    cat "$LOG" 2>/dev/null
else
    echo "No ZeroTier log available yet."
fi

echo ""
echo "Current ZeroTier status:"
if [ -x /usr/local/usr/bin/zerotier-cli ]; then
    /usr/local/usr/bin/zerotier-cli -D/etc/zerotier info 2>&1
    /usr/local/usr/bin/zerotier-cli -D/etc/zerotier listnetworks 2>&1
elif command -v zerotier-cli >/dev/null 2>&1; then
    zerotier-cli -D/etc/zerotier info 2>&1
    zerotier-cli -D/etc/zerotier listnetworks 2>&1
else
    echo "zerotier-cli not found yet."
fi

echo "</pre>"

cat <<HTML
<button onclick="window.location='/cgi-bin/zerotier_setup.sh'">Refresh / Start Again</button>
<button onclick="window.location=window.location.protocol + '//' + window.location.hostname + ':8081/cgi-bin/admin_home.sh'">Return to Admin</button>
<button onclick="window.location='/index.html'">Toolkit Home</button>
</div>
</body>
</html>
HTML
