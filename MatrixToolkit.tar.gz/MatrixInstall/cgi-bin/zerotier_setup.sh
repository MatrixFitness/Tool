#!/bin/sh

echo "Content-Type: text/html"
echo ""

# =====================================================
# MATRIX TOOLKIT - ZEROTIER SETUP v2.0
# =====================================================
# - Installs/checks ZeroTier
# - Starts ZeroTier with /etc/zerotier as home
# - Joins Matrix ZeroTier network
# - Detects ZeroTier interface automatically
# - Creates OpenWRT network interface
# - Creates firewall zone
# - Opens ping and Matrix Toolkit port 8080
# - Fixes permissions so About page can read ZeroTier info
# - Creates autostart service
# =====================================================

ZEROTIER_NETWORK_ID="cf719fd5409699a2"

ZT_HOME="/etc/zerotier"
ZT_ONE="/usr/local/usr/bin/zerotier-one"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"

MATRIX_WEB_PORT="8080"
MATRIX_ADMIN_URL="/admin/index.html"
LOG="/tmp/zerotier_setup.log"

html_start() {
cat << EOF
<html>
<head>
<title>ZeroTier Setup</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
.card { background: white; padding: 20px; border-radius: 8px; max-width: 900px; box-shadow: 0 1px 4px rgba(0,0,0,0.12); }
pre { background: #111; color: #eee; padding: 15px; border-radius: 6px; white-space: pre-wrap; overflow:auto; }
button { margin-top: 15px; width: 220px; height: 50px; font-size: 16px; font-weight: bold; cursor: pointer; border: 0; border-radius: 6px; background: #007bff; color: white; }
.ok { color: green; font-weight: bold; }
.warn { color: #b26a00; font-weight: bold; }
.err { color: red; font-weight: bold; }
</style>
</head>
<body>
<div class="card">
<h2>ZeroTier Setup</h2>
<pre>
EOF
}

html_end() {
cat << EOF
</pre>
<br>
<button onclick="window.location='/admin/index.html'">Return to Admin</button>
<button onclick="window.location='/index.html'">Home</button>
</div>
</body>
</html>
EOF
}

fix_zerotier_permissions() {
    chmod 755 "$ZT_HOME" 2>/dev/null
    chmod 644 "$ZT_HOME/authtoken.secret" 2>/dev/null
    chmod 644 "$ZT_HOME/zerotier-one.port" 2>/dev/null
    chmod 644 "$ZT_HOME/identity.public" 2>/dev/null
    chmod 644 "$ZT_HOME/planet" 2>/dev/null
}

get_zt_dev() {
    ip -o link show 2>/dev/null | awk -F': ' '/zt/ {print $2}' | head -1
}

get_zt_ip() {
    ip -4 addr show 2>/dev/null | awk '/10\.74\./ {print $2}' | cut -d/ -f1 | head -1
}

create_network_config() {
    ZT_DEV="$1"

    uci set network.zerotier=interface
    uci set network.zerotier.proto='none'
    uci set network.zerotier.device="$ZT_DEV"
    uci commit network
    /etc/init.d/network reload >/dev/null 2>&1
}

create_firewall_config() {
    # Clean old named sections first
    uci delete firewall.zerotier 2>/dev/null
    uci delete firewall.allow_ping_zerotier 2>/dev/null
    uci delete firewall.allow_matrix_toolkit 2>/dev/null

    # ZeroTier zone
    uci set firewall.zerotier=zone
    uci set firewall.zerotier.name='zerotier'
    uci set firewall.zerotier.network='zerotier'
    uci set firewall.zerotier.input='ACCEPT'
    uci set firewall.zerotier.output='ACCEPT'
    uci set firewall.zerotier.forward='ACCEPT'

    # Allow ping from ZeroTier
    uci set firewall.allow_ping_zerotier=rule
    uci set firewall.allow_ping_zerotier.name='Allow-Ping-ZeroTier'
    uci set firewall.allow_ping_zerotier.src='zerotier'
    uci set firewall.allow_ping_zerotier.proto='icmp'
    uci set firewall.allow_ping_zerotier.icmp_type='echo-request'
    uci set firewall.allow_ping_zerotier.target='ACCEPT'

    # Allow Matrix Toolkit via ZeroTier
    uci set firewall.allow_matrix_toolkit=rule
    uci set firewall.allow_matrix_toolkit.name='Allow-Matrix-Toolkit-ZeroTier'
    uci set firewall.allow_matrix_toolkit.src='zerotier'
    uci set firewall.allow_matrix_toolkit.proto='tcp'
    uci set firewall.allow_matrix_toolkit.dest_port="$MATRIX_WEB_PORT"
    uci set firewall.allow_matrix_toolkit.target='ACCEPT'

    uci commit firewall
    /etc/init.d/firewall restart >/dev/null 2>&1
}

apply_direct_firewall_rule() {
    ZT_DEV="$1"

    [ -z "$ZT_DEV" ] && return

    iptables -D INPUT -i "$ZT_DEV" -j ACCEPT 2>/dev/null
    iptables -I INPUT 1 -i "$ZT_DEV" -j ACCEPT 2>/dev/null
}

create_autostart_service() {
cat > /etc/init.d/matrix_zerotier << EOF
#!/bin/sh /etc/rc.common

START=99
STOP=10

ZEROTIER_NETWORK_ID="$ZEROTIER_NETWORK_ID"
ZT_HOME="$ZT_HOME"
ZT_ONE="$ZT_ONE"
ZT_CLI="$ZT_CLI"
MATRIX_WEB_PORT="$MATRIX_WEB_PORT"

fix_zerotier_permissions() {
    chmod 755 "\$ZT_HOME" 2>/dev/null
    chmod 644 "\$ZT_HOME/authtoken.secret" 2>/dev/null
    chmod 644 "\$ZT_HOME/zerotier-one.port" 2>/dev/null
    chmod 644 "\$ZT_HOME/identity.public" 2>/dev/null
    chmod 644 "\$ZT_HOME/planet" 2>/dev/null
}

get_zt_dev() {
    ip -o link show 2>/dev/null | awk -F': ' '/zt/ {print \$2}' | head -1
}

start() {
    mkdir -p "\$ZT_HOME"

    killall zerotier-one 2>/dev/null
    "\$ZT_ONE" -d "\$ZT_HOME"

    sleep 25

    fix_zerotier_permissions

    "\$ZT_CLI" -D"\$ZT_HOME" join "\$ZEROTIER_NETWORK_ID" >/dev/null 2>&1

    sleep 10

    ZT_DEV=\$(get_zt_dev)

    if [ -n "\$ZT_DEV" ]; then
        uci set network.zerotier=interface
        uci set network.zerotier.proto='none'
        uci set network.zerotier.device="\$ZT_DEV"
        uci commit network
        /etc/init.d/network reload >/dev/null 2>&1
    fi

    uci delete firewall.zerotier 2>/dev/null
    uci delete firewall.allow_ping_zerotier 2>/dev/null
    uci delete firewall.allow_matrix_toolkit 2>/dev/null

    uci set firewall.zerotier=zone
    uci set firewall.zerotier.name='zerotier'
    uci set firewall.zerotier.network='zerotier'
    uci set firewall.zerotier.input='ACCEPT'
    uci set firewall.zerotier.output='ACCEPT'
    uci set firewall.zerotier.forward='ACCEPT'

    uci set firewall.allow_ping_zerotier=rule
    uci set firewall.allow_ping_zerotier.name='Allow-Ping-ZeroTier'
    uci set firewall.allow_ping_zerotier.src='zerotier'
    uci set firewall.allow_ping_zerotier.proto='icmp'
    uci set firewall.allow_ping_zerotier.icmp_type='echo-request'
    uci set firewall.allow_ping_zerotier.target='ACCEPT'

    uci set firewall.allow_matrix_toolkit=rule
    uci set firewall.allow_matrix_toolkit.name='Allow-Matrix-Toolkit-ZeroTier'
    uci set firewall.allow_matrix_toolkit.src='zerotier'
    uci set firewall.allow_matrix_toolkit.proto='tcp'
    uci set firewall.allow_matrix_toolkit.dest_port="\$MATRIX_WEB_PORT"
    uci set firewall.allow_matrix_toolkit.target='ACCEPT'

    uci commit firewall
    /etc/init.d/firewall restart >/dev/null 2>&1

    if [ -n "\$ZT_DEV" ]; then
        iptables -D INPUT -i "\$ZT_DEV" -j ACCEPT 2>/dev/null
        iptables -I INPUT 1 -i "\$ZT_DEV" -j ACCEPT 2>/dev/null
    fi
}

stop() {
    ZT_DEV=\$(get_zt_dev)

    if [ -n "\$ZT_DEV" ]; then
        iptables -D INPUT -i "\$ZT_DEV" -j ACCEPT 2>/dev/null
    fi

    killall zerotier-one 2>/dev/null
}
EOF

    chmod +x /etc/init.d/matrix_zerotier
    /etc/init.d/matrix_zerotier enable
}

html_start

echo "======================================="
echo " MATRIX TOOLKIT - ZEROTIER SETUP v2.0"
echo "======================================="
echo ""
echo "Network ID: $ZEROTIER_NETWORK_ID"
echo ""

echo "Checking internet..."
ping -c 2 1.1.1.1 >/dev/null 2>&1 || {
    echo "ERROR: No internet connection."
    html_end
    exit 1
}
echo "Internet OK."
echo ""

echo "Installing/checking ZeroTier..."
opkg update >> "$LOG" 2>&1
opkg install zerotier >> "$LOG" 2>&1

if [ ! -x "$ZT_ONE" ] || [ ! -x "$ZT_CLI" ]; then
    echo "ERROR: ZeroTier binaries not found."
    echo ""
    cat "$LOG"
    html_end
    exit 1
fi

echo "ZeroTier installed."
echo ""

echo "Starting ZeroTier..."
mkdir -p "$ZT_HOME"
killall zerotier-one 2>/dev/null
"$ZT_ONE" -d "$ZT_HOME"

sleep 25

fix_zerotier_permissions

echo "Joining ZeroTier network..."
"$ZT_CLI" -D"$ZT_HOME" join "$ZEROTIER_NETWORK_ID"

sleep 15

fix_zerotier_permissions

echo ""
echo "ZeroTier status:"
"$ZT_CLI" -D"$ZT_HOME" info 2>/dev/null
"$ZT_CLI" -D"$ZT_HOME" listnetworks 2>/dev/null

ZT_DEV="$(get_zt_dev)"
ZT_IP="$(get_zt_ip)"

echo ""
echo "Detected ZeroTier interface: ${ZT_DEV:-Not detected yet}"
echo "Detected ZeroTier IP: ${ZT_IP:-Not assigned yet}"
echo ""

if [ -n "$ZT_DEV" ]; then
    echo "Creating OpenWRT network interface..."
    create_network_config "$ZT_DEV"
else
    echo "WARNING: ZeroTier interface not detected yet."
    echo "This can be normal before the router is authorized in ZeroTier Central."
fi

echo ""
echo "Creating firewall zone and rules..."
create_firewall_config

echo ""
echo "Adding direct firewall accept rule..."
if [ -n "$ZT_DEV" ]; then
    apply_direct_firewall_rule "$ZT_DEV"
    echo "Direct firewall rule added for $ZT_DEV."
else
    echo "Skipped direct firewall rule because interface is not detected yet."
fi

echo ""
echo "Creating autostart service..."
create_autostart_service
echo "Autostart service created and enabled."

echo ""
echo "Final permissions check for About page..."
fix_zerotier_permissions
echo "ZeroTier permissions fixed."

echo ""
echo "======================================="
echo " SETUP COMPLETED"
echo "======================================="
echo ""

echo "If not authorized yet:"
echo "Open ZeroTier Central and Auth this router."
echo ""

ZT_IP="$(get_zt_ip)"

if [ -n "$ZT_IP" ]; then
    echo "Matrix Toolkit URL:"
    echo "http://$ZT_IP:$MATRIX_WEB_PORT"
    echo ""
    echo "Matrix Admin URL:"
    echo "http://$ZT_IP:$MATRIX_WEB_PORT/admin/index.html"
else
    echo "ZeroTier IP not assigned yet."
    echo "After authorization, check the About page or run:"
    echo "ip addr | grep 10.74"
fi

echo ""
echo "Current ZeroTier networks:"
"$ZT_CLI" -D"$ZT_HOME" listnetworks 2>/dev/null

html_end
