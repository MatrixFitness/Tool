#!/bin/sh

echo "Content-Type: text/html"
echo ""

ZEROTIER_NETWORK_ID="cf719fd5409699a2"
ZT_HOME="/etc/zerotier"
ZT_ONE="/usr/local/usr/bin/zerotier-one"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"
LOG="/tmp/zerotier_setup.log"

html_start() {
cat << EOF
<html>
<head>
<title>ZeroTier Setup</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; }
pre { background: #f5f5f5; padding: 15px; border-radius: 5px; }
button { width: 220px; height: 50px; font-size: 16px; font-weight: bold; cursor: pointer; }
</style>
</head>
<body>
<h2>ZeroTier Setup</h2>
<pre>
EOF
}

html_end() {
cat << EOF
</pre>
<br>
<button onclick="window.location='/admin/'">Return to Admin</button>
</body>
</html>
EOF
}

html_start

echo "======================================="
echo " MATRIX TOOLKIT - ZEROTIER SETUP"
echo "======================================="
echo ""
echo "Network ID: $ZEROTIER_NETWORK_ID"
echo "ZeroTier Home: $ZT_HOME"
echo ""

echo "Checking internet connection..."
ping -c 2 1.1.1.1 >/dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "ERROR: No internet connection detected."
    html_end
    exit 1
fi

echo "Internet connection OK."
echo ""

echo "Updating package list..."
opkg update >> "$LOG" 2>&1

echo "Checking ZeroTier installation..."

if [ ! -x "$ZT_ONE" ] || [ ! -x "$ZT_CLI" ]; then
    echo "ZeroTier not found. Installing..."
    opkg install zerotier >> "$LOG" 2>&1
else
    echo "ZeroTier already installed."
fi

if [ ! -x "$ZT_ONE" ] || [ ! -x "$ZT_CLI" ]; then
    echo "ERROR: ZeroTier installation failed or binaries not found."
    echo ""
    echo "Log:"
    cat "$LOG"
    html_end
    exit 1
fi

echo "ZeroTier binaries found."
echo ""

echo "Creating ZeroTier home folder..."
mkdir -p "$ZT_HOME"

echo "Stopping old ZeroTier process..."
killall zerotier-one 2>/dev/null
sleep 3

echo "Starting ZeroTier..."
"$ZT_ONE" -d "$ZT_HOME"

sleep 25

echo ""
echo "ZeroTier info:"
"$ZT_CLI" -D"$ZT_HOME" info

echo ""
echo "Joining network..."
"$ZT_CLI" -D"$ZT_HOME" join "$ZEROTIER_NETWORK_ID"

sleep 10

echo ""
echo "Network status:"
"$ZT_CLI" -D"$ZT_HOME" listnetworks

echo ""
echo "Creating Matrix ZeroTier autostart service..."

cat > /etc/init.d/matrix_zerotier << EOF
#!/bin/sh /etc/rc.common

START=99
STOP=10

start() {
    mkdir -p $ZT_HOME
    killall zerotier-one 2>/dev/null
    $ZT_ONE -d $ZT_HOME
    sleep 20
    $ZT_CLI -D$ZT_HOME join $ZEROTIER_NETWORK_ID >/dev/null 2>&1
}

stop() {
    killall zerotier-one 2>/dev/null
}
EOF

chmod +x /etc/init.d/matrix_zerotier
/etc/init.d/matrix_zerotier enable

echo ""
echo "Autostart service created:"
echo "/etc/init.d/matrix_zerotier"
echo ""

echo "======================================="
echo " SETUP COMPLETED"
echo "======================================="
echo ""

echo "Next step:"
echo "Open ZeroTier Central and authorize this router once."
echo ""
echo "Network:"
echo "$ZEROTIER_NETWORK_ID"
echo ""
echo "If status is ACCESS_DENIED:"
echo "Authorize the node in ZeroTier Central."
echo ""
echo "If status is OK:"
echo "Use the ZeroTier IP shown above to open the router."
echo ""
echo "Example:"
echo "http://10.x.x.x"
echo "https://10.x.x.x"

html_end