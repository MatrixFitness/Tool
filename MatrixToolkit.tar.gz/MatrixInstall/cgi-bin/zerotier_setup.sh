#!/bin/sh

echo "Content-Type: text/html"
echo ""

ZEROTIER_NETWORK_ID="cf719fd5409699a2"
ZT_HOME="/etc/zerotier"
ZT_ONE="/usr/local/usr/bin/zerotier-one"
ZT_CLI="/usr/local/usr/bin/zerotier-cli"
ZT_DEV="ztdiyqsthc"
LOG="/tmp/zerotier_setup.log"

html_start() {
cat << EOF
<html>
<head>
<title>ZeroTier Setup</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; }
pre { background: #f5f5f5; padding: 15px; border-radius: 5px; }
button { width: 220px; height: 50px; font-size: 16px; font-weight: bold; cursor: pointer; }
</style>
</head>
<body>
<h2>ZeroTier Setup</h2>
<pre>
EOF
}

html_end() {
cat << EOF
</pre>
<br>
<button onclick="window.location='/admin/'">Return to Admin</button>
</body>
</html>
EOF
}

html_start

echo "======================================="
echo " MATRIX TOOLKIT - ZEROTIER SETUP"
echo "======================================="
echo ""

echo "Network ID: $ZEROTIER_NETWORK_ID"
echo ""

echo "Checking internet..."
ping -c 2 1.1.1.1 >/dev/null 2>&1 || {
    echo "ERROR: No internet connection."
    html_end
    exit 1
}

echo "Internet OK."
echo ""

echo "Installing/checking ZeroTier..."
opkg update >> "$LOG" 2>&1
opkg install zerotier >> "$LOG" 2>&1

if [ ! -x "$ZT_ONE" ] || [ ! -x "$ZT_CLI" ]; then
    echo "ERROR: ZeroTier binaries not found."
    cat "$LOG"
    html_end
    exit 1
fi

echo "ZeroTier installed."
echo ""

echo "Starting ZeroTier..."
mkdir -p "$ZT_HOME"
killall zerotier-one 2>/dev/null
"$ZT_ONE" -d "$ZT_HOME"

sleep 25

echo ""
echo "Joining ZeroTier network..."
"$ZT_CLI" -D"$ZT_HOME" join "$ZEROTIER_NETWORK_ID"

sleep 15

echo ""
echo "ZeroTier status:"
"$ZT_CLI" -D"$ZT_HOME" info
"$ZT_CLI" -D"$ZT_HOME" listnetworks

echo ""
echo "Creating OpenWRT network interface..."
uci set network.zerotier=interface
uci set network.zerotier.proto='none'
uci set network.zerotier.device="$ZT_DEV"
uci commit network
/etc/init.d/network reload

sleep 5

echo ""
echo "Creating firewall zone..."

uci delete firewall.zerotier 2>/dev/null

uci set firewall.zerotier=zone
uci set firewall.zerotier.name='zerotier'
uci set firewall.zerotier.network='zerotier'
uci set firewall.zerotier.input='ACCEPT'
uci set firewall.zerotier.output='ACCEPT'
uci set firewall.zerotier.forward='ACCEPT'

uci delete firewall.allow_ping_zerotier 2>/dev/null

uci set firewall.allow_ping_zerotier=rule
uci set firewall.allow_ping_zerotier.name='Allow-Ping-ZeroTier'
uci set firewall.allow_ping_zerotier.src='zerotier'
uci set firewall.allow_ping_zerotier.proto='icmp'
uci set firewall.allow_ping_zerotier.icmp_type='echo-request'
uci set firewall.allow_ping_zerotier.target='ACCEPT'

uci commit firewall
/etc/init.d/firewall restart

echo ""
echo "Adding direct firewall accept rule..."
iptables -D INPUT -i "$ZT_DEV" -j ACCEPT 2>/dev/null
iptables -I INPUT 1 -i "$ZT_DEV" -j ACCEPT

echo ""
echo "Creating autostart service..."

cat > /etc/init.d/matrix_zerotier << EOF
#!/bin/sh /etc/rc.common

START=99
STOP=10

start() {
    mkdir -p $ZT_HOME
    killall zerotier-one 2>/dev/null
    $ZT_ONE -d $ZT_HOME
    sleep 25
    $ZT_CLI -D$ZT_HOME join $ZEROTIER_NETWORK_ID >/dev/null 2>&1

    uci set network.zerotier=interface
    uci set network.zerotier.proto='none'
    uci set network.zerotier.device='$ZT_DEV'
    uci commit network
    /etc/init.d/network reload >/dev/null 2>&1

    uci set firewall.zerotier=zone
    uci set firewall.zerotier.name='zerotier'
    uci set firewall.zerotier.network='zerotier'
    uci set firewall.zerotier.input='ACCEPT'
    uci set firewall.zerotier.output='ACCEPT'
    uci set firewall.zerotier.forward='ACCEPT'

    uci set firewall.allow_ping_zerotier=rule
    uci set firewall.allow_ping_zerotier.name='Allow-Ping-ZeroTier'
    uci set firewall.allow_ping_zerotier.src='zerotier'
    uci set firewall.allow_ping_zerotier.proto='icmp'
    uci set firewall.allow_ping_zerotier.icmp_type='echo-request'
    uci set firewall.allow_ping_zerotier.target='ACCEPT'

    uci commit firewall
    /etc/init.d/firewall restart >/dev/null 2>&1

    iptables -D INPUT -i $ZT_DEV -j ACCEPT 2>/dev/null
    iptables -I INPUT 1 -i $ZT_DEV -j ACCEPT
}

stop() {
    killall zerotier-one 2>/dev/null
    iptables -D INPUT -i $ZT_DEV -j ACCEPT 2>/dev/null
}
EOF

chmod +x /etc/init.d/matrix_zerotier
/etc/init.d/matrix_zerotier enable

echo ""
echo "======================================="
echo " SETUP COMPLETED"
echo "======================================="
echo ""

echo "If not authorized yet:"
echo "Open ZeroTier Central and Auth this router."
echo ""

echo "After Auth, use:"
echo "http://10.x.x.x:8080    Matrix Toolkit"
echo "http://10.x.x.x:8081    Matrix Admin"
echo ""

echo "Current ZeroTier networks:"
"$ZT_CLI" -D"$ZT_HOME" listnetworks

html_end