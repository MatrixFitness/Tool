#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

echo "Content-Type: text/html; charset=UTF-8"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""

LOG="/tmp/matrix_update_github.log"
REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
PREV="/tmp/matrix_update_github.previous.log"

create_request() {
    [ -f "$LOG" ] && cp -f "$LOG" "$PREV" 2>/dev/null
    echo "GitHub update requested at: $(date)" > "$LOG"
    echo "Waiting for root update worker..." >> "$LOG"
    echo "" >> "$LOG"
    touch "$REQ"
}

if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        STATUS="Update already running"
        BADGE="RUNNING"
        BADGE_CLASS="ok"
        MESSAGE="The root update worker is already running. This page will open the live update log automatically."
    else
        rm -f "$LOCK"
        STATUS="GitHub Update Requested"
        BADGE="QUEUED"
        BADGE_CLASS="ok"
        MESSAGE="The Matrix Toolkit update has been queued successfully."
        create_request
    fi
elif [ -f "$REQ" ]; then
    STATUS="Update Already Requested"
    BADGE="WAITING"
    BADGE_CLASS="warn"
    MESSAGE="An update request is already waiting for the root update worker."
else
    STATUS="GitHub Update Requested"
    BADGE="QUEUED"
    BADGE_CLASS="ok"
    MESSAGE="The Matrix Toolkit update has been queued successfully."
    create_request
fi

HOST_ONLY="$(printf '%s' "${HTTP_HOST:-}" | cut -d: -f1)"
[ -z "$HOST_ONLY" ] && HOST_ONLY="$(uci get system.@system[0].hostname 2>/dev/null)"
[ -z "$HOST_ONLY" ] && HOST_ONLY="$(hostname 2>/dev/null)"
TOOLKIT_BACK_URL="http://$HOST_ONLY:8080/"

cat <<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Matrix Update Center</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5;url=/cgi-bin/update_github_log.sh?ts=$(date +%s)">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
:root{--bg:#eef2f6;--panel:#fff;--text:#1f2933;--muted:#667085;--border:#d9e2ec;--shadow:0 8px 22px rgba(15,23,42,.08);--ok:#1f8a3b;--warn:#b35b00;--blue:#005a9c}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.page{max-width:1100px;margin:0 auto;padding:18px}
.hero{background:linear-gradient(135deg,#0d3b66,#005a9c);color:#fff;border-radius:18px;padding:22px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}
.hero h1{margin:0;font-size:28px}.sub{opacity:.92;margin-top:7px;font-size:14px;line-height:1.45}.contact{margin-top:7px;font-size:13px;opacity:.95}
.top-actions,.actions{display:flex;gap:10px;flex-wrap:wrap}
.btn{display:inline-block;background:#005a9c;color:#fff!important;text-decoration:none!important;border:0;border-radius:12px;padding:12px 15px;font-weight:800;font-size:15px;cursor:pointer}
.btn.light{background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35)}.btn.green{background:var(--ok)}.btn.grey{background:#667085}
.card{background:#fff;border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow);padding:18px;margin-top:18px}
.badge{display:inline-block;border-radius:999px;padding:7px 12px;font-weight:900;font-size:13px;color:#fff}.badge.ok{background:var(--ok)}.badge.warn{background:var(--warn)}
.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:16px}
.step{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:13px}.step b{color:#0d3b66}.step div{font-size:13px;color:var(--muted);margin-top:5px;line-height:1.35}
.note{background:#f8fafc;border:1px solid var(--border);border-radius:13px;padding:13px;color:var(--muted);line-height:1.45}
@media(max-width:700px){.page{padding:10px}.hero{border-radius:14px;padding:16px}.hero h1{font-size:23px}.top-actions,.actions{display:block}.btn{width:100%;text-align:center;margin:6px 0}.steps{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="page">
  <section class="hero">
    <div>
      <h1>Matrix Update Center</h1>
      <div class="sub">$STATUS &middot; The update will be executed by the root update worker.</div>
      <div class="contact">Matrix Fitness &middot; Created by Rob Bosman &middot; rob.bosman@matrixfitness.nl</div>
    </div>
    <div class="top-actions">
      <a class="btn light" href="/cgi-bin/update_github_log.sh?ts=$(date +%s)">View Update Log</a>
      <a class="btn light" href="/cgi-bin/admin_home.sh">Return to Admin</a>
    </div>
  </section>

  <section class="card">
    <p><span class="badge $BADGE_CLASS">$BADGE</span></p>
    <h2>$MESSAGE</h2>
    <p class="note">This page will automatically refresh to the live update log in <b>5 seconds</b>. The root worker normally starts within one minute.</p>

    <div class="steps">
      <div class="step"><b>1. Request queued</b><div>The Admin page created the update request.</div></div>
      <div class="step"><b>2. Root worker starts</b><div>The background worker performs the real update.</div></div>
      <div class="step"><b>3. Log opens</b><div>The update log shows progress and final result.</div></div>
    </div>

    <div class="actions" style="margin-top:18px">
      <a class="btn green" href="/cgi-bin/update_github_log.sh?ts=$(date +%s)">View Update Log</a>
      <a class="btn grey" href="/cgi-bin/admin_home.sh">Return to Admin</a>
    </div>
  </section>
</div>
</body>
</html>
HTML
exit 0
