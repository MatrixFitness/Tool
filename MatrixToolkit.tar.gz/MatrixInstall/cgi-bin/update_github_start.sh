cat > /usr/local/matrix/web/cgi-bin/update_github_start.sh <<'EOF'
#!/bin/sh
echo "Content-Type: text/html"
echo ""

LOG="/tmp/matrix_update_github.log"

echo "Starting GitHub update in background..." > "$LOG"
echo "Started at: $(date)" >> "$LOG"
echo "" >> "$LOG"

nohup sh -c 'MATRIX_UPDATE_BACKGROUND=1 /usr/local/matrix/web/cgi-bin/update_github.sh >> /tmp/matrix_update_github.log 2>&1; echo ""; echo "Finished at: $(date)" >> /tmp/matrix_update_github.log' >/dev/null 2>&1 &

cat << HTML
<html>
<head>
<title>GitHub Update Started</title>
<meta http-equiv="refresh" content="3;url=/cgi-bin/update_github_log.sh">
</head>
<body style="font-family:Arial;margin:20px;">
<h2>GitHub Update Started</h2>
<p>The update is running in the background.</p>
<p><a href="/cgi-bin/update_github_log.sh">View update log</a></p>
</body>
</html>
HTML
EOF

chmod +x /usr/local/matrix/web/cgi-bin/update_github_start.sh