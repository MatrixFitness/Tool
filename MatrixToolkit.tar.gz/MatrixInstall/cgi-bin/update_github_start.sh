cat > /usr/local/matrix/web/cgi-bin/update_github_start.sh <<'EOF'
#!/bin/sh
echo "Content-Type: text/html"
echo ""

LOG="/tmp/matrix_update_github.log"

echo "Starting GitHub update..." > "$LOG"

/usr/local/matrix/web/cgi-bin/update_github.sh > "$LOG" 2>&1 &

cat << HTML
<html>
<head>
<title>GitHub Update Started</title>
<meta http-equiv="refresh" content="3;url=/cgi-bin/update_github_log.sh">
</head>
<body style="font-family:Arial;margin:20px;">
<h2>GitHub Update Started</h2>
<p>The update is running in the background.</p>
<p>This page will refresh to the log in 3 seconds.</p>
<a href="/cgi-bin/update_github_log.sh">View update log</a>
</body>
</html>
HTML
EOF

chmod +x /usr/local/matrix/web/cgi-bin/update_github_start.sh