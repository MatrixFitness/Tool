#!/bin/sh
echo "Content-Type: text/html"
echo ""

LOG="/tmp/matrix_update_github.log"

echo "Starting GitHub update in background..." > "$LOG"
echo "Started at: $(date)" >> "$LOG"
echo "" >> "$LOG"

nohup sh -c '
MATRIX_UPDATE_BACKGROUND=1 \
/usr/local/matrix/web/cgi-bin/update_github.sh \
>> /tmp/matrix_update_github.log 2>&1

echo ""
echo "Finished at: $(date)"
' >> /tmp/matrix_update_github.log 2>&1 &

cat << HTML
<html>
<head>
<title>GitHub Update Started</title>
<meta http-equiv="refresh" content="3;url=/cgi-bin/update_github_log.sh">
<style>
body { font-family: Arial, sans-serif; margin: 20px; }
button { width: 220px; height: 50px; font-size: 16px; }
</style>
</head>
<body>
<h2>GitHub Update Started</h2>
<p>The update is running in the background.</p>
<p>You will be redirected to the log page.</p>

<button onclick="window.location='/cgi-bin/update_github_log.sh'">
View Update Log
</button>
</body>
</html>
HTML