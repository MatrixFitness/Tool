#!/bin/sh
. /usr/local/matrix/adminweb/cgi-bin/admin_session_check.sh || exit 0

echo "Content-Type: text/html"
echo "Cache-Control: no-cache, no-store, must-revalidate"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""

LOG="/tmp/matrix_update_github.log"
REQ="/tmp/matrix_update_request"
LOCK="/tmp/matrix_update_worker.lock"
PREV="/tmp/matrix_update_github.previous.log"

create_request() {
    [ -f "$LOG" ] && cp -f "$LOG" "$PREV" 2>/dev/null
    echo "GitHub update requested at: $(date)" > "$LOG"
    echo "Waiting for root update worker..." >> "$LOG"
    echo "" >> "$LOG"
    touch "$REQ"
}

if [ -f "$LOCK" ]; then
    OLD_PID="$(cat "$LOCK" 2>/dev/null)"
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        STATUS="Update already running"
    else
        rm -f "$LOCK"
        STATUS="GitHub update requested"
        create_request
    fi
elif [ -f "$REQ" ]; then
    STATUS="Update already requested"
else
    STATUS="GitHub update requested"
    create_request
fi

cat <<HTML
<html>
<head>
<title>GitHub Update Requested</title>
<meta http-equiv="refresh" content="5;url=/cgi-bin/update_github_log.sh?ts=$(date +%s)">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background:#f5f5f5; }
.card { background:white; padding:20px; border-radius:8px; max-width:850px; box-shadow:0 1px 4px rgba(0,0,0,0.12); }
button { margin-top:20px; width:220px; height:50px; font-size:16px; font-weight:bold; cursor:pointer; border:0; border-radius:6px; background:#007bff; color:white; margin-right:10px; }
</style>
</head>
<body>
<div class="card">
<h2>$STATUS</h2>
<p>The update will be executed by the root update worker.</p>
<p>This page will refresh to the log in 5 seconds.</p>
<button onclick="window.location='/cgi-bin/update_github_log.sh?ts=' + Date.now()">View Update Log</button>
<button onclick="window.location='/cgi-bin/admin_home.sh'">Return to Admin</button>
</div>
</body>
</html>
HTML
exit 0
